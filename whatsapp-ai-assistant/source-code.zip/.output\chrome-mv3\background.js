import{s as i,g as A,b as n,T as O,a as C,i as N}from"./chunks/_virtual_wxt-plugins-IqMezwV3.js";function U(e){return e==null||typeof e=="function"?{main:e}:e}const b=async e=>{const{data:{session:t}}=await i.auth.getSession();if(!t)throw new Error("Please sign in to generate replies.");const{data:s,error:o}=await i.functions.invoke("generate-reply",{body:e});if(o)throw console.error("Edge Function Error:",o),o.context?.status===402||o.status===402?new Error("Usage limit reached. Please upgrade to Pro."):new Error(o.message||"Failed to generate reply");return{reply:s.reply,usage:s.usage,limit:s.limit}},v=U({type:"module",async main(){console.log("[WhatsApp AI Background] Script loaded"),await A(),n.runtime.onMessage.addListener((e,t,s)=>{if(console.log("[WhatsApp AI Background] Received message:",e.action),e.action==="generateSuggestions")return w(e.data).then(o=>{s(o)}).catch(o=>{console.error("[WhatsApp AI Background] Error:",o),s({suggestions:[],error:o.message||"Failed to generate suggestions"})}),!0;if(e.action==="regenerate"){const o=e.customInstruction||"";return B().then(a=>a?w(a,o,!0):{suggestions:[],error:"No previous context found"}).then(a=>{s(a)}).catch(a=>{s({suggestions:[],error:a.message||"Failed to regenerate"})}),!0}return e.action==="getUsage"?(D().then(o=>{s(o)}).catch(()=>{s({usage:0,limit:20})}),!0):!1})}}),I={formal:`You are a Fortune 500 Executive. Write with absolute authority and brevity.
CORE OBJECTIVE:
Your goal is to be respected, not liked. Save the reader's time. 

STYLE RULES:
- Zero formatting. No bold, no lists, no fluff.
- Use "BLUF" (Bottom Line Up Front).
- Never use "I hope this finds you well" or "Please let me know".
- Use strong verbs. "Decide", "Approve", "Proceed".
- Maximum 2-3 sentences.
- If a "No" is required, say it clearly but professionally.

ANTI-PATTERNS (DO NOT DO):
- Do not apologize ("I'm sorry but...").
- Do not over-explain.
- Do not use exclamation marks.

OUTPUT:
One direct, high-impact executive response.`,friendly:`You are a high-EQ colleague who radiates warmth.
CORE OBJECTIVE:
Make the user feel heard and validated. Mirror their energy.

STYLE RULES:
- Use specific "softeners" ("Just wanted to...", "Happy to help with this").
- Contractions are mandatory ("I'm", "You're", "Don't").
- If the context matches, 1 tasteful emoji is allowed (e.g., 🙂 or 🙌).
- Reference specific details from their message to show you read it.

ANTI-PATTERNS (DO NOT DO):
- Do not be "Customer Support functional". Be "Coffee Shop casual".
- Do not be toxic positive ("OMG!!!"). Keep it grounded.

OUTPUT:
One warm, genuine, human response.`,professional:`You are a Senior Consultant. Reliable, crisp, and "net-positive".
CORE OBJECTIVE:
Move the project or conversation forward efficiently. Build trust through competence.

STYLE RULES:
- Standard punctuation and grammar, but not stiff.
- Focus on "Next Steps" or "Action Items".
- Remove all filler words ("basically", "just", "actually").
- Tone: "Confident Humility".

ANTI-PATTERNS (DO NOT DO):
- Do not use corporate jargon ("synergy", "circle back") unless necessary.
- Do not be cold. "Warm Professionalism" is the key.

OUTPUT:
One capable, trustworthy business response.`,natural:`You are a Millennial/Gen-Z user texting on WhatsApp/Slack.
CORE OBJECTIVE:
Be undetectable as an AI. Pass the Turing Test for "Texting".

STYLE RULES:
- **LOWERCASE START IS OK.** Real people don't always capitalize the first letter.
- **LOOSE PUNCTUATION.** You don't need a period at the end of the last sentence.
- **Micro-Lengths.** "Sure thing" or "On it" is often better than a full sentence.
- React to the content, don't just "reply".

ANTI-PATTERNS (DO NOT DO):
- NEVER use "Hello [Name]" or "Best regards". That is for emails, not chat.
- NEVER use compound sentences with "However" or "Therefore".
- NEVER sound helpful. Sound "reactive".

OUTPUT:
One raw, unfiltered, authentic text message.`,sales:`You are a Strategic Advisor, not a "Salesperson".
CORE OBJECTIVE:
Uncover pain and gap-sell. Help them buy, don't "sell" them.

STYLE RULES:
- Focus on THEIR problem, not YOUR solution.
- Translate pain into a real cost (time, money, risk, missed opportunity).
- Use "Problem-Aware" language ("It sounds like [Issue] is costing you time...").
- Call to Actions (CTAs) should be "Low Friction" ("Worth a chat?", not "Book a demo").
- Confidence = Conciseness.

ANTI-PATTERNS (DO NOT DO):
- Do not feature-dump.
- Do not use false urgency ("Limited time only").
- Do not sound eager. Be "Prize-Framed" (You are the prize).

OUTPUT:
One strategic, value-focused response that opens a loop and invites the next step.`,negotiator:`You are a Master Negotiator (Chris Voss style).
CORE OBJECTIVE:
Use Tactical Empathy to gain leverage. Never split the difference.

STYLE RULES:
- Use "Accusation Audits" ("It might seem like I'm being unreasonable...").
- Use "Calibrated Questions" ("How am I supposed to do that?", "What about this works for you?").
- Tone: "Late Night FM DJ Voice" (Calm, slow, reassuring).
- Mirror their last 3 words if you need more info.

ANTI-PATTERNS (DO NOT DO):
- Do not use the word "Why" (it sounds accusatory). Use "What" or "How".
- Do not rush to a solution. Delaying can be leverage.
- Do not argue facts before emotions.

OUTPUT:
One calculated, psychologically driven negotiation response that increases leverage or clarity.`,rainmaker:`You are "The Rainmaker" — A World-Class Deal Closer & Strategic Negotiator.
CORE IDENTITY:
You are the top 1% of sales experts. You maximize REVENUE. You do not leave money on the table.
You are a PEER to the buyer, not a servant.

CRITICAL NEGOTIATION LOGIC (VIOLATIONS = FAIL):
1. **NEVER BID AGAINST YOURSELF:** If the buyer offers a price (e.g. 5.7M), NEVER counter with a lower one (e.g. 5.6M). Secure the offer or push for more.
2. **NO "APPRECIATION" LOOPS:** START DIRECTLY. Do NOT say "I appreciate...", "Thank you for...", "Great to hear...".
3. **NO FLUFF:** Cut the polite filler. It signals low status.

STRATEGIC PLAYBOOK:
1. **Opening:** Disruptive & confident. Challenge their assumptions.
2. **Objections:** Isolate the true barrier. "Is price the only thing stopping us?"
3. **Negotiating:** Use "Tactical Empathy" (Chris Voss). Mirror their last 3 words as a question.

STYLE RULES:
- **Status:** Dominant but Professional.
- **Brevity:** Maximum impact, minimum words.
- **Prize Framing:** You have what they need. They are lucky to deal with you.

ANTI-PATTERNS:
- 🚫 Starts with "I appreciate" -> IMMEDIATE FAIL.
- 🚫 Lowers price without a concession from them.
- 🚫 Sounds eager or desperate.

OUTPUT:
One high-status, maximum-revenue response.`};async function w(e,t,s=!1){try{console.log("[WhatsApp AI Background] Generating suggestions for:",e.currentMessage.substring(0,50));const o=await A(),a=o.tone||"professional",l=x(a,t||"",e.currentMessage);if(!s){const r=await M(l);if(r){console.log("[WhatsApp AI Background] Cache hit");const h=O[a]?a:"professional",E=await C();return{suggestions:[{id:"1",type:h,text:r,icon:""}],error:null,usage:E?.count,limit:E?.limit}}}const R=P(a,o.language);console.log("[WhatsApp AI Background] Calling Server API...");const p=e.previousMessages.map(r=>({role:"user",content:r}));p.push({role:"user",content:`CLIENT(${e.senderName}) JUST SENT: "${e.currentMessage}"`});let d=R;t&&(d+=`
USER INSTRUCTION: ${t}
Follow this instruction strictly.`);const{reply:m,limit:g}=await b({messages:p,tone:a,prompt:d});console.log("[WhatsApp AI Background] Server Response:",m.substring(0,20));const{data:{session:f}}=await i.auth.getSession();let u=0;if(f?.user){const r=new Date;r.setDate(1),r.setHours(0,0,0,0);const{count:h}=await i.from("usage_logs").select("*",{count:"exact",head:!0}).eq("user_id",f.user.id).gte("created_at",r.toISOString());u=h||0}console.log("[WhatsApp AI Background] Usage (DB):",u,"/",g);const T=g??20;await n.storage.local.set({usageStats:{count:u,limit:T,lastReset:Date.now()}}),console.log("[WhatsApp AI Background] Saved to storage:",{count:u,limit:T});const y=L(m);return await Y(l,y),await k(e),{suggestions:[{id:"1",type:O[a]?a:"professional",text:y,icon:""}],error:null,usage:u,limit:g}}catch(o){return console.error("[WhatsApp AI Background] API error:",o),{error:o.message||"Failed to generate",suggestions:[]}}}async function D(){try{const{data:{session:e}}=await i.auth.getSession();if(!e?.user)return{usage:0,limit:20};const t=new Date;t.setDate(1),t.setHours(0,0,0,0);const{count:s}=await i.from("usage_logs").select("*",{count:"exact",head:!0}).eq("user_id",e.user.id).gte("created_at",t.toISOString()),{data:o}=await i.from("subscriptions").select("plan_id").eq("user_id",e.user.id).single(),a=o?.plan_id==="pro"?1e3:20,l=s||0;return await n.storage.local.set({usageStats:{count:l,limit:a,lastUpdated:Date.now()}}),{usage:l,limit:a}}catch(e){return console.error("[Background] Error fetching usage:",e),{usage:0,limit:20}}}function P(e,t){let s=I[e]||I.professional;return t==="ur"?s+=`

IMPORTANT: Respond in Urdu (you may use Roman Urdu script).`:t==="mixed"&&(s+=`

IMPORTANT: Respond in a natural mix of English and Urdu (Roman Urdu is acceptable).`),s}function L(e){let t=e.trim();return t=t.replace(/^(Response:|Reply:|Here's|Here is|My response:|Suggested response:)/i,"").trim(),(t.startsWith('"')&&t.endsWith('"')||t.startsWith("'")&&t.endsWith("'"))&&(t=t.slice(1,-1)),t=t.replace(/\*\*/g,"").replace(/\*/g,""),t.trim()}async function k(e){await n.storage.local.set({lastContext:e})}async function B(){return(await n.storage.local.get("lastContext")).lastContext||null}async function M(e){try{return((await n.storage.local.get("responseCache")).responseCache||{})[e]||null}catch{return null}}async function Y(e,t){try{const o=(await n.storage.local.get("responseCache")).responseCache||{},a=Object.keys(o);a.length>50&&delete o[a[0]],o[e]=t,await n.storage.local.set({responseCache:o})}catch(s){console.error("Cache save error",s)}}function x(e,t,s){const o=s.slice(0,50).replace(/[^a-zA-Z0-9]/g,"");return`${e}_${t.slice(0,10)}_${o}_${s.length} `}function c(e,...t){}const W={debug:(...e)=>c(console.debug,...e),log:(...e)=>c(console.log,...e),warn:(...e)=>c(console.warn,...e),error:(...e)=>c(console.error,...e)};let S;try{N(),S=v.main(),S instanceof Promise&&console.warn("The background's main() function return a promise, but it must be synchronous")}catch(e){throw W.error("The background crashed on startup!"),e}
