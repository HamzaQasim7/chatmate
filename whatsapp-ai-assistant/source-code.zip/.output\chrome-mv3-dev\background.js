const browser$1 = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
const browser = browser$1;
function defineBackground(arg) {
  if (arg == null || typeof arg === "function") return { main: arg };
  return arg;
}
const default_format = "RFC3986";
const formatters = {
  RFC1738: (v) => String(v).replace(/%20/g, "+"),
  RFC3986: (v) => String(v)
};
const RFC1738 = "RFC1738";
const is_array$1 = Array.isArray;
const hex_table = (() => {
  const array = [];
  for (let i = 0; i < 256; ++i) {
    array.push("%" + ((i < 16 ? "0" : "") + i.toString(16)).toUpperCase());
  }
  return array;
})();
const limit = 1024;
const encode = (str2, _defaultEncoder, charset, _kind, format) => {
  if (str2.length === 0) {
    return str2;
  }
  let string = str2;
  if (typeof str2 === "symbol") {
    string = Symbol.prototype.toString.call(str2);
  } else if (typeof str2 !== "string") {
    string = String(str2);
  }
  if (charset === "iso-8859-1") {
    return escape(string).replace(/%u[0-9a-f]{4}/gi, function($0) {
      return "%26%23" + parseInt($0.slice(2), 16) + "%3B";
    });
  }
  let out = "";
  for (let j = 0; j < string.length; j += limit) {
    const segment = string.length >= limit ? string.slice(j, j + limit) : string;
    const arr = [];
    for (let i = 0; i < segment.length; ++i) {
      let c = segment.charCodeAt(i);
      if (c === 45 || // -
      c === 46 || // .
      c === 95 || // _
      c === 126 || // ~
      c >= 48 && c <= 57 || // 0-9
      c >= 65 && c <= 90 || // a-z
      c >= 97 && c <= 122 || // A-Z
      format === RFC1738 && (c === 40 || c === 41)) {
        arr[arr.length] = segment.charAt(i);
        continue;
      }
      if (c < 128) {
        arr[arr.length] = hex_table[c];
        continue;
      }
      if (c < 2048) {
        arr[arr.length] = hex_table[192 | c >> 6] + hex_table[128 | c & 63];
        continue;
      }
      if (c < 55296 || c >= 57344) {
        arr[arr.length] = hex_table[224 | c >> 12] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
        continue;
      }
      i += 1;
      c = 65536 + ((c & 1023) << 10 | segment.charCodeAt(i) & 1023);
      arr[arr.length] = hex_table[240 | c >> 18] + hex_table[128 | c >> 12 & 63] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
    }
    out += arr.join("");
  }
  return out;
};
function is_buffer(obj) {
  if (!obj || typeof obj !== "object") {
    return false;
  }
  return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
}
function maybe_map(val, fn) {
  if (is_array$1(val)) {
    const mapped = [];
    for (let i = 0; i < val.length; i += 1) {
      mapped.push(fn(val[i]));
    }
    return mapped;
  }
  return fn(val);
}
const has = Object.prototype.hasOwnProperty;
const array_prefix_generators = {
  brackets(prefix) {
    return String(prefix) + "[]";
  },
  comma: "comma",
  indices(prefix, key) {
    return String(prefix) + "[" + key + "]";
  },
  repeat(prefix) {
    return String(prefix);
  }
};
const is_array = Array.isArray;
const push = Array.prototype.push;
const push_to_array = function(arr, value_or_array) {
  push.apply(arr, is_array(value_or_array) ? value_or_array : [value_or_array]);
};
const to_ISO = Date.prototype.toISOString;
const defaults = {
  addQueryPrefix: false,
  allowDots: false,
  allowEmptyArrays: false,
  arrayFormat: "indices",
  charset: "utf-8",
  charsetSentinel: false,
  delimiter: "&",
  encode: true,
  encodeDotInKeys: false,
  encoder: encode,
  encodeValuesOnly: false,
  format: default_format,
  formatter: formatters[default_format],
  /** @deprecated */
  indices: false,
  serializeDate(date) {
    return to_ISO.call(date);
  },
  skipNulls: false,
  strictNullHandling: false
};
function is_non_nullish_primitive(v) {
  return typeof v === "string" || typeof v === "number" || typeof v === "boolean" || typeof v === "symbol" || typeof v === "bigint";
}
const sentinel = {};
function inner_stringify(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
  let obj = object;
  let tmp_sc = sideChannel;
  let step = 0;
  let find_flag = false;
  while ((tmp_sc = tmp_sc.get(sentinel)) !== void 0 && !find_flag) {
    const pos = tmp_sc.get(object);
    step += 1;
    if (typeof pos !== "undefined") {
      if (pos === step) {
        throw new RangeError("Cyclic object value");
      } else {
        find_flag = true;
      }
    }
    if (typeof tmp_sc.get(sentinel) === "undefined") {
      step = 0;
    }
  }
  if (typeof filter === "function") {
    obj = filter(prefix, obj);
  } else if (obj instanceof Date) {
    obj = serializeDate?.(obj);
  } else if (generateArrayPrefix === "comma" && is_array(obj)) {
    obj = maybe_map(obj, function(value) {
      if (value instanceof Date) {
        return serializeDate?.(value);
      }
      return value;
    });
  }
  if (obj === null) {
    if (strictNullHandling) {
      return encoder && !encodeValuesOnly ? (
        // @ts-expect-error
        encoder(prefix, defaults.encoder, charset, "key", format)
      ) : prefix;
    }
    obj = "";
  }
  if (is_non_nullish_primitive(obj) || is_buffer(obj)) {
    if (encoder) {
      const key_value = encodeValuesOnly ? prefix : encoder(prefix, defaults.encoder, charset, "key", format);
      return [
        formatter?.(key_value) + "=" + // @ts-expect-error
        formatter?.(encoder(obj, defaults.encoder, charset, "value", format))
      ];
    }
    return [formatter?.(prefix) + "=" + formatter?.(String(obj))];
  }
  const values = [];
  if (typeof obj === "undefined") {
    return values;
  }
  let obj_keys;
  if (generateArrayPrefix === "comma" && is_array(obj)) {
    if (encodeValuesOnly && encoder) {
      obj = maybe_map(obj, encoder);
    }
    obj_keys = [{ value: obj.length > 0 ? obj.join(",") || null : void 0 }];
  } else if (is_array(filter)) {
    obj_keys = filter;
  } else {
    const keys = Object.keys(obj);
    obj_keys = sort ? keys.sort(sort) : keys;
  }
  const encoded_prefix = encodeDotInKeys ? String(prefix).replace(/\./g, "%2E") : String(prefix);
  const adjusted_prefix = commaRoundTrip && is_array(obj) && obj.length === 1 ? encoded_prefix + "[]" : encoded_prefix;
  if (allowEmptyArrays && is_array(obj) && obj.length === 0) {
    return adjusted_prefix + "[]";
  }
  for (let j = 0; j < obj_keys.length; ++j) {
    const key = obj_keys[j];
    const value = (
      // @ts-ignore
      typeof key === "object" && typeof key.value !== "undefined" ? key.value : obj[key]
    );
    if (skipNulls && value === null) {
      continue;
    }
    const encoded_key = allowDots && encodeDotInKeys ? key.replace(/\./g, "%2E") : key;
    const key_prefix = is_array(obj) ? typeof generateArrayPrefix === "function" ? generateArrayPrefix(adjusted_prefix, encoded_key) : adjusted_prefix : adjusted_prefix + (allowDots ? "." + encoded_key : "[" + encoded_key + "]");
    sideChannel.set(object, step);
    const valueSideChannel = /* @__PURE__ */ new WeakMap();
    valueSideChannel.set(sentinel, sideChannel);
    push_to_array(values, inner_stringify(
      value,
      key_prefix,
      generateArrayPrefix,
      commaRoundTrip,
      allowEmptyArrays,
      strictNullHandling,
      skipNulls,
      encodeDotInKeys,
      // @ts-ignore
      generateArrayPrefix === "comma" && encodeValuesOnly && is_array(obj) ? null : encoder,
      filter,
      sort,
      allowDots,
      serializeDate,
      format,
      formatter,
      encodeValuesOnly,
      charset,
      valueSideChannel
    ));
  }
  return values;
}
function normalize_stringify_options(opts = defaults) {
  if (typeof opts.allowEmptyArrays !== "undefined" && typeof opts.allowEmptyArrays !== "boolean") {
    throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
  }
  if (typeof opts.encodeDotInKeys !== "undefined" && typeof opts.encodeDotInKeys !== "boolean") {
    throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
  }
  if (opts.encoder !== null && typeof opts.encoder !== "undefined" && typeof opts.encoder !== "function") {
    throw new TypeError("Encoder has to be a function.");
  }
  const charset = opts.charset || defaults.charset;
  if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
    throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
  }
  let format = default_format;
  if (typeof opts.format !== "undefined") {
    if (!has.call(formatters, opts.format)) {
      throw new TypeError("Unknown format option provided.");
    }
    format = opts.format;
  }
  const formatter = formatters[format];
  let filter = defaults.filter;
  if (typeof opts.filter === "function" || is_array(opts.filter)) {
    filter = opts.filter;
  }
  let arrayFormat;
  if (opts.arrayFormat && opts.arrayFormat in array_prefix_generators) {
    arrayFormat = opts.arrayFormat;
  } else if ("indices" in opts) {
    arrayFormat = opts.indices ? "indices" : "repeat";
  } else {
    arrayFormat = defaults.arrayFormat;
  }
  if ("commaRoundTrip" in opts && typeof opts.commaRoundTrip !== "boolean") {
    throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
  }
  const allowDots = typeof opts.allowDots === "undefined" ? !!opts.encodeDotInKeys === true ? true : defaults.allowDots : !!opts.allowDots;
  return {
    addQueryPrefix: typeof opts.addQueryPrefix === "boolean" ? opts.addQueryPrefix : defaults.addQueryPrefix,
    // @ts-ignore
    allowDots,
    allowEmptyArrays: typeof opts.allowEmptyArrays === "boolean" ? !!opts.allowEmptyArrays : defaults.allowEmptyArrays,
    arrayFormat,
    charset,
    charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults.charsetSentinel,
    commaRoundTrip: !!opts.commaRoundTrip,
    delimiter: typeof opts.delimiter === "undefined" ? defaults.delimiter : opts.delimiter,
    encode: typeof opts.encode === "boolean" ? opts.encode : defaults.encode,
    encodeDotInKeys: typeof opts.encodeDotInKeys === "boolean" ? opts.encodeDotInKeys : defaults.encodeDotInKeys,
    encoder: typeof opts.encoder === "function" ? opts.encoder : defaults.encoder,
    encodeValuesOnly: typeof opts.encodeValuesOnly === "boolean" ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
    filter,
    format,
    formatter,
    serializeDate: typeof opts.serializeDate === "function" ? opts.serializeDate : defaults.serializeDate,
    skipNulls: typeof opts.skipNulls === "boolean" ? opts.skipNulls : defaults.skipNulls,
    // @ts-ignore
    sort: typeof opts.sort === "function" ? opts.sort : null,
    strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults.strictNullHandling
  };
}
function stringify(object, opts = {}) {
  let obj = object;
  const options = normalize_stringify_options(opts);
  let obj_keys;
  let filter;
  if (typeof options.filter === "function") {
    filter = options.filter;
    obj = filter("", obj);
  } else if (is_array(options.filter)) {
    filter = options.filter;
    obj_keys = filter;
  }
  const keys = [];
  if (typeof obj !== "object" || obj === null) {
    return "";
  }
  const generateArrayPrefix = array_prefix_generators[options.arrayFormat];
  const commaRoundTrip = generateArrayPrefix === "comma" && options.commaRoundTrip;
  if (!obj_keys) {
    obj_keys = Object.keys(obj);
  }
  if (options.sort) {
    obj_keys.sort(options.sort);
  }
  const sideChannel = /* @__PURE__ */ new WeakMap();
  for (let i = 0; i < obj_keys.length; ++i) {
    const key = obj_keys[i];
    if (options.skipNulls && obj[key] === null) {
      continue;
    }
    push_to_array(keys, inner_stringify(
      obj[key],
      key,
      // @ts-expect-error
      generateArrayPrefix,
      commaRoundTrip,
      options.allowEmptyArrays,
      options.strictNullHandling,
      options.skipNulls,
      options.encodeDotInKeys,
      options.encode ? options.encoder : null,
      options.filter,
      options.sort,
      options.allowDots,
      options.serializeDate,
      options.format,
      options.formatter,
      options.encodeValuesOnly,
      options.charset,
      sideChannel
    ));
  }
  const joined = keys.join(options.delimiter);
  let prefix = options.addQueryPrefix === true ? "?" : "";
  if (options.charsetSentinel) {
    if (options.charset === "iso-8859-1") {
      prefix += "utf8=%26%2310003%3B&";
    } else {
      prefix += "utf8=%E2%9C%93&";
    }
  }
  return joined.length > 0 ? prefix + joined : "";
}
const VERSION = "4.104.0";
let auto = false;
let kind = void 0;
let fetch$1 = void 0;
let FormData$1 = void 0;
let File$1 = void 0;
let ReadableStream$1 = void 0;
let getMultipartRequestOptions = void 0;
let getDefaultAgent = void 0;
let fileFromPath = void 0;
let isFsReadStream = void 0;
function setShims(shims, options = { auto: false }) {
  if (auto) {
    throw new Error(`you must \`import 'openai/shims/${shims.kind}'\` before importing anything else from openai`);
  }
  if (kind) {
    throw new Error(`can't \`import 'openai/shims/${shims.kind}'\` after \`import 'openai/shims/${kind}'\``);
  }
  auto = options.auto;
  kind = shims.kind;
  fetch$1 = shims.fetch;
  FormData$1 = shims.FormData;
  File$1 = shims.File;
  ReadableStream$1 = shims.ReadableStream;
  getMultipartRequestOptions = shims.getMultipartRequestOptions;
  getDefaultAgent = shims.getDefaultAgent;
  fileFromPath = shims.fileFromPath;
  isFsReadStream = shims.isFsReadStream;
}
class MultipartBody {
  constructor(body) {
    this.body = body;
  }
  get [Symbol.toStringTag]() {
    return "MultipartBody";
  }
}
function getRuntime({ manuallyImported } = {}) {
  const recommendation = manuallyImported ? `You may need to use polyfills` : `Add one of these imports before your first \`import … from 'openai'\`:
- \`import 'openai/shims/node'\` (if you're running on Node)
- \`import 'openai/shims/web'\` (otherwise)
`;
  let _fetch, _Request, _Response, _Headers;
  try {
    _fetch = fetch;
    _Request = Request;
    _Response = Response;
    _Headers = Headers;
  } catch (error) {
    throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
  }
  return {
    kind: "web",
    fetch: _fetch,
    Request: _Request,
    Response: _Response,
    Headers: _Headers,
    FormData: (
      // @ts-ignore
      typeof FormData !== "undefined" ? FormData : class FormData {
        // @ts-ignore
        constructor() {
          throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
        }
      }
    ),
    Blob: typeof Blob !== "undefined" ? Blob : class Blob {
      constructor() {
        throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
      }
    },
    File: (
      // @ts-ignore
      typeof File !== "undefined" ? File : class File {
        // @ts-ignore
        constructor() {
          throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
        }
      }
    ),
    ReadableStream: (
      // @ts-ignore
      typeof ReadableStream !== "undefined" ? ReadableStream : class ReadableStream {
        // @ts-ignore
        constructor() {
          throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
        }
      }
    ),
    getMultipartRequestOptions: async (form, opts) => ({
      ...opts,
      body: new MultipartBody(form)
    }),
    getDefaultAgent: (url) => void 0,
    fileFromPath: () => {
      throw new Error("The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/openai/openai-node#file-uploads");
    },
    isFsReadStream: (value) => false
  };
}
const init = () => {
  if (!kind) setShims(getRuntime(), { auto: true });
};
init();
class OpenAIError extends Error {
}
class APIError extends OpenAIError {
  constructor(status, error, message, headers) {
    super(`${APIError.makeMessage(status, error, message)}`);
    this.status = status;
    this.headers = headers;
    this.request_id = headers?.["x-request-id"];
    this.error = error;
    const data = error;
    this.code = data?.["code"];
    this.param = data?.["param"];
    this.type = data?.["type"];
  }
  static makeMessage(status, error, message) {
    const msg = error?.message ? typeof error.message === "string" ? error.message : JSON.stringify(error.message) : error ? JSON.stringify(error) : message;
    if (status && msg) {
      return `${status} ${msg}`;
    }
    if (status) {
      return `${status} status code (no body)`;
    }
    if (msg) {
      return msg;
    }
    return "(no status code or body)";
  }
  static generate(status, errorResponse, message, headers) {
    if (!status || !headers) {
      return new APIConnectionError({ message, cause: castToError(errorResponse) });
    }
    const error = errorResponse?.["error"];
    if (status === 400) {
      return new BadRequestError(status, error, message, headers);
    }
    if (status === 401) {
      return new AuthenticationError(status, error, message, headers);
    }
    if (status === 403) {
      return new PermissionDeniedError(status, error, message, headers);
    }
    if (status === 404) {
      return new NotFoundError(status, error, message, headers);
    }
    if (status === 409) {
      return new ConflictError(status, error, message, headers);
    }
    if (status === 422) {
      return new UnprocessableEntityError(status, error, message, headers);
    }
    if (status === 429) {
      return new RateLimitError(status, error, message, headers);
    }
    if (status >= 500) {
      return new InternalServerError(status, error, message, headers);
    }
    return new APIError(status, error, message, headers);
  }
}
class APIUserAbortError extends APIError {
  constructor({ message } = {}) {
    super(void 0, void 0, message || "Request was aborted.", void 0);
  }
}
class APIConnectionError extends APIError {
  constructor({ message, cause }) {
    super(void 0, void 0, message || "Connection error.", void 0);
    if (cause)
      this.cause = cause;
  }
}
class APIConnectionTimeoutError extends APIConnectionError {
  constructor({ message } = {}) {
    super({ message: message ?? "Request timed out." });
  }
}
class BadRequestError extends APIError {
}
class AuthenticationError extends APIError {
}
class PermissionDeniedError extends APIError {
}
class NotFoundError extends APIError {
}
class ConflictError extends APIError {
}
class UnprocessableEntityError extends APIError {
}
class RateLimitError extends APIError {
}
class InternalServerError extends APIError {
}
class LengthFinishReasonError extends OpenAIError {
  constructor() {
    super(`Could not parse response content as the length limit was reached`);
  }
}
class ContentFilterFinishReasonError extends OpenAIError {
  constructor() {
    super(`Could not parse response content as the request was rejected by the content filter`);
  }
}
var __classPrivateFieldSet$5 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet$6 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _LineDecoder_carriageReturnIndex;
class LineDecoder {
  constructor() {
    _LineDecoder_carriageReturnIndex.set(this, void 0);
    this.buffer = new Uint8Array();
    __classPrivateFieldSet$5(this, _LineDecoder_carriageReturnIndex, null, "f");
  }
  decode(chunk) {
    if (chunk == null) {
      return [];
    }
    const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk;
    let newData = new Uint8Array(this.buffer.length + binaryChunk.length);
    newData.set(this.buffer);
    newData.set(binaryChunk, this.buffer.length);
    this.buffer = newData;
    const lines = [];
    let patternIndex;
    while ((patternIndex = findNewlineIndex(this.buffer, __classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f"))) != null) {
      if (patternIndex.carriage && __classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f") == null) {
        __classPrivateFieldSet$5(this, _LineDecoder_carriageReturnIndex, patternIndex.index, "f");
        continue;
      }
      if (__classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f") != null && (patternIndex.index !== __classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f") + 1 || patternIndex.carriage)) {
        lines.push(this.decodeText(this.buffer.slice(0, __classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f") - 1)));
        this.buffer = this.buffer.slice(__classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f"));
        __classPrivateFieldSet$5(this, _LineDecoder_carriageReturnIndex, null, "f");
        continue;
      }
      const endIndex = __classPrivateFieldGet$6(this, _LineDecoder_carriageReturnIndex, "f") !== null ? patternIndex.preceding - 1 : patternIndex.preceding;
      const line = this.decodeText(this.buffer.slice(0, endIndex));
      lines.push(line);
      this.buffer = this.buffer.slice(patternIndex.index);
      __classPrivateFieldSet$5(this, _LineDecoder_carriageReturnIndex, null, "f");
    }
    return lines;
  }
  decodeText(bytes) {
    if (bytes == null)
      return "";
    if (typeof bytes === "string")
      return bytes;
    if (typeof Buffer !== "undefined") {
      if (bytes instanceof Buffer) {
        return bytes.toString();
      }
      if (bytes instanceof Uint8Array) {
        return Buffer.from(bytes).toString();
      }
      throw new OpenAIError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
    }
    if (typeof TextDecoder !== "undefined") {
      if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
        this.textDecoder ?? (this.textDecoder = new TextDecoder("utf8"));
        return this.textDecoder.decode(bytes);
      }
      throw new OpenAIError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
    }
    throw new OpenAIError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
  }
  flush() {
    if (!this.buffer.length) {
      return [];
    }
    return this.decode("\n");
  }
}
_LineDecoder_carriageReturnIndex = /* @__PURE__ */ new WeakMap();
LineDecoder.NEWLINE_CHARS = /* @__PURE__ */ new Set(["\n", "\r"]);
LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
function findNewlineIndex(buffer, startIndex) {
  const newline = 10;
  const carriage = 13;
  for (let i = startIndex ?? 0; i < buffer.length; i++) {
    if (buffer[i] === newline) {
      return { preceding: i, index: i + 1, carriage: false };
    }
    if (buffer[i] === carriage) {
      return { preceding: i, index: i + 1, carriage: true };
    }
  }
  return null;
}
function findDoubleNewlineIndex(buffer) {
  const newline = 10;
  const carriage = 13;
  for (let i = 0; i < buffer.length - 1; i++) {
    if (buffer[i] === newline && buffer[i + 1] === newline) {
      return i + 2;
    }
    if (buffer[i] === carriage && buffer[i + 1] === carriage) {
      return i + 2;
    }
    if (buffer[i] === carriage && buffer[i + 1] === newline && i + 3 < buffer.length && buffer[i + 2] === carriage && buffer[i + 3] === newline) {
      return i + 4;
    }
  }
  return -1;
}
function ReadableStreamToAsyncIterable(stream) {
  if (stream[Symbol.asyncIterator])
    return stream;
  const reader = stream.getReader();
  return {
    async next() {
      try {
        const result2 = await reader.read();
        if (result2?.done)
          reader.releaseLock();
        return result2;
      } catch (e) {
        reader.releaseLock();
        throw e;
      }
    },
    async return() {
      const cancelPromise = reader.cancel();
      reader.releaseLock();
      await cancelPromise;
      return { done: true, value: void 0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}
class Stream {
  constructor(iterator, controller) {
    this.iterator = iterator;
    this.controller = controller;
  }
  static fromSSEResponse(response, controller) {
    let consumed = false;
    async function* iterator() {
      if (consumed) {
        throw new Error("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      }
      consumed = true;
      let done = false;
      try {
        for await (const sse of _iterSSEMessages(response, controller)) {
          if (done)
            continue;
          if (sse.data.startsWith("[DONE]")) {
            done = true;
            continue;
          }
          if (sse.event === null || sse.event.startsWith("response.") || sse.event.startsWith("transcript.")) {
            let data;
            try {
              data = JSON.parse(sse.data);
            } catch (e) {
              console.error(`Could not parse message into JSON:`, sse.data);
              console.error(`From chunk:`, sse.raw);
              throw e;
            }
            if (data && data.error) {
              throw new APIError(void 0, data.error, void 0, createResponseHeaders(response.headers));
            }
            yield data;
          } else {
            let data;
            try {
              data = JSON.parse(sse.data);
            } catch (e) {
              console.error(`Could not parse message into JSON:`, sse.data);
              console.error(`From chunk:`, sse.raw);
              throw e;
            }
            if (sse.event == "error") {
              throw new APIError(void 0, data.error, data.message, void 0);
            }
            yield { event: sse.event, data };
          }
        }
        done = true;
      } catch (e) {
        if (e instanceof Error && e.name === "AbortError")
          return;
        throw e;
      } finally {
        if (!done)
          controller.abort();
      }
    }
    return new Stream(iterator, controller);
  }
  /**
   * Generates a Stream from a newline-separated ReadableStream
   * where each item is a JSON value.
   */
  static fromReadableStream(readableStream, controller) {
    let consumed = false;
    async function* iterLines() {
      const lineDecoder = new LineDecoder();
      const iter = ReadableStreamToAsyncIterable(readableStream);
      for await (const chunk of iter) {
        for (const line of lineDecoder.decode(chunk)) {
          yield line;
        }
      }
      for (const line of lineDecoder.flush()) {
        yield line;
      }
    }
    async function* iterator() {
      if (consumed) {
        throw new Error("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      }
      consumed = true;
      let done = false;
      try {
        for await (const line of iterLines()) {
          if (done)
            continue;
          if (line)
            yield JSON.parse(line);
        }
        done = true;
      } catch (e) {
        if (e instanceof Error && e.name === "AbortError")
          return;
        throw e;
      } finally {
        if (!done)
          controller.abort();
      }
    }
    return new Stream(iterator, controller);
  }
  [Symbol.asyncIterator]() {
    return this.iterator();
  }
  /**
   * Splits the stream into two streams which can be
   * independently read from at different speeds.
   */
  tee() {
    const left = [];
    const right = [];
    const iterator = this.iterator();
    const teeIterator = (queue) => {
      return {
        next: () => {
          if (queue.length === 0) {
            const result2 = iterator.next();
            left.push(result2);
            right.push(result2);
          }
          return queue.shift();
        }
      };
    };
    return [
      new Stream(() => teeIterator(left), this.controller),
      new Stream(() => teeIterator(right), this.controller)
    ];
  }
  /**
   * Converts this stream to a newline-separated ReadableStream of
   * JSON stringified values in the stream
   * which can be turned back into a Stream with `Stream.fromReadableStream()`.
   */
  toReadableStream() {
    const self = this;
    let iter;
    const encoder = new TextEncoder();
    return new ReadableStream$1({
      async start() {
        iter = self[Symbol.asyncIterator]();
      },
      async pull(ctrl) {
        try {
          const { value, done } = await iter.next();
          if (done)
            return ctrl.close();
          const bytes = encoder.encode(JSON.stringify(value) + "\n");
          ctrl.enqueue(bytes);
        } catch (err) {
          ctrl.error(err);
        }
      },
      async cancel() {
        await iter.return?.();
      }
    });
  }
}
async function* _iterSSEMessages(response, controller) {
  if (!response.body) {
    controller.abort();
    throw new OpenAIError(`Attempted to iterate over a response with no body`);
  }
  const sseDecoder = new SSEDecoder();
  const lineDecoder = new LineDecoder();
  const iter = ReadableStreamToAsyncIterable(response.body);
  for await (const sseChunk of iterSSEChunks(iter)) {
    for (const line of lineDecoder.decode(sseChunk)) {
      const sse = sseDecoder.decode(line);
      if (sse)
        yield sse;
    }
  }
  for (const line of lineDecoder.flush()) {
    const sse = sseDecoder.decode(line);
    if (sse)
      yield sse;
  }
}
async function* iterSSEChunks(iterator) {
  let data = new Uint8Array();
  for await (const chunk of iterator) {
    if (chunk == null) {
      continue;
    }
    const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk;
    let newData = new Uint8Array(data.length + binaryChunk.length);
    newData.set(data);
    newData.set(binaryChunk, data.length);
    data = newData;
    let patternIndex;
    while ((patternIndex = findDoubleNewlineIndex(data)) !== -1) {
      yield data.slice(0, patternIndex);
      data = data.slice(patternIndex);
    }
  }
  if (data.length > 0) {
    yield data;
  }
}
class SSEDecoder {
  constructor() {
    this.event = null;
    this.data = [];
    this.chunks = [];
  }
  decode(line) {
    if (line.endsWith("\r")) {
      line = line.substring(0, line.length - 1);
    }
    if (!line) {
      if (!this.event && !this.data.length)
        return null;
      const sse = {
        event: this.event,
        data: this.data.join("\n"),
        raw: this.chunks
      };
      this.event = null;
      this.data = [];
      this.chunks = [];
      return sse;
    }
    this.chunks.push(line);
    if (line.startsWith(":")) {
      return null;
    }
    let [fieldname, _, value] = partition(line, ":");
    if (value.startsWith(" ")) {
      value = value.substring(1);
    }
    if (fieldname === "event") {
      this.event = value;
    } else if (fieldname === "data") {
      this.data.push(value);
    }
    return null;
  }
}
function partition(str2, delimiter) {
  const index = str2.indexOf(delimiter);
  if (index !== -1) {
    return [str2.substring(0, index), delimiter, str2.substring(index + delimiter.length)];
  }
  return [str2, "", ""];
}
const isResponseLike = (value) => value != null && typeof value === "object" && typeof value.url === "string" && typeof value.blob === "function";
const isFileLike = (value) => value != null && typeof value === "object" && typeof value.name === "string" && typeof value.lastModified === "number" && isBlobLike(value);
const isBlobLike = (value) => value != null && typeof value === "object" && typeof value.size === "number" && typeof value.type === "string" && typeof value.text === "function" && typeof value.slice === "function" && typeof value.arrayBuffer === "function";
const isUploadable = (value) => {
  return isFileLike(value) || isResponseLike(value) || isFsReadStream(value);
};
async function toFile(value, name, options) {
  value = await value;
  if (isFileLike(value)) {
    return value;
  }
  if (isResponseLike(value)) {
    const blob = await value.blob();
    name || (name = new URL(value.url).pathname.split(/[\\/]/).pop() ?? "unknown_file");
    const data = isBlobLike(blob) ? [await blob.arrayBuffer()] : [blob];
    return new File$1(data, name, options);
  }
  const bits = await getBytes(value);
  name || (name = getName(value) ?? "unknown_file");
  if (!options?.type) {
    const type = bits[0]?.type;
    if (typeof type === "string") {
      options = { ...options, type };
    }
  }
  return new File$1(bits, name, options);
}
async function getBytes(value) {
  let parts = [];
  if (typeof value === "string" || ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
  value instanceof ArrayBuffer) {
    parts.push(value);
  } else if (isBlobLike(value)) {
    parts.push(await value.arrayBuffer());
  } else if (isAsyncIterableIterator(value)) {
    for await (const chunk of value) {
      parts.push(chunk);
    }
  } else {
    throw new Error(`Unexpected data type: ${typeof value}; constructor: ${value?.constructor?.name}; props: ${propsForError(value)}`);
  }
  return parts;
}
function propsForError(value) {
  const props = Object.getOwnPropertyNames(value);
  return `[${props.map((p) => `"${p}"`).join(", ")}]`;
}
function getName(value) {
  return getStringFromMaybeBuffer(value.name) || getStringFromMaybeBuffer(value.filename) || // For fs.ReadStream
  getStringFromMaybeBuffer(value.path)?.split(/[\\/]/).pop();
}
const getStringFromMaybeBuffer = (x) => {
  if (typeof x === "string")
    return x;
  if (typeof Buffer !== "undefined" && x instanceof Buffer)
    return String(x);
  return void 0;
};
const isAsyncIterableIterator = (value) => value != null && typeof value === "object" && typeof value[Symbol.asyncIterator] === "function";
const isMultipartBody = (body) => body && typeof body === "object" && body.body && body[Symbol.toStringTag] === "MultipartBody";
const multipartFormRequestOptions = async (opts) => {
  const form = await createForm(opts.body);
  return getMultipartRequestOptions(form, opts);
};
const createForm = async (body) => {
  const form = new FormData$1();
  await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value)));
  return form;
};
const addFormValue = async (form, key, value) => {
  if (value === void 0)
    return;
  if (value == null) {
    throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
  }
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    form.append(key, String(value));
  } else if (isUploadable(value)) {
    const file = await toFile(value);
    form.append(key, file);
  } else if (Array.isArray(value)) {
    await Promise.all(value.map((entry) => addFormValue(form, key + "[]", entry)));
  } else if (typeof value === "object") {
    await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop)));
  } else {
    throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
  }
};
var define_process_env_default = {};
var __classPrivateFieldSet$4 = function(receiver, state, value, kind2, f) {
  if (typeof state === "function" ? receiver !== state || true : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return state.set(receiver, value), value;
};
var __classPrivateFieldGet$5 = function(receiver, state, kind2, f) {
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractPage_client;
init();
async function defaultParseResponse(props) {
  const { response } = props;
  if (props.options.stream) {
    debug("response", response.status, response.url, response.headers, response.body);
    if (props.options.__streamClass) {
      return props.options.__streamClass.fromSSEResponse(response, props.controller);
    }
    return Stream.fromSSEResponse(response, props.controller);
  }
  if (response.status === 204) {
    return null;
  }
  if (props.options.__binaryResponse) {
    return response;
  }
  const contentType = response.headers.get("content-type");
  const mediaType = contentType?.split(";")[0]?.trim();
  const isJSON = mediaType?.includes("application/json") || mediaType?.endsWith("+json");
  if (isJSON) {
    const json = await response.json();
    debug("response", response.status, response.url, response.headers, json);
    return _addRequestID(json, response);
  }
  const text = await response.text();
  debug("response", response.status, response.url, response.headers, text);
  return text;
}
function _addRequestID(value, response) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return value;
  }
  return Object.defineProperty(value, "_request_id", {
    value: response.headers.get("x-request-id"),
    enumerable: false
  });
}
class APIPromise extends Promise {
  constructor(responsePromise, parseResponse2 = defaultParseResponse) {
    super((resolve) => {
      resolve(null);
    });
    this.responsePromise = responsePromise;
    this.parseResponse = parseResponse2;
  }
  _thenUnwrap(transform) {
    return new APIPromise(this.responsePromise, async (props) => _addRequestID(transform(await this.parseResponse(props), props), props.response));
  }
  /**
   * Gets the raw `Response` instance instead of parsing the response
   * data.
   *
   * If you want to parse the response body but still get the `Response`
   * instance, you can use {@link withResponse()}.
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` if you can,
   * or add one of these imports before your first `import … from 'openai'`:
   * - `import 'openai/shims/node'` (if you're running on Node)
   * - `import 'openai/shims/web'` (otherwise)
   */
  asResponse() {
    return this.responsePromise.then((p) => p.response);
  }
  /**
   * Gets the parsed response data, the raw `Response` instance and the ID of the request,
   * returned via the X-Request-ID header which is useful for debugging requests and reporting
   * issues to OpenAI.
   *
   * If you just want to get the raw `Response` instance without parsing it,
   * you can use {@link asResponse()}.
   *
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` if you can,
   * or add one of these imports before your first `import … from 'openai'`:
   * - `import 'openai/shims/node'` (if you're running on Node)
   * - `import 'openai/shims/web'` (otherwise)
   */
  async withResponse() {
    const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
    return { data, response, request_id: response.headers.get("x-request-id") };
  }
  parse() {
    if (!this.parsedPromise) {
      this.parsedPromise = this.responsePromise.then(this.parseResponse);
    }
    return this.parsedPromise;
  }
  then(onfulfilled, onrejected) {
    return this.parse().then(onfulfilled, onrejected);
  }
  catch(onrejected) {
    return this.parse().catch(onrejected);
  }
  finally(onfinally) {
    return this.parse().finally(onfinally);
  }
}
class APIClient {
  constructor({
    baseURL,
    maxRetries = 2,
    timeout = 6e5,
    // 10 minutes
    httpAgent,
    fetch: overriddenFetch
  }) {
    this.baseURL = baseURL;
    this.maxRetries = validatePositiveInteger("maxRetries", maxRetries);
    this.timeout = validatePositiveInteger("timeout", timeout);
    this.httpAgent = httpAgent;
    this.fetch = overriddenFetch ?? fetch$1;
  }
  authHeaders(opts) {
    return {};
  }
  /**
   * Override this to add your own default headers, for example:
   *
   *  {
   *    ...super.defaultHeaders(),
   *    Authorization: 'Bearer 123',
   *  }
   */
  defaultHeaders(opts) {
    return {
      Accept: "application/json",
      "Content-Type": "application/json",
      "User-Agent": this.getUserAgent(),
      ...getPlatformHeaders(),
      ...this.authHeaders(opts)
    };
  }
  /**
   * Override this to add your own headers validation:
   */
  validateHeaders(headers, customHeaders) {
  }
  defaultIdempotencyKey() {
    return `stainless-node-retry-${uuid4()}`;
  }
  get(path, opts) {
    return this.methodRequest("get", path, opts);
  }
  post(path, opts) {
    return this.methodRequest("post", path, opts);
  }
  patch(path, opts) {
    return this.methodRequest("patch", path, opts);
  }
  put(path, opts) {
    return this.methodRequest("put", path, opts);
  }
  delete(path, opts) {
    return this.methodRequest("delete", path, opts);
  }
  methodRequest(method, path, opts) {
    return this.request(Promise.resolve(opts).then(async (opts2) => {
      const body = opts2 && isBlobLike(opts2?.body) ? new DataView(await opts2.body.arrayBuffer()) : opts2?.body instanceof DataView ? opts2.body : opts2?.body instanceof ArrayBuffer ? new DataView(opts2.body) : opts2 && ArrayBuffer.isView(opts2?.body) ? new DataView(opts2.body.buffer) : opts2?.body;
      return { method, path, ...opts2, body };
    }));
  }
  getAPIList(path, Page2, opts) {
    return this.requestAPIList(Page2, { method: "get", path, ...opts });
  }
  calculateContentLength(body) {
    if (typeof body === "string") {
      if (typeof Buffer !== "undefined") {
        return Buffer.byteLength(body, "utf8").toString();
      }
      if (typeof TextEncoder !== "undefined") {
        const encoder = new TextEncoder();
        const encoded = encoder.encode(body);
        return encoded.length.toString();
      }
    } else if (ArrayBuffer.isView(body)) {
      return body.byteLength.toString();
    }
    return null;
  }
  buildRequest(inputOptions, { retryCount = 0 } = {}) {
    const options = { ...inputOptions };
    const { method, path, query, headers = {} } = options;
    const body = ArrayBuffer.isView(options.body) || options.__binaryRequest && typeof options.body === "string" ? options.body : isMultipartBody(options.body) ? options.body.body : options.body ? JSON.stringify(options.body, null, 2) : null;
    const contentLength = this.calculateContentLength(body);
    const url = this.buildURL(path, query);
    if ("timeout" in options)
      validatePositiveInteger("timeout", options.timeout);
    options.timeout = options.timeout ?? this.timeout;
    const httpAgent = options.httpAgent ?? this.httpAgent ?? getDefaultAgent(url);
    const minAgentTimeout = options.timeout + 1e3;
    if (typeof httpAgent?.options?.timeout === "number" && minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
      httpAgent.options.timeout = minAgentTimeout;
    }
    if (this.idempotencyHeader && method !== "get") {
      if (!inputOptions.idempotencyKey)
        inputOptions.idempotencyKey = this.defaultIdempotencyKey();
      headers[this.idempotencyHeader] = inputOptions.idempotencyKey;
    }
    const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
    const req = {
      method,
      ...body && { body },
      headers: reqHeaders,
      ...httpAgent && { agent: httpAgent },
      // @ts-ignore node-fetch uses a custom AbortSignal type that is
      // not compatible with standard web types
      signal: options.signal ?? null
    };
    return { req, url, timeout: options.timeout };
  }
  buildHeaders({ options, headers, contentLength, retryCount }) {
    const reqHeaders = {};
    if (contentLength) {
      reqHeaders["content-length"] = contentLength;
    }
    const defaultHeaders = this.defaultHeaders(options);
    applyHeadersMut(reqHeaders, defaultHeaders);
    applyHeadersMut(reqHeaders, headers);
    if (isMultipartBody(options.body) && kind !== "node") {
      delete reqHeaders["content-type"];
    }
    if (getHeader(defaultHeaders, "x-stainless-retry-count") === void 0 && getHeader(headers, "x-stainless-retry-count") === void 0) {
      reqHeaders["x-stainless-retry-count"] = String(retryCount);
    }
    if (getHeader(defaultHeaders, "x-stainless-timeout") === void 0 && getHeader(headers, "x-stainless-timeout") === void 0 && options.timeout) {
      reqHeaders["x-stainless-timeout"] = String(Math.trunc(options.timeout / 1e3));
    }
    this.validateHeaders(reqHeaders, headers);
    return reqHeaders;
  }
  /**
   * Used as a callback for mutating the given `FinalRequestOptions` object.
   */
  async prepareOptions(options) {
  }
  /**
   * Used as a callback for mutating the given `RequestInit` object.
   *
   * This is useful for cases where you want to add certain headers based off of
   * the request properties, e.g. `method` or `url`.
   */
  async prepareRequest(request, { url, options }) {
  }
  parseHeaders(headers) {
    return !headers ? {} : Symbol.iterator in headers ? Object.fromEntries(Array.from(headers).map((header) => [...header])) : { ...headers };
  }
  makeStatusError(status, error, message, headers) {
    return APIError.generate(status, error, message, headers);
  }
  request(options, remainingRetries = null) {
    return new APIPromise(this.makeRequest(options, remainingRetries));
  }
  async makeRequest(optionsInput, retriesRemaining) {
    const options = await optionsInput;
    const maxRetries = options.maxRetries ?? this.maxRetries;
    if (retriesRemaining == null) {
      retriesRemaining = maxRetries;
    }
    await this.prepareOptions(options);
    const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
    await this.prepareRequest(req, { url, options });
    debug("request", url, options, req.headers);
    if (options.signal?.aborted) {
      throw new APIUserAbortError();
    }
    const controller = new AbortController();
    const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
    if (response instanceof Error) {
      if (options.signal?.aborted) {
        throw new APIUserAbortError();
      }
      if (retriesRemaining) {
        return this.retryRequest(options, retriesRemaining);
      }
      if (response.name === "AbortError") {
        throw new APIConnectionTimeoutError();
      }
      throw new APIConnectionError({ cause: response });
    }
    const responseHeaders = createResponseHeaders(response.headers);
    if (!response.ok) {
      if (retriesRemaining && this.shouldRetry(response)) {
        const retryMessage2 = `retrying, ${retriesRemaining} attempts remaining`;
        debug(`response (error; ${retryMessage2})`, response.status, url, responseHeaders);
        return this.retryRequest(options, retriesRemaining, responseHeaders);
      }
      const errText = await response.text().catch((e) => castToError(e).message);
      const errJSON = safeJSON(errText);
      const errMessage = errJSON ? void 0 : errText;
      const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
      debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
      const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
      throw err;
    }
    return { response, options, controller };
  }
  requestAPIList(Page2, options) {
    const request = this.makeRequest(options, null);
    return new PagePromise(this, request, Page2);
  }
  buildURL(path, query) {
    const url = isAbsoluteURL(path) ? new URL(path) : new URL(this.baseURL + (this.baseURL.endsWith("/") && path.startsWith("/") ? path.slice(1) : path));
    const defaultQuery = this.defaultQuery();
    if (!isEmptyObj(defaultQuery)) {
      query = { ...defaultQuery, ...query };
    }
    if (typeof query === "object" && query && !Array.isArray(query)) {
      url.search = this.stringifyQuery(query);
    }
    return url.toString();
  }
  stringifyQuery(query) {
    return Object.entries(query).filter(([_, value]) => typeof value !== "undefined").map(([key, value]) => {
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
      }
      if (value === null) {
        return `${encodeURIComponent(key)}=`;
      }
      throw new OpenAIError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
    }).join("&");
  }
  async fetchWithTimeout(url, init2, ms, controller) {
    const { signal, ...options } = init2 || {};
    if (signal)
      signal.addEventListener("abort", () => controller.abort());
    const timeout = setTimeout(() => controller.abort(), ms);
    const fetchOptions = {
      signal: controller.signal,
      ...options
    };
    if (fetchOptions.method) {
      fetchOptions.method = fetchOptions.method.toUpperCase();
    }
    return (
      // use undefined this binding; fetch errors if bound to something else in browser/cloudflare
      this.fetch.call(void 0, url, fetchOptions).finally(() => {
        clearTimeout(timeout);
      })
    );
  }
  shouldRetry(response) {
    const shouldRetryHeader = response.headers.get("x-should-retry");
    if (shouldRetryHeader === "true")
      return true;
    if (shouldRetryHeader === "false")
      return false;
    if (response.status === 408)
      return true;
    if (response.status === 409)
      return true;
    if (response.status === 429)
      return true;
    if (response.status >= 500)
      return true;
    return false;
  }
  async retryRequest(options, retriesRemaining, responseHeaders) {
    let timeoutMillis;
    const retryAfterMillisHeader = responseHeaders?.["retry-after-ms"];
    if (retryAfterMillisHeader) {
      const timeoutMs = parseFloat(retryAfterMillisHeader);
      if (!Number.isNaN(timeoutMs)) {
        timeoutMillis = timeoutMs;
      }
    }
    const retryAfterHeader = responseHeaders?.["retry-after"];
    if (retryAfterHeader && !timeoutMillis) {
      const timeoutSeconds = parseFloat(retryAfterHeader);
      if (!Number.isNaN(timeoutSeconds)) {
        timeoutMillis = timeoutSeconds * 1e3;
      } else {
        timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
      }
    }
    if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1e3)) {
      const maxRetries = options.maxRetries ?? this.maxRetries;
      timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
    }
    await sleep(timeoutMillis);
    return this.makeRequest(options, retriesRemaining - 1);
  }
  calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
    const initialRetryDelay = 0.5;
    const maxRetryDelay = 8;
    const numRetries = maxRetries - retriesRemaining;
    const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
    const jitter = 1 - Math.random() * 0.25;
    return sleepSeconds * jitter * 1e3;
  }
  getUserAgent() {
    return `${this.constructor.name}/JS ${VERSION}`;
  }
}
class AbstractPage {
  constructor(client, response, body, options) {
    _AbstractPage_client.set(this, void 0);
    __classPrivateFieldSet$4(this, _AbstractPage_client, client);
    this.options = options;
    this.response = response;
    this.body = body;
  }
  hasNextPage() {
    const items = this.getPaginatedItems();
    if (!items.length)
      return false;
    return this.nextPageInfo() != null;
  }
  async getNextPage() {
    const nextInfo = this.nextPageInfo();
    if (!nextInfo) {
      throw new OpenAIError("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
    }
    const nextOptions = { ...this.options };
    if ("params" in nextInfo && typeof nextOptions.query === "object") {
      nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
    } else if ("url" in nextInfo) {
      const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
      for (const [key, value] of params) {
        nextInfo.url.searchParams.set(key, value);
      }
      nextOptions.query = void 0;
      nextOptions.path = nextInfo.url.toString();
    }
    return await __classPrivateFieldGet$5(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
  }
  async *iterPages() {
    let page = this;
    yield page;
    while (page.hasNextPage()) {
      page = await page.getNextPage();
      yield page;
    }
  }
  async *[(_AbstractPage_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
    for await (const page of this.iterPages()) {
      for (const item of page.getPaginatedItems()) {
        yield item;
      }
    }
  }
}
class PagePromise extends APIPromise {
  constructor(client, request, Page2) {
    super(request, async (props) => new Page2(client, props.response, await defaultParseResponse(props), props.options));
  }
  /**
   * Allow auto-paginating iteration on an unawaited list call, eg:
   *
   *    for await (const item of client.items.list()) {
   *      console.log(item)
   *    }
   */
  async *[Symbol.asyncIterator]() {
    const page = await this;
    for await (const item of page) {
      yield item;
    }
  }
}
const createResponseHeaders = (headers) => {
  return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()
  ), {
    get(target, name) {
      const key = name.toString();
      return target[key.toLowerCase()] || target[key];
    }
  });
};
const requestOptionsKeys = {
  method: true,
  path: true,
  query: true,
  body: true,
  headers: true,
  maxRetries: true,
  stream: true,
  timeout: true,
  httpAgent: true,
  signal: true,
  idempotencyKey: true,
  __metadata: true,
  __binaryRequest: true,
  __binaryResponse: true,
  __streamClass: true
};
const isRequestOptions = (obj) => {
  return typeof obj === "object" && obj !== null && !isEmptyObj(obj) && Object.keys(obj).every((k) => hasOwn(requestOptionsKeys, k));
};
const getPlatformProperties = () => {
  if (typeof Deno !== "undefined" && Deno.build != null) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(Deno.build.os),
      "X-Stainless-Arch": normalizeArch(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version === "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  }
  if (typeof EdgeRuntime !== "undefined") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": process.version
    };
  }
  if (Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(process.platform),
      "X-Stainless-Arch": normalizeArch(process.arch),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": process.version
    };
  }
  const browserInfo = getBrowserInfo();
  if (browserInfo) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": "unknown",
      "X-Stainless-Runtime": `browser:${browserInfo.browser}`,
      "X-Stainless-Runtime-Version": browserInfo.version
    };
  }
  return {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": VERSION,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function getBrowserInfo() {
  if (typeof navigator === "undefined" || !navigator) {
    return null;
  }
  const browserPatterns = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key, pattern } of browserPatterns) {
    const match = pattern.exec(navigator.userAgent);
    if (match) {
      const major = match[1] || 0;
      const minor = match[2] || 0;
      const patch = match[3] || 0;
      return { browser: key, version: `${major}.${minor}.${patch}` };
    }
  }
  return null;
}
const normalizeArch = (arch) => {
  if (arch === "x32")
    return "x32";
  if (arch === "x86_64" || arch === "x64")
    return "x64";
  if (arch === "arm")
    return "arm";
  if (arch === "aarch64" || arch === "arm64")
    return "arm64";
  if (arch)
    return `other:${arch}`;
  return "unknown";
};
const normalizePlatform = (platform) => {
  platform = platform.toLowerCase();
  if (platform.includes("ios"))
    return "iOS";
  if (platform === "android")
    return "Android";
  if (platform === "darwin")
    return "MacOS";
  if (platform === "win32")
    return "Windows";
  if (platform === "freebsd")
    return "FreeBSD";
  if (platform === "openbsd")
    return "OpenBSD";
  if (platform === "linux")
    return "Linux";
  if (platform)
    return `Other:${platform}`;
  return "Unknown";
};
let _platformHeaders;
const getPlatformHeaders = () => {
  return _platformHeaders ?? (_platformHeaders = getPlatformProperties());
};
const safeJSON = (text) => {
  try {
    return JSON.parse(text);
  } catch (err) {
    return void 0;
  }
};
const startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
const isAbsoluteURL = (url) => {
  return startsWithSchemeRegexp.test(url);
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const validatePositiveInteger = (name, n) => {
  if (typeof n !== "number" || !Number.isInteger(n)) {
    throw new OpenAIError(`${name} must be an integer`);
  }
  if (n < 0) {
    throw new OpenAIError(`${name} must be a positive integer`);
  }
  return n;
};
const castToError = (err) => {
  if (err instanceof Error)
    return err;
  if (typeof err === "object" && err !== null) {
    try {
      return new Error(JSON.stringify(err));
    } catch {
    }
  }
  return new Error(err);
};
const readEnv = (env) => {
  if (typeof process !== "undefined") {
    return define_process_env_default?.[env]?.trim() ?? void 0;
  }
  if (typeof Deno !== "undefined") {
    return Deno.env?.get?.(env)?.trim();
  }
  return void 0;
};
function isEmptyObj(obj) {
  if (!obj)
    return true;
  for (const _k in obj)
    return false;
  return true;
}
function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
function applyHeadersMut(targetHeaders, newHeaders) {
  for (const k in newHeaders) {
    if (!hasOwn(newHeaders, k))
      continue;
    const lowerKey = k.toLowerCase();
    if (!lowerKey)
      continue;
    const val = newHeaders[k];
    if (val === null) {
      delete targetHeaders[lowerKey];
    } else if (val !== void 0) {
      targetHeaders[lowerKey] = val;
    }
  }
}
const SENSITIVE_HEADERS = /* @__PURE__ */ new Set(["authorization", "api-key"]);
function debug(action, ...args) {
  if (typeof process !== "undefined" && define_process_env_default?.["DEBUG"] === "true") {
    const modifiedArgs = args.map((arg) => {
      if (!arg) {
        return arg;
      }
      if (arg["headers"]) {
        const modifiedArg2 = { ...arg, headers: { ...arg["headers"] } };
        for (const header in arg["headers"]) {
          if (SENSITIVE_HEADERS.has(header.toLowerCase())) {
            modifiedArg2["headers"][header] = "REDACTED";
          }
        }
        return modifiedArg2;
      }
      let modifiedArg = null;
      for (const header in arg) {
        if (SENSITIVE_HEADERS.has(header.toLowerCase())) {
          modifiedArg ?? (modifiedArg = { ...arg });
          modifiedArg[header] = "REDACTED";
        }
      }
      return modifiedArg ?? arg;
    });
    console.log(`OpenAI:DEBUG:${action}`, ...modifiedArgs);
  }
}
const uuid4 = () => {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
};
const isRunningInBrowser = () => {
  return (
    // @ts-ignore
    typeof window !== "undefined" && // @ts-ignore
    typeof window.document !== "undefined" && // @ts-ignore
    typeof navigator !== "undefined"
  );
};
const isHeadersProtocol = (headers) => {
  return typeof headers?.get === "function";
};
const getHeader = (headers, header) => {
  const lowerCasedHeader = header.toLowerCase();
  if (isHeadersProtocol(headers)) {
    const intercapsHeader = header[0]?.toUpperCase() + header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
    for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
      const value = headers.get(key);
      if (value) {
        return value;
      }
    }
  }
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === lowerCasedHeader) {
      if (Array.isArray(value)) {
        if (value.length <= 1)
          return value[0];
        console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
        return value[0];
      }
      return value;
    }
  }
  return void 0;
};
const toFloat32Array = (base64Str) => {
  if (typeof Buffer !== "undefined") {
    const buf = Buffer.from(base64Str, "base64");
    return Array.from(new Float32Array(buf.buffer, buf.byteOffset, buf.length / Float32Array.BYTES_PER_ELEMENT));
  } else {
    const binaryStr = atob(base64Str);
    const len = binaryStr.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    return Array.from(new Float32Array(bytes.buffer));
  }
};
function isObj(obj) {
  return obj != null && typeof obj === "object" && !Array.isArray(obj);
}
class Page extends AbstractPage {
  constructor(client, response, body, options) {
    super(client, response, body, options);
    this.data = body.data || [];
    this.object = body.object;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  // @deprecated Please use `nextPageInfo()` instead
  /**
   * This page represents a response that isn't actually paginated at the API level
   * so there will never be any next page params.
   */
  nextPageParams() {
    return null;
  }
  nextPageInfo() {
    return null;
  }
}
class CursorPage extends AbstractPage {
  constructor(client, response, body, options) {
    super(client, response, body, options);
    this.data = body.data || [];
    this.has_more = body.has_more || false;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    if (this.has_more === false) {
      return false;
    }
    return super.hasNextPage();
  }
  // @deprecated Please use `nextPageInfo()` instead
  nextPageParams() {
    const info = this.nextPageInfo();
    if (!info)
      return null;
    if ("params" in info)
      return info.params;
    const params = Object.fromEntries(info.url.searchParams);
    if (!Object.keys(params).length)
      return null;
    return params;
  }
  nextPageInfo() {
    const data = this.getPaginatedItems();
    if (!data.length) {
      return null;
    }
    const id = data[data.length - 1]?.id;
    if (!id) {
      return null;
    }
    return { params: { after: id } };
  }
}
class APIResource {
  constructor(client) {
    this._client = client;
  }
}
let Messages$1 = class Messages extends APIResource {
  list(completionId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(completionId, {}, query);
    }
    return this._client.getAPIList(`/chat/completions/${completionId}/messages`, ChatCompletionStoreMessagesPage, { query, ...options });
  }
};
let Completions$2 = class Completions extends APIResource {
  constructor() {
    super(...arguments);
    this.messages = new Messages$1(this._client);
  }
  create(body, options) {
    return this._client.post("/chat/completions", { body, ...options, stream: body.stream ?? false });
  }
  /**
   * Get a stored chat completion. Only Chat Completions that have been created with
   * the `store` parameter set to `true` will be returned.
   *
   * @example
   * ```ts
   * const chatCompletion =
   *   await client.chat.completions.retrieve('completion_id');
   * ```
   */
  retrieve(completionId, options) {
    return this._client.get(`/chat/completions/${completionId}`, options);
  }
  /**
   * Modify a stored chat completion. Only Chat Completions that have been created
   * with the `store` parameter set to `true` can be modified. Currently, the only
   * supported modification is to update the `metadata` field.
   *
   * @example
   * ```ts
   * const chatCompletion = await client.chat.completions.update(
   *   'completion_id',
   *   { metadata: { foo: 'string' } },
   * );
   * ```
   */
  update(completionId, body, options) {
    return this._client.post(`/chat/completions/${completionId}`, { body, ...options });
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/chat/completions", ChatCompletionsPage, { query, ...options });
  }
  /**
   * Delete a stored chat completion. Only Chat Completions that have been created
   * with the `store` parameter set to `true` can be deleted.
   *
   * @example
   * ```ts
   * const chatCompletionDeleted =
   *   await client.chat.completions.del('completion_id');
   * ```
   */
  del(completionId, options) {
    return this._client.delete(`/chat/completions/${completionId}`, options);
  }
};
class ChatCompletionsPage extends CursorPage {
}
class ChatCompletionStoreMessagesPage extends CursorPage {
}
Completions$2.ChatCompletionsPage = ChatCompletionsPage;
Completions$2.Messages = Messages$1;
let Chat$1 = class Chat extends APIResource {
  constructor() {
    super(...arguments);
    this.completions = new Completions$2(this._client);
  }
};
Chat$1.Completions = Completions$2;
Chat$1.ChatCompletionsPage = ChatCompletionsPage;
class Speech extends APIResource {
  /**
   * Generates audio from the input text.
   *
   * @example
   * ```ts
   * const speech = await client.audio.speech.create({
   *   input: 'input',
   *   model: 'string',
   *   voice: 'ash',
   * });
   *
   * const content = await speech.blob();
   * console.log(content);
   * ```
   */
  create(body, options) {
    return this._client.post("/audio/speech", {
      body,
      ...options,
      headers: { Accept: "application/octet-stream", ...options?.headers },
      __binaryResponse: true
    });
  }
}
class Transcriptions extends APIResource {
  create(body, options) {
    return this._client.post("/audio/transcriptions", multipartFormRequestOptions({
      body,
      ...options,
      stream: body.stream ?? false,
      __metadata: { model: body.model }
    }));
  }
}
class Translations extends APIResource {
  create(body, options) {
    return this._client.post("/audio/translations", multipartFormRequestOptions({ body, ...options, __metadata: { model: body.model } }));
  }
}
class Audio extends APIResource {
  constructor() {
    super(...arguments);
    this.transcriptions = new Transcriptions(this._client);
    this.translations = new Translations(this._client);
    this.speech = new Speech(this._client);
  }
}
Audio.Transcriptions = Transcriptions;
Audio.Translations = Translations;
Audio.Speech = Speech;
class Batches extends APIResource {
  /**
   * Creates and executes a batch from an uploaded file of requests
   */
  create(body, options) {
    return this._client.post("/batches", { body, ...options });
  }
  /**
   * Retrieves a batch.
   */
  retrieve(batchId, options) {
    return this._client.get(`/batches/${batchId}`, options);
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/batches", BatchesPage, { query, ...options });
  }
  /**
   * Cancels an in-progress batch. The batch will be in status `cancelling` for up to
   * 10 minutes, before changing to `cancelled`, where it will have partial results
   * (if any) available in the output file.
   */
  cancel(batchId, options) {
    return this._client.post(`/batches/${batchId}/cancel`, options);
  }
}
class BatchesPage extends CursorPage {
}
Batches.BatchesPage = BatchesPage;
var __classPrivateFieldSet$3 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet$4 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _EventStream_instances, _EventStream_connectedPromise, _EventStream_resolveConnectedPromise, _EventStream_rejectConnectedPromise, _EventStream_endPromise, _EventStream_resolveEndPromise, _EventStream_rejectEndPromise, _EventStream_listeners, _EventStream_ended, _EventStream_errored, _EventStream_aborted, _EventStream_catchingPromiseCreated, _EventStream_handleError;
class EventStream {
  constructor() {
    _EventStream_instances.add(this);
    this.controller = new AbortController();
    _EventStream_connectedPromise.set(this, void 0);
    _EventStream_resolveConnectedPromise.set(this, () => {
    });
    _EventStream_rejectConnectedPromise.set(this, () => {
    });
    _EventStream_endPromise.set(this, void 0);
    _EventStream_resolveEndPromise.set(this, () => {
    });
    _EventStream_rejectEndPromise.set(this, () => {
    });
    _EventStream_listeners.set(this, {});
    _EventStream_ended.set(this, false);
    _EventStream_errored.set(this, false);
    _EventStream_aborted.set(this, false);
    _EventStream_catchingPromiseCreated.set(this, false);
    __classPrivateFieldSet$3(this, _EventStream_connectedPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet$3(this, _EventStream_resolveConnectedPromise, resolve, "f");
      __classPrivateFieldSet$3(this, _EventStream_rejectConnectedPromise, reject, "f");
    }), "f");
    __classPrivateFieldSet$3(this, _EventStream_endPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet$3(this, _EventStream_resolveEndPromise, resolve, "f");
      __classPrivateFieldSet$3(this, _EventStream_rejectEndPromise, reject, "f");
    }), "f");
    __classPrivateFieldGet$4(this, _EventStream_connectedPromise, "f").catch(() => {
    });
    __classPrivateFieldGet$4(this, _EventStream_endPromise, "f").catch(() => {
    });
  }
  _run(executor) {
    setTimeout(() => {
      executor().then(() => {
        this._emitFinal();
        this._emit("end");
      }, __classPrivateFieldGet$4(this, _EventStream_instances, "m", _EventStream_handleError).bind(this));
    }, 0);
  }
  _connected() {
    if (this.ended)
      return;
    __classPrivateFieldGet$4(this, _EventStream_resolveConnectedPromise, "f").call(this);
    this._emit("connect");
  }
  get ended() {
    return __classPrivateFieldGet$4(this, _EventStream_ended, "f");
  }
  get errored() {
    return __classPrivateFieldGet$4(this, _EventStream_errored, "f");
  }
  get aborted() {
    return __classPrivateFieldGet$4(this, _EventStream_aborted, "f");
  }
  abort() {
    this.controller.abort();
  }
  /**
   * Adds the listener function to the end of the listeners array for the event.
   * No checks are made to see if the listener has already been added. Multiple calls passing
   * the same combination of event and listener will result in the listener being added, and
   * called, multiple times.
   * @returns this ChatCompletionStream, so that calls can be chained
   */
  on(event, listener) {
    const listeners = __classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event] || (__classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event] = []);
    listeners.push({ listener });
    return this;
  }
  /**
   * Removes the specified listener from the listener array for the event.
   * off() will remove, at most, one instance of a listener from the listener array. If any single
   * listener has been added multiple times to the listener array for the specified event, then
   * off() must be called multiple times to remove each instance.
   * @returns this ChatCompletionStream, so that calls can be chained
   */
  off(event, listener) {
    const listeners = __classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event];
    if (!listeners)
      return this;
    const index = listeners.findIndex((l) => l.listener === listener);
    if (index >= 0)
      listeners.splice(index, 1);
    return this;
  }
  /**
   * Adds a one-time listener function for the event. The next time the event is triggered,
   * this listener is removed and then invoked.
   * @returns this ChatCompletionStream, so that calls can be chained
   */
  once(event, listener) {
    const listeners = __classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event] || (__classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event] = []);
    listeners.push({ listener, once: true });
    return this;
  }
  /**
   * This is similar to `.once()`, but returns a Promise that resolves the next time
   * the event is triggered, instead of calling a listener callback.
   * @returns a Promise that resolves the next time given event is triggered,
   * or rejects if an error is emitted.  (If you request the 'error' event,
   * returns a promise that resolves with the error).
   *
   * Example:
   *
   *   const message = await stream.emitted('message') // rejects if the stream errors
   */
  emitted(event) {
    return new Promise((resolve, reject) => {
      __classPrivateFieldSet$3(this, _EventStream_catchingPromiseCreated, true, "f");
      if (event !== "error")
        this.once("error", reject);
      this.once(event, resolve);
    });
  }
  async done() {
    __classPrivateFieldSet$3(this, _EventStream_catchingPromiseCreated, true, "f");
    await __classPrivateFieldGet$4(this, _EventStream_endPromise, "f");
  }
  _emit(event, ...args) {
    if (__classPrivateFieldGet$4(this, _EventStream_ended, "f")) {
      return;
    }
    if (event === "end") {
      __classPrivateFieldSet$3(this, _EventStream_ended, true, "f");
      __classPrivateFieldGet$4(this, _EventStream_resolveEndPromise, "f").call(this);
    }
    const listeners = __classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event];
    if (listeners) {
      __classPrivateFieldGet$4(this, _EventStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
      listeners.forEach(({ listener }) => listener(...args));
    }
    if (event === "abort") {
      const error = args[0];
      if (!__classPrivateFieldGet$4(this, _EventStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet$4(this, _EventStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet$4(this, _EventStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
      return;
    }
    if (event === "error") {
      const error = args[0];
      if (!__classPrivateFieldGet$4(this, _EventStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet$4(this, _EventStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet$4(this, _EventStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
    }
  }
  _emitFinal() {
  }
}
_EventStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _EventStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _EventStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _EventStream_endPromise = /* @__PURE__ */ new WeakMap(), _EventStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _EventStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _EventStream_listeners = /* @__PURE__ */ new WeakMap(), _EventStream_ended = /* @__PURE__ */ new WeakMap(), _EventStream_errored = /* @__PURE__ */ new WeakMap(), _EventStream_aborted = /* @__PURE__ */ new WeakMap(), _EventStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _EventStream_instances = /* @__PURE__ */ new WeakSet(), _EventStream_handleError = function _EventStream_handleError2(error) {
  __classPrivateFieldSet$3(this, _EventStream_errored, true, "f");
  if (error instanceof Error && error.name === "AbortError") {
    error = new APIUserAbortError();
  }
  if (error instanceof APIUserAbortError) {
    __classPrivateFieldSet$3(this, _EventStream_aborted, true, "f");
    return this._emit("abort", error);
  }
  if (error instanceof OpenAIError) {
    return this._emit("error", error);
  }
  if (error instanceof Error) {
    const openAIError = new OpenAIError(error.message);
    openAIError.cause = error;
    return this._emit("error", openAIError);
  }
  return this._emit("error", new OpenAIError(String(error)));
};
var __classPrivateFieldGet$3 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet$2 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var _AssistantStream_instances, _AssistantStream_events, _AssistantStream_runStepSnapshots, _AssistantStream_messageSnapshots, _AssistantStream_messageSnapshot, _AssistantStream_finalRun, _AssistantStream_currentContentIndex, _AssistantStream_currentContent, _AssistantStream_currentToolCallIndex, _AssistantStream_currentToolCall, _AssistantStream_currentEvent, _AssistantStream_currentRunSnapshot, _AssistantStream_currentRunStepSnapshot, _AssistantStream_addEvent, _AssistantStream_endRequest, _AssistantStream_handleMessage, _AssistantStream_handleRunStep, _AssistantStream_handleEvent, _AssistantStream_accumulateRunStep, _AssistantStream_accumulateMessage, _AssistantStream_accumulateContent, _AssistantStream_handleRun;
class AssistantStream extends EventStream {
  constructor() {
    super(...arguments);
    _AssistantStream_instances.add(this);
    _AssistantStream_events.set(this, []);
    _AssistantStream_runStepSnapshots.set(this, {});
    _AssistantStream_messageSnapshots.set(this, {});
    _AssistantStream_messageSnapshot.set(this, void 0);
    _AssistantStream_finalRun.set(this, void 0);
    _AssistantStream_currentContentIndex.set(this, void 0);
    _AssistantStream_currentContent.set(this, void 0);
    _AssistantStream_currentToolCallIndex.set(this, void 0);
    _AssistantStream_currentToolCall.set(this, void 0);
    _AssistantStream_currentEvent.set(this, void 0);
    _AssistantStream_currentRunSnapshot.set(this, void 0);
    _AssistantStream_currentRunStepSnapshot.set(this, void 0);
  }
  [(_AssistantStream_events = /* @__PURE__ */ new WeakMap(), _AssistantStream_runStepSnapshots = /* @__PURE__ */ new WeakMap(), _AssistantStream_messageSnapshots = /* @__PURE__ */ new WeakMap(), _AssistantStream_messageSnapshot = /* @__PURE__ */ new WeakMap(), _AssistantStream_finalRun = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentContentIndex = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentContent = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentToolCallIndex = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentToolCall = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentEvent = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentRunSnapshot = /* @__PURE__ */ new WeakMap(), _AssistantStream_currentRunStepSnapshot = /* @__PURE__ */ new WeakMap(), _AssistantStream_instances = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
    const pushQueue = [];
    const readQueue = [];
    let done = false;
    this.on("event", (event) => {
      const reader = readQueue.shift();
      if (reader) {
        reader.resolve(event);
      } else {
        pushQueue.push(event);
      }
    });
    this.on("end", () => {
      done = true;
      for (const reader of readQueue) {
        reader.resolve(void 0);
      }
      readQueue.length = 0;
    });
    this.on("abort", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    this.on("error", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    return {
      next: async () => {
        if (!pushQueue.length) {
          if (done) {
            return { value: void 0, done: true };
          }
          return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
        }
        const chunk = pushQueue.shift();
        return { value: chunk, done: false };
      },
      return: async () => {
        this.abort();
        return { value: void 0, done: true };
      }
    };
  }
  static fromReadableStream(stream) {
    const runner = new AssistantStream();
    runner._run(() => runner._fromReadableStream(stream));
    return runner;
  }
  async _fromReadableStream(readableStream, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    this._connected();
    const stream = Stream.fromReadableStream(readableStream, this.controller);
    for await (const event of stream) {
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return this._addRun(__classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
  }
  toReadableStream() {
    const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
    return stream.toReadableStream();
  }
  static createToolAssistantStream(threadId, runId, runs, params, options) {
    const runner = new AssistantStream();
    runner._run(() => runner._runToolAssistantStream(threadId, runId, runs, params, {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" }
    }));
    return runner;
  }
  async _createToolAssistantStream(run, threadId, runId, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    const body = { ...params, stream: true };
    const stream = await run.submitToolOutputs(threadId, runId, body, {
      ...options,
      signal: this.controller.signal
    });
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return this._addRun(__classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
  }
  static createThreadAssistantStream(params, thread, options) {
    const runner = new AssistantStream();
    runner._run(() => runner._threadAssistantStream(params, thread, {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" }
    }));
    return runner;
  }
  static createAssistantStream(threadId, runs, params, options) {
    const runner = new AssistantStream();
    runner._run(() => runner._runAssistantStream(threadId, runs, params, {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" }
    }));
    return runner;
  }
  currentEvent() {
    return __classPrivateFieldGet$3(this, _AssistantStream_currentEvent, "f");
  }
  currentRun() {
    return __classPrivateFieldGet$3(this, _AssistantStream_currentRunSnapshot, "f");
  }
  currentMessageSnapshot() {
    return __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f");
  }
  currentRunStepSnapshot() {
    return __classPrivateFieldGet$3(this, _AssistantStream_currentRunStepSnapshot, "f");
  }
  async finalRunSteps() {
    await this.done();
    return Object.values(__classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f"));
  }
  async finalMessages() {
    await this.done();
    return Object.values(__classPrivateFieldGet$3(this, _AssistantStream_messageSnapshots, "f"));
  }
  async finalRun() {
    await this.done();
    if (!__classPrivateFieldGet$3(this, _AssistantStream_finalRun, "f"))
      throw Error("Final run was not received.");
    return __classPrivateFieldGet$3(this, _AssistantStream_finalRun, "f");
  }
  async _createThreadAssistantStream(thread, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    const body = { ...params, stream: true };
    const stream = await thread.createAndRun(body, { ...options, signal: this.controller.signal });
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return this._addRun(__classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
  }
  async _createAssistantStream(run, threadId, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    const body = { ...params, stream: true };
    const stream = await run.create(threadId, body, { ...options, signal: this.controller.signal });
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_addEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return this._addRun(__classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_endRequest).call(this));
  }
  static accumulateDelta(acc, delta) {
    for (const [key, deltaValue] of Object.entries(delta)) {
      if (!acc.hasOwnProperty(key)) {
        acc[key] = deltaValue;
        continue;
      }
      let accValue = acc[key];
      if (accValue === null || accValue === void 0) {
        acc[key] = deltaValue;
        continue;
      }
      if (key === "index" || key === "type") {
        acc[key] = deltaValue;
        continue;
      }
      if (typeof accValue === "string" && typeof deltaValue === "string") {
        accValue += deltaValue;
      } else if (typeof accValue === "number" && typeof deltaValue === "number") {
        accValue += deltaValue;
      } else if (isObj(accValue) && isObj(deltaValue)) {
        accValue = this.accumulateDelta(accValue, deltaValue);
      } else if (Array.isArray(accValue) && Array.isArray(deltaValue)) {
        if (accValue.every((x) => typeof x === "string" || typeof x === "number")) {
          accValue.push(...deltaValue);
          continue;
        }
        for (const deltaEntry of deltaValue) {
          if (!isObj(deltaEntry)) {
            throw new Error(`Expected array delta entry to be an object but got: ${deltaEntry}`);
          }
          const index = deltaEntry["index"];
          if (index == null) {
            console.error(deltaEntry);
            throw new Error("Expected array delta entry to have an `index` property");
          }
          if (typeof index !== "number") {
            throw new Error(`Expected array delta entry \`index\` property to be a number but got ${index}`);
          }
          const accEntry = accValue[index];
          if (accEntry == null) {
            accValue.push(deltaEntry);
          } else {
            accValue[index] = this.accumulateDelta(accEntry, deltaEntry);
          }
        }
        continue;
      } else {
        throw Error(`Unhandled record type: ${key}, deltaValue: ${deltaValue}, accValue: ${accValue}`);
      }
      acc[key] = accValue;
    }
    return acc;
  }
  _addRun(run) {
    return run;
  }
  async _threadAssistantStream(params, thread, options) {
    return await this._createThreadAssistantStream(thread, params, options);
  }
  async _runAssistantStream(threadId, runs, params, options) {
    return await this._createAssistantStream(runs, threadId, params, options);
  }
  async _runToolAssistantStream(threadId, runId, runs, params, options) {
    return await this._createToolAssistantStream(runs, threadId, runId, params, options);
  }
}
_AssistantStream_addEvent = function _AssistantStream_addEvent2(event) {
  if (this.ended)
    return;
  __classPrivateFieldSet$2(this, _AssistantStream_currentEvent, event, "f");
  __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_handleEvent).call(this, event);
  switch (event.event) {
    case "thread.created":
      break;
    case "thread.run.created":
    case "thread.run.queued":
    case "thread.run.in_progress":
    case "thread.run.requires_action":
    case "thread.run.completed":
    case "thread.run.incomplete":
    case "thread.run.failed":
    case "thread.run.cancelling":
    case "thread.run.cancelled":
    case "thread.run.expired":
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_handleRun).call(this, event);
      break;
    case "thread.run.step.created":
    case "thread.run.step.in_progress":
    case "thread.run.step.delta":
    case "thread.run.step.completed":
    case "thread.run.step.failed":
    case "thread.run.step.cancelled":
    case "thread.run.step.expired":
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_handleRunStep).call(this, event);
      break;
    case "thread.message.created":
    case "thread.message.in_progress":
    case "thread.message.delta":
    case "thread.message.completed":
    case "thread.message.incomplete":
      __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_handleMessage).call(this, event);
      break;
    case "error":
      throw new Error("Encountered an error event in event processing - errors should be processed earlier");
  }
}, _AssistantStream_endRequest = function _AssistantStream_endRequest2() {
  if (this.ended) {
    throw new OpenAIError(`stream has ended, this shouldn't happen`);
  }
  if (!__classPrivateFieldGet$3(this, _AssistantStream_finalRun, "f"))
    throw Error("Final run has not been received");
  return __classPrivateFieldGet$3(this, _AssistantStream_finalRun, "f");
}, _AssistantStream_handleMessage = function _AssistantStream_handleMessage2(event) {
  const [accumulatedMessage, newContent] = __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_accumulateMessage).call(this, event, __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f"));
  __classPrivateFieldSet$2(this, _AssistantStream_messageSnapshot, accumulatedMessage, "f");
  __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshots, "f")[accumulatedMessage.id] = accumulatedMessage;
  for (const content of newContent) {
    const snapshotContent = accumulatedMessage.content[content.index];
    if (snapshotContent?.type == "text") {
      this._emit("textCreated", snapshotContent.text);
    }
  }
  switch (event.event) {
    case "thread.message.created":
      this._emit("messageCreated", event.data);
      break;
    case "thread.message.in_progress":
      break;
    case "thread.message.delta":
      this._emit("messageDelta", event.data.delta, accumulatedMessage);
      if (event.data.delta.content) {
        for (const content of event.data.delta.content) {
          if (content.type == "text" && content.text) {
            let textDelta = content.text;
            let snapshot = accumulatedMessage.content[content.index];
            if (snapshot && snapshot.type == "text") {
              this._emit("textDelta", textDelta, snapshot.text);
            } else {
              throw Error("The snapshot associated with this text delta is not text or missing");
            }
          }
          if (content.index != __classPrivateFieldGet$3(this, _AssistantStream_currentContentIndex, "f")) {
            if (__classPrivateFieldGet$3(this, _AssistantStream_currentContent, "f")) {
              switch (__classPrivateFieldGet$3(this, _AssistantStream_currentContent, "f").type) {
                case "text":
                  this._emit("textDone", __classPrivateFieldGet$3(this, _AssistantStream_currentContent, "f").text, __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f"));
                  break;
                case "image_file":
                  this._emit("imageFileDone", __classPrivateFieldGet$3(this, _AssistantStream_currentContent, "f").image_file, __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f"));
                  break;
              }
            }
            __classPrivateFieldSet$2(this, _AssistantStream_currentContentIndex, content.index, "f");
          }
          __classPrivateFieldSet$2(this, _AssistantStream_currentContent, accumulatedMessage.content[content.index], "f");
        }
      }
      break;
    case "thread.message.completed":
    case "thread.message.incomplete":
      if (__classPrivateFieldGet$3(this, _AssistantStream_currentContentIndex, "f") !== void 0) {
        const currentContent = event.data.content[__classPrivateFieldGet$3(this, _AssistantStream_currentContentIndex, "f")];
        if (currentContent) {
          switch (currentContent.type) {
            case "image_file":
              this._emit("imageFileDone", currentContent.image_file, __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f"));
              break;
            case "text":
              this._emit("textDone", currentContent.text, __classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f"));
              break;
          }
        }
      }
      if (__classPrivateFieldGet$3(this, _AssistantStream_messageSnapshot, "f")) {
        this._emit("messageDone", event.data);
      }
      __classPrivateFieldSet$2(this, _AssistantStream_messageSnapshot, void 0, "f");
  }
}, _AssistantStream_handleRunStep = function _AssistantStream_handleRunStep2(event) {
  const accumulatedRunStep = __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_accumulateRunStep).call(this, event);
  __classPrivateFieldSet$2(this, _AssistantStream_currentRunStepSnapshot, accumulatedRunStep, "f");
  switch (event.event) {
    case "thread.run.step.created":
      this._emit("runStepCreated", event.data);
      break;
    case "thread.run.step.delta":
      const delta = event.data.delta;
      if (delta.step_details && delta.step_details.type == "tool_calls" && delta.step_details.tool_calls && accumulatedRunStep.step_details.type == "tool_calls") {
        for (const toolCall of delta.step_details.tool_calls) {
          if (toolCall.index == __classPrivateFieldGet$3(this, _AssistantStream_currentToolCallIndex, "f")) {
            this._emit("toolCallDelta", toolCall, accumulatedRunStep.step_details.tool_calls[toolCall.index]);
          } else {
            if (__classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f")) {
              this._emit("toolCallDone", __classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f"));
            }
            __classPrivateFieldSet$2(this, _AssistantStream_currentToolCallIndex, toolCall.index, "f");
            __classPrivateFieldSet$2(this, _AssistantStream_currentToolCall, accumulatedRunStep.step_details.tool_calls[toolCall.index], "f");
            if (__classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f"))
              this._emit("toolCallCreated", __classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f"));
          }
        }
      }
      this._emit("runStepDelta", event.data.delta, accumulatedRunStep);
      break;
    case "thread.run.step.completed":
    case "thread.run.step.failed":
    case "thread.run.step.cancelled":
    case "thread.run.step.expired":
      __classPrivateFieldSet$2(this, _AssistantStream_currentRunStepSnapshot, void 0, "f");
      const details = event.data.step_details;
      if (details.type == "tool_calls") {
        if (__classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f")) {
          this._emit("toolCallDone", __classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f"));
          __classPrivateFieldSet$2(this, _AssistantStream_currentToolCall, void 0, "f");
        }
      }
      this._emit("runStepDone", event.data, accumulatedRunStep);
      break;
  }
}, _AssistantStream_handleEvent = function _AssistantStream_handleEvent2(event) {
  __classPrivateFieldGet$3(this, _AssistantStream_events, "f").push(event);
  this._emit("event", event);
}, _AssistantStream_accumulateRunStep = function _AssistantStream_accumulateRunStep2(event) {
  switch (event.event) {
    case "thread.run.step.created":
      __classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = event.data;
      return event.data;
    case "thread.run.step.delta":
      let snapshot = __classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
      if (!snapshot) {
        throw Error("Received a RunStepDelta before creation of a snapshot");
      }
      let data = event.data;
      if (data.delta) {
        const accumulated = AssistantStream.accumulateDelta(snapshot, data.delta);
        __classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = accumulated;
      }
      return __classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
    case "thread.run.step.completed":
    case "thread.run.step.failed":
    case "thread.run.step.cancelled":
    case "thread.run.step.expired":
    case "thread.run.step.in_progress":
      __classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id] = event.data;
      break;
  }
  if (__classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id])
    return __classPrivateFieldGet$3(this, _AssistantStream_runStepSnapshots, "f")[event.data.id];
  throw new Error("No snapshot available");
}, _AssistantStream_accumulateMessage = function _AssistantStream_accumulateMessage2(event, snapshot) {
  let newContent = [];
  switch (event.event) {
    case "thread.message.created":
      return [event.data, newContent];
    case "thread.message.delta":
      if (!snapshot) {
        throw Error("Received a delta with no existing snapshot (there should be one from message creation)");
      }
      let data = event.data;
      if (data.delta.content) {
        for (const contentElement of data.delta.content) {
          if (contentElement.index in snapshot.content) {
            let currentContent = snapshot.content[contentElement.index];
            snapshot.content[contentElement.index] = __classPrivateFieldGet$3(this, _AssistantStream_instances, "m", _AssistantStream_accumulateContent).call(this, contentElement, currentContent);
          } else {
            snapshot.content[contentElement.index] = contentElement;
            newContent.push(contentElement);
          }
        }
      }
      return [snapshot, newContent];
    case "thread.message.in_progress":
    case "thread.message.completed":
    case "thread.message.incomplete":
      if (snapshot) {
        return [snapshot, newContent];
      } else {
        throw Error("Received thread message event with no existing snapshot");
      }
  }
  throw Error("Tried to accumulate a non-message event");
}, _AssistantStream_accumulateContent = function _AssistantStream_accumulateContent2(contentElement, currentContent) {
  return AssistantStream.accumulateDelta(currentContent, contentElement);
}, _AssistantStream_handleRun = function _AssistantStream_handleRun2(event) {
  __classPrivateFieldSet$2(this, _AssistantStream_currentRunSnapshot, event.data, "f");
  switch (event.event) {
    case "thread.run.created":
      break;
    case "thread.run.queued":
      break;
    case "thread.run.in_progress":
      break;
    case "thread.run.requires_action":
    case "thread.run.cancelled":
    case "thread.run.failed":
    case "thread.run.completed":
    case "thread.run.expired":
      __classPrivateFieldSet$2(this, _AssistantStream_finalRun, event.data, "f");
      if (__classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f")) {
        this._emit("toolCallDone", __classPrivateFieldGet$3(this, _AssistantStream_currentToolCall, "f"));
        __classPrivateFieldSet$2(this, _AssistantStream_currentToolCall, void 0, "f");
      }
      break;
  }
};
class Assistants extends APIResource {
  /**
   * Create an assistant with a model and instructions.
   *
   * @example
   * ```ts
   * const assistant = await client.beta.assistants.create({
   *   model: 'gpt-4o',
   * });
   * ```
   */
  create(body, options) {
    return this._client.post("/assistants", {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Retrieves an assistant.
   *
   * @example
   * ```ts
   * const assistant = await client.beta.assistants.retrieve(
   *   'assistant_id',
   * );
   * ```
   */
  retrieve(assistantId, options) {
    return this._client.get(`/assistants/${assistantId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Modifies an assistant.
   *
   * @example
   * ```ts
   * const assistant = await client.beta.assistants.update(
   *   'assistant_id',
   * );
   * ```
   */
  update(assistantId, body, options) {
    return this._client.post(`/assistants/${assistantId}`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/assistants", AssistantsPage, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Delete an assistant.
   *
   * @example
   * ```ts
   * const assistantDeleted = await client.beta.assistants.del(
   *   'assistant_id',
   * );
   * ```
   */
  del(assistantId, options) {
    return this._client.delete(`/assistants/${assistantId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
}
class AssistantsPage extends CursorPage {
}
Assistants.AssistantsPage = AssistantsPage;
function isRunnableFunctionWithParse(fn) {
  return typeof fn.parse === "function";
}
const isAssistantMessage = (message) => {
  return message?.role === "assistant";
};
const isFunctionMessage = (message) => {
  return message?.role === "function";
};
const isToolMessage = (message) => {
  return message?.role === "tool";
};
function isAutoParsableResponseFormat(response_format) {
  return response_format?.["$brand"] === "auto-parseable-response-format";
}
function isAutoParsableTool$1(tool) {
  return tool?.["$brand"] === "auto-parseable-tool";
}
function maybeParseChatCompletion(completion, params) {
  if (!params || !hasAutoParseableInput$1(params)) {
    return {
      ...completion,
      choices: completion.choices.map((choice) => ({
        ...choice,
        message: {
          ...choice.message,
          parsed: null,
          ...choice.message.tool_calls ? {
            tool_calls: choice.message.tool_calls
          } : void 0
        }
      }))
    };
  }
  return parseChatCompletion(completion, params);
}
function parseChatCompletion(completion, params) {
  const choices = completion.choices.map((choice) => {
    if (choice.finish_reason === "length") {
      throw new LengthFinishReasonError();
    }
    if (choice.finish_reason === "content_filter") {
      throw new ContentFilterFinishReasonError();
    }
    return {
      ...choice,
      message: {
        ...choice.message,
        ...choice.message.tool_calls ? {
          tool_calls: choice.message.tool_calls?.map((toolCall) => parseToolCall$1(params, toolCall)) ?? void 0
        } : void 0,
        parsed: choice.message.content && !choice.message.refusal ? parseResponseFormat(params, choice.message.content) : null
      }
    };
  });
  return { ...completion, choices };
}
function parseResponseFormat(params, content) {
  if (params.response_format?.type !== "json_schema") {
    return null;
  }
  if (params.response_format?.type === "json_schema") {
    if ("$parseRaw" in params.response_format) {
      const response_format = params.response_format;
      return response_format.$parseRaw(content);
    }
    return JSON.parse(content);
  }
  return null;
}
function parseToolCall$1(params, toolCall) {
  const inputTool = params.tools?.find((inputTool2) => inputTool2.function?.name === toolCall.function.name);
  return {
    ...toolCall,
    function: {
      ...toolCall.function,
      parsed_arguments: isAutoParsableTool$1(inputTool) ? inputTool.$parseRaw(toolCall.function.arguments) : inputTool?.function.strict ? JSON.parse(toolCall.function.arguments) : null
    }
  };
}
function shouldParseToolCall(params, toolCall) {
  if (!params) {
    return false;
  }
  const inputTool = params.tools?.find((inputTool2) => inputTool2.function?.name === toolCall.function.name);
  return isAutoParsableTool$1(inputTool) || inputTool?.function.strict || false;
}
function hasAutoParseableInput$1(params) {
  if (isAutoParsableResponseFormat(params.response_format)) {
    return true;
  }
  return params.tools?.some((t) => isAutoParsableTool$1(t) || t.type === "function" && t.function.strict === true) ?? false;
}
function validateInputTools(tools) {
  for (const tool of tools ?? []) {
    if (tool.type !== "function") {
      throw new OpenAIError(`Currently only \`function\` tool types support auto-parsing; Received \`${tool.type}\``);
    }
    if (tool.function.strict !== true) {
      throw new OpenAIError(`The \`${tool.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`);
    }
  }
}
var __classPrivateFieldGet$2 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractChatCompletionRunner_instances, _AbstractChatCompletionRunner_getFinalContent, _AbstractChatCompletionRunner_getFinalMessage, _AbstractChatCompletionRunner_getFinalFunctionCall, _AbstractChatCompletionRunner_getFinalFunctionCallResult, _AbstractChatCompletionRunner_calculateTotalUsage, _AbstractChatCompletionRunner_validateParams, _AbstractChatCompletionRunner_stringifyFunctionCallResult;
const DEFAULT_MAX_CHAT_COMPLETIONS = 10;
class AbstractChatCompletionRunner extends EventStream {
  constructor() {
    super(...arguments);
    _AbstractChatCompletionRunner_instances.add(this);
    this._chatCompletions = [];
    this.messages = [];
  }
  _addChatCompletion(chatCompletion) {
    this._chatCompletions.push(chatCompletion);
    this._emit("chatCompletion", chatCompletion);
    const message = chatCompletion.choices[0]?.message;
    if (message)
      this._addMessage(message);
    return chatCompletion;
  }
  _addMessage(message, emit = true) {
    if (!("content" in message))
      message.content = null;
    this.messages.push(message);
    if (emit) {
      this._emit("message", message);
      if ((isFunctionMessage(message) || isToolMessage(message)) && message.content) {
        this._emit("functionCallResult", message.content);
      } else if (isAssistantMessage(message) && message.function_call) {
        this._emit("functionCall", message.function_call);
      } else if (isAssistantMessage(message) && message.tool_calls) {
        for (const tool_call of message.tool_calls) {
          if (tool_call.type === "function") {
            this._emit("functionCall", tool_call.function);
          }
        }
      }
    }
  }
  /**
   * @returns a promise that resolves with the final ChatCompletion, or rejects
   * if an error occurred or the stream ended prematurely without producing a ChatCompletion.
   */
  async finalChatCompletion() {
    await this.done();
    const completion = this._chatCompletions[this._chatCompletions.length - 1];
    if (!completion)
      throw new OpenAIError("stream ended without producing a ChatCompletion");
    return completion;
  }
  /**
   * @returns a promise that resolves with the content of the final ChatCompletionMessage, or rejects
   * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
   */
  async finalContent() {
    await this.done();
    return __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalContent).call(this);
  }
  /**
   * @returns a promise that resolves with the the final assistant ChatCompletionMessage response,
   * or rejects if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
   */
  async finalMessage() {
    await this.done();
    return __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this);
  }
  /**
   * @returns a promise that resolves with the content of the final FunctionCall, or rejects
   * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
   */
  async finalFunctionCall() {
    await this.done();
    return __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCall).call(this);
  }
  async finalFunctionCallResult() {
    await this.done();
    return __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCallResult).call(this);
  }
  async totalUsage() {
    await this.done();
    return __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_calculateTotalUsage).call(this);
  }
  allChatCompletions() {
    return [...this._chatCompletions];
  }
  _emitFinal() {
    const completion = this._chatCompletions[this._chatCompletions.length - 1];
    if (completion)
      this._emit("finalChatCompletion", completion);
    const finalMessage = __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this);
    if (finalMessage)
      this._emit("finalMessage", finalMessage);
    const finalContent = __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalContent).call(this);
    if (finalContent)
      this._emit("finalContent", finalContent);
    const finalFunctionCall = __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCall).call(this);
    if (finalFunctionCall)
      this._emit("finalFunctionCall", finalFunctionCall);
    const finalFunctionCallResult = __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalFunctionCallResult).call(this);
    if (finalFunctionCallResult != null)
      this._emit("finalFunctionCallResult", finalFunctionCallResult);
    if (this._chatCompletions.some((c) => c.usage)) {
      this._emit("totalUsage", __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_calculateTotalUsage).call(this));
    }
  }
  async _createChatCompletion(client, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_validateParams).call(this, params);
    const chatCompletion = await client.chat.completions.create({ ...params, stream: false }, { ...options, signal: this.controller.signal });
    this._connected();
    return this._addChatCompletion(parseChatCompletion(chatCompletion, params));
  }
  async _runChatCompletion(client, params, options) {
    for (const message of params.messages) {
      this._addMessage(message, false);
    }
    return await this._createChatCompletion(client, params, options);
  }
  async _runFunctions(client, params, options) {
    const role = "function";
    const { function_call = "auto", stream, ...restParams } = params;
    const singleFunctionToCall = typeof function_call !== "string" && function_call?.name;
    const { maxChatCompletions = DEFAULT_MAX_CHAT_COMPLETIONS } = options || {};
    const functionsByName = {};
    for (const f of params.functions) {
      functionsByName[f.name || f.function.name] = f;
    }
    const functions = params.functions.map((f) => ({
      name: f.name || f.function.name,
      parameters: f.parameters,
      description: f.description
    }));
    for (const message of params.messages) {
      this._addMessage(message, false);
    }
    for (let i = 0; i < maxChatCompletions; ++i) {
      const chatCompletion = await this._createChatCompletion(client, {
        ...restParams,
        function_call,
        functions,
        messages: [...this.messages]
      }, options);
      const message = chatCompletion.choices[0]?.message;
      if (!message) {
        throw new OpenAIError(`missing message in ChatCompletion response`);
      }
      if (!message.function_call)
        return;
      const { name, arguments: args } = message.function_call;
      const fn = functionsByName[name];
      if (!fn) {
        const content2 = `Invalid function_call: ${JSON.stringify(name)}. Available options are: ${functions.map((f) => JSON.stringify(f.name)).join(", ")}. Please try again`;
        this._addMessage({ role, name, content: content2 });
        continue;
      } else if (singleFunctionToCall && singleFunctionToCall !== name) {
        const content2 = `Invalid function_call: ${JSON.stringify(name)}. ${JSON.stringify(singleFunctionToCall)} requested. Please try again`;
        this._addMessage({ role, name, content: content2 });
        continue;
      }
      let parsed;
      try {
        parsed = isRunnableFunctionWithParse(fn) ? await fn.parse(args) : args;
      } catch (error) {
        this._addMessage({
          role,
          name,
          content: error instanceof Error ? error.message : String(error)
        });
        continue;
      }
      const rawContent = await fn.function(parsed, this);
      const content = __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_stringifyFunctionCallResult).call(this, rawContent);
      this._addMessage({ role, name, content });
      if (singleFunctionToCall)
        return;
    }
  }
  async _runTools(client, params, options) {
    const role = "tool";
    const { tool_choice = "auto", stream, ...restParams } = params;
    const singleFunctionToCall = typeof tool_choice !== "string" && tool_choice?.function?.name;
    const { maxChatCompletions = DEFAULT_MAX_CHAT_COMPLETIONS } = options || {};
    const inputTools = params.tools.map((tool) => {
      if (isAutoParsableTool$1(tool)) {
        if (!tool.$callback) {
          throw new OpenAIError("Tool given to `.runTools()` that does not have an associated function");
        }
        return {
          type: "function",
          function: {
            function: tool.$callback,
            name: tool.function.name,
            description: tool.function.description || "",
            parameters: tool.function.parameters,
            parse: tool.$parseRaw,
            strict: true
          }
        };
      }
      return tool;
    });
    const functionsByName = {};
    for (const f of inputTools) {
      if (f.type === "function") {
        functionsByName[f.function.name || f.function.function.name] = f.function;
      }
    }
    const tools = "tools" in params ? inputTools.map((t) => t.type === "function" ? {
      type: "function",
      function: {
        name: t.function.name || t.function.function.name,
        parameters: t.function.parameters,
        description: t.function.description,
        strict: t.function.strict
      }
    } : t) : void 0;
    for (const message of params.messages) {
      this._addMessage(message, false);
    }
    for (let i = 0; i < maxChatCompletions; ++i) {
      const chatCompletion = await this._createChatCompletion(client, {
        ...restParams,
        tool_choice,
        tools,
        messages: [...this.messages]
      }, options);
      const message = chatCompletion.choices[0]?.message;
      if (!message) {
        throw new OpenAIError(`missing message in ChatCompletion response`);
      }
      if (!message.tool_calls?.length) {
        return;
      }
      for (const tool_call of message.tool_calls) {
        if (tool_call.type !== "function")
          continue;
        const tool_call_id = tool_call.id;
        const { name, arguments: args } = tool_call.function;
        const fn = functionsByName[name];
        if (!fn) {
          const content2 = `Invalid tool_call: ${JSON.stringify(name)}. Available options are: ${Object.keys(functionsByName).map((name2) => JSON.stringify(name2)).join(", ")}. Please try again`;
          this._addMessage({ role, tool_call_id, content: content2 });
          continue;
        } else if (singleFunctionToCall && singleFunctionToCall !== name) {
          const content2 = `Invalid tool_call: ${JSON.stringify(name)}. ${JSON.stringify(singleFunctionToCall)} requested. Please try again`;
          this._addMessage({ role, tool_call_id, content: content2 });
          continue;
        }
        let parsed;
        try {
          parsed = isRunnableFunctionWithParse(fn) ? await fn.parse(args) : args;
        } catch (error) {
          const content2 = error instanceof Error ? error.message : String(error);
          this._addMessage({ role, tool_call_id, content: content2 });
          continue;
        }
        const rawContent = await fn.function(parsed, this);
        const content = __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_stringifyFunctionCallResult).call(this, rawContent);
        this._addMessage({ role, tool_call_id, content });
        if (singleFunctionToCall) {
          return;
        }
      }
    }
    return;
  }
}
_AbstractChatCompletionRunner_instances = /* @__PURE__ */ new WeakSet(), _AbstractChatCompletionRunner_getFinalContent = function _AbstractChatCompletionRunner_getFinalContent2() {
  return __classPrivateFieldGet$2(this, _AbstractChatCompletionRunner_instances, "m", _AbstractChatCompletionRunner_getFinalMessage).call(this).content ?? null;
}, _AbstractChatCompletionRunner_getFinalMessage = function _AbstractChatCompletionRunner_getFinalMessage2() {
  let i = this.messages.length;
  while (i-- > 0) {
    const message = this.messages[i];
    if (isAssistantMessage(message)) {
      const { function_call, ...rest } = message;
      const ret = {
        ...rest,
        content: message.content ?? null,
        refusal: message.refusal ?? null
      };
      if (function_call) {
        ret.function_call = function_call;
      }
      return ret;
    }
  }
  throw new OpenAIError("stream ended without producing a ChatCompletionMessage with role=assistant");
}, _AbstractChatCompletionRunner_getFinalFunctionCall = function _AbstractChatCompletionRunner_getFinalFunctionCall2() {
  for (let i = this.messages.length - 1; i >= 0; i--) {
    const message = this.messages[i];
    if (isAssistantMessage(message) && message?.function_call) {
      return message.function_call;
    }
    if (isAssistantMessage(message) && message?.tool_calls?.length) {
      return message.tool_calls.at(-1)?.function;
    }
  }
  return;
}, _AbstractChatCompletionRunner_getFinalFunctionCallResult = function _AbstractChatCompletionRunner_getFinalFunctionCallResult2() {
  for (let i = this.messages.length - 1; i >= 0; i--) {
    const message = this.messages[i];
    if (isFunctionMessage(message) && message.content != null) {
      return message.content;
    }
    if (isToolMessage(message) && message.content != null && typeof message.content === "string" && this.messages.some((x) => x.role === "assistant" && x.tool_calls?.some((y) => y.type === "function" && y.id === message.tool_call_id))) {
      return message.content;
    }
  }
  return;
}, _AbstractChatCompletionRunner_calculateTotalUsage = function _AbstractChatCompletionRunner_calculateTotalUsage2() {
  const total = {
    completion_tokens: 0,
    prompt_tokens: 0,
    total_tokens: 0
  };
  for (const { usage } of this._chatCompletions) {
    if (usage) {
      total.completion_tokens += usage.completion_tokens;
      total.prompt_tokens += usage.prompt_tokens;
      total.total_tokens += usage.total_tokens;
    }
  }
  return total;
}, _AbstractChatCompletionRunner_validateParams = function _AbstractChatCompletionRunner_validateParams2(params) {
  if (params.n != null && params.n > 1) {
    throw new OpenAIError("ChatCompletion convenience helpers only support n=1 at this time. To use n>1, please use chat.completions.create() directly.");
  }
}, _AbstractChatCompletionRunner_stringifyFunctionCallResult = function _AbstractChatCompletionRunner_stringifyFunctionCallResult2(rawContent) {
  return typeof rawContent === "string" ? rawContent : rawContent === void 0 ? "undefined" : JSON.stringify(rawContent);
};
class ChatCompletionRunner extends AbstractChatCompletionRunner {
  /** @deprecated - please use `runTools` instead. */
  static runFunctions(client, params, options) {
    const runner = new ChatCompletionRunner();
    const opts = {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "runFunctions" }
    };
    runner._run(() => runner._runFunctions(client, params, opts));
    return runner;
  }
  static runTools(client, params, options) {
    const runner = new ChatCompletionRunner();
    const opts = {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "runTools" }
    };
    runner._run(() => runner._runTools(client, params, opts));
    return runner;
  }
  _addMessage(message, emit = true) {
    super._addMessage(message, emit);
    if (isAssistantMessage(message) && message.content) {
      this._emit("content", message.content);
    }
  }
}
const STR = 1;
const NUM = 2;
const ARR = 4;
const OBJ = 8;
const NULL = 16;
const BOOL = 32;
const NAN = 64;
const INFINITY = 128;
const MINUS_INFINITY = 256;
const INF = INFINITY | MINUS_INFINITY;
const SPECIAL = NULL | BOOL | INF | NAN;
const ATOM = STR | NUM | SPECIAL;
const COLLECTION = ARR | OBJ;
const ALL = ATOM | COLLECTION;
const Allow = {
  STR,
  NUM,
  ARR,
  OBJ,
  NULL,
  BOOL,
  NAN,
  INFINITY,
  MINUS_INFINITY,
  INF,
  SPECIAL,
  ATOM,
  COLLECTION,
  ALL
};
class PartialJSON extends Error {
}
class MalformedJSON extends Error {
}
function parseJSON(jsonString, allowPartial = Allow.ALL) {
  if (typeof jsonString !== "string") {
    throw new TypeError(`expecting str, got ${typeof jsonString}`);
  }
  if (!jsonString.trim()) {
    throw new Error(`${jsonString} is empty`);
  }
  return _parseJSON(jsonString.trim(), allowPartial);
}
const _parseJSON = (jsonString, allow) => {
  const length = jsonString.length;
  let index = 0;
  const markPartialJSON = (msg) => {
    throw new PartialJSON(`${msg} at position ${index}`);
  };
  const throwMalformedError = (msg) => {
    throw new MalformedJSON(`${msg} at position ${index}`);
  };
  const parseAny = () => {
    skipBlank();
    if (index >= length)
      markPartialJSON("Unexpected end of input");
    if (jsonString[index] === '"')
      return parseStr();
    if (jsonString[index] === "{")
      return parseObj();
    if (jsonString[index] === "[")
      return parseArr();
    if (jsonString.substring(index, index + 4) === "null" || Allow.NULL & allow && length - index < 4 && "null".startsWith(jsonString.substring(index))) {
      index += 4;
      return null;
    }
    if (jsonString.substring(index, index + 4) === "true" || Allow.BOOL & allow && length - index < 4 && "true".startsWith(jsonString.substring(index))) {
      index += 4;
      return true;
    }
    if (jsonString.substring(index, index + 5) === "false" || Allow.BOOL & allow && length - index < 5 && "false".startsWith(jsonString.substring(index))) {
      index += 5;
      return false;
    }
    if (jsonString.substring(index, index + 8) === "Infinity" || Allow.INFINITY & allow && length - index < 8 && "Infinity".startsWith(jsonString.substring(index))) {
      index += 8;
      return Infinity;
    }
    if (jsonString.substring(index, index + 9) === "-Infinity" || Allow.MINUS_INFINITY & allow && 1 < length - index && length - index < 9 && "-Infinity".startsWith(jsonString.substring(index))) {
      index += 9;
      return -Infinity;
    }
    if (jsonString.substring(index, index + 3) === "NaN" || Allow.NAN & allow && length - index < 3 && "NaN".startsWith(jsonString.substring(index))) {
      index += 3;
      return NaN;
    }
    return parseNum();
  };
  const parseStr = () => {
    const start = index;
    let escape2 = false;
    index++;
    while (index < length && (jsonString[index] !== '"' || escape2 && jsonString[index - 1] === "\\")) {
      escape2 = jsonString[index] === "\\" ? !escape2 : false;
      index++;
    }
    if (jsonString.charAt(index) == '"') {
      try {
        return JSON.parse(jsonString.substring(start, ++index - Number(escape2)));
      } catch (e) {
        throwMalformedError(String(e));
      }
    } else if (Allow.STR & allow) {
      try {
        return JSON.parse(jsonString.substring(start, index - Number(escape2)) + '"');
      } catch (e) {
        return JSON.parse(jsonString.substring(start, jsonString.lastIndexOf("\\")) + '"');
      }
    }
    markPartialJSON("Unterminated string literal");
  };
  const parseObj = () => {
    index++;
    skipBlank();
    const obj = {};
    try {
      while (jsonString[index] !== "}") {
        skipBlank();
        if (index >= length && Allow.OBJ & allow)
          return obj;
        const key = parseStr();
        skipBlank();
        index++;
        try {
          const value = parseAny();
          Object.defineProperty(obj, key, { value, writable: true, enumerable: true, configurable: true });
        } catch (e) {
          if (Allow.OBJ & allow)
            return obj;
          else
            throw e;
        }
        skipBlank();
        if (jsonString[index] === ",")
          index++;
      }
    } catch (e) {
      if (Allow.OBJ & allow)
        return obj;
      else
        markPartialJSON("Expected '}' at end of object");
    }
    index++;
    return obj;
  };
  const parseArr = () => {
    index++;
    const arr = [];
    try {
      while (jsonString[index] !== "]") {
        arr.push(parseAny());
        skipBlank();
        if (jsonString[index] === ",") {
          index++;
        }
      }
    } catch (e) {
      if (Allow.ARR & allow) {
        return arr;
      }
      markPartialJSON("Expected ']' at end of array");
    }
    index++;
    return arr;
  };
  const parseNum = () => {
    if (index === 0) {
      if (jsonString === "-" && Allow.NUM & allow)
        markPartialJSON("Not sure what '-' is");
      try {
        return JSON.parse(jsonString);
      } catch (e) {
        if (Allow.NUM & allow) {
          try {
            if ("." === jsonString[jsonString.length - 1])
              return JSON.parse(jsonString.substring(0, jsonString.lastIndexOf(".")));
            return JSON.parse(jsonString.substring(0, jsonString.lastIndexOf("e")));
          } catch (e2) {
          }
        }
        throwMalformedError(String(e));
      }
    }
    const start = index;
    if (jsonString[index] === "-")
      index++;
    while (jsonString[index] && !",]}".includes(jsonString[index]))
      index++;
    if (index == length && !(Allow.NUM & allow))
      markPartialJSON("Unterminated number literal");
    try {
      return JSON.parse(jsonString.substring(start, index));
    } catch (e) {
      if (jsonString.substring(start, index) === "-" && Allow.NUM & allow)
        markPartialJSON("Not sure what '-' is");
      try {
        return JSON.parse(jsonString.substring(start, jsonString.lastIndexOf("e")));
      } catch (e2) {
        throwMalformedError(String(e2));
      }
    }
  };
  const skipBlank = () => {
    while (index < length && " \n\r	".includes(jsonString[index])) {
      index++;
    }
  };
  return parseAny();
};
const partialParse = (input) => parseJSON(input, Allow.ALL ^ Allow.NUM);
var __classPrivateFieldSet$1 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet$1 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ChatCompletionStream_instances, _ChatCompletionStream_params, _ChatCompletionStream_choiceEventStates, _ChatCompletionStream_currentChatCompletionSnapshot, _ChatCompletionStream_beginRequest, _ChatCompletionStream_getChoiceEventState, _ChatCompletionStream_addChunk, _ChatCompletionStream_emitToolCallDoneEvent, _ChatCompletionStream_emitContentDoneEvents, _ChatCompletionStream_endRequest, _ChatCompletionStream_getAutoParseableResponseFormat, _ChatCompletionStream_accumulateChatCompletion;
class ChatCompletionStream extends AbstractChatCompletionRunner {
  constructor(params) {
    super();
    _ChatCompletionStream_instances.add(this);
    _ChatCompletionStream_params.set(this, void 0);
    _ChatCompletionStream_choiceEventStates.set(this, void 0);
    _ChatCompletionStream_currentChatCompletionSnapshot.set(this, void 0);
    __classPrivateFieldSet$1(this, _ChatCompletionStream_params, params, "f");
    __classPrivateFieldSet$1(this, _ChatCompletionStream_choiceEventStates, [], "f");
  }
  get currentChatCompletionSnapshot() {
    return __classPrivateFieldGet$1(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
  }
  /**
   * Intended for use on the frontend, consuming a stream produced with
   * `.toReadableStream()` on the backend.
   *
   * Note that messages sent to the model do not appear in `.on('message')`
   * in this context.
   */
  static fromReadableStream(stream) {
    const runner = new ChatCompletionStream(null);
    runner._run(() => runner._fromReadableStream(stream));
    return runner;
  }
  static createChatCompletion(client, params, options) {
    const runner = new ChatCompletionStream(params);
    runner._run(() => runner._runChatCompletion(client, { ...params, stream: true }, { ...options, headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" } }));
    return runner;
  }
  async _createChatCompletion(client, params, options) {
    super._createChatCompletion;
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_beginRequest).call(this);
    const stream = await client.chat.completions.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
    this._connected();
    for await (const chunk of stream) {
      __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_addChunk).call(this, chunk);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return this._addChatCompletion(__classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
  }
  async _fromReadableStream(readableStream, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_beginRequest).call(this);
    this._connected();
    const stream = Stream.fromReadableStream(readableStream, this.controller);
    let chatId;
    for await (const chunk of stream) {
      if (chatId && chatId !== chunk.id) {
        this._addChatCompletion(__classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
      }
      __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_addChunk).call(this, chunk);
      chatId = chunk.id;
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return this._addChatCompletion(__classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_endRequest).call(this));
  }
  [(_ChatCompletionStream_params = /* @__PURE__ */ new WeakMap(), _ChatCompletionStream_choiceEventStates = /* @__PURE__ */ new WeakMap(), _ChatCompletionStream_currentChatCompletionSnapshot = /* @__PURE__ */ new WeakMap(), _ChatCompletionStream_instances = /* @__PURE__ */ new WeakSet(), _ChatCompletionStream_beginRequest = function _ChatCompletionStream_beginRequest2() {
    if (this.ended)
      return;
    __classPrivateFieldSet$1(this, _ChatCompletionStream_currentChatCompletionSnapshot, void 0, "f");
  }, _ChatCompletionStream_getChoiceEventState = function _ChatCompletionStream_getChoiceEventState2(choice) {
    let state = __classPrivateFieldGet$1(this, _ChatCompletionStream_choiceEventStates, "f")[choice.index];
    if (state) {
      return state;
    }
    state = {
      content_done: false,
      refusal_done: false,
      logprobs_content_done: false,
      logprobs_refusal_done: false,
      done_tool_calls: /* @__PURE__ */ new Set(),
      current_tool_call_index: null
    };
    __classPrivateFieldGet$1(this, _ChatCompletionStream_choiceEventStates, "f")[choice.index] = state;
    return state;
  }, _ChatCompletionStream_addChunk = function _ChatCompletionStream_addChunk2(chunk) {
    if (this.ended)
      return;
    const completion = __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_accumulateChatCompletion).call(this, chunk);
    this._emit("chunk", chunk, completion);
    for (const choice of chunk.choices) {
      const choiceSnapshot = completion.choices[choice.index];
      if (choice.delta.content != null && choiceSnapshot.message?.role === "assistant" && choiceSnapshot.message?.content) {
        this._emit("content", choice.delta.content, choiceSnapshot.message.content);
        this._emit("content.delta", {
          delta: choice.delta.content,
          snapshot: choiceSnapshot.message.content,
          parsed: choiceSnapshot.message.parsed
        });
      }
      if (choice.delta.refusal != null && choiceSnapshot.message?.role === "assistant" && choiceSnapshot.message?.refusal) {
        this._emit("refusal.delta", {
          delta: choice.delta.refusal,
          snapshot: choiceSnapshot.message.refusal
        });
      }
      if (choice.logprobs?.content != null && choiceSnapshot.message?.role === "assistant") {
        this._emit("logprobs.content.delta", {
          content: choice.logprobs?.content,
          snapshot: choiceSnapshot.logprobs?.content ?? []
        });
      }
      if (choice.logprobs?.refusal != null && choiceSnapshot.message?.role === "assistant") {
        this._emit("logprobs.refusal.delta", {
          refusal: choice.logprobs?.refusal,
          snapshot: choiceSnapshot.logprobs?.refusal ?? []
        });
      }
      const state = __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
      if (choiceSnapshot.finish_reason) {
        __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitContentDoneEvents).call(this, choiceSnapshot);
        if (state.current_tool_call_index != null) {
          __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitToolCallDoneEvent).call(this, choiceSnapshot, state.current_tool_call_index);
        }
      }
      for (const toolCall of choice.delta.tool_calls ?? []) {
        if (state.current_tool_call_index !== toolCall.index) {
          __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitContentDoneEvents).call(this, choiceSnapshot);
          if (state.current_tool_call_index != null) {
            __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_emitToolCallDoneEvent).call(this, choiceSnapshot, state.current_tool_call_index);
          }
        }
        state.current_tool_call_index = toolCall.index;
      }
      for (const toolCallDelta of choice.delta.tool_calls ?? []) {
        const toolCallSnapshot = choiceSnapshot.message.tool_calls?.[toolCallDelta.index];
        if (!toolCallSnapshot?.type) {
          continue;
        }
        if (toolCallSnapshot?.type === "function") {
          this._emit("tool_calls.function.arguments.delta", {
            name: toolCallSnapshot.function?.name,
            index: toolCallDelta.index,
            arguments: toolCallSnapshot.function.arguments,
            parsed_arguments: toolCallSnapshot.function.parsed_arguments,
            arguments_delta: toolCallDelta.function?.arguments ?? ""
          });
        } else {
          assertNever(toolCallSnapshot?.type);
        }
      }
    }
  }, _ChatCompletionStream_emitToolCallDoneEvent = function _ChatCompletionStream_emitToolCallDoneEvent2(choiceSnapshot, toolCallIndex) {
    const state = __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
    if (state.done_tool_calls.has(toolCallIndex)) {
      return;
    }
    const toolCallSnapshot = choiceSnapshot.message.tool_calls?.[toolCallIndex];
    if (!toolCallSnapshot) {
      throw new Error("no tool call snapshot");
    }
    if (!toolCallSnapshot.type) {
      throw new Error("tool call snapshot missing `type`");
    }
    if (toolCallSnapshot.type === "function") {
      const inputTool = __classPrivateFieldGet$1(this, _ChatCompletionStream_params, "f")?.tools?.find((tool) => tool.type === "function" && tool.function.name === toolCallSnapshot.function.name);
      this._emit("tool_calls.function.arguments.done", {
        name: toolCallSnapshot.function.name,
        index: toolCallIndex,
        arguments: toolCallSnapshot.function.arguments,
        parsed_arguments: isAutoParsableTool$1(inputTool) ? inputTool.$parseRaw(toolCallSnapshot.function.arguments) : inputTool?.function.strict ? JSON.parse(toolCallSnapshot.function.arguments) : null
      });
    } else {
      assertNever(toolCallSnapshot.type);
    }
  }, _ChatCompletionStream_emitContentDoneEvents = function _ChatCompletionStream_emitContentDoneEvents2(choiceSnapshot) {
    const state = __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getChoiceEventState).call(this, choiceSnapshot);
    if (choiceSnapshot.message.content && !state.content_done) {
      state.content_done = true;
      const responseFormat = __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getAutoParseableResponseFormat).call(this);
      this._emit("content.done", {
        content: choiceSnapshot.message.content,
        parsed: responseFormat ? responseFormat.$parseRaw(choiceSnapshot.message.content) : null
      });
    }
    if (choiceSnapshot.message.refusal && !state.refusal_done) {
      state.refusal_done = true;
      this._emit("refusal.done", { refusal: choiceSnapshot.message.refusal });
    }
    if (choiceSnapshot.logprobs?.content && !state.logprobs_content_done) {
      state.logprobs_content_done = true;
      this._emit("logprobs.content.done", { content: choiceSnapshot.logprobs.content });
    }
    if (choiceSnapshot.logprobs?.refusal && !state.logprobs_refusal_done) {
      state.logprobs_refusal_done = true;
      this._emit("logprobs.refusal.done", { refusal: choiceSnapshot.logprobs.refusal });
    }
  }, _ChatCompletionStream_endRequest = function _ChatCompletionStream_endRequest2() {
    if (this.ended) {
      throw new OpenAIError(`stream has ended, this shouldn't happen`);
    }
    const snapshot = __classPrivateFieldGet$1(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
    if (!snapshot) {
      throw new OpenAIError(`request ended without sending any chunks`);
    }
    __classPrivateFieldSet$1(this, _ChatCompletionStream_currentChatCompletionSnapshot, void 0, "f");
    __classPrivateFieldSet$1(this, _ChatCompletionStream_choiceEventStates, [], "f");
    return finalizeChatCompletion(snapshot, __classPrivateFieldGet$1(this, _ChatCompletionStream_params, "f"));
  }, _ChatCompletionStream_getAutoParseableResponseFormat = function _ChatCompletionStream_getAutoParseableResponseFormat2() {
    const responseFormat = __classPrivateFieldGet$1(this, _ChatCompletionStream_params, "f")?.response_format;
    if (isAutoParsableResponseFormat(responseFormat)) {
      return responseFormat;
    }
    return null;
  }, _ChatCompletionStream_accumulateChatCompletion = function _ChatCompletionStream_accumulateChatCompletion2(chunk) {
    var _a2, _b, _c, _d;
    let snapshot = __classPrivateFieldGet$1(this, _ChatCompletionStream_currentChatCompletionSnapshot, "f");
    const { choices, ...rest } = chunk;
    if (!snapshot) {
      snapshot = __classPrivateFieldSet$1(this, _ChatCompletionStream_currentChatCompletionSnapshot, {
        ...rest,
        choices: []
      }, "f");
    } else {
      Object.assign(snapshot, rest);
    }
    for (const { delta, finish_reason, index, logprobs = null, ...other } of chunk.choices) {
      let choice = snapshot.choices[index];
      if (!choice) {
        choice = snapshot.choices[index] = { finish_reason, index, message: {}, logprobs, ...other };
      }
      if (logprobs) {
        if (!choice.logprobs) {
          choice.logprobs = Object.assign({}, logprobs);
        } else {
          const { content: content2, refusal: refusal2, ...rest3 } = logprobs;
          Object.assign(choice.logprobs, rest3);
          if (content2) {
            (_a2 = choice.logprobs).content ?? (_a2.content = []);
            choice.logprobs.content.push(...content2);
          }
          if (refusal2) {
            (_b = choice.logprobs).refusal ?? (_b.refusal = []);
            choice.logprobs.refusal.push(...refusal2);
          }
        }
      }
      if (finish_reason) {
        choice.finish_reason = finish_reason;
        if (__classPrivateFieldGet$1(this, _ChatCompletionStream_params, "f") && hasAutoParseableInput$1(__classPrivateFieldGet$1(this, _ChatCompletionStream_params, "f"))) {
          if (finish_reason === "length") {
            throw new LengthFinishReasonError();
          }
          if (finish_reason === "content_filter") {
            throw new ContentFilterFinishReasonError();
          }
        }
      }
      Object.assign(choice, other);
      if (!delta)
        continue;
      const { content, refusal, function_call, role, tool_calls, ...rest2 } = delta;
      Object.assign(choice.message, rest2);
      if (refusal) {
        choice.message.refusal = (choice.message.refusal || "") + refusal;
      }
      if (role)
        choice.message.role = role;
      if (function_call) {
        if (!choice.message.function_call) {
          choice.message.function_call = function_call;
        } else {
          if (function_call.name)
            choice.message.function_call.name = function_call.name;
          if (function_call.arguments) {
            (_c = choice.message.function_call).arguments ?? (_c.arguments = "");
            choice.message.function_call.arguments += function_call.arguments;
          }
        }
      }
      if (content) {
        choice.message.content = (choice.message.content || "") + content;
        if (!choice.message.refusal && __classPrivateFieldGet$1(this, _ChatCompletionStream_instances, "m", _ChatCompletionStream_getAutoParseableResponseFormat).call(this)) {
          choice.message.parsed = partialParse(choice.message.content);
        }
      }
      if (tool_calls) {
        if (!choice.message.tool_calls)
          choice.message.tool_calls = [];
        for (const { index: index2, id, type, function: fn, ...rest3 } of tool_calls) {
          const tool_call = (_d = choice.message.tool_calls)[index2] ?? (_d[index2] = {});
          Object.assign(tool_call, rest3);
          if (id)
            tool_call.id = id;
          if (type)
            tool_call.type = type;
          if (fn)
            tool_call.function ?? (tool_call.function = { name: fn.name ?? "", arguments: "" });
          if (fn?.name)
            tool_call.function.name = fn.name;
          if (fn?.arguments) {
            tool_call.function.arguments += fn.arguments;
            if (shouldParseToolCall(__classPrivateFieldGet$1(this, _ChatCompletionStream_params, "f"), tool_call)) {
              tool_call.function.parsed_arguments = partialParse(tool_call.function.arguments);
            }
          }
        }
      }
    }
    return snapshot;
  }, Symbol.asyncIterator)]() {
    const pushQueue = [];
    const readQueue = [];
    let done = false;
    this.on("chunk", (chunk) => {
      const reader = readQueue.shift();
      if (reader) {
        reader.resolve(chunk);
      } else {
        pushQueue.push(chunk);
      }
    });
    this.on("end", () => {
      done = true;
      for (const reader of readQueue) {
        reader.resolve(void 0);
      }
      readQueue.length = 0;
    });
    this.on("abort", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    this.on("error", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    return {
      next: async () => {
        if (!pushQueue.length) {
          if (done) {
            return { value: void 0, done: true };
          }
          return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
        }
        const chunk = pushQueue.shift();
        return { value: chunk, done: false };
      },
      return: async () => {
        this.abort();
        return { value: void 0, done: true };
      }
    };
  }
  toReadableStream() {
    const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
    return stream.toReadableStream();
  }
}
function finalizeChatCompletion(snapshot, params) {
  const { id, choices, created, model, system_fingerprint, ...rest } = snapshot;
  const completion = {
    ...rest,
    id,
    choices: choices.map(({ message, finish_reason, index, logprobs, ...choiceRest }) => {
      if (!finish_reason) {
        throw new OpenAIError(`missing finish_reason for choice ${index}`);
      }
      const { content = null, function_call, tool_calls, ...messageRest } = message;
      const role = message.role;
      if (!role) {
        throw new OpenAIError(`missing role for choice ${index}`);
      }
      if (function_call) {
        const { arguments: args, name } = function_call;
        if (args == null) {
          throw new OpenAIError(`missing function_call.arguments for choice ${index}`);
        }
        if (!name) {
          throw new OpenAIError(`missing function_call.name for choice ${index}`);
        }
        return {
          ...choiceRest,
          message: {
            content,
            function_call: { arguments: args, name },
            role,
            refusal: message.refusal ?? null
          },
          finish_reason,
          index,
          logprobs
        };
      }
      if (tool_calls) {
        return {
          ...choiceRest,
          index,
          finish_reason,
          logprobs,
          message: {
            ...messageRest,
            role,
            content,
            refusal: message.refusal ?? null,
            tool_calls: tool_calls.map((tool_call, i) => {
              const { function: fn, type, id: id2, ...toolRest } = tool_call;
              const { arguments: args, name, ...fnRest } = fn || {};
              if (id2 == null) {
                throw new OpenAIError(`missing choices[${index}].tool_calls[${i}].id
${str(snapshot)}`);
              }
              if (type == null) {
                throw new OpenAIError(`missing choices[${index}].tool_calls[${i}].type
${str(snapshot)}`);
              }
              if (name == null) {
                throw new OpenAIError(`missing choices[${index}].tool_calls[${i}].function.name
${str(snapshot)}`);
              }
              if (args == null) {
                throw new OpenAIError(`missing choices[${index}].tool_calls[${i}].function.arguments
${str(snapshot)}`);
              }
              return { ...toolRest, id: id2, type, function: { ...fnRest, name, arguments: args } };
            })
          }
        };
      }
      return {
        ...choiceRest,
        message: { ...messageRest, content, role, refusal: message.refusal ?? null },
        finish_reason,
        index,
        logprobs
      };
    }),
    created,
    model,
    object: "chat.completion",
    ...system_fingerprint ? { system_fingerprint } : {}
  };
  return maybeParseChatCompletion(completion, params);
}
function str(x) {
  return JSON.stringify(x);
}
function assertNever(_x) {
}
class ChatCompletionStreamingRunner extends ChatCompletionStream {
  static fromReadableStream(stream) {
    const runner = new ChatCompletionStreamingRunner(null);
    runner._run(() => runner._fromReadableStream(stream));
    return runner;
  }
  /** @deprecated - please use `runTools` instead. */
  static runFunctions(client, params, options) {
    const runner = new ChatCompletionStreamingRunner(null);
    const opts = {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "runFunctions" }
    };
    runner._run(() => runner._runFunctions(client, params, opts));
    return runner;
  }
  static runTools(client, params, options) {
    const runner = new ChatCompletionStreamingRunner(
      // @ts-expect-error TODO these types are incompatible
      params
    );
    const opts = {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "runTools" }
    };
    runner._run(() => runner._runTools(client, params, opts));
    return runner;
  }
}
let Completions$1 = class Completions2 extends APIResource {
  parse(body, options) {
    validateInputTools(body.tools);
    return this._client.chat.completions.create(body, {
      ...options,
      headers: {
        ...options?.headers,
        "X-Stainless-Helper-Method": "beta.chat.completions.parse"
      }
    })._thenUnwrap((completion) => parseChatCompletion(completion, body));
  }
  runFunctions(body, options) {
    if (body.stream) {
      return ChatCompletionStreamingRunner.runFunctions(this._client, body, options);
    }
    return ChatCompletionRunner.runFunctions(this._client, body, options);
  }
  runTools(body, options) {
    if (body.stream) {
      return ChatCompletionStreamingRunner.runTools(this._client, body, options);
    }
    return ChatCompletionRunner.runTools(this._client, body, options);
  }
  /**
   * Creates a chat completion stream
   */
  stream(body, options) {
    return ChatCompletionStream.createChatCompletion(this._client, body, options);
  }
};
class Chat2 extends APIResource {
  constructor() {
    super(...arguments);
    this.completions = new Completions$1(this._client);
  }
}
(function(Chat3) {
  Chat3.Completions = Completions$1;
})(Chat2 || (Chat2 = {}));
class Sessions extends APIResource {
  /**
   * Create an ephemeral API token for use in client-side applications with the
   * Realtime API. Can be configured with the same session parameters as the
   * `session.update` client event.
   *
   * It responds with a session object, plus a `client_secret` key which contains a
   * usable ephemeral API token that can be used to authenticate browser clients for
   * the Realtime API.
   *
   * @example
   * ```ts
   * const session =
   *   await client.beta.realtime.sessions.create();
   * ```
   */
  create(body, options) {
    return this._client.post("/realtime/sessions", {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
}
class TranscriptionSessions extends APIResource {
  /**
   * Create an ephemeral API token for use in client-side applications with the
   * Realtime API specifically for realtime transcriptions. Can be configured with
   * the same session parameters as the `transcription_session.update` client event.
   *
   * It responds with a session object, plus a `client_secret` key which contains a
   * usable ephemeral API token that can be used to authenticate browser clients for
   * the Realtime API.
   *
   * @example
   * ```ts
   * const transcriptionSession =
   *   await client.beta.realtime.transcriptionSessions.create();
   * ```
   */
  create(body, options) {
    return this._client.post("/realtime/transcription_sessions", {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
}
class Realtime extends APIResource {
  constructor() {
    super(...arguments);
    this.sessions = new Sessions(this._client);
    this.transcriptionSessions = new TranscriptionSessions(this._client);
  }
}
Realtime.Sessions = Sessions;
Realtime.TranscriptionSessions = TranscriptionSessions;
class Messages2 extends APIResource {
  /**
   * Create a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  create(threadId, body, options) {
    return this._client.post(`/threads/${threadId}/messages`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Retrieve a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(threadId, messageId, options) {
    return this._client.get(`/threads/${threadId}/messages/${messageId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Modifies a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  update(threadId, messageId, body, options) {
    return this._client.post(`/threads/${threadId}/messages/${messageId}`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  list(threadId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(threadId, {}, query);
    }
    return this._client.getAPIList(`/threads/${threadId}/messages`, MessagesPage, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Deletes a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  del(threadId, messageId, options) {
    return this._client.delete(`/threads/${threadId}/messages/${messageId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
}
class MessagesPage extends CursorPage {
}
Messages2.MessagesPage = MessagesPage;
class Steps extends APIResource {
  retrieve(threadId, runId, stepId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.retrieve(threadId, runId, stepId, {}, query);
    }
    return this._client.get(`/threads/${threadId}/runs/${runId}/steps/${stepId}`, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  list(threadId, runId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(threadId, runId, {}, query);
    }
    return this._client.getAPIList(`/threads/${threadId}/runs/${runId}/steps`, RunStepsPage, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
}
class RunStepsPage extends CursorPage {
}
Steps.RunStepsPage = RunStepsPage;
let Runs$1 = class Runs extends APIResource {
  constructor() {
    super(...arguments);
    this.steps = new Steps(this._client);
  }
  create(threadId, params, options) {
    const { include, ...body } = params;
    return this._client.post(`/threads/${threadId}/runs`, {
      query: { include },
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers },
      stream: params.stream ?? false
    });
  }
  /**
   * Retrieves a run.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(threadId, runId, options) {
    return this._client.get(`/threads/${threadId}/runs/${runId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Modifies a run.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  update(threadId, runId, body, options) {
    return this._client.post(`/threads/${threadId}/runs/${runId}`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  list(threadId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(threadId, {}, query);
    }
    return this._client.getAPIList(`/threads/${threadId}/runs`, RunsPage, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Cancels a run that is `in_progress`.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  cancel(threadId, runId, options) {
    return this._client.post(`/threads/${threadId}/runs/${runId}/cancel`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * A helper to create a run an poll for a terminal state. More information on Run
   * lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async createAndPoll(threadId, body, options) {
    const run = await this.create(threadId, body, options);
    return await this.poll(threadId, run.id, options);
  }
  /**
   * Create a Run stream
   *
   * @deprecated use `stream` instead
   */
  createAndStream(threadId, body, options) {
    return AssistantStream.createAssistantStream(threadId, this._client.beta.threads.runs, body, options);
  }
  /**
   * A helper to poll a run status until it reaches a terminal state. More
   * information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async poll(threadId, runId, options) {
    const headers = { ...options?.headers, "X-Stainless-Poll-Helper": "true" };
    if (options?.pollIntervalMs) {
      headers["X-Stainless-Custom-Poll-Interval"] = options.pollIntervalMs.toString();
    }
    while (true) {
      const { data: run, response } = await this.retrieve(threadId, runId, {
        ...options,
        headers: { ...options?.headers, ...headers }
      }).withResponse();
      switch (run.status) {
        //If we are in any sort of intermediate state we poll
        case "queued":
        case "in_progress":
        case "cancelling":
          let sleepInterval = 5e3;
          if (options?.pollIntervalMs) {
            sleepInterval = options.pollIntervalMs;
          } else {
            const headerInterval = response.headers.get("openai-poll-after-ms");
            if (headerInterval) {
              const headerIntervalMs = parseInt(headerInterval);
              if (!isNaN(headerIntervalMs)) {
                sleepInterval = headerIntervalMs;
              }
            }
          }
          await sleep(sleepInterval);
          break;
        //We return the run in any terminal state.
        case "requires_action":
        case "incomplete":
        case "cancelled":
        case "completed":
        case "failed":
        case "expired":
          return run;
      }
    }
  }
  /**
   * Create a Run stream
   */
  stream(threadId, body, options) {
    return AssistantStream.createAssistantStream(threadId, this._client.beta.threads.runs, body, options);
  }
  submitToolOutputs(threadId, runId, body, options) {
    return this._client.post(`/threads/${threadId}/runs/${runId}/submit_tool_outputs`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers },
      stream: body.stream ?? false
    });
  }
  /**
   * A helper to submit a tool output to a run and poll for a terminal run state.
   * More information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async submitToolOutputsAndPoll(threadId, runId, body, options) {
    const run = await this.submitToolOutputs(threadId, runId, body, options);
    return await this.poll(threadId, run.id, options);
  }
  /**
   * Submit the tool outputs from a previous run and stream the run to a terminal
   * state. More information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  submitToolOutputsStream(threadId, runId, body, options) {
    return AssistantStream.createToolAssistantStream(threadId, runId, this._client.beta.threads.runs, body, options);
  }
};
class RunsPage extends CursorPage {
}
Runs$1.RunsPage = RunsPage;
Runs$1.Steps = Steps;
Runs$1.RunStepsPage = RunStepsPage;
class Threads extends APIResource {
  constructor() {
    super(...arguments);
    this.runs = new Runs$1(this._client);
    this.messages = new Messages2(this._client);
  }
  create(body = {}, options) {
    if (isRequestOptions(body)) {
      return this.create({}, body);
    }
    return this._client.post("/threads", {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Retrieves a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(threadId, options) {
    return this._client.get(`/threads/${threadId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Modifies a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  update(threadId, body, options) {
    return this._client.post(`/threads/${threadId}`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Delete a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  del(threadId, options) {
    return this._client.delete(`/threads/${threadId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  createAndRun(body, options) {
    return this._client.post("/threads/runs", {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers },
      stream: body.stream ?? false
    });
  }
  /**
   * A helper to create a thread, start a run and then poll for a terminal state.
   * More information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async createAndRunPoll(body, options) {
    const run = await this.createAndRun(body, options);
    return await this.runs.poll(run.thread_id, run.id, options);
  }
  /**
   * Create a thread and stream the run back
   */
  createAndRunStream(body, options) {
    return AssistantStream.createThreadAssistantStream(body, this._client.beta.threads, options);
  }
}
Threads.Runs = Runs$1;
Threads.RunsPage = RunsPage;
Threads.Messages = Messages2;
Threads.MessagesPage = MessagesPage;
class Beta extends APIResource {
  constructor() {
    super(...arguments);
    this.realtime = new Realtime(this._client);
    this.chat = new Chat2(this._client);
    this.assistants = new Assistants(this._client);
    this.threads = new Threads(this._client);
  }
}
Beta.Realtime = Realtime;
Beta.Assistants = Assistants;
Beta.AssistantsPage = AssistantsPage;
Beta.Threads = Threads;
class Completions3 extends APIResource {
  create(body, options) {
    return this._client.post("/completions", { body, ...options, stream: body.stream ?? false });
  }
}
class Content extends APIResource {
  /**
   * Retrieve Container File Content
   */
  retrieve(containerId, fileId, options) {
    return this._client.get(`/containers/${containerId}/files/${fileId}/content`, {
      ...options,
      headers: { Accept: "application/binary", ...options?.headers },
      __binaryResponse: true
    });
  }
}
let Files$2 = class Files extends APIResource {
  constructor() {
    super(...arguments);
    this.content = new Content(this._client);
  }
  /**
   * Create a Container File
   *
   * You can send either a multipart/form-data request with the raw file content, or
   * a JSON request with a file ID.
   */
  create(containerId, body, options) {
    return this._client.post(`/containers/${containerId}/files`, multipartFormRequestOptions({ body, ...options }));
  }
  /**
   * Retrieve Container File
   */
  retrieve(containerId, fileId, options) {
    return this._client.get(`/containers/${containerId}/files/${fileId}`, options);
  }
  list(containerId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(containerId, {}, query);
    }
    return this._client.getAPIList(`/containers/${containerId}/files`, FileListResponsesPage, {
      query,
      ...options
    });
  }
  /**
   * Delete Container File
   */
  del(containerId, fileId, options) {
    return this._client.delete(`/containers/${containerId}/files/${fileId}`, {
      ...options,
      headers: { Accept: "*/*", ...options?.headers }
    });
  }
};
class FileListResponsesPage extends CursorPage {
}
Files$2.FileListResponsesPage = FileListResponsesPage;
Files$2.Content = Content;
class Containers extends APIResource {
  constructor() {
    super(...arguments);
    this.files = new Files$2(this._client);
  }
  /**
   * Create Container
   */
  create(body, options) {
    return this._client.post("/containers", { body, ...options });
  }
  /**
   * Retrieve Container
   */
  retrieve(containerId, options) {
    return this._client.get(`/containers/${containerId}`, options);
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/containers", ContainerListResponsesPage, { query, ...options });
  }
  /**
   * Delete Container
   */
  del(containerId, options) {
    return this._client.delete(`/containers/${containerId}`, {
      ...options,
      headers: { Accept: "*/*", ...options?.headers }
    });
  }
}
class ContainerListResponsesPage extends CursorPage {
}
Containers.ContainerListResponsesPage = ContainerListResponsesPage;
Containers.Files = Files$2;
Containers.FileListResponsesPage = FileListResponsesPage;
class Embeddings extends APIResource {
  /**
   * Creates an embedding vector representing the input text.
   *
   * @example
   * ```ts
   * const createEmbeddingResponse =
   *   await client.embeddings.create({
   *     input: 'The quick brown fox jumped over the lazy dog',
   *     model: 'text-embedding-3-small',
   *   });
   * ```
   */
  create(body, options) {
    const hasUserProvidedEncodingFormat = !!body.encoding_format;
    let encoding_format = hasUserProvidedEncodingFormat ? body.encoding_format : "base64";
    if (hasUserProvidedEncodingFormat) {
      debug("Request", "User defined encoding_format:", body.encoding_format);
    }
    const response = this._client.post("/embeddings", {
      body: {
        ...body,
        encoding_format
      },
      ...options
    });
    if (hasUserProvidedEncodingFormat) {
      return response;
    }
    debug("response", "Decoding base64 embeddings to float32 array");
    return response._thenUnwrap((response2) => {
      if (response2 && response2.data) {
        response2.data.forEach((embeddingBase64Obj) => {
          const embeddingBase64Str = embeddingBase64Obj.embedding;
          embeddingBase64Obj.embedding = toFloat32Array(embeddingBase64Str);
        });
      }
      return response2;
    });
  }
}
class OutputItems extends APIResource {
  /**
   * Get an evaluation run output item by ID.
   */
  retrieve(evalId, runId, outputItemId, options) {
    return this._client.get(`/evals/${evalId}/runs/${runId}/output_items/${outputItemId}`, options);
  }
  list(evalId, runId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(evalId, runId, {}, query);
    }
    return this._client.getAPIList(`/evals/${evalId}/runs/${runId}/output_items`, OutputItemListResponsesPage, { query, ...options });
  }
}
class OutputItemListResponsesPage extends CursorPage {
}
OutputItems.OutputItemListResponsesPage = OutputItemListResponsesPage;
class Runs2 extends APIResource {
  constructor() {
    super(...arguments);
    this.outputItems = new OutputItems(this._client);
  }
  /**
   * Kicks off a new run for a given evaluation, specifying the data source, and what
   * model configuration to use to test. The datasource will be validated against the
   * schema specified in the config of the evaluation.
   */
  create(evalId, body, options) {
    return this._client.post(`/evals/${evalId}/runs`, { body, ...options });
  }
  /**
   * Get an evaluation run by ID.
   */
  retrieve(evalId, runId, options) {
    return this._client.get(`/evals/${evalId}/runs/${runId}`, options);
  }
  list(evalId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(evalId, {}, query);
    }
    return this._client.getAPIList(`/evals/${evalId}/runs`, RunListResponsesPage, { query, ...options });
  }
  /**
   * Delete an eval run.
   */
  del(evalId, runId, options) {
    return this._client.delete(`/evals/${evalId}/runs/${runId}`, options);
  }
  /**
   * Cancel an ongoing evaluation run.
   */
  cancel(evalId, runId, options) {
    return this._client.post(`/evals/${evalId}/runs/${runId}`, options);
  }
}
class RunListResponsesPage extends CursorPage {
}
Runs2.RunListResponsesPage = RunListResponsesPage;
Runs2.OutputItems = OutputItems;
Runs2.OutputItemListResponsesPage = OutputItemListResponsesPage;
class Evals extends APIResource {
  constructor() {
    super(...arguments);
    this.runs = new Runs2(this._client);
  }
  /**
   * Create the structure of an evaluation that can be used to test a model's
   * performance. An evaluation is a set of testing criteria and the config for a
   * data source, which dictates the schema of the data used in the evaluation. After
   * creating an evaluation, you can run it on different models and model parameters.
   * We support several types of graders and datasources. For more information, see
   * the [Evals guide](https://platform.openai.com/docs/guides/evals).
   */
  create(body, options) {
    return this._client.post("/evals", { body, ...options });
  }
  /**
   * Get an evaluation by ID.
   */
  retrieve(evalId, options) {
    return this._client.get(`/evals/${evalId}`, options);
  }
  /**
   * Update certain properties of an evaluation.
   */
  update(evalId, body, options) {
    return this._client.post(`/evals/${evalId}`, { body, ...options });
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/evals", EvalListResponsesPage, { query, ...options });
  }
  /**
   * Delete an evaluation.
   */
  del(evalId, options) {
    return this._client.delete(`/evals/${evalId}`, options);
  }
}
class EvalListResponsesPage extends CursorPage {
}
Evals.EvalListResponsesPage = EvalListResponsesPage;
Evals.Runs = Runs2;
Evals.RunListResponsesPage = RunListResponsesPage;
let Files$1 = class Files2 extends APIResource {
  /**
   * Upload a file that can be used across various endpoints. Individual files can be
   * up to 512 MB, and the size of all files uploaded by one organization can be up
   * to 100 GB.
   *
   * The Assistants API supports files up to 2 million tokens and of specific file
   * types. See the
   * [Assistants Tools guide](https://platform.openai.com/docs/assistants/tools) for
   * details.
   *
   * The Fine-tuning API only supports `.jsonl` files. The input also has certain
   * required formats for fine-tuning
   * [chat](https://platform.openai.com/docs/api-reference/fine-tuning/chat-input) or
   * [completions](https://platform.openai.com/docs/api-reference/fine-tuning/completions-input)
   * models.
   *
   * The Batch API only supports `.jsonl` files up to 200 MB in size. The input also
   * has a specific required
   * [format](https://platform.openai.com/docs/api-reference/batch/request-input).
   *
   * Please [contact us](https://help.openai.com/) if you need to increase these
   * storage limits.
   */
  create(body, options) {
    return this._client.post("/files", multipartFormRequestOptions({ body, ...options }));
  }
  /**
   * Returns information about a specific file.
   */
  retrieve(fileId, options) {
    return this._client.get(`/files/${fileId}`, options);
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/files", FileObjectsPage, { query, ...options });
  }
  /**
   * Delete a file.
   */
  del(fileId, options) {
    return this._client.delete(`/files/${fileId}`, options);
  }
  /**
   * Returns the contents of the specified file.
   */
  content(fileId, options) {
    return this._client.get(`/files/${fileId}/content`, {
      ...options,
      headers: { Accept: "application/binary", ...options?.headers },
      __binaryResponse: true
    });
  }
  /**
   * Returns the contents of the specified file.
   *
   * @deprecated The `.content()` method should be used instead
   */
  retrieveContent(fileId, options) {
    return this._client.get(`/files/${fileId}/content`, options);
  }
  /**
   * Waits for the given file to be processed, default timeout is 30 mins.
   */
  async waitForProcessing(id, { pollInterval = 5e3, maxWait = 30 * 60 * 1e3 } = {}) {
    const TERMINAL_STATES = /* @__PURE__ */ new Set(["processed", "error", "deleted"]);
    const start = Date.now();
    let file = await this.retrieve(id);
    while (!file.status || !TERMINAL_STATES.has(file.status)) {
      await sleep(pollInterval);
      file = await this.retrieve(id);
      if (Date.now() - start > maxWait) {
        throw new APIConnectionTimeoutError({
          message: `Giving up on waiting for file ${id} to finish processing after ${maxWait} milliseconds.`
        });
      }
    }
    return file;
  }
};
class FileObjectsPage extends CursorPage {
}
Files$1.FileObjectsPage = FileObjectsPage;
class Methods extends APIResource {
}
let Graders$1 = class Graders extends APIResource {
  /**
   * Run a grader.
   *
   * @example
   * ```ts
   * const response = await client.fineTuning.alpha.graders.run({
   *   grader: {
   *     input: 'input',
   *     name: 'name',
   *     operation: 'eq',
   *     reference: 'reference',
   *     type: 'string_check',
   *   },
   *   model_sample: 'model_sample',
   *   reference_answer: 'string',
   * });
   * ```
   */
  run(body, options) {
    return this._client.post("/fine_tuning/alpha/graders/run", { body, ...options });
  }
  /**
   * Validate a grader.
   *
   * @example
   * ```ts
   * const response =
   *   await client.fineTuning.alpha.graders.validate({
   *     grader: {
   *       input: 'input',
   *       name: 'name',
   *       operation: 'eq',
   *       reference: 'reference',
   *       type: 'string_check',
   *     },
   *   });
   * ```
   */
  validate(body, options) {
    return this._client.post("/fine_tuning/alpha/graders/validate", { body, ...options });
  }
};
class Alpha extends APIResource {
  constructor() {
    super(...arguments);
    this.graders = new Graders$1(this._client);
  }
}
Alpha.Graders = Graders$1;
class Permissions extends APIResource {
  /**
   * **NOTE:** Calling this endpoint requires an [admin API key](../admin-api-keys).
   *
   * This enables organization owners to share fine-tuned models with other projects
   * in their organization.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const permissionCreateResponse of client.fineTuning.checkpoints.permissions.create(
   *   'ft:gpt-4o-mini-2024-07-18:org:weather:B7R9VjQd',
   *   { project_ids: ['string'] },
   * )) {
   *   // ...
   * }
   * ```
   */
  create(fineTunedModelCheckpoint, body, options) {
    return this._client.getAPIList(`/fine_tuning/checkpoints/${fineTunedModelCheckpoint}/permissions`, PermissionCreateResponsesPage, { body, method: "post", ...options });
  }
  retrieve(fineTunedModelCheckpoint, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.retrieve(fineTunedModelCheckpoint, {}, query);
    }
    return this._client.get(`/fine_tuning/checkpoints/${fineTunedModelCheckpoint}/permissions`, {
      query,
      ...options
    });
  }
  /**
   * **NOTE:** This endpoint requires an [admin API key](../admin-api-keys).
   *
   * Organization owners can use this endpoint to delete a permission for a
   * fine-tuned model checkpoint.
   *
   * @example
   * ```ts
   * const permission =
   *   await client.fineTuning.checkpoints.permissions.del(
   *     'ft:gpt-4o-mini-2024-07-18:org:weather:B7R9VjQd',
   *     'cp_zc4Q7MP6XxulcVzj4MZdwsAB',
   *   );
   * ```
   */
  del(fineTunedModelCheckpoint, permissionId, options) {
    return this._client.delete(`/fine_tuning/checkpoints/${fineTunedModelCheckpoint}/permissions/${permissionId}`, options);
  }
}
class PermissionCreateResponsesPage extends Page {
}
Permissions.PermissionCreateResponsesPage = PermissionCreateResponsesPage;
let Checkpoints$1 = class Checkpoints extends APIResource {
  constructor() {
    super(...arguments);
    this.permissions = new Permissions(this._client);
  }
};
Checkpoints$1.Permissions = Permissions;
Checkpoints$1.PermissionCreateResponsesPage = PermissionCreateResponsesPage;
class Checkpoints2 extends APIResource {
  list(fineTuningJobId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(fineTuningJobId, {}, query);
    }
    return this._client.getAPIList(`/fine_tuning/jobs/${fineTuningJobId}/checkpoints`, FineTuningJobCheckpointsPage, { query, ...options });
  }
}
class FineTuningJobCheckpointsPage extends CursorPage {
}
Checkpoints2.FineTuningJobCheckpointsPage = FineTuningJobCheckpointsPage;
class Jobs extends APIResource {
  constructor() {
    super(...arguments);
    this.checkpoints = new Checkpoints2(this._client);
  }
  /**
   * Creates a fine-tuning job which begins the process of creating a new model from
   * a given dataset.
   *
   * Response includes details of the enqueued job including job status and the name
   * of the fine-tuned models once complete.
   *
   * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/fine-tuning)
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.create({
   *   model: 'gpt-4o-mini',
   *   training_file: 'file-abc123',
   * });
   * ```
   */
  create(body, options) {
    return this._client.post("/fine_tuning/jobs", { body, ...options });
  }
  /**
   * Get info about a fine-tuning job.
   *
   * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/fine-tuning)
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.retrieve(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  retrieve(fineTuningJobId, options) {
    return this._client.get(`/fine_tuning/jobs/${fineTuningJobId}`, options);
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/fine_tuning/jobs", FineTuningJobsPage, { query, ...options });
  }
  /**
   * Immediately cancel a fine-tune job.
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.cancel(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  cancel(fineTuningJobId, options) {
    return this._client.post(`/fine_tuning/jobs/${fineTuningJobId}/cancel`, options);
  }
  listEvents(fineTuningJobId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.listEvents(fineTuningJobId, {}, query);
    }
    return this._client.getAPIList(`/fine_tuning/jobs/${fineTuningJobId}/events`, FineTuningJobEventsPage, {
      query,
      ...options
    });
  }
  /**
   * Pause a fine-tune job.
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.pause(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  pause(fineTuningJobId, options) {
    return this._client.post(`/fine_tuning/jobs/${fineTuningJobId}/pause`, options);
  }
  /**
   * Resume a fine-tune job.
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.resume(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  resume(fineTuningJobId, options) {
    return this._client.post(`/fine_tuning/jobs/${fineTuningJobId}/resume`, options);
  }
}
class FineTuningJobsPage extends CursorPage {
}
class FineTuningJobEventsPage extends CursorPage {
}
Jobs.FineTuningJobsPage = FineTuningJobsPage;
Jobs.FineTuningJobEventsPage = FineTuningJobEventsPage;
Jobs.Checkpoints = Checkpoints2;
Jobs.FineTuningJobCheckpointsPage = FineTuningJobCheckpointsPage;
class FineTuning extends APIResource {
  constructor() {
    super(...arguments);
    this.methods = new Methods(this._client);
    this.jobs = new Jobs(this._client);
    this.checkpoints = new Checkpoints$1(this._client);
    this.alpha = new Alpha(this._client);
  }
}
FineTuning.Methods = Methods;
FineTuning.Jobs = Jobs;
FineTuning.FineTuningJobsPage = FineTuningJobsPage;
FineTuning.FineTuningJobEventsPage = FineTuningJobEventsPage;
FineTuning.Checkpoints = Checkpoints$1;
FineTuning.Alpha = Alpha;
class GraderModels extends APIResource {
}
class Graders2 extends APIResource {
  constructor() {
    super(...arguments);
    this.graderModels = new GraderModels(this._client);
  }
}
Graders2.GraderModels = GraderModels;
class Images extends APIResource {
  /**
   * Creates a variation of a given image. This endpoint only supports `dall-e-2`.
   *
   * @example
   * ```ts
   * const imagesResponse = await client.images.createVariation({
   *   image: fs.createReadStream('otter.png'),
   * });
   * ```
   */
  createVariation(body, options) {
    return this._client.post("/images/variations", multipartFormRequestOptions({ body, ...options }));
  }
  /**
   * Creates an edited or extended image given one or more source images and a
   * prompt. This endpoint only supports `gpt-image-1` and `dall-e-2`.
   *
   * @example
   * ```ts
   * const imagesResponse = await client.images.edit({
   *   image: fs.createReadStream('path/to/file'),
   *   prompt: 'A cute baby sea otter wearing a beret',
   * });
   * ```
   */
  edit(body, options) {
    return this._client.post("/images/edits", multipartFormRequestOptions({ body, ...options }));
  }
  /**
   * Creates an image given a prompt.
   * [Learn more](https://platform.openai.com/docs/guides/images).
   *
   * @example
   * ```ts
   * const imagesResponse = await client.images.generate({
   *   prompt: 'A cute baby sea otter',
   * });
   * ```
   */
  generate(body, options) {
    return this._client.post("/images/generations", { body, ...options });
  }
}
class Models extends APIResource {
  /**
   * Retrieves a model instance, providing basic information about the model such as
   * the owner and permissioning.
   */
  retrieve(model, options) {
    return this._client.get(`/models/${model}`, options);
  }
  /**
   * Lists the currently available models, and provides basic information about each
   * one such as the owner and availability.
   */
  list(options) {
    return this._client.getAPIList("/models", ModelsPage, options);
  }
  /**
   * Delete a fine-tuned model. You must have the Owner role in your organization to
   * delete a model.
   */
  del(model, options) {
    return this._client.delete(`/models/${model}`, options);
  }
}
class ModelsPage extends Page {
}
Models.ModelsPage = ModelsPage;
class Moderations extends APIResource {
  /**
   * Classifies if text and/or image inputs are potentially harmful. Learn more in
   * the [moderation guide](https://platform.openai.com/docs/guides/moderation).
   */
  create(body, options) {
    return this._client.post("/moderations", { body, ...options });
  }
}
function maybeParseResponse(response, params) {
  if (!params || !hasAutoParseableInput(params)) {
    return {
      ...response,
      output_parsed: null,
      output: response.output.map((item) => {
        if (item.type === "function_call") {
          return {
            ...item,
            parsed_arguments: null
          };
        }
        if (item.type === "message") {
          return {
            ...item,
            content: item.content.map((content) => ({
              ...content,
              parsed: null
            }))
          };
        } else {
          return item;
        }
      })
    };
  }
  return parseResponse(response, params);
}
function parseResponse(response, params) {
  const output = response.output.map((item) => {
    if (item.type === "function_call") {
      return {
        ...item,
        parsed_arguments: parseToolCall(params, item)
      };
    }
    if (item.type === "message") {
      const content = item.content.map((content2) => {
        if (content2.type === "output_text") {
          return {
            ...content2,
            parsed: parseTextFormat(params, content2.text)
          };
        }
        return content2;
      });
      return {
        ...item,
        content
      };
    }
    return item;
  });
  const parsed = Object.assign({}, response, { output });
  if (!Object.getOwnPropertyDescriptor(response, "output_text")) {
    addOutputText(parsed);
  }
  Object.defineProperty(parsed, "output_parsed", {
    enumerable: true,
    get() {
      for (const output2 of parsed.output) {
        if (output2.type !== "message") {
          continue;
        }
        for (const content of output2.content) {
          if (content.type === "output_text" && content.parsed !== null) {
            return content.parsed;
          }
        }
      }
      return null;
    }
  });
  return parsed;
}
function parseTextFormat(params, content) {
  if (params.text?.format?.type !== "json_schema") {
    return null;
  }
  if ("$parseRaw" in params.text?.format) {
    const text_format = params.text?.format;
    return text_format.$parseRaw(content);
  }
  return JSON.parse(content);
}
function hasAutoParseableInput(params) {
  if (isAutoParsableResponseFormat(params.text?.format)) {
    return true;
  }
  return false;
}
function isAutoParsableTool(tool) {
  return tool?.["$brand"] === "auto-parseable-tool";
}
function getInputToolByName(input_tools, name) {
  return input_tools.find((tool) => tool.type === "function" && tool.name === name);
}
function parseToolCall(params, toolCall) {
  const inputTool = getInputToolByName(params.tools ?? [], toolCall.name);
  return {
    ...toolCall,
    ...toolCall,
    parsed_arguments: isAutoParsableTool(inputTool) ? inputTool.$parseRaw(toolCall.arguments) : inputTool?.strict ? JSON.parse(toolCall.arguments) : null
  };
}
function addOutputText(rsp) {
  const texts = [];
  for (const output of rsp.output) {
    if (output.type !== "message") {
      continue;
    }
    for (const content of output.content) {
      if (content.type === "output_text") {
        texts.push(content.text);
      }
    }
  }
  rsp.output_text = texts.join("");
}
class InputItems extends APIResource {
  list(responseId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(responseId, {}, query);
    }
    return this._client.getAPIList(`/responses/${responseId}/input_items`, ResponseItemsPage, {
      query,
      ...options
    });
  }
}
var __classPrivateFieldSet = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ResponseStream_instances, _ResponseStream_params, _ResponseStream_currentResponseSnapshot, _ResponseStream_finalResponse, _ResponseStream_beginRequest, _ResponseStream_addEvent, _ResponseStream_endRequest, _ResponseStream_accumulateResponse;
class ResponseStream extends EventStream {
  constructor(params) {
    super();
    _ResponseStream_instances.add(this);
    _ResponseStream_params.set(this, void 0);
    _ResponseStream_currentResponseSnapshot.set(this, void 0);
    _ResponseStream_finalResponse.set(this, void 0);
    __classPrivateFieldSet(this, _ResponseStream_params, params, "f");
  }
  static createResponse(client, params, options) {
    const runner = new ResponseStream(params);
    runner._run(() => runner._createOrRetrieveResponse(client, params, {
      ...options,
      headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" }
    }));
    return runner;
  }
  async _createOrRetrieveResponse(client, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_beginRequest).call(this);
    let stream;
    let starting_after = null;
    if ("response_id" in params) {
      stream = await client.responses.retrieve(params.response_id, { stream: true }, { ...options, signal: this.controller.signal, stream: true });
      starting_after = params.starting_after ?? null;
    } else {
      stream = await client.responses.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
    }
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_addEvent).call(this, event, starting_after);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    return __classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_endRequest).call(this);
  }
  [(_ResponseStream_params = /* @__PURE__ */ new WeakMap(), _ResponseStream_currentResponseSnapshot = /* @__PURE__ */ new WeakMap(), _ResponseStream_finalResponse = /* @__PURE__ */ new WeakMap(), _ResponseStream_instances = /* @__PURE__ */ new WeakSet(), _ResponseStream_beginRequest = function _ResponseStream_beginRequest2() {
    if (this.ended)
      return;
    __classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, void 0, "f");
  }, _ResponseStream_addEvent = function _ResponseStream_addEvent2(event, starting_after) {
    if (this.ended)
      return;
    const maybeEmit = (name, event2) => {
      if (starting_after == null || event2.sequence_number > starting_after) {
        this._emit(name, event2);
      }
    };
    const response = __classPrivateFieldGet(this, _ResponseStream_instances, "m", _ResponseStream_accumulateResponse).call(this, event);
    maybeEmit("event", event);
    switch (event.type) {
      case "response.output_text.delta": {
        const output = response.output[event.output_index];
        if (!output) {
          throw new OpenAIError(`missing output at index ${event.output_index}`);
        }
        if (output.type === "message") {
          const content = output.content[event.content_index];
          if (!content) {
            throw new OpenAIError(`missing content at index ${event.content_index}`);
          }
          if (content.type !== "output_text") {
            throw new OpenAIError(`expected content to be 'output_text', got ${content.type}`);
          }
          maybeEmit("response.output_text.delta", {
            ...event,
            snapshot: content.text
          });
        }
        break;
      }
      case "response.function_call_arguments.delta": {
        const output = response.output[event.output_index];
        if (!output) {
          throw new OpenAIError(`missing output at index ${event.output_index}`);
        }
        if (output.type === "function_call") {
          maybeEmit("response.function_call_arguments.delta", {
            ...event,
            snapshot: output.arguments
          });
        }
        break;
      }
      default:
        maybeEmit(event.type, event);
        break;
    }
  }, _ResponseStream_endRequest = function _ResponseStream_endRequest2() {
    if (this.ended) {
      throw new OpenAIError(`stream has ended, this shouldn't happen`);
    }
    const snapshot = __classPrivateFieldGet(this, _ResponseStream_currentResponseSnapshot, "f");
    if (!snapshot) {
      throw new OpenAIError(`request ended without sending any events`);
    }
    __classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, void 0, "f");
    const parsedResponse = finalizeResponse(snapshot, __classPrivateFieldGet(this, _ResponseStream_params, "f"));
    __classPrivateFieldSet(this, _ResponseStream_finalResponse, parsedResponse, "f");
    return parsedResponse;
  }, _ResponseStream_accumulateResponse = function _ResponseStream_accumulateResponse2(event) {
    let snapshot = __classPrivateFieldGet(this, _ResponseStream_currentResponseSnapshot, "f");
    if (!snapshot) {
      if (event.type !== "response.created") {
        throw new OpenAIError(`When snapshot hasn't been set yet, expected 'response.created' event, got ${event.type}`);
      }
      snapshot = __classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, event.response, "f");
      return snapshot;
    }
    switch (event.type) {
      case "response.output_item.added": {
        snapshot.output.push(event.item);
        break;
      }
      case "response.content_part.added": {
        const output = snapshot.output[event.output_index];
        if (!output) {
          throw new OpenAIError(`missing output at index ${event.output_index}`);
        }
        if (output.type === "message") {
          output.content.push(event.part);
        }
        break;
      }
      case "response.output_text.delta": {
        const output = snapshot.output[event.output_index];
        if (!output) {
          throw new OpenAIError(`missing output at index ${event.output_index}`);
        }
        if (output.type === "message") {
          const content = output.content[event.content_index];
          if (!content) {
            throw new OpenAIError(`missing content at index ${event.content_index}`);
          }
          if (content.type !== "output_text") {
            throw new OpenAIError(`expected content to be 'output_text', got ${content.type}`);
          }
          content.text += event.delta;
        }
        break;
      }
      case "response.function_call_arguments.delta": {
        const output = snapshot.output[event.output_index];
        if (!output) {
          throw new OpenAIError(`missing output at index ${event.output_index}`);
        }
        if (output.type === "function_call") {
          output.arguments += event.delta;
        }
        break;
      }
      case "response.completed": {
        __classPrivateFieldSet(this, _ResponseStream_currentResponseSnapshot, event.response, "f");
        break;
      }
    }
    return snapshot;
  }, Symbol.asyncIterator)]() {
    const pushQueue = [];
    const readQueue = [];
    let done = false;
    this.on("event", (event) => {
      const reader = readQueue.shift();
      if (reader) {
        reader.resolve(event);
      } else {
        pushQueue.push(event);
      }
    });
    this.on("end", () => {
      done = true;
      for (const reader of readQueue) {
        reader.resolve(void 0);
      }
      readQueue.length = 0;
    });
    this.on("abort", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    this.on("error", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    return {
      next: async () => {
        if (!pushQueue.length) {
          if (done) {
            return { value: void 0, done: true };
          }
          return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((event2) => event2 ? { value: event2, done: false } : { value: void 0, done: true });
        }
        const event = pushQueue.shift();
        return { value: event, done: false };
      },
      return: async () => {
        this.abort();
        return { value: void 0, done: true };
      }
    };
  }
  /**
   * @returns a promise that resolves with the final Response, or rejects
   * if an error occurred or the stream ended prematurely without producing a REsponse.
   */
  async finalResponse() {
    await this.done();
    const response = __classPrivateFieldGet(this, _ResponseStream_finalResponse, "f");
    if (!response)
      throw new OpenAIError("stream ended without producing a ChatCompletion");
    return response;
  }
}
function finalizeResponse(snapshot, params) {
  return maybeParseResponse(snapshot, params);
}
class Responses extends APIResource {
  constructor() {
    super(...arguments);
    this.inputItems = new InputItems(this._client);
  }
  create(body, options) {
    return this._client.post("/responses", { body, ...options, stream: body.stream ?? false })._thenUnwrap((rsp) => {
      if ("object" in rsp && rsp.object === "response") {
        addOutputText(rsp);
      }
      return rsp;
    });
  }
  retrieve(responseId, query = {}, options) {
    return this._client.get(`/responses/${responseId}`, {
      query,
      ...options,
      stream: query?.stream ?? false
    });
  }
  /**
   * Deletes a model response with the given ID.
   *
   * @example
   * ```ts
   * await client.responses.del(
   *   'resp_677efb5139a88190b512bc3fef8e535d',
   * );
   * ```
   */
  del(responseId, options) {
    return this._client.delete(`/responses/${responseId}`, {
      ...options,
      headers: { Accept: "*/*", ...options?.headers }
    });
  }
  parse(body, options) {
    return this._client.responses.create(body, options)._thenUnwrap((response) => parseResponse(response, body));
  }
  /**
   * Creates a model response stream
   */
  stream(body, options) {
    return ResponseStream.createResponse(this._client, body, options);
  }
  /**
   * Cancels a model response with the given ID. Only responses created with the
   * `background` parameter set to `true` can be cancelled.
   * [Learn more](https://platform.openai.com/docs/guides/background).
   *
   * @example
   * ```ts
   * await client.responses.cancel(
   *   'resp_677efb5139a88190b512bc3fef8e535d',
   * );
   * ```
   */
  cancel(responseId, options) {
    return this._client.post(`/responses/${responseId}/cancel`, {
      ...options,
      headers: { Accept: "*/*", ...options?.headers }
    });
  }
}
class ResponseItemsPage extends CursorPage {
}
Responses.InputItems = InputItems;
class Parts extends APIResource {
  /**
   * Adds a
   * [Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
   * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
   * A Part represents a chunk of bytes from the file you are trying to upload.
   *
   * Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
   * maximum of 8 GB.
   *
   * It is possible to add multiple Parts in parallel. You can decide the intended
   * order of the Parts when you
   * [complete the Upload](https://platform.openai.com/docs/api-reference/uploads/complete).
   */
  create(uploadId, body, options) {
    return this._client.post(`/uploads/${uploadId}/parts`, multipartFormRequestOptions({ body, ...options }));
  }
}
class Uploads extends APIResource {
  constructor() {
    super(...arguments);
    this.parts = new Parts(this._client);
  }
  /**
   * Creates an intermediate
   * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
   * that you can add
   * [Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
   * Currently, an Upload can accept at most 8 GB in total and expires after an hour
   * after you create it.
   *
   * Once you complete the Upload, we will create a
   * [File](https://platform.openai.com/docs/api-reference/files/object) object that
   * contains all the parts you uploaded. This File is usable in the rest of our
   * platform as a regular File object.
   *
   * For certain `purpose` values, the correct `mime_type` must be specified. Please
   * refer to documentation for the
   * [supported MIME types for your use case](https://platform.openai.com/docs/assistants/tools/file-search#supported-files).
   *
   * For guidance on the proper filename extensions for each purpose, please follow
   * the documentation on
   * [creating a File](https://platform.openai.com/docs/api-reference/files/create).
   */
  create(body, options) {
    return this._client.post("/uploads", { body, ...options });
  }
  /**
   * Cancels the Upload. No Parts may be added after an Upload is cancelled.
   */
  cancel(uploadId, options) {
    return this._client.post(`/uploads/${uploadId}/cancel`, options);
  }
  /**
   * Completes the
   * [Upload](https://platform.openai.com/docs/api-reference/uploads/object).
   *
   * Within the returned Upload object, there is a nested
   * [File](https://platform.openai.com/docs/api-reference/files/object) object that
   * is ready to use in the rest of the platform.
   *
   * You can specify the order of the Parts by passing in an ordered list of the Part
   * IDs.
   *
   * The number of bytes uploaded upon completion must match the number of bytes
   * initially specified when creating the Upload object. No Parts may be added after
   * an Upload is completed.
   */
  complete(uploadId, body, options) {
    return this._client.post(`/uploads/${uploadId}/complete`, { body, ...options });
  }
}
Uploads.Parts = Parts;
const allSettledWithThrow = async (promises) => {
  const results = await Promise.allSettled(promises);
  const rejected = results.filter((result2) => result2.status === "rejected");
  if (rejected.length) {
    for (const result2 of rejected) {
      console.error(result2.reason);
    }
    throw new Error(`${rejected.length} promise(s) failed - see the above errors`);
  }
  const values = [];
  for (const result2 of results) {
    if (result2.status === "fulfilled") {
      values.push(result2.value);
    }
  }
  return values;
};
class Files3 extends APIResource {
  /**
   * Create a vector store file by attaching a
   * [File](https://platform.openai.com/docs/api-reference/files) to a
   * [vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).
   */
  create(vectorStoreId, body, options) {
    return this._client.post(`/vector_stores/${vectorStoreId}/files`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Retrieves a vector store file.
   */
  retrieve(vectorStoreId, fileId, options) {
    return this._client.get(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Update attributes on a vector store file.
   */
  update(vectorStoreId, fileId, body, options) {
    return this._client.post(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  list(vectorStoreId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list(vectorStoreId, {}, query);
    }
    return this._client.getAPIList(`/vector_stores/${vectorStoreId}/files`, VectorStoreFilesPage, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Delete a vector store file. This will remove the file from the vector store but
   * the file itself will not be deleted. To delete the file, use the
   * [delete file](https://platform.openai.com/docs/api-reference/files/delete)
   * endpoint.
   */
  del(vectorStoreId, fileId, options) {
    return this._client.delete(`/vector_stores/${vectorStoreId}/files/${fileId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Attach a file to the given vector store and wait for it to be processed.
   */
  async createAndPoll(vectorStoreId, body, options) {
    const file = await this.create(vectorStoreId, body, options);
    return await this.poll(vectorStoreId, file.id, options);
  }
  /**
   * Wait for the vector store file to finish processing.
   *
   * Note: this will return even if the file failed to process, you need to check
   * file.last_error and file.status to handle these cases
   */
  async poll(vectorStoreId, fileId, options) {
    const headers = { ...options?.headers, "X-Stainless-Poll-Helper": "true" };
    if (options?.pollIntervalMs) {
      headers["X-Stainless-Custom-Poll-Interval"] = options.pollIntervalMs.toString();
    }
    while (true) {
      const fileResponse = await this.retrieve(vectorStoreId, fileId, {
        ...options,
        headers
      }).withResponse();
      const file = fileResponse.data;
      switch (file.status) {
        case "in_progress":
          let sleepInterval = 5e3;
          if (options?.pollIntervalMs) {
            sleepInterval = options.pollIntervalMs;
          } else {
            const headerInterval = fileResponse.response.headers.get("openai-poll-after-ms");
            if (headerInterval) {
              const headerIntervalMs = parseInt(headerInterval);
              if (!isNaN(headerIntervalMs)) {
                sleepInterval = headerIntervalMs;
              }
            }
          }
          await sleep(sleepInterval);
          break;
        case "failed":
        case "completed":
          return file;
      }
    }
  }
  /**
   * Upload a file to the `files` API and then attach it to the given vector store.
   *
   * Note the file will be asynchronously processed (you can use the alternative
   * polling helper method to wait for processing to complete).
   */
  async upload(vectorStoreId, file, options) {
    const fileInfo = await this._client.files.create({ file, purpose: "assistants" }, options);
    return this.create(vectorStoreId, { file_id: fileInfo.id }, options);
  }
  /**
   * Add a file to a vector store and poll until processing is complete.
   */
  async uploadAndPoll(vectorStoreId, file, options) {
    const fileInfo = await this.upload(vectorStoreId, file, options);
    return await this.poll(vectorStoreId, fileInfo.id, options);
  }
  /**
   * Retrieve the parsed contents of a vector store file.
   */
  content(vectorStoreId, fileId, options) {
    return this._client.getAPIList(`/vector_stores/${vectorStoreId}/files/${fileId}/content`, FileContentResponsesPage, { ...options, headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers } });
  }
}
class VectorStoreFilesPage extends CursorPage {
}
class FileContentResponsesPage extends Page {
}
Files3.VectorStoreFilesPage = VectorStoreFilesPage;
Files3.FileContentResponsesPage = FileContentResponsesPage;
class FileBatches extends APIResource {
  /**
   * Create a vector store file batch.
   */
  create(vectorStoreId, body, options) {
    return this._client.post(`/vector_stores/${vectorStoreId}/file_batches`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Retrieves a vector store file batch.
   */
  retrieve(vectorStoreId, batchId, options) {
    return this._client.get(`/vector_stores/${vectorStoreId}/file_batches/${batchId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Cancel a vector store file batch. This attempts to cancel the processing of
   * files in this batch as soon as possible.
   */
  cancel(vectorStoreId, batchId, options) {
    return this._client.post(`/vector_stores/${vectorStoreId}/file_batches/${batchId}/cancel`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Create a vector store batch and poll until all files have been processed.
   */
  async createAndPoll(vectorStoreId, body, options) {
    const batch = await this.create(vectorStoreId, body);
    return await this.poll(vectorStoreId, batch.id, options);
  }
  listFiles(vectorStoreId, batchId, query = {}, options) {
    if (isRequestOptions(query)) {
      return this.listFiles(vectorStoreId, batchId, {}, query);
    }
    return this._client.getAPIList(`/vector_stores/${vectorStoreId}/file_batches/${batchId}/files`, VectorStoreFilesPage, { query, ...options, headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers } });
  }
  /**
   * Wait for the given file batch to be processed.
   *
   * Note: this will return even if one of the files failed to process, you need to
   * check batch.file_counts.failed_count to handle this case.
   */
  async poll(vectorStoreId, batchId, options) {
    const headers = { ...options?.headers, "X-Stainless-Poll-Helper": "true" };
    if (options?.pollIntervalMs) {
      headers["X-Stainless-Custom-Poll-Interval"] = options.pollIntervalMs.toString();
    }
    while (true) {
      const { data: batch, response } = await this.retrieve(vectorStoreId, batchId, {
        ...options,
        headers
      }).withResponse();
      switch (batch.status) {
        case "in_progress":
          let sleepInterval = 5e3;
          if (options?.pollIntervalMs) {
            sleepInterval = options.pollIntervalMs;
          } else {
            const headerInterval = response.headers.get("openai-poll-after-ms");
            if (headerInterval) {
              const headerIntervalMs = parseInt(headerInterval);
              if (!isNaN(headerIntervalMs)) {
                sleepInterval = headerIntervalMs;
              }
            }
          }
          await sleep(sleepInterval);
          break;
        case "failed":
        case "cancelled":
        case "completed":
          return batch;
      }
    }
  }
  /**
   * Uploads the given files concurrently and then creates a vector store file batch.
   *
   * The concurrency limit is configurable using the `maxConcurrency` parameter.
   */
  async uploadAndPoll(vectorStoreId, { files, fileIds = [] }, options) {
    if (files == null || files.length == 0) {
      throw new Error(`No \`files\` provided to process. If you've already uploaded files you should use \`.createAndPoll()\` instead`);
    }
    const configuredConcurrency = options?.maxConcurrency ?? 5;
    const concurrencyLimit = Math.min(configuredConcurrency, files.length);
    const client = this._client;
    const fileIterator = files.values();
    const allFileIds = [...fileIds];
    async function processFiles(iterator) {
      for (let item of iterator) {
        const fileObj = await client.files.create({ file: item, purpose: "assistants" }, options);
        allFileIds.push(fileObj.id);
      }
    }
    const workers = Array(concurrencyLimit).fill(fileIterator).map(processFiles);
    await allSettledWithThrow(workers);
    return await this.createAndPoll(vectorStoreId, {
      file_ids: allFileIds
    });
  }
}
class VectorStores extends APIResource {
  constructor() {
    super(...arguments);
    this.files = new Files3(this._client);
    this.fileBatches = new FileBatches(this._client);
  }
  /**
   * Create a vector store.
   */
  create(body, options) {
    return this._client.post("/vector_stores", {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Retrieves a vector store.
   */
  retrieve(vectorStoreId, options) {
    return this._client.get(`/vector_stores/${vectorStoreId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Modifies a vector store.
   */
  update(vectorStoreId, body, options) {
    return this._client.post(`/vector_stores/${vectorStoreId}`, {
      body,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  list(query = {}, options) {
    if (isRequestOptions(query)) {
      return this.list({}, query);
    }
    return this._client.getAPIList("/vector_stores", VectorStoresPage, {
      query,
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Delete a vector store.
   */
  del(vectorStoreId, options) {
    return this._client.delete(`/vector_stores/${vectorStoreId}`, {
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
  /**
   * Search a vector store for relevant chunks based on a query and file attributes
   * filter.
   */
  search(vectorStoreId, body, options) {
    return this._client.getAPIList(`/vector_stores/${vectorStoreId}/search`, VectorStoreSearchResponsesPage, {
      body,
      method: "post",
      ...options,
      headers: { "OpenAI-Beta": "assistants=v2", ...options?.headers }
    });
  }
}
class VectorStoresPage extends CursorPage {
}
class VectorStoreSearchResponsesPage extends Page {
}
VectorStores.VectorStoresPage = VectorStoresPage;
VectorStores.VectorStoreSearchResponsesPage = VectorStoreSearchResponsesPage;
VectorStores.Files = Files3;
VectorStores.VectorStoreFilesPage = VectorStoreFilesPage;
VectorStores.FileContentResponsesPage = FileContentResponsesPage;
VectorStores.FileBatches = FileBatches;
var _a;
class OpenAI extends APIClient {
  /**
   * API Client for interfacing with the OpenAI API.
   *
   * @param {string | undefined} [opts.apiKey=process.env['OPENAI_API_KEY'] ?? undefined]
   * @param {string | null | undefined} [opts.organization=process.env['OPENAI_ORG_ID'] ?? null]
   * @param {string | null | undefined} [opts.project=process.env['OPENAI_PROJECT_ID'] ?? null]
   * @param {string} [opts.baseURL=process.env['OPENAI_BASE_URL'] ?? https://api.openai.com/v1] - Override the default base URL for the API.
   * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
   * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
   * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
   * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
   * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
   * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
   * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
   */
  constructor({ baseURL = readEnv("OPENAI_BASE_URL"), apiKey = readEnv("OPENAI_API_KEY"), organization = readEnv("OPENAI_ORG_ID") ?? null, project = readEnv("OPENAI_PROJECT_ID") ?? null, ...opts } = {}) {
    if (apiKey === void 0) {
      throw new OpenAIError("The OPENAI_API_KEY environment variable is missing or empty; either provide it, or instantiate the OpenAI client with an apiKey option, like new OpenAI({ apiKey: 'My API Key' }).");
    }
    const options = {
      apiKey,
      organization,
      project,
      ...opts,
      baseURL: baseURL || `https://api.openai.com/v1`
    };
    if (!options.dangerouslyAllowBrowser && isRunningInBrowser()) {
      throw new OpenAIError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew OpenAI({ apiKey, dangerouslyAllowBrowser: true });\n\nhttps://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety\n");
    }
    super({
      baseURL: options.baseURL,
      timeout: options.timeout ?? 6e5,
      httpAgent: options.httpAgent,
      maxRetries: options.maxRetries,
      fetch: options.fetch
    });
    this.completions = new Completions3(this);
    this.chat = new Chat$1(this);
    this.embeddings = new Embeddings(this);
    this.files = new Files$1(this);
    this.images = new Images(this);
    this.audio = new Audio(this);
    this.moderations = new Moderations(this);
    this.models = new Models(this);
    this.fineTuning = new FineTuning(this);
    this.graders = new Graders2(this);
    this.vectorStores = new VectorStores(this);
    this.beta = new Beta(this);
    this.batches = new Batches(this);
    this.uploads = new Uploads(this);
    this.responses = new Responses(this);
    this.evals = new Evals(this);
    this.containers = new Containers(this);
    this._options = options;
    this.apiKey = apiKey;
    this.organization = organization;
    this.project = project;
  }
  defaultQuery() {
    return this._options.defaultQuery;
  }
  defaultHeaders(opts) {
    return {
      ...super.defaultHeaders(opts),
      "OpenAI-Organization": this.organization,
      "OpenAI-Project": this.project,
      ...this._options.defaultHeaders
    };
  }
  authHeaders(opts) {
    return { Authorization: `Bearer ${this.apiKey}` };
  }
  stringifyQuery(query) {
    return stringify(query, { arrayFormat: "brackets" });
  }
}
_a = OpenAI;
OpenAI.OpenAI = _a;
OpenAI.DEFAULT_TIMEOUT = 6e5;
OpenAI.OpenAIError = OpenAIError;
OpenAI.APIError = APIError;
OpenAI.APIConnectionError = APIConnectionError;
OpenAI.APIConnectionTimeoutError = APIConnectionTimeoutError;
OpenAI.APIUserAbortError = APIUserAbortError;
OpenAI.NotFoundError = NotFoundError;
OpenAI.ConflictError = ConflictError;
OpenAI.RateLimitError = RateLimitError;
OpenAI.BadRequestError = BadRequestError;
OpenAI.AuthenticationError = AuthenticationError;
OpenAI.InternalServerError = InternalServerError;
OpenAI.PermissionDeniedError = PermissionDeniedError;
OpenAI.UnprocessableEntityError = UnprocessableEntityError;
OpenAI.toFile = toFile;
OpenAI.fileFromPath = fileFromPath;
OpenAI.Completions = Completions3;
OpenAI.Chat = Chat$1;
OpenAI.ChatCompletionsPage = ChatCompletionsPage;
OpenAI.Embeddings = Embeddings;
OpenAI.Files = Files$1;
OpenAI.FileObjectsPage = FileObjectsPage;
OpenAI.Images = Images;
OpenAI.Audio = Audio;
OpenAI.Moderations = Moderations;
OpenAI.Models = Models;
OpenAI.ModelsPage = ModelsPage;
OpenAI.FineTuning = FineTuning;
OpenAI.Graders = Graders2;
OpenAI.VectorStores = VectorStores;
OpenAI.VectorStoresPage = VectorStoresPage;
OpenAI.VectorStoreSearchResponsesPage = VectorStoreSearchResponsesPage;
OpenAI.Beta = Beta;
OpenAI.Batches = Batches;
OpenAI.BatchesPage = BatchesPage;
OpenAI.Uploads = Uploads;
OpenAI.Responses = Responses;
OpenAI.Evals = Evals;
OpenAI.EvalListResponsesPage = EvalListResponsesPage;
OpenAI.Containers = Containers;
OpenAI.ContainerListResponsesPage = ContainerListResponsesPage;
const DEFAULT_SETTINGS = {
  apiKey: "sk-proj-FigS8y0eSADMDUJduN89pKQx6e_2PTYpcjZnTfYwcQLB5WmDtTDI_mpVFhIPh9Fr-1YsMIzhAT3BlbkFJ8pwifDHbL7JTeBZI1N65pGwBLAQDK2E3nngXTcQS1E3aD_Hkd156-4I71bdoqdQq-7M3DTegA",
  model: "gpt-3.5-turbo",
  language: "en",
  isEnabled: true,
  tone: "balanced"
};
async function getSettings() {
  const result2 = await browser.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...result2.settings };
}
const definition = defineBackground({
  type: "module",
  main() {
    console.log("WhatsApp AI Assistant: Background script loaded");
    browser.runtime.onMessage.addListener(async (message, _sender) => {
      if (message.action === "generateSuggestions") {
        return await generateSuggestions(message.data);
      }
      if (message.action === "regenerate") {
        const lastContext = await getLastContext();
        if (lastContext) {
          return await generateSuggestions(lastContext);
        }
        return { suggestions: [], error: "No previous context found" };
      }
    });
  }
});
async function generateSuggestions(context) {
  try {
    const settings = await getSettings();
    if (!settings.apiKey) {
      return {
        error: "API key not configured. Please add your OpenAI API key in settings.",
        suggestions: []
      };
    }
    const openai = new OpenAI({
      apiKey: settings.apiKey,
      dangerouslyAllowBrowser: true
      // For extension usage
    });
    const systemPrompt = getSystemPrompt(settings.language);
    const userPrompt = formatUserPrompt(context);
    const response = await openai.chat.completions.create({
      model: settings.model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: 0.7,
      max_tokens: 500
    });
    const aiResponse = response.choices[0]?.message?.content || "";
    const suggestions = parseAIResponse(aiResponse);
    await saveLastContext(context);
    return { suggestions, error: null };
  } catch (error) {
    console.error("OpenAI API error:", error);
    return {
      error: formatError(error),
      suggestions: []
    };
  }
}
function getSystemPrompt(language) {
  const prompts = {
    en: "You are a professional communication assistant for a freelancer communicating with clients on WhatsApp. Generate 3 different response suggestions with these tones: 1) PROFESSIONAL (formal and business-like), 2) FRIENDLY (warm and approachable), 3) QUICK (brief and to-the-point). Keep all responses concise (2-3 sentences max). Focus on clear, helpful communication.",
    ur: "آپ ایک فری لانسر کے لیے پروفیشنل کمیونیکیشن اسسٹنٹ ہیں جو واٹس ایپ پر کلائنٹس سے بات کر رہا ہے۔ 3 مختلف جوابات تیار کریں: 1) PROFESSIONAL (رسمی اور بزنس لائق), 2) FRIENDLY (دوستانہ اور گرمجوش), 3) QUICK (مختصر اور واضح)۔ سب جوابات مختصر رکھیں (2-3 جملے)۔",
    mixed: "You are a professional communication assistant. Generate 3 response suggestions in a mix of English and Urdu (Roman Urdu is acceptable). Tones: 1) PROFESSIONAL (formal), 2) FRIENDLY (warm), 3) QUICK (brief). Keep responses concise (2-3 sentences)."
  };
  return prompts[language] || prompts.en;
}
function formatUserPrompt(context) {
  const contextStr = context.previousMessages.length > 0 ? `Previous conversation:
${context.previousMessages.join("\n")}

` : "";
  return `${contextStr}Client (${context.senderName}) just sent: "${context.currentMessage}"

Generate 3 response options in this EXACT format:

1. PROFESSIONAL:
[Your professional response here]

2. FRIENDLY:
[Your friendly response here]

3. QUICK:
[Your quick response here]`;
}
function parseAIResponse(response) {
  const suggestions = [];
  const professionalMatch = response.match(/1\.\s*PROFESSIONAL:\s*\n([\s\S]*?)(?=\n2\.|$)/i);
  if (professionalMatch) {
    suggestions.push({
      id: "1",
      type: "professional",
      text: professionalMatch[1].trim(),
      icon: "🎯"
    });
  }
  const friendlyMatch = response.match(/2\.\s*FRIENDLY:\s*\n([\s\S]*?)(?=\n3\.|$)/i);
  if (friendlyMatch) {
    suggestions.push({
      id: "2",
      type: "friendly",
      text: friendlyMatch[1].trim(),
      icon: "😊"
    });
  }
  const quickMatch = response.match(/3\.\s*QUICK:\s*\n([\s\S]*?)$/i);
  if (quickMatch) {
    suggestions.push({
      id: "3",
      type: "quick",
      text: quickMatch[1].trim(),
      icon: "⚡"
    });
  }
  if (suggestions.length === 0) {
    const lines = response.split("\n").filter((line) => line.trim());
    let currentType = "professional";
    let currentText = "";
    for (const line of lines) {
      if (line.match(/1\.|professional/i)) {
        if (currentText) {
          suggestions.push({
            id: String(suggestions.length + 1),
            type: currentType,
            text: currentText.trim(),
            icon: currentType === "professional" ? "🎯" : currentType === "friendly" ? "😊" : "⚡"
          });
        }
        currentType = "professional";
        currentText = line.replace(/1\.|professional:/gi, "").trim();
      } else if (line.match(/2\.|friendly/i)) {
        if (currentText) {
          suggestions.push({
            id: String(suggestions.length + 1),
            type: currentType,
            text: currentText.trim(),
            icon: currentType === "professional" ? "🎯" : currentType === "friendly" ? "😊" : "⚡"
          });
        }
        currentType = "friendly";
        currentText = line.replace(/2\.|friendly:/gi, "").trim();
      } else if (line.match(/3\.|quick/i)) {
        if (currentText) {
          suggestions.push({
            id: String(suggestions.length + 1),
            type: currentType,
            text: currentText.trim(),
            icon: currentType === "professional" ? "🎯" : currentType === "friendly" ? "😊" : "⚡"
          });
        }
        currentType = "quick";
        currentText = line.replace(/3\.|quick:/gi, "").trim();
      } else {
        currentText += " " + line.trim();
      }
    }
    if (currentText && suggestions.length < 3) {
      suggestions.push({
        id: String(suggestions.length + 1),
        type: currentType,
        text: currentText.trim(),
        icon: currentType === "professional" ? "🎯" : currentType === "friendly" ? "😊" : "⚡"
      });
    }
  }
  return suggestions;
}
function formatError(error) {
  if (error.status === 401) return "Invalid API key. Please check your settings.";
  if (error.status === 429) return "Rate limit exceeded. Please wait a moment.";
  if (error.status === 500) return "OpenAI service error. Please try again.";
  return "Failed to generate suggestions. Please try again.";
}
async function saveLastContext(context) {
  await browser.storage.local.set({ lastContext: context });
}
async function getLastContext() {
  const result2 = await browser.storage.local.get("lastContext");
  return result2.lastContext || null;
}
function initPlugins() {
}
var _MatchPattern = class {
  constructor(matchPattern) {
    if (matchPattern === "<all_urls>") {
      this.isAllUrls = true;
      this.protocolMatches = [..._MatchPattern.PROTOCOLS];
      this.hostnameMatch = "*";
      this.pathnameMatch = "*";
    } else {
      const groups = /(.*):\/\/(.*?)(\/.*)/.exec(matchPattern);
      if (groups == null)
        throw new InvalidMatchPattern(matchPattern, "Incorrect format");
      const [_, protocol, hostname, pathname] = groups;
      validateProtocol(matchPattern, protocol);
      validateHostname(matchPattern, hostname);
      this.protocolMatches = protocol === "*" ? ["http", "https"] : [protocol];
      this.hostnameMatch = hostname;
      this.pathnameMatch = pathname;
    }
  }
  includes(url) {
    if (this.isAllUrls)
      return true;
    const u = typeof url === "string" ? new URL(url) : url instanceof Location ? new URL(url.href) : url;
    return !!this.protocolMatches.find((protocol) => {
      if (protocol === "http")
        return this.isHttpMatch(u);
      if (protocol === "https")
        return this.isHttpsMatch(u);
      if (protocol === "file")
        return this.isFileMatch(u);
      if (protocol === "ftp")
        return this.isFtpMatch(u);
      if (protocol === "urn")
        return this.isUrnMatch(u);
    });
  }
  isHttpMatch(url) {
    return url.protocol === "http:" && this.isHostPathMatch(url);
  }
  isHttpsMatch(url) {
    return url.protocol === "https:" && this.isHostPathMatch(url);
  }
  isHostPathMatch(url) {
    if (!this.hostnameMatch || !this.pathnameMatch)
      return false;
    const hostnameMatchRegexs = [
      this.convertPatternToRegex(this.hostnameMatch),
      this.convertPatternToRegex(this.hostnameMatch.replace(/^\*\./, ""))
    ];
    const pathnameMatchRegex = this.convertPatternToRegex(this.pathnameMatch);
    return !!hostnameMatchRegexs.find((regex) => regex.test(url.hostname)) && pathnameMatchRegex.test(url.pathname);
  }
  isFileMatch(url) {
    throw Error("Not implemented: file:// pattern matching. Open a PR to add support");
  }
  isFtpMatch(url) {
    throw Error("Not implemented: ftp:// pattern matching. Open a PR to add support");
  }
  isUrnMatch(url) {
    throw Error("Not implemented: urn:// pattern matching. Open a PR to add support");
  }
  convertPatternToRegex(pattern) {
    const escaped = this.escapeForRegex(pattern);
    const starsReplaced = escaped.replace(/\\\*/g, ".*");
    return RegExp(`^${starsReplaced}$`);
  }
  escapeForRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
};
var MatchPattern = _MatchPattern;
MatchPattern.PROTOCOLS = ["http", "https", "file", "ftp", "urn"];
var InvalidMatchPattern = class extends Error {
  constructor(matchPattern, reason) {
    super(`Invalid match pattern "${matchPattern}": ${reason}`);
  }
};
function validateProtocol(matchPattern, protocol) {
  if (!MatchPattern.PROTOCOLS.includes(protocol) && protocol !== "*")
    throw new InvalidMatchPattern(
      matchPattern,
      `${protocol} not a valid protocol (${MatchPattern.PROTOCOLS.join(", ")})`
    );
}
function validateHostname(matchPattern, hostname) {
  if (hostname.includes(":"))
    throw new InvalidMatchPattern(matchPattern, `Hostname cannot include a port`);
  if (hostname.includes("*") && hostname.length > 1 && !hostname.startsWith("*."))
    throw new InvalidMatchPattern(
      matchPattern,
      `If using a wildcard (*), it must go at the start of the hostname`
    );
}
function print(method, ...args) {
  if (typeof args[0] === "string") {
    const message = args.shift();
    method(`[wxt] ${message}`, ...args);
  } else {
    method("[wxt]", ...args);
  }
}
const logger = {
  debug: (...args) => print(console.debug, ...args),
  log: (...args) => print(console.log, ...args),
  warn: (...args) => print(console.warn, ...args),
  error: (...args) => print(console.error, ...args)
};
let ws;
function getDevServerWebSocket() {
  if (ws == null) {
    const serverUrl = "ws://localhost:3000";
    logger.debug("Connecting to dev server @", serverUrl);
    ws = new WebSocket(serverUrl, "vite-hmr");
    ws.addWxtEventListener = ws.addEventListener.bind(ws);
    ws.sendCustom = (event, payload) => ws?.send(JSON.stringify({ type: "custom", event, payload }));
    ws.addEventListener("open", () => {
      logger.debug("Connected to dev server");
    });
    ws.addEventListener("close", () => {
      logger.debug("Disconnected from dev server");
    });
    ws.addEventListener("error", (event) => {
      logger.error("Failed to connect to dev server", event);
    });
    ws.addEventListener("message", (e) => {
      try {
        const message = JSON.parse(e.data);
        if (message.type === "custom") {
          ws?.dispatchEvent(
            new CustomEvent(message.event, { detail: message.data })
          );
        }
      } catch (err) {
        logger.error("Failed to handle message", err);
      }
    });
  }
  return ws;
}
function keepServiceWorkerAlive() {
  setInterval(async () => {
    await browser.runtime.getPlatformInfo();
  }, 5e3);
}
function reloadContentScript(payload) {
  const manifest = browser.runtime.getManifest();
  if (manifest.manifest_version == 2) {
    void reloadContentScriptMv2();
  } else {
    void reloadContentScriptMv3(payload);
  }
}
async function reloadContentScriptMv3({
  registration,
  contentScript
}) {
  if (registration === "runtime") {
    await reloadRuntimeContentScriptMv3(contentScript);
  } else {
    await reloadManifestContentScriptMv3(contentScript);
  }
}
async function reloadManifestContentScriptMv3(contentScript) {
  const id = `wxt:${contentScript.js[0]}`;
  logger.log("Reloading content script:", contentScript);
  const registered = await browser.scripting.getRegisteredContentScripts();
  logger.debug("Existing scripts:", registered);
  const existing = registered.find((cs) => cs.id === id);
  if (existing) {
    logger.debug("Updating content script", existing);
    await browser.scripting.updateContentScripts([
      {
        ...contentScript,
        id,
        css: contentScript.css ?? []
      }
    ]);
  } else {
    logger.debug("Registering new content script...");
    await browser.scripting.registerContentScripts([
      {
        ...contentScript,
        id,
        css: contentScript.css ?? []
      }
    ]);
  }
  await reloadTabsForContentScript(contentScript);
}
async function reloadRuntimeContentScriptMv3(contentScript) {
  logger.log("Reloading content script:", contentScript);
  const registered = await browser.scripting.getRegisteredContentScripts();
  logger.debug("Existing scripts:", registered);
  const matches = registered.filter((cs) => {
    const hasJs = contentScript.js?.find((js) => cs.js?.includes(js));
    const hasCss = contentScript.css?.find((css) => cs.css?.includes(css));
    return hasJs || hasCss;
  });
  if (matches.length === 0) {
    logger.log(
      "Content script is not registered yet, nothing to reload",
      contentScript
    );
    return;
  }
  await browser.scripting.updateContentScripts(matches);
  await reloadTabsForContentScript(contentScript);
}
async function reloadTabsForContentScript(contentScript) {
  const allTabs = await browser.tabs.query({});
  const matchPatterns = contentScript.matches.map(
    (match) => new MatchPattern(match)
  );
  const matchingTabs = allTabs.filter((tab) => {
    const url = tab.url;
    if (!url) return false;
    return !!matchPatterns.find((pattern) => pattern.includes(url));
  });
  await Promise.all(
    matchingTabs.map(async (tab) => {
      try {
        await browser.tabs.reload(tab.id);
      } catch (err) {
        logger.warn("Failed to reload tab:", err);
      }
    })
  );
}
async function reloadContentScriptMv2(_payload) {
  throw Error("TODO: reloadContentScriptMv2");
}
{
  try {
    const ws2 = getDevServerWebSocket();
    ws2.addWxtEventListener("wxt:reload-extension", () => {
      browser.runtime.reload();
    });
    ws2.addWxtEventListener("wxt:reload-content-script", (event) => {
      reloadContentScript(event.detail);
    });
    if (true) {
      ws2.addEventListener(
        "open",
        () => ws2.sendCustom("wxt:background-initialized")
      );
      keepServiceWorkerAlive();
    }
  } catch (err) {
    logger.error("Failed to setup web socket connection with dev server", err);
  }
  browser.commands.onCommand.addListener((command) => {
    if (command === "wxt:reload-extension") {
      browser.runtime.reload();
    }
  });
}
let result;
try {
  initPlugins();
  result = definition.main();
  if (result instanceof Promise) {
    console.warn(
      "The background's main() function return a promise, but it must be synchronous"
    );
  }
} catch (err) {
  logger.error("The background crashed on startup!");
  throw err;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vbm9kZV9tb2R1bGVzL0B3eHQtZGV2L2Jyb3dzZXIvc3JjL2luZGV4Lm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC9icm93c2VyLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9kZWZpbmUtYmFja2dyb3VuZC5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2ludGVybmFsL3FzL2Zvcm1hdHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9pbnRlcm5hbC9xcy91dGlscy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2ludGVybmFsL3FzL3N0cmluZ2lmeS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3ZlcnNpb24ubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9fc2hpbXMvcmVnaXN0cnkubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9fc2hpbXMvTXVsdGlwYXJ0Qm9keS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL19zaGltcy93ZWItcnVudGltZS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL19zaGltcy9pbmRleC5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2Vycm9yLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvaW50ZXJuYWwvZGVjb2RlcnMvbGluZS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2ludGVybmFsL3N0cmVhbS11dGlscy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3N0cmVhbWluZy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3VwbG9hZHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9jb3JlLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcGFnaW5hdGlvbi5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2NoYXQvY29tcGxldGlvbnMvbWVzc2FnZXMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvY2hhdC9jb21wbGV0aW9ucy9jb21wbGV0aW9ucy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9jaGF0L2NoYXQubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvYXVkaW8vc3BlZWNoLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2F1ZGlvL3RyYW5zY3JpcHRpb25zLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2F1ZGlvL3RyYW5zbGF0aW9ucy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9hdWRpby9hdWRpby5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iYXRjaGVzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvbGliL0V2ZW50U3RyZWFtLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvbGliL0Fzc2lzdGFudFN0cmVhbS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iZXRhL2Fzc2lzdGFudHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9saWIvUnVubmFibGVGdW5jdGlvbi5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2xpYi9jaGF0Q29tcGxldGlvblV0aWxzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvbGliL3BhcnNlci5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2xpYi9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvbGliL0NoYXRDb21wbGV0aW9uUnVubmVyLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvX3ZlbmRvci9wYXJ0aWFsLWpzb24tcGFyc2VyL3BhcnNlci5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2xpYi9DaGF0Q29tcGxldGlvblN0cmVhbS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2xpYi9DaGF0Q29tcGxldGlvblN0cmVhbWluZ1J1bm5lci5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iZXRhL2NoYXQvY29tcGxldGlvbnMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvYmV0YS9jaGF0L2NoYXQubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvYmV0YS9yZWFsdGltZS9zZXNzaW9ucy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iZXRhL3JlYWx0aW1lL3RyYW5zY3JpcHRpb24tc2Vzc2lvbnMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvYmV0YS9yZWFsdGltZS9yZWFsdGltZS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iZXRhL3RocmVhZHMvbWVzc2FnZXMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvYmV0YS90aHJlYWRzL3J1bnMvc3RlcHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvYmV0YS90aHJlYWRzL3J1bnMvcnVucy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iZXRhL3RocmVhZHMvdGhyZWFkcy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9iZXRhL2JldGEubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvY29tcGxldGlvbnMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvY29udGFpbmVycy9maWxlcy9jb250ZW50Lm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2NvbnRhaW5lcnMvZmlsZXMvZmlsZXMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvY29udGFpbmVycy9jb250YWluZXJzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2VtYmVkZGluZ3MubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvZXZhbHMvcnVucy9vdXRwdXQtaXRlbXMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvZXZhbHMvcnVucy9ydW5zLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2V2YWxzL2V2YWxzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2ZpbGVzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2ZpbmUtdHVuaW5nL21ldGhvZHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvZmluZS10dW5pbmcvYWxwaGEvZ3JhZGVycy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9maW5lLXR1bmluZy9hbHBoYS9hbHBoYS5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9maW5lLXR1bmluZy9jaGVja3BvaW50cy9wZXJtaXNzaW9ucy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9maW5lLXR1bmluZy9jaGVja3BvaW50cy9jaGVja3BvaW50cy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9maW5lLXR1bmluZy9qb2JzL2NoZWNrcG9pbnRzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2ZpbmUtdHVuaW5nL2pvYnMvam9icy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9maW5lLXR1bmluZy9maW5lLXR1bmluZy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9ncmFkZXJzL2dyYWRlci1tb2RlbHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvZ3JhZGVycy9ncmFkZXJzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL2ltYWdlcy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy9tb2RlbHMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvbW9kZXJhdGlvbnMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9saWIvUmVzcG9uc2VzUGFyc2VyLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL3Jlc3BvbnNlcy9pbnB1dC1pdGVtcy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2xpYi9yZXNwb25zZXMvUmVzcG9uc2VTdHJlYW0ubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvcmVzcG9uc2VzL3Jlc3BvbnNlcy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL3Jlc291cmNlcy91cGxvYWRzL3BhcnRzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL3VwbG9hZHMvdXBsb2Fkcy5tanMiLCIuLi8uLi9ub2RlX21vZHVsZXMvb3BlbmFpL2xpYi9VdGlsLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvcmVzb3VyY2VzL3ZlY3Rvci1zdG9yZXMvZmlsZXMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvdmVjdG9yLXN0b3Jlcy9maWxlLWJhdGNoZXMubWpzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL29wZW5haS9yZXNvdXJjZXMvdmVjdG9yLXN0b3Jlcy92ZWN0b3Itc3RvcmVzLm1qcyIsIi4uLy4uL25vZGVfbW9kdWxlcy9vcGVuYWkvaW5kZXgubWpzIiwiLi4vLi4vbGliL3N0b3JhZ2UudHMiLCIuLi8uLi9lbnRyeXBvaW50cy9iYWNrZ3JvdW5kLnRzIiwiLi4vLi4vbm9kZV9tb2R1bGVzL0B3ZWJleHQtY29yZS9tYXRjaC1wYXR0ZXJucy9saWIvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gI3JlZ2lvbiBzbmlwcGV0XG5leHBvcnQgY29uc3QgYnJvd3NlciA9IGdsb2JhbFRoaXMuYnJvd3Nlcj8ucnVudGltZT8uaWRcbiAgPyBnbG9iYWxUaGlzLmJyb3dzZXJcbiAgOiBnbG9iYWxUaGlzLmNocm9tZTtcbi8vICNlbmRyZWdpb24gc25pcHBldFxuIiwiaW1wb3J0IHsgYnJvd3NlciBhcyBfYnJvd3NlciB9IGZyb20gXCJAd3h0LWRldi9icm93c2VyXCI7XG5leHBvcnQgY29uc3QgYnJvd3NlciA9IF9icm93c2VyO1xuZXhwb3J0IHt9O1xuIiwiZXhwb3J0IGZ1bmN0aW9uIGRlZmluZUJhY2tncm91bmQoYXJnKSB7XG4gIGlmIChhcmcgPT0gbnVsbCB8fCB0eXBlb2YgYXJnID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiB7IG1haW46IGFyZyB9O1xuICByZXR1cm4gYXJnO1xufVxuIiwiZXhwb3J0IGNvbnN0IGRlZmF1bHRfZm9ybWF0ID0gJ1JGQzM5ODYnO1xuZXhwb3J0IGNvbnN0IGZvcm1hdHRlcnMgPSB7XG4gICAgUkZDMTczODogKHYpID0+IFN0cmluZyh2KS5yZXBsYWNlKC8lMjAvZywgJysnKSxcbiAgICBSRkMzOTg2OiAodikgPT4gU3RyaW5nKHYpLFxufTtcbmV4cG9ydCBjb25zdCBSRkMxNzM4ID0gJ1JGQzE3MzgnO1xuZXhwb3J0IGNvbnN0IFJGQzM5ODYgPSAnUkZDMzk4Nic7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1mb3JtYXRzLm1qcy5tYXAiLCJpbXBvcnQgeyBSRkMxNzM4IH0gZnJvbSBcIi4vZm9ybWF0cy5tanNcIjtcbmNvbnN0IGhhcyA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5jb25zdCBpc19hcnJheSA9IEFycmF5LmlzQXJyYXk7XG5jb25zdCBoZXhfdGFibGUgPSAoKCkgPT4ge1xuICAgIGNvbnN0IGFycmF5ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCAyNTY7ICsraSkge1xuICAgICAgICBhcnJheS5wdXNoKCclJyArICgoaSA8IDE2ID8gJzAnIDogJycpICsgaS50b1N0cmluZygxNikpLnRvVXBwZXJDYXNlKCkpO1xuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG59KSgpO1xuZnVuY3Rpb24gY29tcGFjdF9xdWV1ZShxdWV1ZSkge1xuICAgIHdoaWxlIChxdWV1ZS5sZW5ndGggPiAxKSB7XG4gICAgICAgIGNvbnN0IGl0ZW0gPSBxdWV1ZS5wb3AoKTtcbiAgICAgICAgaWYgKCFpdGVtKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIGNvbnN0IG9iaiA9IGl0ZW0ub2JqW2l0ZW0ucHJvcF07XG4gICAgICAgIGlmIChpc19hcnJheShvYmopKSB7XG4gICAgICAgICAgICBjb25zdCBjb21wYWN0ZWQgPSBbXTtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgb2JqLmxlbmd0aDsgKytqKSB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmpbal0gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbXBhY3RlZC5wdXNoKG9ialtqXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICAgICAgaXRlbS5vYmpbaXRlbS5wcm9wXSA9IGNvbXBhY3RlZDtcbiAgICAgICAgfVxuICAgIH1cbn1cbmZ1bmN0aW9uIGFycmF5X3RvX29iamVjdChzb3VyY2UsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBvYmogPSBvcHRpb25zICYmIG9wdGlvbnMucGxhaW5PYmplY3RzID8gT2JqZWN0LmNyZWF0ZShudWxsKSA6IHt9O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlLmxlbmd0aDsgKytpKSB7XG4gICAgICAgIGlmICh0eXBlb2Ygc291cmNlW2ldICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgb2JqW2ldID0gc291cmNlW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvYmo7XG59XG5leHBvcnQgZnVuY3Rpb24gbWVyZ2UodGFyZ2V0LCBzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICghc291cmNlKSB7XG4gICAgICAgIHJldHVybiB0YXJnZXQ7XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygc291cmNlICE9PSAnb2JqZWN0Jykge1xuICAgICAgICBpZiAoaXNfYXJyYXkodGFyZ2V0KSkge1xuICAgICAgICAgICAgdGFyZ2V0LnB1c2goc291cmNlKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0YXJnZXQgJiYgdHlwZW9mIHRhcmdldCA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIGlmICgob3B0aW9ucyAmJiAob3B0aW9ucy5wbGFpbk9iamVjdHMgfHwgb3B0aW9ucy5hbGxvd1Byb3RvdHlwZXMpKSB8fFxuICAgICAgICAgICAgICAgICFoYXMuY2FsbChPYmplY3QucHJvdG90eXBlLCBzb3VyY2UpKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W3NvdXJjZV0gPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIFt0YXJnZXQsIHNvdXJjZV07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICB9XG4gICAgaWYgKCF0YXJnZXQgfHwgdHlwZW9mIHRhcmdldCAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIFt0YXJnZXRdLmNvbmNhdChzb3VyY2UpO1xuICAgIH1cbiAgICBsZXQgbWVyZ2VUYXJnZXQgPSB0YXJnZXQ7XG4gICAgaWYgKGlzX2FycmF5KHRhcmdldCkgJiYgIWlzX2FycmF5KHNvdXJjZSkpIHtcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBtZXJnZVRhcmdldCA9IGFycmF5X3RvX29iamVjdCh0YXJnZXQsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBpZiAoaXNfYXJyYXkodGFyZ2V0KSAmJiBpc19hcnJheShzb3VyY2UpKSB7XG4gICAgICAgIHNvdXJjZS5mb3JFYWNoKGZ1bmN0aW9uIChpdGVtLCBpKSB7XG4gICAgICAgICAgICBpZiAoaGFzLmNhbGwodGFyZ2V0LCBpKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldEl0ZW0gPSB0YXJnZXRbaV07XG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldEl0ZW0gJiYgdHlwZW9mIHRhcmdldEl0ZW0gPT09ICdvYmplY3QnICYmIGl0ZW0gJiYgdHlwZW9mIGl0ZW0gPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhcmdldFtpXSA9IG1lcmdlKHRhcmdldEl0ZW0sIGl0ZW0sIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W2ldID0gaXRlbTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0YXJnZXQ7XG4gICAgfVxuICAgIHJldHVybiBPYmplY3Qua2V5cyhzb3VyY2UpLnJlZHVjZShmdW5jdGlvbiAoYWNjLCBrZXkpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBzb3VyY2Vba2V5XTtcbiAgICAgICAgaWYgKGhhcy5jYWxsKGFjYywga2V5KSkge1xuICAgICAgICAgICAgYWNjW2tleV0gPSBtZXJnZShhY2Nba2V5XSwgdmFsdWUsIG9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYWNjW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjO1xuICAgIH0sIG1lcmdlVGFyZ2V0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBhc3NpZ25fc2luZ2xlX3NvdXJjZSh0YXJnZXQsIHNvdXJjZSkge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhzb3VyY2UpLnJlZHVjZShmdW5jdGlvbiAoYWNjLCBrZXkpIHtcbiAgICAgICAgYWNjW2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICAgICAgcmV0dXJuIGFjYztcbiAgICB9LCB0YXJnZXQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZShzdHIsIF8sIGNoYXJzZXQpIHtcbiAgICBjb25zdCBzdHJXaXRob3V0UGx1cyA9IHN0ci5yZXBsYWNlKC9cXCsvZywgJyAnKTtcbiAgICBpZiAoY2hhcnNldCA9PT0gJ2lzby04ODU5LTEnKSB7XG4gICAgICAgIC8vIHVuZXNjYXBlIG5ldmVyIHRocm93cywgbm8gdHJ5Li4uY2F0Y2ggbmVlZGVkOlxuICAgICAgICByZXR1cm4gc3RyV2l0aG91dFBsdXMucmVwbGFjZSgvJVswLTlhLWZdezJ9L2dpLCB1bmVzY2FwZSk7XG4gICAgfVxuICAgIC8vIHV0Zi04XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudChzdHJXaXRob3V0UGx1cyk7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBzdHJXaXRob3V0UGx1cztcbiAgICB9XG59XG5jb25zdCBsaW1pdCA9IDEwMjQ7XG5leHBvcnQgY29uc3QgZW5jb2RlID0gKHN0ciwgX2RlZmF1bHRFbmNvZGVyLCBjaGFyc2V0LCBfa2luZCwgZm9ybWF0KSA9PiB7XG4gICAgLy8gVGhpcyBjb2RlIHdhcyBvcmlnaW5hbGx5IHdyaXR0ZW4gYnkgQnJpYW4gV2hpdGUgZm9yIHRoZSBpby5qcyBjb3JlIHF1ZXJ5c3RyaW5nIGxpYnJhcnkuXG4gICAgLy8gSXQgaGFzIGJlZW4gYWRhcHRlZCBoZXJlIGZvciBzdHJpY3RlciBhZGhlcmVuY2UgdG8gUkZDIDM5ODZcbiAgICBpZiAoc3RyLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gc3RyO1xuICAgIH1cbiAgICBsZXQgc3RyaW5nID0gc3RyO1xuICAgIGlmICh0eXBlb2Ygc3RyID09PSAnc3ltYm9sJykge1xuICAgICAgICBzdHJpbmcgPSBTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoc3RyKTtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIHN0ciAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgc3RyaW5nID0gU3RyaW5nKHN0cik7XG4gICAgfVxuICAgIGlmIChjaGFyc2V0ID09PSAnaXNvLTg4NTktMScpIHtcbiAgICAgICAgcmV0dXJuIGVzY2FwZShzdHJpbmcpLnJlcGxhY2UoLyV1WzAtOWEtZl17NH0vZ2ksIGZ1bmN0aW9uICgkMCkge1xuICAgICAgICAgICAgcmV0dXJuICclMjYlMjMnICsgcGFyc2VJbnQoJDAuc2xpY2UoMiksIDE2KSArICclM0InO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgbGV0IG91dCA9ICcnO1xuICAgIGZvciAobGV0IGogPSAwOyBqIDwgc3RyaW5nLmxlbmd0aDsgaiArPSBsaW1pdCkge1xuICAgICAgICBjb25zdCBzZWdtZW50ID0gc3RyaW5nLmxlbmd0aCA+PSBsaW1pdCA/IHN0cmluZy5zbGljZShqLCBqICsgbGltaXQpIDogc3RyaW5nO1xuICAgICAgICBjb25zdCBhcnIgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50Lmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICBsZXQgYyA9IHNlZ21lbnQuY2hhckNvZGVBdChpKTtcbiAgICAgICAgICAgIGlmIChjID09PSAweDJkIHx8IC8vIC1cbiAgICAgICAgICAgICAgICBjID09PSAweDJlIHx8IC8vIC5cbiAgICAgICAgICAgICAgICBjID09PSAweDVmIHx8IC8vIF9cbiAgICAgICAgICAgICAgICBjID09PSAweDdlIHx8IC8vIH5cbiAgICAgICAgICAgICAgICAoYyA+PSAweDMwICYmIGMgPD0gMHgzOSkgfHwgLy8gMC05XG4gICAgICAgICAgICAgICAgKGMgPj0gMHg0MSAmJiBjIDw9IDB4NWEpIHx8IC8vIGEtelxuICAgICAgICAgICAgICAgIChjID49IDB4NjEgJiYgYyA8PSAweDdhKSB8fCAvLyBBLVpcbiAgICAgICAgICAgICAgICAoZm9ybWF0ID09PSBSRkMxNzM4ICYmIChjID09PSAweDI4IHx8IGMgPT09IDB4MjkpKSAvLyAoIClcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgIGFyclthcnIubGVuZ3RoXSA9IHNlZ21lbnQuY2hhckF0KGkpO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGMgPCAweDgwKSB7XG4gICAgICAgICAgICAgICAgYXJyW2Fyci5sZW5ndGhdID0gaGV4X3RhYmxlW2NdO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGMgPCAweDgwMCkge1xuICAgICAgICAgICAgICAgIGFyclthcnIubGVuZ3RoXSA9IGhleF90YWJsZVsweGMwIHwgKGMgPj4gNildICsgaGV4X3RhYmxlWzB4ODAgfCAoYyAmIDB4M2YpXTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjIDwgMHhkODAwIHx8IGMgPj0gMHhlMDAwKSB7XG4gICAgICAgICAgICAgICAgYXJyW2Fyci5sZW5ndGhdID1cbiAgICAgICAgICAgICAgICAgICAgaGV4X3RhYmxlWzB4ZTAgfCAoYyA+PiAxMildICsgaGV4X3RhYmxlWzB4ODAgfCAoKGMgPj4gNikgJiAweDNmKV0gKyBoZXhfdGFibGVbMHg4MCB8IChjICYgMHgzZildO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaSArPSAxO1xuICAgICAgICAgICAgYyA9IDB4MTAwMDAgKyAoKChjICYgMHgzZmYpIDw8IDEwKSB8IChzZWdtZW50LmNoYXJDb2RlQXQoaSkgJiAweDNmZikpO1xuICAgICAgICAgICAgYXJyW2Fyci5sZW5ndGhdID1cbiAgICAgICAgICAgICAgICBoZXhfdGFibGVbMHhmMCB8IChjID4+IDE4KV0gK1xuICAgICAgICAgICAgICAgICAgICBoZXhfdGFibGVbMHg4MCB8ICgoYyA+PiAxMikgJiAweDNmKV0gK1xuICAgICAgICAgICAgICAgICAgICBoZXhfdGFibGVbMHg4MCB8ICgoYyA+PiA2KSAmIDB4M2YpXSArXG4gICAgICAgICAgICAgICAgICAgIGhleF90YWJsZVsweDgwIHwgKGMgJiAweDNmKV07XG4gICAgICAgIH1cbiAgICAgICAgb3V0ICs9IGFyci5qb2luKCcnKTtcbiAgICB9XG4gICAgcmV0dXJuIG91dDtcbn07XG5leHBvcnQgZnVuY3Rpb24gY29tcGFjdCh2YWx1ZSkge1xuICAgIGNvbnN0IHF1ZXVlID0gW3sgb2JqOiB7IG86IHZhbHVlIH0sIHByb3A6ICdvJyB9XTtcbiAgICBjb25zdCByZWZzID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBxdWV1ZS5sZW5ndGg7ICsraSkge1xuICAgICAgICBjb25zdCBpdGVtID0gcXVldWVbaV07XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgY29uc3Qgb2JqID0gaXRlbS5vYmpbaXRlbS5wcm9wXTtcbiAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9iaik7XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwga2V5cy5sZW5ndGg7ICsraikge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0ga2V5c1tqXTtcbiAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9ialtrZXldO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICdvYmplY3QnICYmIHZhbCAhPT0gbnVsbCAmJiByZWZzLmluZGV4T2YodmFsKSA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICBxdWV1ZS5wdXNoKHsgb2JqOiBvYmosIHByb3A6IGtleSB9KTtcbiAgICAgICAgICAgICAgICByZWZzLnB1c2godmFsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBjb21wYWN0X3F1ZXVlKHF1ZXVlKTtcbiAgICByZXR1cm4gdmFsdWU7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNfcmVnZXhwKG9iaikge1xuICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob2JqKSA9PT0gJ1tvYmplY3QgUmVnRXhwXSc7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNfYnVmZmVyKG9iaikge1xuICAgIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuICEhKG9iai5jb25zdHJ1Y3RvciAmJiBvYmouY29uc3RydWN0b3IuaXNCdWZmZXIgJiYgb2JqLmNvbnN0cnVjdG9yLmlzQnVmZmVyKG9iaikpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNvbWJpbmUoYSwgYikge1xuICAgIHJldHVybiBbXS5jb25jYXQoYSwgYik7XG59XG5leHBvcnQgZnVuY3Rpb24gbWF5YmVfbWFwKHZhbCwgZm4pIHtcbiAgICBpZiAoaXNfYXJyYXkodmFsKSkge1xuICAgICAgICBjb25zdCBtYXBwZWQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWwubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgICAgIG1hcHBlZC5wdXNoKGZuKHZhbFtpXSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtYXBwZWQ7XG4gICAgfVxuICAgIHJldHVybiBmbih2YWwpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMubWpzLm1hcCIsImltcG9ydCB7IGVuY29kZSwgaXNfYnVmZmVyLCBtYXliZV9tYXAgfSBmcm9tIFwiLi91dGlscy5tanNcIjtcbmltcG9ydCB7IGRlZmF1bHRfZm9ybWF0LCBmb3JtYXR0ZXJzIH0gZnJvbSBcIi4vZm9ybWF0cy5tanNcIjtcbmNvbnN0IGhhcyA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5jb25zdCBhcnJheV9wcmVmaXhfZ2VuZXJhdG9ycyA9IHtcbiAgICBicmFja2V0cyhwcmVmaXgpIHtcbiAgICAgICAgcmV0dXJuIFN0cmluZyhwcmVmaXgpICsgJ1tdJztcbiAgICB9LFxuICAgIGNvbW1hOiAnY29tbWEnLFxuICAgIGluZGljZXMocHJlZml4LCBrZXkpIHtcbiAgICAgICAgcmV0dXJuIFN0cmluZyhwcmVmaXgpICsgJ1snICsga2V5ICsgJ10nO1xuICAgIH0sXG4gICAgcmVwZWF0KHByZWZpeCkge1xuICAgICAgICByZXR1cm4gU3RyaW5nKHByZWZpeCk7XG4gICAgfSxcbn07XG5jb25zdCBpc19hcnJheSA9IEFycmF5LmlzQXJyYXk7XG5jb25zdCBwdXNoID0gQXJyYXkucHJvdG90eXBlLnB1c2g7XG5jb25zdCBwdXNoX3RvX2FycmF5ID0gZnVuY3Rpb24gKGFyciwgdmFsdWVfb3JfYXJyYXkpIHtcbiAgICBwdXNoLmFwcGx5KGFyciwgaXNfYXJyYXkodmFsdWVfb3JfYXJyYXkpID8gdmFsdWVfb3JfYXJyYXkgOiBbdmFsdWVfb3JfYXJyYXldKTtcbn07XG5jb25zdCB0b19JU08gPSBEYXRlLnByb3RvdHlwZS50b0lTT1N0cmluZztcbmNvbnN0IGRlZmF1bHRzID0ge1xuICAgIGFkZFF1ZXJ5UHJlZml4OiBmYWxzZSxcbiAgICBhbGxvd0RvdHM6IGZhbHNlLFxuICAgIGFsbG93RW1wdHlBcnJheXM6IGZhbHNlLFxuICAgIGFycmF5Rm9ybWF0OiAnaW5kaWNlcycsXG4gICAgY2hhcnNldDogJ3V0Zi04JyxcbiAgICBjaGFyc2V0U2VudGluZWw6IGZhbHNlLFxuICAgIGRlbGltaXRlcjogJyYnLFxuICAgIGVuY29kZTogdHJ1ZSxcbiAgICBlbmNvZGVEb3RJbktleXM6IGZhbHNlLFxuICAgIGVuY29kZXI6IGVuY29kZSxcbiAgICBlbmNvZGVWYWx1ZXNPbmx5OiBmYWxzZSxcbiAgICBmb3JtYXQ6IGRlZmF1bHRfZm9ybWF0LFxuICAgIGZvcm1hdHRlcjogZm9ybWF0dGVyc1tkZWZhdWx0X2Zvcm1hdF0sXG4gICAgLyoqIEBkZXByZWNhdGVkICovXG4gICAgaW5kaWNlczogZmFsc2UsXG4gICAgc2VyaWFsaXplRGF0ZShkYXRlKSB7XG4gICAgICAgIHJldHVybiB0b19JU08uY2FsbChkYXRlKTtcbiAgICB9LFxuICAgIHNraXBOdWxsczogZmFsc2UsXG4gICAgc3RyaWN0TnVsbEhhbmRsaW5nOiBmYWxzZSxcbn07XG5mdW5jdGlvbiBpc19ub25fbnVsbGlzaF9wcmltaXRpdmUodikge1xuICAgIHJldHVybiAodHlwZW9mIHYgPT09ICdzdHJpbmcnIHx8XG4gICAgICAgIHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fFxuICAgICAgICB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nIHx8XG4gICAgICAgIHR5cGVvZiB2ID09PSAnc3ltYm9sJyB8fFxuICAgICAgICB0eXBlb2YgdiA9PT0gJ2JpZ2ludCcpO1xufVxuY29uc3Qgc2VudGluZWwgPSB7fTtcbmZ1bmN0aW9uIGlubmVyX3N0cmluZ2lmeShvYmplY3QsIHByZWZpeCwgZ2VuZXJhdGVBcnJheVByZWZpeCwgY29tbWFSb3VuZFRyaXAsIGFsbG93RW1wdHlBcnJheXMsIHN0cmljdE51bGxIYW5kbGluZywgc2tpcE51bGxzLCBlbmNvZGVEb3RJbktleXMsIGVuY29kZXIsIGZpbHRlciwgc29ydCwgYWxsb3dEb3RzLCBzZXJpYWxpemVEYXRlLCBmb3JtYXQsIGZvcm1hdHRlciwgZW5jb2RlVmFsdWVzT25seSwgY2hhcnNldCwgc2lkZUNoYW5uZWwpIHtcbiAgICBsZXQgb2JqID0gb2JqZWN0O1xuICAgIGxldCB0bXBfc2MgPSBzaWRlQ2hhbm5lbDtcbiAgICBsZXQgc3RlcCA9IDA7XG4gICAgbGV0IGZpbmRfZmxhZyA9IGZhbHNlO1xuICAgIHdoaWxlICgodG1wX3NjID0gdG1wX3NjLmdldChzZW50aW5lbCkpICE9PSB2b2lkIHVuZGVmaW5lZCAmJiAhZmluZF9mbGFnKSB7XG4gICAgICAgIC8vIFdoZXJlIG9iamVjdCBsYXN0IGFwcGVhcmVkIGluIHRoZSByZWYgdHJlZVxuICAgICAgICBjb25zdCBwb3MgPSB0bXBfc2MuZ2V0KG9iamVjdCk7XG4gICAgICAgIHN0ZXAgKz0gMTtcbiAgICAgICAgaWYgKHR5cGVvZiBwb3MgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBpZiAocG9zID09PSBzdGVwKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0N5Y2xpYyBvYmplY3QgdmFsdWUnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGZpbmRfZmxhZyA9IHRydWU7IC8vIEJyZWFrIHdoaWxlXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB0bXBfc2MuZ2V0KHNlbnRpbmVsKSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIHN0ZXAgPSAwO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZmlsdGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIG9iaiA9IGZpbHRlcihwcmVmaXgsIG9iaik7XG4gICAgfVxuICAgIGVsc2UgaWYgKG9iaiBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgb2JqID0gc2VyaWFsaXplRGF0ZT8uKG9iaik7XG4gICAgfVxuICAgIGVsc2UgaWYgKGdlbmVyYXRlQXJyYXlQcmVmaXggPT09ICdjb21tYScgJiYgaXNfYXJyYXkob2JqKSkge1xuICAgICAgICBvYmogPSBtYXliZV9tYXAob2JqLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VyaWFsaXplRGF0ZT8uKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChvYmogPT09IG51bGwpIHtcbiAgICAgICAgaWYgKHN0cmljdE51bGxIYW5kbGluZykge1xuICAgICAgICAgICAgcmV0dXJuIGVuY29kZXIgJiYgIWVuY29kZVZhbHVlc09ubHkgP1xuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICBlbmNvZGVyKHByZWZpeCwgZGVmYXVsdHMuZW5jb2RlciwgY2hhcnNldCwgJ2tleScsIGZvcm1hdClcbiAgICAgICAgICAgICAgICA6IHByZWZpeDtcbiAgICAgICAgfVxuICAgICAgICBvYmogPSAnJztcbiAgICB9XG4gICAgaWYgKGlzX25vbl9udWxsaXNoX3ByaW1pdGl2ZShvYmopIHx8IGlzX2J1ZmZlcihvYmopKSB7XG4gICAgICAgIGlmIChlbmNvZGVyKSB7XG4gICAgICAgICAgICBjb25zdCBrZXlfdmFsdWUgPSBlbmNvZGVWYWx1ZXNPbmx5ID8gcHJlZml4XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIDogZW5jb2RlcihwcmVmaXgsIGRlZmF1bHRzLmVuY29kZXIsIGNoYXJzZXQsICdrZXknLCBmb3JtYXQpO1xuICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZXI/LihrZXlfdmFsdWUpICtcbiAgICAgICAgICAgICAgICAgICAgJz0nICtcbiAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXR0ZXI/LihlbmNvZGVyKG9iaiwgZGVmYXVsdHMuZW5jb2RlciwgY2hhcnNldCwgJ3ZhbHVlJywgZm9ybWF0KSksXG4gICAgICAgICAgICBdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbZm9ybWF0dGVyPy4ocHJlZml4KSArICc9JyArIGZvcm1hdHRlcj8uKFN0cmluZyhvYmopKV07XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlcyA9IFtdO1xuICAgIGlmICh0eXBlb2Ygb2JqID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gdmFsdWVzO1xuICAgIH1cbiAgICBsZXQgb2JqX2tleXM7XG4gICAgaWYgKGdlbmVyYXRlQXJyYXlQcmVmaXggPT09ICdjb21tYScgJiYgaXNfYXJyYXkob2JqKSkge1xuICAgICAgICAvLyB3ZSBuZWVkIHRvIGpvaW4gZWxlbWVudHMgaW5cbiAgICAgICAgaWYgKGVuY29kZVZhbHVlc09ubHkgJiYgZW5jb2Rlcikge1xuICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciB2YWx1ZXMgb25seVxuICAgICAgICAgICAgb2JqID0gbWF5YmVfbWFwKG9iaiwgZW5jb2Rlcik7XG4gICAgICAgIH1cbiAgICAgICAgb2JqX2tleXMgPSBbeyB2YWx1ZTogb2JqLmxlbmd0aCA+IDAgPyBvYmouam9pbignLCcpIHx8IG51bGwgOiB2b2lkIHVuZGVmaW5lZCB9XTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNfYXJyYXkoZmlsdGVyKSkge1xuICAgICAgICBvYmpfa2V5cyA9IGZpbHRlcjtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvYmopO1xuICAgICAgICBvYmpfa2V5cyA9IHNvcnQgPyBrZXlzLnNvcnQoc29ydCkgOiBrZXlzO1xuICAgIH1cbiAgICBjb25zdCBlbmNvZGVkX3ByZWZpeCA9IGVuY29kZURvdEluS2V5cyA/IFN0cmluZyhwcmVmaXgpLnJlcGxhY2UoL1xcLi9nLCAnJTJFJykgOiBTdHJpbmcocHJlZml4KTtcbiAgICBjb25zdCBhZGp1c3RlZF9wcmVmaXggPSBjb21tYVJvdW5kVHJpcCAmJiBpc19hcnJheShvYmopICYmIG9iai5sZW5ndGggPT09IDEgPyBlbmNvZGVkX3ByZWZpeCArICdbXScgOiBlbmNvZGVkX3ByZWZpeDtcbiAgICBpZiAoYWxsb3dFbXB0eUFycmF5cyAmJiBpc19hcnJheShvYmopICYmIG9iai5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGFkanVzdGVkX3ByZWZpeCArICdbXSc7XG4gICAgfVxuICAgIGZvciAobGV0IGogPSAwOyBqIDwgb2JqX2tleXMubGVuZ3RoOyArK2opIHtcbiAgICAgICAgY29uc3Qga2V5ID0gb2JqX2tleXNbal07XG4gICAgICAgIGNvbnN0IHZhbHVlID0gXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgdHlwZW9mIGtleSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIGtleS52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgPyBrZXkudmFsdWUgOiBvYmpba2V5XTtcbiAgICAgICAgaWYgKHNraXBOdWxscyAmJiB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBjb25zdCBlbmNvZGVkX2tleSA9IGFsbG93RG90cyAmJiBlbmNvZGVEb3RJbktleXMgPyBrZXkucmVwbGFjZSgvXFwuL2csICclMkUnKSA6IGtleTtcbiAgICAgICAgY29uc3Qga2V5X3ByZWZpeCA9IGlzX2FycmF5KG9iaikgP1xuICAgICAgICAgICAgdHlwZW9mIGdlbmVyYXRlQXJyYXlQcmVmaXggPT09ICdmdW5jdGlvbicgP1xuICAgICAgICAgICAgICAgIGdlbmVyYXRlQXJyYXlQcmVmaXgoYWRqdXN0ZWRfcHJlZml4LCBlbmNvZGVkX2tleSlcbiAgICAgICAgICAgICAgICA6IGFkanVzdGVkX3ByZWZpeFxuICAgICAgICAgICAgOiBhZGp1c3RlZF9wcmVmaXggKyAoYWxsb3dEb3RzID8gJy4nICsgZW5jb2RlZF9rZXkgOiAnWycgKyBlbmNvZGVkX2tleSArICddJyk7XG4gICAgICAgIHNpZGVDaGFubmVsLnNldChvYmplY3QsIHN0ZXApO1xuICAgICAgICBjb25zdCB2YWx1ZVNpZGVDaGFubmVsID0gbmV3IFdlYWtNYXAoKTtcbiAgICAgICAgdmFsdWVTaWRlQ2hhbm5lbC5zZXQoc2VudGluZWwsIHNpZGVDaGFubmVsKTtcbiAgICAgICAgcHVzaF90b19hcnJheSh2YWx1ZXMsIGlubmVyX3N0cmluZ2lmeSh2YWx1ZSwga2V5X3ByZWZpeCwgZ2VuZXJhdGVBcnJheVByZWZpeCwgY29tbWFSb3VuZFRyaXAsIGFsbG93RW1wdHlBcnJheXMsIHN0cmljdE51bGxIYW5kbGluZywgc2tpcE51bGxzLCBlbmNvZGVEb3RJbktleXMsIFxuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIGdlbmVyYXRlQXJyYXlQcmVmaXggPT09ICdjb21tYScgJiYgZW5jb2RlVmFsdWVzT25seSAmJiBpc19hcnJheShvYmopID8gbnVsbCA6IGVuY29kZXIsIGZpbHRlciwgc29ydCwgYWxsb3dEb3RzLCBzZXJpYWxpemVEYXRlLCBmb3JtYXQsIGZvcm1hdHRlciwgZW5jb2RlVmFsdWVzT25seSwgY2hhcnNldCwgdmFsdWVTaWRlQ2hhbm5lbCkpO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWVzO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplX3N0cmluZ2lmeV9vcHRpb25zKG9wdHMgPSBkZWZhdWx0cykge1xuICAgIGlmICh0eXBlb2Ygb3B0cy5hbGxvd0VtcHR5QXJyYXlzICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2Ygb3B0cy5hbGxvd0VtcHR5QXJyYXlzICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignYGFsbG93RW1wdHlBcnJheXNgIG9wdGlvbiBjYW4gb25seSBiZSBgdHJ1ZWAgb3IgYGZhbHNlYCwgd2hlbiBwcm92aWRlZCcpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG9wdHMuZW5jb2RlRG90SW5LZXlzICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2Ygb3B0cy5lbmNvZGVEb3RJbktleXMgIT09ICdib29sZWFuJykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdgZW5jb2RlRG90SW5LZXlzYCBvcHRpb24gY2FuIG9ubHkgYmUgYHRydWVgIG9yIGBmYWxzZWAsIHdoZW4gcHJvdmlkZWQnKTtcbiAgICB9XG4gICAgaWYgKG9wdHMuZW5jb2RlciAhPT0gbnVsbCAmJiB0eXBlb2Ygb3B0cy5lbmNvZGVyICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2Ygb3B0cy5lbmNvZGVyICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0VuY29kZXIgaGFzIHRvIGJlIGEgZnVuY3Rpb24uJyk7XG4gICAgfVxuICAgIGNvbnN0IGNoYXJzZXQgPSBvcHRzLmNoYXJzZXQgfHwgZGVmYXVsdHMuY2hhcnNldDtcbiAgICBpZiAodHlwZW9mIG9wdHMuY2hhcnNldCAhPT0gJ3VuZGVmaW5lZCcgJiYgb3B0cy5jaGFyc2V0ICE9PSAndXRmLTgnICYmIG9wdHMuY2hhcnNldCAhPT0gJ2lzby04ODU5LTEnKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RoZSBjaGFyc2V0IG9wdGlvbiBtdXN0IGJlIGVpdGhlciB1dGYtOCwgaXNvLTg4NTktMSwgb3IgdW5kZWZpbmVkJyk7XG4gICAgfVxuICAgIGxldCBmb3JtYXQgPSBkZWZhdWx0X2Zvcm1hdDtcbiAgICBpZiAodHlwZW9mIG9wdHMuZm9ybWF0ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICBpZiAoIWhhcy5jYWxsKGZvcm1hdHRlcnMsIG9wdHMuZm9ybWF0KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVW5rbm93biBmb3JtYXQgb3B0aW9uIHByb3ZpZGVkLicpO1xuICAgICAgICB9XG4gICAgICAgIGZvcm1hdCA9IG9wdHMuZm9ybWF0O1xuICAgIH1cbiAgICBjb25zdCBmb3JtYXR0ZXIgPSBmb3JtYXR0ZXJzW2Zvcm1hdF07XG4gICAgbGV0IGZpbHRlciA9IGRlZmF1bHRzLmZpbHRlcjtcbiAgICBpZiAodHlwZW9mIG9wdHMuZmlsdGVyID09PSAnZnVuY3Rpb24nIHx8IGlzX2FycmF5KG9wdHMuZmlsdGVyKSkge1xuICAgICAgICBmaWx0ZXIgPSBvcHRzLmZpbHRlcjtcbiAgICB9XG4gICAgbGV0IGFycmF5Rm9ybWF0O1xuICAgIGlmIChvcHRzLmFycmF5Rm9ybWF0ICYmIG9wdHMuYXJyYXlGb3JtYXQgaW4gYXJyYXlfcHJlZml4X2dlbmVyYXRvcnMpIHtcbiAgICAgICAgYXJyYXlGb3JtYXQgPSBvcHRzLmFycmF5Rm9ybWF0O1xuICAgIH1cbiAgICBlbHNlIGlmICgnaW5kaWNlcycgaW4gb3B0cykge1xuICAgICAgICBhcnJheUZvcm1hdCA9IG9wdHMuaW5kaWNlcyA/ICdpbmRpY2VzJyA6ICdyZXBlYXQnO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgYXJyYXlGb3JtYXQgPSBkZWZhdWx0cy5hcnJheUZvcm1hdDtcbiAgICB9XG4gICAgaWYgKCdjb21tYVJvdW5kVHJpcCcgaW4gb3B0cyAmJiB0eXBlb2Ygb3B0cy5jb21tYVJvdW5kVHJpcCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2Bjb21tYVJvdW5kVHJpcGAgbXVzdCBiZSBhIGJvb2xlYW4sIG9yIGFic2VudCcpO1xuICAgIH1cbiAgICBjb25zdCBhbGxvd0RvdHMgPSB0eXBlb2Ygb3B0cy5hbGxvd0RvdHMgPT09ICd1bmRlZmluZWQnID9cbiAgICAgICAgISFvcHRzLmVuY29kZURvdEluS2V5cyA9PT0gdHJ1ZSA/XG4gICAgICAgICAgICB0cnVlXG4gICAgICAgICAgICA6IGRlZmF1bHRzLmFsbG93RG90c1xuICAgICAgICA6ICEhb3B0cy5hbGxvd0RvdHM7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYWRkUXVlcnlQcmVmaXg6IHR5cGVvZiBvcHRzLmFkZFF1ZXJ5UHJlZml4ID09PSAnYm9vbGVhbicgPyBvcHRzLmFkZFF1ZXJ5UHJlZml4IDogZGVmYXVsdHMuYWRkUXVlcnlQcmVmaXgsXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgYWxsb3dEb3RzOiBhbGxvd0RvdHMsXG4gICAgICAgIGFsbG93RW1wdHlBcnJheXM6IHR5cGVvZiBvcHRzLmFsbG93RW1wdHlBcnJheXMgPT09ICdib29sZWFuJyA/ICEhb3B0cy5hbGxvd0VtcHR5QXJyYXlzIDogZGVmYXVsdHMuYWxsb3dFbXB0eUFycmF5cyxcbiAgICAgICAgYXJyYXlGb3JtYXQ6IGFycmF5Rm9ybWF0LFxuICAgICAgICBjaGFyc2V0OiBjaGFyc2V0LFxuICAgICAgICBjaGFyc2V0U2VudGluZWw6IHR5cGVvZiBvcHRzLmNoYXJzZXRTZW50aW5lbCA9PT0gJ2Jvb2xlYW4nID8gb3B0cy5jaGFyc2V0U2VudGluZWwgOiBkZWZhdWx0cy5jaGFyc2V0U2VudGluZWwsXG4gICAgICAgIGNvbW1hUm91bmRUcmlwOiAhIW9wdHMuY29tbWFSb3VuZFRyaXAsXG4gICAgICAgIGRlbGltaXRlcjogdHlwZW9mIG9wdHMuZGVsaW1pdGVyID09PSAndW5kZWZpbmVkJyA/IGRlZmF1bHRzLmRlbGltaXRlciA6IG9wdHMuZGVsaW1pdGVyLFxuICAgICAgICBlbmNvZGU6IHR5cGVvZiBvcHRzLmVuY29kZSA9PT0gJ2Jvb2xlYW4nID8gb3B0cy5lbmNvZGUgOiBkZWZhdWx0cy5lbmNvZGUsXG4gICAgICAgIGVuY29kZURvdEluS2V5czogdHlwZW9mIG9wdHMuZW5jb2RlRG90SW5LZXlzID09PSAnYm9vbGVhbicgPyBvcHRzLmVuY29kZURvdEluS2V5cyA6IGRlZmF1bHRzLmVuY29kZURvdEluS2V5cyxcbiAgICAgICAgZW5jb2RlcjogdHlwZW9mIG9wdHMuZW5jb2RlciA9PT0gJ2Z1bmN0aW9uJyA/IG9wdHMuZW5jb2RlciA6IGRlZmF1bHRzLmVuY29kZXIsXG4gICAgICAgIGVuY29kZVZhbHVlc09ubHk6IHR5cGVvZiBvcHRzLmVuY29kZVZhbHVlc09ubHkgPT09ICdib29sZWFuJyA/IG9wdHMuZW5jb2RlVmFsdWVzT25seSA6IGRlZmF1bHRzLmVuY29kZVZhbHVlc09ubHksXG4gICAgICAgIGZpbHRlcjogZmlsdGVyLFxuICAgICAgICBmb3JtYXQ6IGZvcm1hdCxcbiAgICAgICAgZm9ybWF0dGVyOiBmb3JtYXR0ZXIsXG4gICAgICAgIHNlcmlhbGl6ZURhdGU6IHR5cGVvZiBvcHRzLnNlcmlhbGl6ZURhdGUgPT09ICdmdW5jdGlvbicgPyBvcHRzLnNlcmlhbGl6ZURhdGUgOiBkZWZhdWx0cy5zZXJpYWxpemVEYXRlLFxuICAgICAgICBza2lwTnVsbHM6IHR5cGVvZiBvcHRzLnNraXBOdWxscyA9PT0gJ2Jvb2xlYW4nID8gb3B0cy5za2lwTnVsbHMgOiBkZWZhdWx0cy5za2lwTnVsbHMsXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgc29ydDogdHlwZW9mIG9wdHMuc29ydCA9PT0gJ2Z1bmN0aW9uJyA/IG9wdHMuc29ydCA6IG51bGwsXG4gICAgICAgIHN0cmljdE51bGxIYW5kbGluZzogdHlwZW9mIG9wdHMuc3RyaWN0TnVsbEhhbmRsaW5nID09PSAnYm9vbGVhbicgPyBvcHRzLnN0cmljdE51bGxIYW5kbGluZyA6IGRlZmF1bHRzLnN0cmljdE51bGxIYW5kbGluZyxcbiAgICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHN0cmluZ2lmeShvYmplY3QsIG9wdHMgPSB7fSkge1xuICAgIGxldCBvYmogPSBvYmplY3Q7XG4gICAgY29uc3Qgb3B0aW9ucyA9IG5vcm1hbGl6ZV9zdHJpbmdpZnlfb3B0aW9ucyhvcHRzKTtcbiAgICBsZXQgb2JqX2tleXM7XG4gICAgbGV0IGZpbHRlcjtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuZmlsdGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGZpbHRlciA9IG9wdGlvbnMuZmlsdGVyO1xuICAgICAgICBvYmogPSBmaWx0ZXIoJycsIG9iaik7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzX2FycmF5KG9wdGlvbnMuZmlsdGVyKSkge1xuICAgICAgICBmaWx0ZXIgPSBvcHRpb25zLmZpbHRlcjtcbiAgICAgICAgb2JqX2tleXMgPSBmaWx0ZXI7XG4gICAgfVxuICAgIGNvbnN0IGtleXMgPSBbXTtcbiAgICBpZiAodHlwZW9mIG9iaiAhPT0gJ29iamVjdCcgfHwgb2JqID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgY29uc3QgZ2VuZXJhdGVBcnJheVByZWZpeCA9IGFycmF5X3ByZWZpeF9nZW5lcmF0b3JzW29wdGlvbnMuYXJyYXlGb3JtYXRdO1xuICAgIGNvbnN0IGNvbW1hUm91bmRUcmlwID0gZ2VuZXJhdGVBcnJheVByZWZpeCA9PT0gJ2NvbW1hJyAmJiBvcHRpb25zLmNvbW1hUm91bmRUcmlwO1xuICAgIGlmICghb2JqX2tleXMpIHtcbiAgICAgICAgb2JqX2tleXMgPSBPYmplY3Qua2V5cyhvYmopO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5zb3J0KSB7XG4gICAgICAgIG9ial9rZXlzLnNvcnQob3B0aW9ucy5zb3J0KTtcbiAgICB9XG4gICAgY29uc3Qgc2lkZUNoYW5uZWwgPSBuZXcgV2Vha01hcCgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb2JqX2tleXMubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gb2JqX2tleXNbaV07XG4gICAgICAgIGlmIChvcHRpb25zLnNraXBOdWxscyAmJiBvYmpba2V5XSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcHVzaF90b19hcnJheShrZXlzLCBpbm5lcl9zdHJpbmdpZnkob2JqW2tleV0sIGtleSwgXG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgZ2VuZXJhdGVBcnJheVByZWZpeCwgY29tbWFSb3VuZFRyaXAsIG9wdGlvbnMuYWxsb3dFbXB0eUFycmF5cywgb3B0aW9ucy5zdHJpY3ROdWxsSGFuZGxpbmcsIG9wdGlvbnMuc2tpcE51bGxzLCBvcHRpb25zLmVuY29kZURvdEluS2V5cywgb3B0aW9ucy5lbmNvZGUgPyBvcHRpb25zLmVuY29kZXIgOiBudWxsLCBvcHRpb25zLmZpbHRlciwgb3B0aW9ucy5zb3J0LCBvcHRpb25zLmFsbG93RG90cywgb3B0aW9ucy5zZXJpYWxpemVEYXRlLCBvcHRpb25zLmZvcm1hdCwgb3B0aW9ucy5mb3JtYXR0ZXIsIG9wdGlvbnMuZW5jb2RlVmFsdWVzT25seSwgb3B0aW9ucy5jaGFyc2V0LCBzaWRlQ2hhbm5lbCkpO1xuICAgIH1cbiAgICBjb25zdCBqb2luZWQgPSBrZXlzLmpvaW4ob3B0aW9ucy5kZWxpbWl0ZXIpO1xuICAgIGxldCBwcmVmaXggPSBvcHRpb25zLmFkZFF1ZXJ5UHJlZml4ID09PSB0cnVlID8gJz8nIDogJyc7XG4gICAgaWYgKG9wdGlvbnMuY2hhcnNldFNlbnRpbmVsKSB7XG4gICAgICAgIGlmIChvcHRpb25zLmNoYXJzZXQgPT09ICdpc28tODg1OS0xJykge1xuICAgICAgICAgICAgLy8gZW5jb2RlVVJJQ29tcG9uZW50KCcmIzEwMDAzOycpLCB0aGUgXCJudW1lcmljIGVudGl0eVwiIHJlcHJlc2VudGF0aW9uIG9mIGEgY2hlY2ttYXJrXG4gICAgICAgICAgICBwcmVmaXggKz0gJ3V0Zjg9JTI2JTIzMTAwMDMlM0ImJztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIGVuY29kZVVSSUNvbXBvbmVudCgn4pyTJylcbiAgICAgICAgICAgIHByZWZpeCArPSAndXRmOD0lRTIlOUMlOTMmJztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gam9pbmVkLmxlbmd0aCA+IDAgPyBwcmVmaXggKyBqb2luZWQgOiAnJztcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0cmluZ2lmeS5tanMubWFwIiwiZXhwb3J0IGNvbnN0IFZFUlNJT04gPSAnNC4xMDQuMCc7IC8vIHgtcmVsZWFzZS1wbGVhc2UtdmVyc2lvblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dmVyc2lvbi5tanMubWFwIiwiZXhwb3J0IGxldCBhdXRvID0gZmFsc2U7XG5leHBvcnQgbGV0IGtpbmQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IGZldGNoID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBSZXF1ZXN0ID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBSZXNwb25zZSA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgSGVhZGVycyA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgRm9ybURhdGEgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IEJsb2IgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IEZpbGUgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IFJlYWRhYmxlU3RyZWFtID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucyA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgZ2V0RGVmYXVsdEFnZW50ID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBmaWxlRnJvbVBhdGggPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IGlzRnNSZWFkU3RyZWFtID0gdW5kZWZpbmVkO1xuZXhwb3J0IGZ1bmN0aW9uIHNldFNoaW1zKHNoaW1zLCBvcHRpb25zID0geyBhdXRvOiBmYWxzZSB9KSB7XG4gICAgaWYgKGF1dG8pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGB5b3UgbXVzdCBcXGBpbXBvcnQgJ29wZW5haS9zaGltcy8ke3NoaW1zLmtpbmR9J1xcYCBiZWZvcmUgaW1wb3J0aW5nIGFueXRoaW5nIGVsc2UgZnJvbSBvcGVuYWlgKTtcbiAgICB9XG4gICAgaWYgKGtpbmQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBjYW4ndCBcXGBpbXBvcnQgJ29wZW5haS9zaGltcy8ke3NoaW1zLmtpbmR9J1xcYCBhZnRlciBcXGBpbXBvcnQgJ29wZW5haS9zaGltcy8ke2tpbmR9J1xcYGApO1xuICAgIH1cbiAgICBhdXRvID0gb3B0aW9ucy5hdXRvO1xuICAgIGtpbmQgPSBzaGltcy5raW5kO1xuICAgIGZldGNoID0gc2hpbXMuZmV0Y2g7XG4gICAgUmVxdWVzdCA9IHNoaW1zLlJlcXVlc3Q7XG4gICAgUmVzcG9uc2UgPSBzaGltcy5SZXNwb25zZTtcbiAgICBIZWFkZXJzID0gc2hpbXMuSGVhZGVycztcbiAgICBGb3JtRGF0YSA9IHNoaW1zLkZvcm1EYXRhO1xuICAgIEJsb2IgPSBzaGltcy5CbG9iO1xuICAgIEZpbGUgPSBzaGltcy5GaWxlO1xuICAgIFJlYWRhYmxlU3RyZWFtID0gc2hpbXMuUmVhZGFibGVTdHJlYW07XG4gICAgZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnMgPSBzaGltcy5nZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucztcbiAgICBnZXREZWZhdWx0QWdlbnQgPSBzaGltcy5nZXREZWZhdWx0QWdlbnQ7XG4gICAgZmlsZUZyb21QYXRoID0gc2hpbXMuZmlsZUZyb21QYXRoO1xuICAgIGlzRnNSZWFkU3RyZWFtID0gc2hpbXMuaXNGc1JlYWRTdHJlYW07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZWdpc3RyeS5tanMubWFwIiwiLyoqXG4gKiBEaXNjbGFpbWVyOiBtb2R1bGVzIGluIF9zaGltcyBhcmVuJ3QgaW50ZW5kZWQgdG8gYmUgaW1wb3J0ZWQgYnkgU0RLIHVzZXJzLlxuICovXG5leHBvcnQgY2xhc3MgTXVsdGlwYXJ0Qm9keSB7XG4gICAgY29uc3RydWN0b3IoYm9keSkge1xuICAgICAgICB0aGlzLmJvZHkgPSBib2R5O1xuICAgIH1cbiAgICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgICAgIHJldHVybiAnTXVsdGlwYXJ0Qm9keSc7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9TXVsdGlwYXJ0Qm9keS5tanMubWFwIiwiaW1wb3J0IHsgTXVsdGlwYXJ0Qm9keSB9IGZyb20gXCIuL011bHRpcGFydEJvZHkubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gZ2V0UnVudGltZSh7IG1hbnVhbGx5SW1wb3J0ZWQgfSA9IHt9KSB7XG4gICAgY29uc3QgcmVjb21tZW5kYXRpb24gPSBtYW51YWxseUltcG9ydGVkID9cbiAgICAgICAgYFlvdSBtYXkgbmVlZCB0byB1c2UgcG9seWZpbGxzYFxuICAgICAgICA6IGBBZGQgb25lIG9mIHRoZXNlIGltcG9ydHMgYmVmb3JlIHlvdXIgZmlyc3QgXFxgaW1wb3J0IOKApiBmcm9tICdvcGVuYWknXFxgOlxuLSBcXGBpbXBvcnQgJ29wZW5haS9zaGltcy9ub2RlJ1xcYCAoaWYgeW91J3JlIHJ1bm5pbmcgb24gTm9kZSlcbi0gXFxgaW1wb3J0ICdvcGVuYWkvc2hpbXMvd2ViJ1xcYCAob3RoZXJ3aXNlKVxuYDtcbiAgICBsZXQgX2ZldGNoLCBfUmVxdWVzdCwgX1Jlc3BvbnNlLCBfSGVhZGVycztcbiAgICB0cnkge1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIF9mZXRjaCA9IGZldGNoO1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIF9SZXF1ZXN0ID0gUmVxdWVzdDtcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBfUmVzcG9uc2UgPSBSZXNwb25zZTtcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBfSGVhZGVycyA9IEhlYWRlcnM7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHRoaXMgZW52aXJvbm1lbnQgaXMgbWlzc2luZyB0aGUgZm9sbG93aW5nIFdlYiBGZXRjaCBBUEkgdHlwZTogJHtlcnJvci5tZXNzYWdlfS4gJHtyZWNvbW1lbmRhdGlvbn1gKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAga2luZDogJ3dlYicsXG4gICAgICAgIGZldGNoOiBfZmV0Y2gsXG4gICAgICAgIFJlcXVlc3Q6IF9SZXF1ZXN0LFxuICAgICAgICBSZXNwb25zZTogX1Jlc3BvbnNlLFxuICAgICAgICBIZWFkZXJzOiBfSGVhZGVycyxcbiAgICAgICAgRm9ybURhdGE6IFxuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHR5cGVvZiBGb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgPyBGb3JtRGF0YSA6IChjbGFzcyBGb3JtRGF0YSB7XG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGZpbGUgdXBsb2FkcyBhcmVuJ3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQgeWV0IGFzICdGb3JtRGF0YScgaXMgdW5kZWZpbmVkLiAke3JlY29tbWVuZGF0aW9ufWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KSxcbiAgICAgICAgQmxvYjogdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnID8gQmxvYiA6IChjbGFzcyBCbG9iIHtcbiAgICAgICAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZmlsZSB1cGxvYWRzIGFyZW4ndCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudCB5ZXQgYXMgJ0Jsb2InIGlzIHVuZGVmaW5lZC4gJHtyZWNvbW1lbmRhdGlvbn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICAgIEZpbGU6IFxuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHR5cGVvZiBGaWxlICE9PSAndW5kZWZpbmVkJyA/IEZpbGUgOiAoY2xhc3MgRmlsZSB7XG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGZpbGUgdXBsb2FkcyBhcmVuJ3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQgeWV0IGFzICdGaWxlJyBpcyB1bmRlZmluZWQuICR7cmVjb21tZW5kYXRpb259YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pLFxuICAgICAgICBSZWFkYWJsZVN0cmVhbTogXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgdHlwZW9mIFJlYWRhYmxlU3RyZWFtICE9PSAndW5kZWZpbmVkJyA/IFJlYWRhYmxlU3RyZWFtIDogKGNsYXNzIFJlYWRhYmxlU3RyZWFtIHtcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgc3RyZWFtaW5nIGlzbid0IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50IHlldCBhcyAnUmVhZGFibGVTdHJlYW0nIGlzIHVuZGVmaW5lZC4gJHtyZWNvbW1lbmRhdGlvbn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICAgIGdldE11bHRpcGFydFJlcXVlc3RPcHRpb25zOiBhc3luYyAoXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgZm9ybSwgb3B0cykgPT4gKHtcbiAgICAgICAgICAgIC4uLm9wdHMsXG4gICAgICAgICAgICBib2R5OiBuZXcgTXVsdGlwYXJ0Qm9keShmb3JtKSxcbiAgICAgICAgfSksXG4gICAgICAgIGdldERlZmF1bHRBZ2VudDogKHVybCkgPT4gdW5kZWZpbmVkLFxuICAgICAgICBmaWxlRnJvbVBhdGg6ICgpID0+IHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGhlIGBmaWxlRnJvbVBhdGhgIGZ1bmN0aW9uIGlzIG9ubHkgc3VwcG9ydGVkIGluIE5vZGUuIFNlZSB0aGUgUkVBRE1FIGZvciBtb3JlIGRldGFpbHM6IGh0dHBzOi8vd3d3LmdpdGh1Yi5jb20vb3BlbmFpL29wZW5haS1ub2RlI2ZpbGUtdXBsb2FkcycpO1xuICAgICAgICB9LFxuICAgICAgICBpc0ZzUmVhZFN0cmVhbTogKHZhbHVlKSA9PiBmYWxzZSxcbiAgICB9O1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d2ViLXJ1bnRpbWUubWpzLm1hcCIsIi8qKlxuICogRGlzY2xhaW1lcjogbW9kdWxlcyBpbiBfc2hpbXMgYXJlbid0IGludGVuZGVkIHRvIGJlIGltcG9ydGVkIGJ5IFNESyB1c2Vycy5cbiAqL1xuaW1wb3J0ICogYXMgc2hpbXMgZnJvbSAnLi9yZWdpc3RyeS5tanMnO1xuaW1wb3J0ICogYXMgYXV0byBmcm9tICdvcGVuYWkvX3NoaW1zL2F1dG8vcnVudGltZSc7XG5leHBvcnQgY29uc3QgaW5pdCA9ICgpID0+IHtcbiAgaWYgKCFzaGltcy5raW5kKSBzaGltcy5zZXRTaGltcyhhdXRvLmdldFJ1bnRpbWUoKSwgeyBhdXRvOiB0cnVlIH0pO1xufTtcbmV4cG9ydCAqIGZyb20gJy4vcmVnaXN0cnkubWpzJztcblxuaW5pdCgpO1xuIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IGNhc3RUb0Vycm9yIH0gZnJvbSBcIi4vY29yZS5tanNcIjtcbmV4cG9ydCBjbGFzcyBPcGVuQUlFcnJvciBleHRlbmRzIEVycm9yIHtcbn1cbmV4cG9ydCBjbGFzcyBBUElFcnJvciBleHRlbmRzIE9wZW5BSUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKSB7XG4gICAgICAgIHN1cGVyKGAke0FQSUVycm9yLm1ha2VNZXNzYWdlKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UpfWApO1xuICAgICAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgICAgICAgdGhpcy5oZWFkZXJzID0gaGVhZGVycztcbiAgICAgICAgdGhpcy5yZXF1ZXN0X2lkID0gaGVhZGVycz8uWyd4LXJlcXVlc3QtaWQnXTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGVycm9yO1xuICAgICAgICBjb25zdCBkYXRhID0gZXJyb3I7XG4gICAgICAgIHRoaXMuY29kZSA9IGRhdGE/LlsnY29kZSddO1xuICAgICAgICB0aGlzLnBhcmFtID0gZGF0YT8uWydwYXJhbSddO1xuICAgICAgICB0aGlzLnR5cGUgPSBkYXRhPy5bJ3R5cGUnXTtcbiAgICB9XG4gICAgc3RhdGljIG1ha2VNZXNzYWdlKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UpIHtcbiAgICAgICAgY29uc3QgbXNnID0gZXJyb3I/Lm1lc3NhZ2UgP1xuICAgICAgICAgICAgdHlwZW9mIGVycm9yLm1lc3NhZ2UgPT09ICdzdHJpbmcnID9cbiAgICAgICAgICAgICAgICBlcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgOiBKU09OLnN0cmluZ2lmeShlcnJvci5tZXNzYWdlKVxuICAgICAgICAgICAgOiBlcnJvciA/IEpTT04uc3RyaW5naWZ5KGVycm9yKVxuICAgICAgICAgICAgICAgIDogbWVzc2FnZTtcbiAgICAgICAgaWYgKHN0YXR1cyAmJiBtc2cpIHtcbiAgICAgICAgICAgIHJldHVybiBgJHtzdGF0dXN9ICR7bXNnfWA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXR1cykge1xuICAgICAgICAgICAgcmV0dXJuIGAke3N0YXR1c30gc3RhdHVzIGNvZGUgKG5vIGJvZHkpYDtcbiAgICAgICAgfVxuICAgICAgICBpZiAobXNnKSB7XG4gICAgICAgICAgICByZXR1cm4gbXNnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAnKG5vIHN0YXR1cyBjb2RlIG9yIGJvZHkpJztcbiAgICB9XG4gICAgc3RhdGljIGdlbmVyYXRlKHN0YXR1cywgZXJyb3JSZXNwb25zZSwgbWVzc2FnZSwgaGVhZGVycykge1xuICAgICAgICBpZiAoIXN0YXR1cyB8fCAhaGVhZGVycykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBBUElDb25uZWN0aW9uRXJyb3IoeyBtZXNzYWdlLCBjYXVzZTogY2FzdFRvRXJyb3IoZXJyb3JSZXNwb25zZSkgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZXJyb3IgPSBlcnJvclJlc3BvbnNlPy5bJ2Vycm9yJ107XG4gICAgICAgIGlmIChzdGF0dXMgPT09IDQwMCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBCYWRSZXF1ZXN0RXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IEF1dGhlbnRpY2F0aW9uRXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFBlcm1pc3Npb25EZW5pZWRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgTm90Rm91bmRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdHVzID09PSA0MDkpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgQ29uZmxpY3RFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdHVzID09PSA0MjIpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVW5wcm9jZXNzYWJsZUVudGl0eUVycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdGF0dXMgPT09IDQyOSkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBSYXRlTGltaXRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdHVzID49IDUwMCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBJbnRlcm5hbFNlcnZlckVycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgQVBJRXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEFQSVVzZXJBYm9ydEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKHsgbWVzc2FnZSB9ID0ge30pIHtcbiAgICAgICAgc3VwZXIodW5kZWZpbmVkLCB1bmRlZmluZWQsIG1lc3NhZ2UgfHwgJ1JlcXVlc3Qgd2FzIGFib3J0ZWQuJywgdW5kZWZpbmVkKTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQVBJQ29ubmVjdGlvbkVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKHsgbWVzc2FnZSwgY2F1c2UgfSkge1xuICAgICAgICBzdXBlcih1bmRlZmluZWQsIHVuZGVmaW5lZCwgbWVzc2FnZSB8fCAnQ29ubmVjdGlvbiBlcnJvci4nLCB1bmRlZmluZWQpO1xuICAgICAgICAvLyBpbiBzb21lIGVudmlyb25tZW50cyB0aGUgJ2NhdXNlJyBwcm9wZXJ0eSBpcyBhbHJlYWR5IGRlY2xhcmVkXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgaWYgKGNhdXNlKVxuICAgICAgICAgICAgdGhpcy5jYXVzZSA9IGNhdXNlO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBUElDb25uZWN0aW9uVGltZW91dEVycm9yIGV4dGVuZHMgQVBJQ29ubmVjdGlvbkVycm9yIHtcbiAgICBjb25zdHJ1Y3Rvcih7IG1lc3NhZ2UgfSA9IHt9KSB7XG4gICAgICAgIHN1cGVyKHsgbWVzc2FnZTogbWVzc2FnZSA/PyAnUmVxdWVzdCB0aW1lZCBvdXQuJyB9KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQmFkUmVxdWVzdEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xufVxuZXhwb3J0IGNsYXNzIEF1dGhlbnRpY2F0aW9uRXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG59XG5leHBvcnQgY2xhc3MgUGVybWlzc2lvbkRlbmllZEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xufVxuZXhwb3J0IGNsYXNzIE5vdEZvdW5kRXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG59XG5leHBvcnQgY2xhc3MgQ29uZmxpY3RFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbn1cbmV4cG9ydCBjbGFzcyBVbnByb2Nlc3NhYmxlRW50aXR5RXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG59XG5leHBvcnQgY2xhc3MgUmF0ZUxpbWl0RXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG59XG5leHBvcnQgY2xhc3MgSW50ZXJuYWxTZXJ2ZXJFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbn1cbmV4cG9ydCBjbGFzcyBMZW5ndGhGaW5pc2hSZWFzb25FcnJvciBleHRlbmRzIE9wZW5BSUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoYENvdWxkIG5vdCBwYXJzZSByZXNwb25zZSBjb250ZW50IGFzIHRoZSBsZW5ndGggbGltaXQgd2FzIHJlYWNoZWRgKTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQ29udGVudEZpbHRlckZpbmlzaFJlYXNvbkVycm9yIGV4dGVuZHMgT3BlbkFJRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihgQ291bGQgbm90IHBhcnNlIHJlc3BvbnNlIGNvbnRlbnQgYXMgdGhlIHJlcXVlc3Qgd2FzIHJlamVjdGVkIGJ5IHRoZSBjb250ZW50IGZpbHRlcmApO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9yLm1qcy5tYXAiLCJ2YXIgX19jbGFzc1ByaXZhdGVGaWVsZFNldCA9ICh0aGlzICYmIHRoaXMuX19jbGFzc1ByaXZhdGVGaWVsZFNldCkgfHwgZnVuY3Rpb24gKHJlY2VpdmVyLCBzdGF0ZSwgdmFsdWUsIGtpbmQsIGYpIHtcbiAgICBpZiAoa2luZCA9PT0gXCJtXCIpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIG1ldGhvZCBpcyBub3Qgd3JpdGFibGVcIik7XG4gICAgaWYgKGtpbmQgPT09IFwiYVwiICYmICFmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBhY2Nlc3NvciB3YXMgZGVmaW5lZCB3aXRob3V0IGEgc2V0dGVyXCIpO1xuICAgIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHdyaXRlIHByaXZhdGUgbWVtYmVyIHRvIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gICAgcmV0dXJuIChraW5kID09PSBcImFcIiA/IGYuY2FsbChyZWNlaXZlciwgdmFsdWUpIDogZiA/IGYudmFsdWUgPSB2YWx1ZSA6IHN0YXRlLnNldChyZWNlaXZlciwgdmFsdWUpKSwgdmFsdWU7XG59O1xudmFyIF9fY2xhc3NQcml2YXRlRmllbGRHZXQgPSAodGhpcyAmJiB0aGlzLl9fY2xhc3NQcml2YXRlRmllbGRHZXQpIHx8IGZ1bmN0aW9uIChyZWNlaXZlciwgc3RhdGUsIGtpbmQsIGYpIHtcbiAgICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBnZXR0ZXJcIik7XG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgcmVhZCBwcml2YXRlIG1lbWJlciBmcm9tIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gICAgcmV0dXJuIGtpbmQgPT09IFwibVwiID8gZiA6IGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyKSA6IGYgPyBmLnZhbHVlIDogc3RhdGUuZ2V0KHJlY2VpdmVyKTtcbn07XG52YXIgX0xpbmVEZWNvZGVyX2NhcnJpYWdlUmV0dXJuSW5kZXg7XG5pbXBvcnQgeyBPcGVuQUlFcnJvciB9IGZyb20gXCIuLi8uLi9lcnJvci5tanNcIjtcbi8qKlxuICogQSByZS1pbXBsZW1lbnRhdGlvbiBvZiBodHRweCdzIGBMaW5lRGVjb2RlcmAgaW4gUHl0aG9uIHRoYXQgaGFuZGxlcyBpbmNyZW1lbnRhbGx5XG4gKiByZWFkaW5nIGxpbmVzIGZyb20gdGV4dC5cbiAqXG4gKiBodHRwczovL2dpdGh1Yi5jb20vZW5jb2RlL2h0dHB4L2Jsb2IvOTIwMzMzZWE5ODExOGU5Y2Y2MTdmMjQ2OTA1ZDdiMjAyNTEwOTQxYy9odHRweC9fZGVjb2RlcnMucHkjTDI1OFxuICovXG5leHBvcnQgY2xhc3MgTGluZURlY29kZXIge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBfTGluZURlY29kZXJfY2FycmlhZ2VSZXR1cm5JbmRleC5zZXQodGhpcywgdm9pZCAwKTtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBuZXcgVWludDhBcnJheSgpO1xuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9MaW5lRGVjb2Rlcl9jYXJyaWFnZVJldHVybkluZGV4LCBudWxsLCBcImZcIik7XG4gICAgfVxuICAgIGRlY29kZShjaHVuaykge1xuICAgICAgICBpZiAoY2h1bmsgPT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJpbmFyeUNodW5rID0gY2h1bmsgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciA/IG5ldyBVaW50OEFycmF5KGNodW5rKVxuICAgICAgICAgICAgOiB0eXBlb2YgY2h1bmsgPT09ICdzdHJpbmcnID8gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGNodW5rKVxuICAgICAgICAgICAgICAgIDogY2h1bms7XG4gICAgICAgIGxldCBuZXdEYXRhID0gbmV3IFVpbnQ4QXJyYXkodGhpcy5idWZmZXIubGVuZ3RoICsgYmluYXJ5Q2h1bmsubGVuZ3RoKTtcbiAgICAgICAgbmV3RGF0YS5zZXQodGhpcy5idWZmZXIpO1xuICAgICAgICBuZXdEYXRhLnNldChiaW5hcnlDaHVuaywgdGhpcy5idWZmZXIubGVuZ3RoKTtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBuZXdEYXRhO1xuICAgICAgICBjb25zdCBsaW5lcyA9IFtdO1xuICAgICAgICBsZXQgcGF0dGVybkluZGV4O1xuICAgICAgICB3aGlsZSAoKHBhdHRlcm5JbmRleCA9IGZpbmROZXdsaW5lSW5kZXgodGhpcy5idWZmZXIsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0xpbmVEZWNvZGVyX2NhcnJpYWdlUmV0dXJuSW5kZXgsIFwiZlwiKSkpICE9IG51bGwpIHtcbiAgICAgICAgICAgIGlmIChwYXR0ZXJuSW5kZXguY2FycmlhZ2UgJiYgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfTGluZURlY29kZXJfY2FycmlhZ2VSZXR1cm5JbmRleCwgXCJmXCIpID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAvLyBza2lwIHVudGlsIHdlIGVpdGhlciBnZXQgYSBjb3JyZXNwb25kaW5nIGBcXG5gLCBhIG5ldyBgXFxyYCBvciBub3RoaW5nXG4gICAgICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfTGluZURlY29kZXJfY2FycmlhZ2VSZXR1cm5JbmRleCwgcGF0dGVybkluZGV4LmluZGV4LCBcImZcIik7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyB3ZSBnb3QgZG91YmxlIFxcciBvciBcXHJ0ZXh0XFxuXG4gICAgICAgICAgICBpZiAoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfTGluZURlY29kZXJfY2FycmlhZ2VSZXR1cm5JbmRleCwgXCJmXCIpICE9IG51bGwgJiZcbiAgICAgICAgICAgICAgICAocGF0dGVybkluZGV4LmluZGV4ICE9PSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9MaW5lRGVjb2Rlcl9jYXJyaWFnZVJldHVybkluZGV4LCBcImZcIikgKyAxIHx8IHBhdHRlcm5JbmRleC5jYXJyaWFnZSkpIHtcbiAgICAgICAgICAgICAgICBsaW5lcy5wdXNoKHRoaXMuZGVjb2RlVGV4dCh0aGlzLmJ1ZmZlci5zbGljZSgwLCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9MaW5lRGVjb2Rlcl9jYXJyaWFnZVJldHVybkluZGV4LCBcImZcIikgLSAxKSkpO1xuICAgICAgICAgICAgICAgIHRoaXMuYnVmZmVyID0gdGhpcy5idWZmZXIuc2xpY2UoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfTGluZURlY29kZXJfY2FycmlhZ2VSZXR1cm5JbmRleCwgXCJmXCIpKTtcbiAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9MaW5lRGVjb2Rlcl9jYXJyaWFnZVJldHVybkluZGV4LCBudWxsLCBcImZcIik7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBlbmRJbmRleCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0xpbmVEZWNvZGVyX2NhcnJpYWdlUmV0dXJuSW5kZXgsIFwiZlwiKSAhPT0gbnVsbCA/IHBhdHRlcm5JbmRleC5wcmVjZWRpbmcgLSAxIDogcGF0dGVybkluZGV4LnByZWNlZGluZztcbiAgICAgICAgICAgIGNvbnN0IGxpbmUgPSB0aGlzLmRlY29kZVRleHQodGhpcy5idWZmZXIuc2xpY2UoMCwgZW5kSW5kZXgpKTtcbiAgICAgICAgICAgIGxpbmVzLnB1c2gobGluZSk7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlciA9IHRoaXMuYnVmZmVyLnNsaWNlKHBhdHRlcm5JbmRleC5pbmRleCk7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9MaW5lRGVjb2Rlcl9jYXJyaWFnZVJldHVybkluZGV4LCBudWxsLCBcImZcIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGxpbmVzO1xuICAgIH1cbiAgICBkZWNvZGVUZXh0KGJ5dGVzKSB7XG4gICAgICAgIGlmIChieXRlcyA9PSBudWxsKVxuICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICBpZiAodHlwZW9mIGJ5dGVzID09PSAnc3RyaW5nJylcbiAgICAgICAgICAgIHJldHVybiBieXRlcztcbiAgICAgICAgLy8gTm9kZTpcbiAgICAgICAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBpZiAoYnl0ZXMgaW5zdGFuY2VvZiBCdWZmZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnl0ZXMudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChieXRlcyBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gQnVmZmVyLmZyb20oYnl0ZXMpLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYFVuZXhwZWN0ZWQ6IHJlY2VpdmVkIG5vbi1VaW50OEFycmF5ICgke2J5dGVzLmNvbnN0cnVjdG9yLm5hbWV9KSBzdHJlYW0gY2h1bmsgaW4gYW4gZW52aXJvbm1lbnQgd2l0aCBhIGdsb2JhbCBcIkJ1ZmZlclwiIGRlZmluZWQsIHdoaWNoIHRoaXMgbGlicmFyeSBhc3N1bWVzIHRvIGJlIE5vZGUuIFBsZWFzZSByZXBvcnQgdGhpcyBlcnJvci5gKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBCcm93c2VyXG4gICAgICAgIGlmICh0eXBlb2YgVGV4dERlY29kZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBpZiAoYnl0ZXMgaW5zdGFuY2VvZiBVaW50OEFycmF5IHx8IGJ5dGVzIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRleHREZWNvZGVyID8/ICh0aGlzLnRleHREZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCd1dGY4JykpO1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnRleHREZWNvZGVyLmRlY29kZShieXRlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYFVuZXhwZWN0ZWQ6IHJlY2VpdmVkIG5vbi1VaW50OEFycmF5L0FycmF5QnVmZmVyICgke2J5dGVzLmNvbnN0cnVjdG9yLm5hbWV9KSBpbiBhIHdlYiBwbGF0Zm9ybS4gUGxlYXNlIHJlcG9ydCB0aGlzIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgVW5leHBlY3RlZDogbmVpdGhlciBCdWZmZXIgbm9yIFRleHREZWNvZGVyIGFyZSBhdmFpbGFibGUgYXMgZ2xvYmFscy4gUGxlYXNlIHJlcG9ydCB0aGlzIGVycm9yLmApO1xuICAgIH1cbiAgICBmbHVzaCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLmJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUoJ1xcbicpO1xuICAgIH1cbn1cbl9MaW5lRGVjb2Rlcl9jYXJyaWFnZVJldHVybkluZGV4ID0gbmV3IFdlYWtNYXAoKTtcbi8vIHByZXR0aWVyLWlnbm9yZVxuTGluZURlY29kZXIuTkVXTElORV9DSEFSUyA9IG5ldyBTZXQoWydcXG4nLCAnXFxyJ10pO1xuTGluZURlY29kZXIuTkVXTElORV9SRUdFWFAgPSAvXFxyXFxufFtcXG5cXHJdL2c7XG4vKipcbiAqIFRoaXMgZnVuY3Rpb24gc2VhcmNoZXMgdGhlIGJ1ZmZlciBmb3IgdGhlIGVuZCBwYXR0ZXJucywgKFxcciBvciBcXG4pXG4gKiBhbmQgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCB0aGUgaW5kZXggcHJlY2VkaW5nIHRoZSBtYXRjaGVkIG5ld2xpbmUgYW5kIHRoZVxuICogaW5kZXggYWZ0ZXIgdGhlIG5ld2xpbmUgY2hhci4gYG51bGxgIGlzIHJldHVybmVkIGlmIG5vIG5ldyBsaW5lIGlzIGZvdW5kLlxuICpcbiAqIGBgYHRzXG4gKiBmaW5kTmV3TGluZUluZGV4KCdhYmNcXG5kZWYnKSAtPiB7IHByZWNlZGluZzogMiwgaW5kZXg6IDMgfVxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIGZpbmROZXdsaW5lSW5kZXgoYnVmZmVyLCBzdGFydEluZGV4KSB7XG4gICAgY29uc3QgbmV3bGluZSA9IDB4MGE7IC8vIFxcblxuICAgIGNvbnN0IGNhcnJpYWdlID0gMHgwZDsgLy8gXFxyXG4gICAgZm9yIChsZXQgaSA9IHN0YXJ0SW5kZXggPz8gMDsgaSA8IGJ1ZmZlci5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoYnVmZmVyW2ldID09PSBuZXdsaW5lKSB7XG4gICAgICAgICAgICByZXR1cm4geyBwcmVjZWRpbmc6IGksIGluZGV4OiBpICsgMSwgY2FycmlhZ2U6IGZhbHNlIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJ1ZmZlcltpXSA9PT0gY2FycmlhZ2UpIHtcbiAgICAgICAgICAgIHJldHVybiB7IHByZWNlZGluZzogaSwgaW5kZXg6IGkgKyAxLCBjYXJyaWFnZTogdHJ1ZSB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmREb3VibGVOZXdsaW5lSW5kZXgoYnVmZmVyKSB7XG4gICAgLy8gVGhpcyBmdW5jdGlvbiBzZWFyY2hlcyB0aGUgYnVmZmVyIGZvciB0aGUgZW5kIHBhdHRlcm5zIChcXHJcXHIsIFxcblxcbiwgXFxyXFxuXFxyXFxuKVxuICAgIC8vIGFuZCByZXR1cm5zIHRoZSBpbmRleCByaWdodCBhZnRlciB0aGUgZmlyc3Qgb2NjdXJyZW5jZSBvZiBhbnkgcGF0dGVybixcbiAgICAvLyBvciAtMSBpZiBub25lIG9mIHRoZSBwYXR0ZXJucyBhcmUgZm91bmQuXG4gICAgY29uc3QgbmV3bGluZSA9IDB4MGE7IC8vIFxcblxuICAgIGNvbnN0IGNhcnJpYWdlID0gMHgwZDsgLy8gXFxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBidWZmZXIubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgIGlmIChidWZmZXJbaV0gPT09IG5ld2xpbmUgJiYgYnVmZmVyW2kgKyAxXSA9PT0gbmV3bGluZSkge1xuICAgICAgICAgICAgLy8gXFxuXFxuXG4gICAgICAgICAgICByZXR1cm4gaSArIDI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJ1ZmZlcltpXSA9PT0gY2FycmlhZ2UgJiYgYnVmZmVyW2kgKyAxXSA9PT0gY2FycmlhZ2UpIHtcbiAgICAgICAgICAgIC8vIFxcclxcclxuICAgICAgICAgICAgcmV0dXJuIGkgKyAyO1xuICAgICAgICB9XG4gICAgICAgIGlmIChidWZmZXJbaV0gPT09IGNhcnJpYWdlICYmXG4gICAgICAgICAgICBidWZmZXJbaSArIDFdID09PSBuZXdsaW5lICYmXG4gICAgICAgICAgICBpICsgMyA8IGJ1ZmZlci5sZW5ndGggJiZcbiAgICAgICAgICAgIGJ1ZmZlcltpICsgMl0gPT09IGNhcnJpYWdlICYmXG4gICAgICAgICAgICBidWZmZXJbaSArIDNdID09PSBuZXdsaW5lKSB7XG4gICAgICAgICAgICAvLyBcXHJcXG5cXHJcXG5cbiAgICAgICAgICAgIHJldHVybiBpICsgNDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gLTE7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1saW5lLm1qcy5tYXAiLCIvKipcbiAqIE1vc3QgYnJvd3NlcnMgZG9uJ3QgeWV0IGhhdmUgYXN5bmMgaXRlcmFibGUgc3VwcG9ydCBmb3IgUmVhZGFibGVTdHJlYW0sXG4gKiBhbmQgTm9kZSBoYXMgYSB2ZXJ5IGRpZmZlcmVudCB3YXkgb2YgcmVhZGluZyBieXRlcyBmcm9tIGl0cyBcIlJlYWRhYmxlU3RyZWFtXCIuXG4gKlxuICogVGhpcyBwb2x5ZmlsbCB3YXMgcHVsbGVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL01hdHRpYXNCdWVsZW5zL3dlYi1zdHJlYW1zLXBvbHlmaWxsL3B1bGwvMTIyI2lzc3VlY29tbWVudC0xNjI3MzU0NDkwXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSZWFkYWJsZVN0cmVhbVRvQXN5bmNJdGVyYWJsZShzdHJlYW0pIHtcbiAgICBpZiAoc3RyZWFtW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSlcbiAgICAgICAgcmV0dXJuIHN0cmVhbTtcbiAgICBjb25zdCByZWFkZXIgPSBzdHJlYW0uZ2V0UmVhZGVyKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYXN5bmMgbmV4dCgpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzdWx0Py5kb25lKVxuICAgICAgICAgICAgICAgICAgICByZWFkZXIucmVsZWFzZUxvY2soKTsgLy8gcmVsZWFzZSBsb2NrIHdoZW4gc3RyZWFtIGJlY29tZXMgY2xvc2VkXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlbGVhc2VMb2NrKCk7IC8vIHJlbGVhc2UgbG9jayB3aGVuIHN0cmVhbSBiZWNvbWVzIGVycm9yZWRcbiAgICAgICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBhc3luYyByZXR1cm4oKSB7XG4gICAgICAgICAgICBjb25zdCBjYW5jZWxQcm9taXNlID0gcmVhZGVyLmNhbmNlbCgpO1xuICAgICAgICAgICAgcmVhZGVyLnJlbGVhc2VMb2NrKCk7XG4gICAgICAgICAgICBhd2FpdCBjYW5jZWxQcm9taXNlO1xuICAgICAgICAgICAgcmV0dXJuIHsgZG9uZTogdHJ1ZSwgdmFsdWU6IHVuZGVmaW5lZCB9O1xuICAgICAgICB9LFxuICAgICAgICBbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH0sXG4gICAgfTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0cmVhbS11dGlscy5tanMubWFwIiwiaW1wb3J0IHsgUmVhZGFibGVTdHJlYW0gfSBmcm9tIFwiLi9fc2hpbXMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBPcGVuQUlFcnJvciB9IGZyb20gXCIuL2Vycm9yLm1qc1wiO1xuaW1wb3J0IHsgZmluZERvdWJsZU5ld2xpbmVJbmRleCwgTGluZURlY29kZXIgfSBmcm9tIFwiLi9pbnRlcm5hbC9kZWNvZGVycy9saW5lLm1qc1wiO1xuaW1wb3J0IHsgUmVhZGFibGVTdHJlYW1Ub0FzeW5jSXRlcmFibGUgfSBmcm9tIFwiLi9pbnRlcm5hbC9zdHJlYW0tdXRpbHMubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSZXNwb25zZUhlYWRlcnMgfSBmcm9tIFwiLi9jb3JlLm1qc1wiO1xuaW1wb3J0IHsgQVBJRXJyb3IgfSBmcm9tIFwiLi9lcnJvci5tanNcIjtcbmV4cG9ydCBjbGFzcyBTdHJlYW0ge1xuICAgIGNvbnN0cnVjdG9yKGl0ZXJhdG9yLCBjb250cm9sbGVyKSB7XG4gICAgICAgIHRoaXMuaXRlcmF0b3IgPSBpdGVyYXRvcjtcbiAgICAgICAgdGhpcy5jb250cm9sbGVyID0gY29udHJvbGxlcjtcbiAgICB9XG4gICAgc3RhdGljIGZyb21TU0VSZXNwb25zZShyZXNwb25zZSwgY29udHJvbGxlcikge1xuICAgICAgICBsZXQgY29uc3VtZWQgPSBmYWxzZTtcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24qIGl0ZXJhdG9yKCkge1xuICAgICAgICAgICAgaWYgKGNvbnN1bWVkKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgaXRlcmF0ZSBvdmVyIGEgY29uc3VtZWQgc3RyZWFtLCB1c2UgYC50ZWUoKWAgdG8gc3BsaXQgdGhlIHN0cmVhbS4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN1bWVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGxldCBkb25lID0gZmFsc2U7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGZvciBhd2FpdCAoY29uc3Qgc3NlIG9mIF9pdGVyU1NFTWVzc2FnZXMocmVzcG9uc2UsIGNvbnRyb2xsZXIpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkb25lKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzc2UuZGF0YS5zdGFydHNXaXRoKCdbRE9ORV0nKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoc3NlLmV2ZW50ID09PSBudWxsIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICBzc2UuZXZlbnQuc3RhcnRzV2l0aCgncmVzcG9uc2UuJykgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNzZS5ldmVudC5zdGFydHNXaXRoKCd0cmFuc2NyaXB0LicpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YSA9IEpTT04ucGFyc2Uoc3NlLmRhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBDb3VsZCBub3QgcGFyc2UgbWVzc2FnZSBpbnRvIEpTT046YCwgc3NlLmRhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZyb20gY2h1bms6YCwgc3NlLnJhdyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYXRhICYmIGRhdGEuZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgQVBJRXJyb3IodW5kZWZpbmVkLCBkYXRhLmVycm9yLCB1bmRlZmluZWQsIGNyZWF0ZVJlc3BvbnNlSGVhZGVycyhyZXNwb25zZS5oZWFkZXJzKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB5aWVsZCBkYXRhO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEgPSBKU09OLnBhcnNlKHNzZS5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgQ291bGQgbm90IHBhcnNlIG1lc3NhZ2UgaW50byBKU09OOmAsIHNzZS5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBGcm9tIGNodW5rOmAsIHNzZS5yYXcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiBJcyB0aGlzIHdoZXJlIHRoZSBlcnJvciBzaG91bGQgYmUgdGhyb3duP1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNzZS5ldmVudCA9PSAnZXJyb3InKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFQSUVycm9yKHVuZGVmaW5lZCwgZGF0YS5lcnJvciwgZGF0YS5tZXNzYWdlLCB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgeWllbGQgeyBldmVudDogc3NlLmV2ZW50LCBkYXRhOiBkYXRhIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIC8vIElmIHRoZSB1c2VyIGNhbGxzIGBzdHJlYW0uY29udHJvbGxlci5hYm9ydCgpYCwgd2Ugc2hvdWxkIGV4aXQgd2l0aG91dCB0aHJvd2luZy5cbiAgICAgICAgICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yICYmIGUubmFtZSA9PT0gJ0Fib3J0RXJyb3InKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIC8vIElmIHRoZSB1c2VyIGBicmVha2BzLCBhYm9ydCB0aGUgb25nb2luZyByZXF1ZXN0LlxuICAgICAgICAgICAgICAgIGlmICghZG9uZSlcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgU3RyZWFtKGl0ZXJhdG9yLCBjb250cm9sbGVyKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2VuZXJhdGVzIGEgU3RyZWFtIGZyb20gYSBuZXdsaW5lLXNlcGFyYXRlZCBSZWFkYWJsZVN0cmVhbVxuICAgICAqIHdoZXJlIGVhY2ggaXRlbSBpcyBhIEpTT04gdmFsdWUuXG4gICAgICovXG4gICAgc3RhdGljIGZyb21SZWFkYWJsZVN0cmVhbShyZWFkYWJsZVN0cmVhbSwgY29udHJvbGxlcikge1xuICAgICAgICBsZXQgY29uc3VtZWQgPSBmYWxzZTtcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24qIGl0ZXJMaW5lcygpIHtcbiAgICAgICAgICAgIGNvbnN0IGxpbmVEZWNvZGVyID0gbmV3IExpbmVEZWNvZGVyKCk7XG4gICAgICAgICAgICBjb25zdCBpdGVyID0gUmVhZGFibGVTdHJlYW1Ub0FzeW5jSXRlcmFibGUocmVhZGFibGVTdHJlYW0pO1xuICAgICAgICAgICAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiBpdGVyKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVEZWNvZGVyLmRlY29kZShjaHVuaykpIHtcbiAgICAgICAgICAgICAgICAgICAgeWllbGQgbGluZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZURlY29kZXIuZmx1c2goKSkge1xuICAgICAgICAgICAgICAgIHlpZWxkIGxpbmU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgYXN5bmMgZnVuY3Rpb24qIGl0ZXJhdG9yKCkge1xuICAgICAgICAgICAgaWYgKGNvbnN1bWVkKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgaXRlcmF0ZSBvdmVyIGEgY29uc3VtZWQgc3RyZWFtLCB1c2UgYC50ZWUoKWAgdG8gc3BsaXQgdGhlIHN0cmVhbS4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN1bWVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGxldCBkb25lID0gZmFsc2U7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGZvciBhd2FpdCAoY29uc3QgbGluZSBvZiBpdGVyTGluZXMoKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZG9uZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAobGluZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHlpZWxkIEpTT04ucGFyc2UobGluZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGUgdXNlciBjYWxscyBgc3RyZWFtLmNvbnRyb2xsZXIuYWJvcnQoKWAsIHdlIHNob3VsZCBleGl0IHdpdGhvdXQgdGhyb3dpbmcuXG4gICAgICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvciAmJiBlLm5hbWUgPT09ICdBYm9ydEVycm9yJylcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGUgdXNlciBgYnJlYWtgcywgYWJvcnQgdGhlIG9uZ29pbmcgcmVxdWVzdC5cbiAgICAgICAgICAgICAgICBpZiAoIWRvbmUpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IFN0cmVhbShpdGVyYXRvciwgY29udHJvbGxlcik7XG4gICAgfVxuICAgIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLml0ZXJhdG9yKCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFNwbGl0cyB0aGUgc3RyZWFtIGludG8gdHdvIHN0cmVhbXMgd2hpY2ggY2FuIGJlXG4gICAgICogaW5kZXBlbmRlbnRseSByZWFkIGZyb20gYXQgZGlmZmVyZW50IHNwZWVkcy5cbiAgICAgKi9cbiAgICB0ZWUoKSB7XG4gICAgICAgIGNvbnN0IGxlZnQgPSBbXTtcbiAgICAgICAgY29uc3QgcmlnaHQgPSBbXTtcbiAgICAgICAgY29uc3QgaXRlcmF0b3IgPSB0aGlzLml0ZXJhdG9yKCk7XG4gICAgICAgIGNvbnN0IHRlZUl0ZXJhdG9yID0gKHF1ZXVlKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHF1ZXVlLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGVmdC5wdXNoKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByaWdodC5wdXNoKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHF1ZXVlLnNoaWZ0KCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICBuZXcgU3RyZWFtKCgpID0+IHRlZUl0ZXJhdG9yKGxlZnQpLCB0aGlzLmNvbnRyb2xsZXIpLFxuICAgICAgICAgICAgbmV3IFN0cmVhbSgoKSA9PiB0ZWVJdGVyYXRvcihyaWdodCksIHRoaXMuY29udHJvbGxlciksXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENvbnZlcnRzIHRoaXMgc3RyZWFtIHRvIGEgbmV3bGluZS1zZXBhcmF0ZWQgUmVhZGFibGVTdHJlYW0gb2ZcbiAgICAgKiBKU09OIHN0cmluZ2lmaWVkIHZhbHVlcyBpbiB0aGUgc3RyZWFtXG4gICAgICogd2hpY2ggY2FuIGJlIHR1cm5lZCBiYWNrIGludG8gYSBTdHJlYW0gd2l0aCBgU3RyZWFtLmZyb21SZWFkYWJsZVN0cmVhbSgpYC5cbiAgICAgKi9cbiAgICB0b1JlYWRhYmxlU3RyZWFtKCkge1xuICAgICAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICAgICAgbGV0IGl0ZXI7XG4gICAgICAgIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbSh7XG4gICAgICAgICAgICBhc3luYyBzdGFydCgpIHtcbiAgICAgICAgICAgICAgICBpdGVyID0gc2VsZltTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBhc3luYyBwdWxsKGN0cmwpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB7IHZhbHVlLCBkb25lIH0gPSBhd2FpdCBpdGVyLm5leHQoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRvbmUpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY3RybC5jbG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBieXRlcyA9IGVuY29kZXIuZW5jb2RlKEpTT04uc3RyaW5naWZ5KHZhbHVlKSArICdcXG4nKTtcbiAgICAgICAgICAgICAgICAgICAgY3RybC5lbnF1ZXVlKGJ5dGVzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICBjdHJsLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGFzeW5jIGNhbmNlbCgpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBpdGVyLnJldHVybj8uKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24qIF9pdGVyU1NFTWVzc2FnZXMocmVzcG9uc2UsIGNvbnRyb2xsZXIpIHtcbiAgICBpZiAoIXJlc3BvbnNlLmJvZHkpIHtcbiAgICAgICAgY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYEF0dGVtcHRlZCB0byBpdGVyYXRlIG92ZXIgYSByZXNwb25zZSB3aXRoIG5vIGJvZHlgKTtcbiAgICB9XG4gICAgY29uc3Qgc3NlRGVjb2RlciA9IG5ldyBTU0VEZWNvZGVyKCk7XG4gICAgY29uc3QgbGluZURlY29kZXIgPSBuZXcgTGluZURlY29kZXIoKTtcbiAgICBjb25zdCBpdGVyID0gUmVhZGFibGVTdHJlYW1Ub0FzeW5jSXRlcmFibGUocmVzcG9uc2UuYm9keSk7XG4gICAgZm9yIGF3YWl0IChjb25zdCBzc2VDaHVuayBvZiBpdGVyU1NFQ2h1bmtzKGl0ZXIpKSB7XG4gICAgICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lRGVjb2Rlci5kZWNvZGUoc3NlQ2h1bmspKSB7XG4gICAgICAgICAgICBjb25zdCBzc2UgPSBzc2VEZWNvZGVyLmRlY29kZShsaW5lKTtcbiAgICAgICAgICAgIGlmIChzc2UpXG4gICAgICAgICAgICAgICAgeWllbGQgc3NlO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lRGVjb2Rlci5mbHVzaCgpKSB7XG4gICAgICAgIGNvbnN0IHNzZSA9IHNzZURlY29kZXIuZGVjb2RlKGxpbmUpO1xuICAgICAgICBpZiAoc3NlKVxuICAgICAgICAgICAgeWllbGQgc3NlO1xuICAgIH1cbn1cbi8qKlxuICogR2l2ZW4gYW4gYXN5bmMgaXRlcmFibGUgaXRlcmF0b3IsIGl0ZXJhdGVzIG92ZXIgaXQgYW5kIHlpZWxkcyBmdWxsXG4gKiBTU0UgY2h1bmtzLCBpLmUuIHlpZWxkcyB3aGVuIGEgZG91YmxlIG5ldy1saW5lIGlzIGVuY291bnRlcmVkLlxuICovXG5hc3luYyBmdW5jdGlvbiogaXRlclNTRUNodW5rcyhpdGVyYXRvcikge1xuICAgIGxldCBkYXRhID0gbmV3IFVpbnQ4QXJyYXkoKTtcbiAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIGl0ZXJhdG9yKSB7XG4gICAgICAgIGlmIChjaHVuayA9PSBudWxsKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBiaW5hcnlDaHVuayA9IGNodW5rIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgPyBuZXcgVWludDhBcnJheShjaHVuaylcbiAgICAgICAgICAgIDogdHlwZW9mIGNodW5rID09PSAnc3RyaW5nJyA/IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShjaHVuaylcbiAgICAgICAgICAgICAgICA6IGNodW5rO1xuICAgICAgICBsZXQgbmV3RGF0YSA9IG5ldyBVaW50OEFycmF5KGRhdGEubGVuZ3RoICsgYmluYXJ5Q2h1bmsubGVuZ3RoKTtcbiAgICAgICAgbmV3RGF0YS5zZXQoZGF0YSk7XG4gICAgICAgIG5ld0RhdGEuc2V0KGJpbmFyeUNodW5rLCBkYXRhLmxlbmd0aCk7XG4gICAgICAgIGRhdGEgPSBuZXdEYXRhO1xuICAgICAgICBsZXQgcGF0dGVybkluZGV4O1xuICAgICAgICB3aGlsZSAoKHBhdHRlcm5JbmRleCA9IGZpbmREb3VibGVOZXdsaW5lSW5kZXgoZGF0YSkpICE9PSAtMSkge1xuICAgICAgICAgICAgeWllbGQgZGF0YS5zbGljZSgwLCBwYXR0ZXJuSW5kZXgpO1xuICAgICAgICAgICAgZGF0YSA9IGRhdGEuc2xpY2UocGF0dGVybkluZGV4KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoZGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHlpZWxkIGRhdGE7XG4gICAgfVxufVxuY2xhc3MgU1NFRGVjb2RlciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuZXZlbnQgPSBudWxsO1xuICAgICAgICB0aGlzLmRhdGEgPSBbXTtcbiAgICAgICAgdGhpcy5jaHVua3MgPSBbXTtcbiAgICB9XG4gICAgZGVjb2RlKGxpbmUpIHtcbiAgICAgICAgaWYgKGxpbmUuZW5kc1dpdGgoJ1xccicpKSB7XG4gICAgICAgICAgICBsaW5lID0gbGluZS5zdWJzdHJpbmcoMCwgbGluZS5sZW5ndGggLSAxKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWxpbmUpIHtcbiAgICAgICAgICAgIC8vIGVtcHR5IGxpbmUgYW5kIHdlIGRpZG4ndCBwcmV2aW91c2x5IGVuY291bnRlciBhbnkgbWVzc2FnZXNcbiAgICAgICAgICAgIGlmICghdGhpcy5ldmVudCAmJiAhdGhpcy5kYXRhLmxlbmd0aClcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IHNzZSA9IHtcbiAgICAgICAgICAgICAgICBldmVudDogdGhpcy5ldmVudCxcbiAgICAgICAgICAgICAgICBkYXRhOiB0aGlzLmRhdGEuam9pbignXFxuJyksXG4gICAgICAgICAgICAgICAgcmF3OiB0aGlzLmNodW5rcyxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLmV2ZW50ID0gbnVsbDtcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IFtdO1xuICAgICAgICAgICAgdGhpcy5jaHVua3MgPSBbXTtcbiAgICAgICAgICAgIHJldHVybiBzc2U7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jaHVua3MucHVzaChsaW5lKTtcbiAgICAgICAgaWYgKGxpbmUuc3RhcnRzV2l0aCgnOicpKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgW2ZpZWxkbmFtZSwgXywgdmFsdWVdID0gcGFydGl0aW9uKGxpbmUsICc6Jyk7XG4gICAgICAgIGlmICh2YWx1ZS5zdGFydHNXaXRoKCcgJykpIHtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuc3Vic3RyaW5nKDEpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmaWVsZG5hbWUgPT09ICdldmVudCcpIHtcbiAgICAgICAgICAgIHRoaXMuZXZlbnQgPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChmaWVsZG5hbWUgPT09ICdkYXRhJykge1xuICAgICAgICAgICAgdGhpcy5kYXRhLnB1c2godmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHBhcnRpdGlvbihzdHIsIGRlbGltaXRlcikge1xuICAgIGNvbnN0IGluZGV4ID0gc3RyLmluZGV4T2YoZGVsaW1pdGVyKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgIHJldHVybiBbc3RyLnN1YnN0cmluZygwLCBpbmRleCksIGRlbGltaXRlciwgc3RyLnN1YnN0cmluZyhpbmRleCArIGRlbGltaXRlci5sZW5ndGgpXTtcbiAgICB9XG4gICAgcmV0dXJuIFtzdHIsICcnLCAnJ107XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdHJlYW1pbmcubWpzLm1hcCIsImltcG9ydCB7IEZvcm1EYXRhLCBGaWxlLCBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucywgaXNGc1JlYWRTdHJlYW0sIH0gZnJvbSBcIi4vX3NoaW1zL2luZGV4Lm1qc1wiO1xuZXhwb3J0IHsgZmlsZUZyb21QYXRoIH0gZnJvbSBcIi4vX3NoaW1zL2luZGV4Lm1qc1wiO1xuZXhwb3J0IGNvbnN0IGlzUmVzcG9uc2VMaWtlID0gKHZhbHVlKSA9PiB2YWx1ZSAhPSBudWxsICYmXG4gICAgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJlxuICAgIHR5cGVvZiB2YWx1ZS51cmwgPT09ICdzdHJpbmcnICYmXG4gICAgdHlwZW9mIHZhbHVlLmJsb2IgPT09ICdmdW5jdGlvbic7XG5leHBvcnQgY29uc3QgaXNGaWxlTGlrZSA9ICh2YWx1ZSkgPT4gdmFsdWUgIT0gbnVsbCAmJlxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiZcbiAgICB0eXBlb2YgdmFsdWUubmFtZSA9PT0gJ3N0cmluZycgJiZcbiAgICB0eXBlb2YgdmFsdWUubGFzdE1vZGlmaWVkID09PSAnbnVtYmVyJyAmJlxuICAgIGlzQmxvYkxpa2UodmFsdWUpO1xuLyoqXG4gKiBUaGUgQmxvYkxpa2UgdHlwZSBvbWl0cyBhcnJheUJ1ZmZlcigpIGJlY2F1c2UgQHR5cGVzL25vZGUtZmV0Y2hAXjIuNi40IGxhY2tzIGl0OyBidXQgdGhpcyBjaGVja1xuICogYWRkcyB0aGUgYXJyYXlCdWZmZXIoKSBtZXRob2QgdHlwZSBiZWNhdXNlIGl0IGlzIGF2YWlsYWJsZSBhbmQgdXNlZCBhdCBydW50aW1lXG4gKi9cbmV4cG9ydCBjb25zdCBpc0Jsb2JMaWtlID0gKHZhbHVlKSA9PiB2YWx1ZSAhPSBudWxsICYmXG4gICAgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJlxuICAgIHR5cGVvZiB2YWx1ZS5zaXplID09PSAnbnVtYmVyJyAmJlxuICAgIHR5cGVvZiB2YWx1ZS50eXBlID09PSAnc3RyaW5nJyAmJlxuICAgIHR5cGVvZiB2YWx1ZS50ZXh0ID09PSAnZnVuY3Rpb24nICYmXG4gICAgdHlwZW9mIHZhbHVlLnNsaWNlID09PSAnZnVuY3Rpb24nICYmXG4gICAgdHlwZW9mIHZhbHVlLmFycmF5QnVmZmVyID09PSAnZnVuY3Rpb24nO1xuZXhwb3J0IGNvbnN0IGlzVXBsb2FkYWJsZSA9ICh2YWx1ZSkgPT4ge1xuICAgIHJldHVybiBpc0ZpbGVMaWtlKHZhbHVlKSB8fCBpc1Jlc3BvbnNlTGlrZSh2YWx1ZSkgfHwgaXNGc1JlYWRTdHJlYW0odmFsdWUpO1xufTtcbi8qKlxuICogSGVscGVyIGZvciBjcmVhdGluZyBhIHtAbGluayBGaWxlfSB0byBwYXNzIHRvIGFuIFNESyB1cGxvYWQgbWV0aG9kIGZyb20gYSB2YXJpZXR5IG9mIGRpZmZlcmVudCBkYXRhIGZvcm1hdHNcbiAqIEBwYXJhbSB2YWx1ZSB0aGUgcmF3IGNvbnRlbnQgb2YgdGhlIGZpbGUuICBDYW4gYmUgYW4ge0BsaW5rIFVwbG9hZGFibGV9LCB7QGxpbmsgQmxvYkxpa2VQYXJ0fSwgb3Ige0BsaW5rIEFzeW5jSXRlcmFibGV9IG9mIHtAbGluayBCbG9iTGlrZVBhcnR9c1xuICogQHBhcmFtIHtzdHJpbmc9fSBuYW1lIHRoZSBuYW1lIG9mIHRoZSBmaWxlLiBJZiBvbWl0dGVkLCB0b0ZpbGUgd2lsbCB0cnkgdG8gZGV0ZXJtaW5lIGEgZmlsZSBuYW1lIGZyb20gYml0cyBpZiBwb3NzaWJsZVxuICogQHBhcmFtIHtPYmplY3Q9fSBvcHRpb25zIGFkZGl0aW9uYWwgcHJvcGVydGllc1xuICogQHBhcmFtIHtzdHJpbmc9fSBvcHRpb25zLnR5cGUgdGhlIE1JTUUgdHlwZSBvZiB0aGUgY29udGVudFxuICogQHBhcmFtIHtudW1iZXI9fSBvcHRpb25zLmxhc3RNb2RpZmllZCB0aGUgbGFzdCBtb2RpZmllZCB0aW1lc3RhbXBcbiAqIEByZXR1cm5zIGEge0BsaW5rIEZpbGV9IHdpdGggdGhlIGdpdmVuIHByb3BlcnRpZXNcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvRmlsZSh2YWx1ZSwgbmFtZSwgb3B0aW9ucykge1xuICAgIC8vIElmIGl0J3MgYSBwcm9taXNlLCByZXNvbHZlIGl0LlxuICAgIHZhbHVlID0gYXdhaXQgdmFsdWU7XG4gICAgLy8gSWYgd2UndmUgYmVlbiBnaXZlbiBhIGBGaWxlYCB3ZSBkb24ndCBuZWVkIHRvIGRvIGFueXRoaW5nXG4gICAgaWYgKGlzRmlsZUxpa2UodmFsdWUpKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgaWYgKGlzUmVzcG9uc2VMaWtlKHZhbHVlKSkge1xuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgdmFsdWUuYmxvYigpO1xuICAgICAgICBuYW1lIHx8IChuYW1lID0gbmV3IFVSTCh2YWx1ZS51cmwpLnBhdGhuYW1lLnNwbGl0KC9bXFxcXC9dLykucG9wKCkgPz8gJ3Vua25vd25fZmlsZScpO1xuICAgICAgICAvLyB3ZSBuZWVkIHRvIGNvbnZlcnQgdGhlIGBCbG9iYCBpbnRvIGFuIGFycmF5IGJ1ZmZlciBiZWNhdXNlIHRoZSBgQmxvYmAgY2xhc3NcbiAgICAgICAgLy8gdGhhdCBgbm9kZS1mZXRjaGAgZGVmaW5lcyBpcyBpbmNvbXBhdGlibGUgd2l0aCB0aGUgd2ViIHN0YW5kYXJkIHdoaWNoIHJlc3VsdHNcbiAgICAgICAgLy8gaW4gYG5ldyBGaWxlYCBpbnRlcnByZXRpbmcgaXQgYXMgYSBzdHJpbmcgaW5zdGVhZCBvZiBiaW5hcnkgZGF0YS5cbiAgICAgICAgY29uc3QgZGF0YSA9IGlzQmxvYkxpa2UoYmxvYikgPyBbKGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSldIDogW2Jsb2JdO1xuICAgICAgICByZXR1cm4gbmV3IEZpbGUoZGF0YSwgbmFtZSwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGNvbnN0IGJpdHMgPSBhd2FpdCBnZXRCeXRlcyh2YWx1ZSk7XG4gICAgbmFtZSB8fCAobmFtZSA9IGdldE5hbWUodmFsdWUpID8/ICd1bmtub3duX2ZpbGUnKTtcbiAgICBpZiAoIW9wdGlvbnM/LnR5cGUpIHtcbiAgICAgICAgY29uc3QgdHlwZSA9IGJpdHNbMF0/LnR5cGU7XG4gICAgICAgIGlmICh0eXBlb2YgdHlwZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIG9wdGlvbnMgPSB7IC4uLm9wdGlvbnMsIHR5cGUgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbmV3IEZpbGUoYml0cywgbmFtZSwgb3B0aW9ucyk7XG59XG5hc3luYyBmdW5jdGlvbiBnZXRCeXRlcyh2YWx1ZSkge1xuICAgIGxldCBwYXJ0cyA9IFtdO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8XG4gICAgICAgIEFycmF5QnVmZmVyLmlzVmlldyh2YWx1ZSkgfHwgLy8gaW5jbHVkZXMgVWludDhBcnJheSwgQnVmZmVyLCBldGMuXG4gICAgICAgIHZhbHVlIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgICAgcGFydHMucHVzaCh2YWx1ZSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzQmxvYkxpa2UodmFsdWUpKSB7XG4gICAgICAgIHBhcnRzLnB1c2goYXdhaXQgdmFsdWUuYXJyYXlCdWZmZXIoKSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzQXN5bmNJdGVyYWJsZUl0ZXJhdG9yKHZhbHVlKSAvLyBpbmNsdWRlcyBSZWFkYWJsZSwgUmVhZGFibGVTdHJlYW0sIGV0Yy5cbiAgICApIHtcbiAgICAgICAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiB2YWx1ZSkge1xuICAgICAgICAgICAgcGFydHMucHVzaChjaHVuayk7IC8vIFRPRE8sIGNvbnNpZGVyIHZhbGlkYXRpbmc/XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBkYXRhIHR5cGU6ICR7dHlwZW9mIHZhbHVlfTsgY29uc3RydWN0b3I6ICR7dmFsdWU/LmNvbnN0cnVjdG9yXG4gICAgICAgICAgICA/Lm5hbWV9OyBwcm9wczogJHtwcm9wc0ZvckVycm9yKHZhbHVlKX1gKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcnRzO1xufVxuZnVuY3Rpb24gcHJvcHNGb3JFcnJvcih2YWx1ZSkge1xuICAgIGNvbnN0IHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModmFsdWUpO1xuICAgIHJldHVybiBgWyR7cHJvcHMubWFwKChwKSA9PiBgXCIke3B9XCJgKS5qb2luKCcsICcpfV1gO1xufVxuZnVuY3Rpb24gZ2V0TmFtZSh2YWx1ZSkge1xuICAgIHJldHVybiAoZ2V0U3RyaW5nRnJvbU1heWJlQnVmZmVyKHZhbHVlLm5hbWUpIHx8XG4gICAgICAgIGdldFN0cmluZ0Zyb21NYXliZUJ1ZmZlcih2YWx1ZS5maWxlbmFtZSkgfHxcbiAgICAgICAgLy8gRm9yIGZzLlJlYWRTdHJlYW1cbiAgICAgICAgZ2V0U3RyaW5nRnJvbU1heWJlQnVmZmVyKHZhbHVlLnBhdGgpPy5zcGxpdCgvW1xcXFwvXS8pLnBvcCgpKTtcbn1cbmNvbnN0IGdldFN0cmluZ0Zyb21NYXliZUJ1ZmZlciA9ICh4KSA9PiB7XG4gICAgaWYgKHR5cGVvZiB4ID09PSAnc3RyaW5nJylcbiAgICAgICAgcmV0dXJuIHg7XG4gICAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnICYmIHggaW5zdGFuY2VvZiBCdWZmZXIpXG4gICAgICAgIHJldHVybiBTdHJpbmcoeCk7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5jb25zdCBpc0FzeW5jSXRlcmFibGVJdGVyYXRvciA9ICh2YWx1ZSkgPT4gdmFsdWUgIT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHR5cGVvZiB2YWx1ZVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPT09ICdmdW5jdGlvbic7XG5leHBvcnQgY29uc3QgaXNNdWx0aXBhcnRCb2R5ID0gKGJvZHkpID0+IGJvZHkgJiYgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkuYm9keSAmJiBib2R5W1N5bWJvbC50b1N0cmluZ1RhZ10gPT09ICdNdWx0aXBhcnRCb2R5Jztcbi8qKlxuICogUmV0dXJucyBhIG11bHRpcGFydC9mb3JtLWRhdGEgcmVxdWVzdCBpZiBhbnkgcGFydCBvZiB0aGUgZ2l2ZW4gcmVxdWVzdCBib2R5IGNvbnRhaW5zIGEgRmlsZSAvIEJsb2IgdmFsdWUuXG4gKiBPdGhlcndpc2UgcmV0dXJucyB0aGUgcmVxdWVzdCBhcyBpcy5cbiAqL1xuZXhwb3J0IGNvbnN0IG1heWJlTXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zID0gYXN5bmMgKG9wdHMpID0+IHtcbiAgICBpZiAoIWhhc1VwbG9hZGFibGVWYWx1ZShvcHRzLmJvZHkpKVxuICAgICAgICByZXR1cm4gb3B0cztcbiAgICBjb25zdCBmb3JtID0gYXdhaXQgY3JlYXRlRm9ybShvcHRzLmJvZHkpO1xuICAgIHJldHVybiBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucyhmb3JtLCBvcHRzKTtcbn07XG5leHBvcnQgY29uc3QgbXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zID0gYXN5bmMgKG9wdHMpID0+IHtcbiAgICBjb25zdCBmb3JtID0gYXdhaXQgY3JlYXRlRm9ybShvcHRzLmJvZHkpO1xuICAgIHJldHVybiBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucyhmb3JtLCBvcHRzKTtcbn07XG5leHBvcnQgY29uc3QgY3JlYXRlRm9ybSA9IGFzeW5jIChib2R5KSA9PiB7XG4gICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgIGF3YWl0IFByb21pc2UuYWxsKE9iamVjdC5lbnRyaWVzKGJvZHkgfHwge30pLm1hcCgoW2tleSwgdmFsdWVdKSA9PiBhZGRGb3JtVmFsdWUoZm9ybSwga2V5LCB2YWx1ZSkpKTtcbiAgICByZXR1cm4gZm9ybTtcbn07XG5jb25zdCBoYXNVcGxvYWRhYmxlVmFsdWUgPSAodmFsdWUpID0+IHtcbiAgICBpZiAoaXNVcGxvYWRhYmxlKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKVxuICAgICAgICByZXR1cm4gdmFsdWUuc29tZShoYXNVcGxvYWRhYmxlVmFsdWUpO1xuICAgIGlmICh2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGZvciAoY29uc3QgayBpbiB2YWx1ZSkge1xuICAgICAgICAgICAgaWYgKGhhc1VwbG9hZGFibGVWYWx1ZSh2YWx1ZVtrXSkpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufTtcbmNvbnN0IGFkZEZvcm1WYWx1ZSA9IGFzeW5jIChmb3JtLCBrZXksIHZhbHVlKSA9PiB7XG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpXG4gICAgICAgIHJldHVybjtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBSZWNlaXZlZCBudWxsIGZvciBcIiR7a2V5fVwiOyB0byBwYXNzIG51bGwgaW4gRm9ybURhdGEsIHlvdSBtdXN0IHVzZSB0aGUgc3RyaW5nICdudWxsJ2ApO1xuICAgIH1cbiAgICAvLyBUT0RPOiBtYWtlIG5lc3RlZCBmb3JtYXRzIGNvbmZpZ3VyYWJsZVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgZm9ybS5hcHBlbmQoa2V5LCBTdHJpbmcodmFsdWUpKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNVcGxvYWRhYmxlKHZhbHVlKSkge1xuICAgICAgICBjb25zdCBmaWxlID0gYXdhaXQgdG9GaWxlKHZhbHVlKTtcbiAgICAgICAgZm9ybS5hcHBlbmQoa2V5LCBmaWxlKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwodmFsdWUubWFwKChlbnRyeSkgPT4gYWRkRm9ybVZhbHVlKGZvcm0sIGtleSArICdbXScsIGVudHJ5KSkpO1xuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKE9iamVjdC5lbnRyaWVzKHZhbHVlKS5tYXAoKFtuYW1lLCBwcm9wXSkgPT4gYWRkRm9ybVZhbHVlKGZvcm0sIGAke2tleX1bJHtuYW1lfV1gLCBwcm9wKSkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCB2YWx1ZSBnaXZlbiB0byBmb3JtLCBleHBlY3RlZCBhIHN0cmluZywgbnVtYmVyLCBib29sZWFuLCBvYmplY3QsIEFycmF5LCBGaWxlIG9yIEJsb2IgYnV0IGdvdCAke3ZhbHVlfSBpbnN0ZWFkYCk7XG4gICAgfVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVwbG9hZHMubWpzLm1hcCIsInZhciBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0ID0gKHRoaXMgJiYgdGhpcy5fX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KSB8fCBmdW5jdGlvbiAocmVjZWl2ZXIsIHN0YXRlLCB2YWx1ZSwga2luZCwgZikge1xuICAgIGlmIChraW5kID09PSBcIm1cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgbWV0aG9kIGlzIG5vdCB3cml0YWJsZVwiKTtcbiAgICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBzZXR0ZXJcIik7XG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3Qgd3JpdGUgcHJpdmF0ZSBtZW1iZXIgdG8gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcbiAgICByZXR1cm4gKGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyLCB2YWx1ZSkgOiBmID8gZi52YWx1ZSA9IHZhbHVlIDogc3RhdGUuc2V0KHJlY2VpdmVyLCB2YWx1ZSkpLCB2YWx1ZTtcbn07XG52YXIgX19jbGFzc1ByaXZhdGVGaWVsZEdldCA9ICh0aGlzICYmIHRoaXMuX19jbGFzc1ByaXZhdGVGaWVsZEdldCkgfHwgZnVuY3Rpb24gKHJlY2VpdmVyLCBzdGF0ZSwga2luZCwgZikge1xuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcbiAgICBpZiAodHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciAhPT0gc3RhdGUgfHwgIWYgOiAhc3RhdGUuaGFzKHJlY2VpdmVyKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCByZWFkIHByaXZhdGUgbWVtYmVyIGZyb20gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcbiAgICByZXR1cm4ga2luZCA9PT0gXCJtXCIgPyBmIDoga2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIpIDogZiA/IGYudmFsdWUgOiBzdGF0ZS5nZXQocmVjZWl2ZXIpO1xufTtcbnZhciBfQWJzdHJhY3RQYWdlX2NsaWVudDtcbmltcG9ydCB7IFZFUlNJT04gfSBmcm9tIFwiLi92ZXJzaW9uLm1qc1wiO1xuaW1wb3J0IHsgU3RyZWFtIH0gZnJvbSBcIi4vc3RyZWFtaW5nLm1qc1wiO1xuaW1wb3J0IHsgT3BlbkFJRXJyb3IsIEFQSUVycm9yLCBBUElDb25uZWN0aW9uRXJyb3IsIEFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IsIEFQSVVzZXJBYm9ydEVycm9yLCB9IGZyb20gXCIuL2Vycm9yLm1qc1wiO1xuaW1wb3J0IHsga2luZCBhcyBzaGltc0tpbmQsIGdldERlZmF1bHRBZ2VudCwgZmV0Y2gsIGluaXQsIH0gZnJvbSBcIi4vX3NoaW1zL2luZGV4Lm1qc1wiO1xuLy8gdHJ5IHJ1bm5pbmcgc2lkZSBlZmZlY3RzIG91dHNpZGUgb2YgX3NoaW1zL2luZGV4IHRvIHdvcmthcm91bmQgaHR0cHM6Ly9naXRodWIuY29tL3ZlcmNlbC9uZXh0LmpzL2lzc3Vlcy83Njg4MVxuaW5pdCgpO1xuaW1wb3J0IHsgaXNCbG9iTGlrZSwgaXNNdWx0aXBhcnRCb2R5IH0gZnJvbSBcIi4vdXBsb2Fkcy5tanNcIjtcbmV4cG9ydCB7IG1heWJlTXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zLCBtdWx0aXBhcnRGb3JtUmVxdWVzdE9wdGlvbnMsIGNyZWF0ZUZvcm0sIH0gZnJvbSBcIi4vdXBsb2Fkcy5tanNcIjtcbmFzeW5jIGZ1bmN0aW9uIGRlZmF1bHRQYXJzZVJlc3BvbnNlKHByb3BzKSB7XG4gICAgY29uc3QgeyByZXNwb25zZSB9ID0gcHJvcHM7XG4gICAgaWYgKHByb3BzLm9wdGlvbnMuc3RyZWFtKSB7XG4gICAgICAgIGRlYnVnKCdyZXNwb25zZScsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2UudXJsLCByZXNwb25zZS5oZWFkZXJzLCByZXNwb25zZS5ib2R5KTtcbiAgICAgICAgLy8gTm90ZTogdGhlcmUgaXMgYW4gaW52YXJpYW50IGhlcmUgdGhhdCBpc24ndCByZXByZXNlbnRlZCBpbiB0aGUgdHlwZSBzeXN0ZW1cbiAgICAgICAgLy8gdGhhdCBpZiB5b3Ugc2V0IGBzdHJlYW06IHRydWVgIHRoZSByZXNwb25zZSB0eXBlIG11c3QgYWxzbyBiZSBgU3RyZWFtPFQ+YFxuICAgICAgICBpZiAocHJvcHMub3B0aW9ucy5fX3N0cmVhbUNsYXNzKSB7XG4gICAgICAgICAgICByZXR1cm4gcHJvcHMub3B0aW9ucy5fX3N0cmVhbUNsYXNzLmZyb21TU0VSZXNwb25zZShyZXNwb25zZSwgcHJvcHMuY29udHJvbGxlcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFN0cmVhbS5mcm9tU1NFUmVzcG9uc2UocmVzcG9uc2UsIHByb3BzLmNvbnRyb2xsZXIpO1xuICAgIH1cbiAgICAvLyBmZXRjaCByZWZ1c2VzIHRvIHJlYWQgdGhlIGJvZHkgd2hlbiB0aGUgc3RhdHVzIGNvZGUgaXMgMjA0LlxuICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwNCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKHByb3BzLm9wdGlvbnMuX19iaW5hcnlSZXNwb25zZSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfVxuICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpO1xuICAgIGNvbnN0IG1lZGlhVHlwZSA9IGNvbnRlbnRUeXBlPy5zcGxpdCgnOycpWzBdPy50cmltKCk7XG4gICAgY29uc3QgaXNKU09OID0gbWVkaWFUeXBlPy5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpIHx8IG1lZGlhVHlwZT8uZW5kc1dpdGgoJytqc29uJyk7XG4gICAgaWYgKGlzSlNPTikge1xuICAgICAgICBjb25zdCBqc29uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBkZWJ1ZygncmVzcG9uc2UnLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnVybCwgcmVzcG9uc2UuaGVhZGVycywganNvbik7XG4gICAgICAgIHJldHVybiBfYWRkUmVxdWVzdElEKGpzb24sIHJlc3BvbnNlKTtcbiAgICB9XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICBkZWJ1ZygncmVzcG9uc2UnLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnVybCwgcmVzcG9uc2UuaGVhZGVycywgdGV4dCk7XG4gICAgLy8gVE9ETyBoYW5kbGUgYmxvYiwgYXJyYXlidWZmZXIsIG90aGVyIGNvbnRlbnQgdHlwZXMsIGV0Yy5cbiAgICByZXR1cm4gdGV4dDtcbn1cbmZ1bmN0aW9uIF9hZGRSZXF1ZXN0SUQodmFsdWUsIHJlc3BvbnNlKSB7XG4gICAgaWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnIHx8IEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh2YWx1ZSwgJ19yZXF1ZXN0X2lkJywge1xuICAgICAgICB2YWx1ZTogcmVzcG9uc2UuaGVhZGVycy5nZXQoJ3gtcmVxdWVzdC1pZCcpLFxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICB9KTtcbn1cbi8qKlxuICogQSBzdWJjbGFzcyBvZiBgUHJvbWlzZWAgcHJvdmlkaW5nIGFkZGl0aW9uYWwgaGVscGVyIG1ldGhvZHNcbiAqIGZvciBpbnRlcmFjdGluZyB3aXRoIHRoZSBTREsuXG4gKi9cbmV4cG9ydCBjbGFzcyBBUElQcm9taXNlIGV4dGVuZHMgUHJvbWlzZSB7XG4gICAgY29uc3RydWN0b3IocmVzcG9uc2VQcm9taXNlLCBwYXJzZVJlc3BvbnNlID0gZGVmYXVsdFBhcnNlUmVzcG9uc2UpIHtcbiAgICAgICAgc3VwZXIoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgIC8vIHRoaXMgaXMgbWF5YmUgYSBiaXQgd2VpcmQgYnV0IHRoaXMgaGFzIHRvIGJlIGEgbm8tb3AgdG8gbm90IGltcGxpY2l0bHlcbiAgICAgICAgICAgIC8vIHBhcnNlIHRoZSByZXNwb25zZSBib2R5OyBpbnN0ZWFkIC50aGVuLCAuY2F0Y2gsIC5maW5hbGx5IGFyZSBvdmVycmlkZGVuXG4gICAgICAgICAgICAvLyB0byBwYXJzZSB0aGUgcmVzcG9uc2VcbiAgICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnJlc3BvbnNlUHJvbWlzZSA9IHJlc3BvbnNlUHJvbWlzZTtcbiAgICAgICAgdGhpcy5wYXJzZVJlc3BvbnNlID0gcGFyc2VSZXNwb25zZTtcbiAgICB9XG4gICAgX3RoZW5VbndyYXAodHJhbnNmb3JtKSB7XG4gICAgICAgIHJldHVybiBuZXcgQVBJUHJvbWlzZSh0aGlzLnJlc3BvbnNlUHJvbWlzZSwgYXN5bmMgKHByb3BzKSA9PiBfYWRkUmVxdWVzdElEKHRyYW5zZm9ybShhd2FpdCB0aGlzLnBhcnNlUmVzcG9uc2UocHJvcHMpLCBwcm9wcyksIHByb3BzLnJlc3BvbnNlKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIHJhdyBgUmVzcG9uc2VgIGluc3RhbmNlIGluc3RlYWQgb2YgcGFyc2luZyB0aGUgcmVzcG9uc2VcbiAgICAgKiBkYXRhLlxuICAgICAqXG4gICAgICogSWYgeW91IHdhbnQgdG8gcGFyc2UgdGhlIHJlc3BvbnNlIGJvZHkgYnV0IHN0aWxsIGdldCB0aGUgYFJlc3BvbnNlYFxuICAgICAqIGluc3RhbmNlLCB5b3UgY2FuIHVzZSB7QGxpbmsgd2l0aFJlc3BvbnNlKCl9LlxuICAgICAqXG4gICAgICog8J+RiyBHZXR0aW5nIHRoZSB3cm9uZyBUeXBlU2NyaXB0IHR5cGUgZm9yIGBSZXNwb25zZWA/XG4gICAgICogVHJ5IHNldHRpbmcgYFwibW9kdWxlUmVzb2x1dGlvblwiOiBcIk5vZGVOZXh0XCJgIGlmIHlvdSBjYW4sXG4gICAgICogb3IgYWRkIG9uZSBvZiB0aGVzZSBpbXBvcnRzIGJlZm9yZSB5b3VyIGZpcnN0IGBpbXBvcnQg4oCmIGZyb20gJ29wZW5haSdgOlxuICAgICAqIC0gYGltcG9ydCAnb3BlbmFpL3NoaW1zL25vZGUnYCAoaWYgeW91J3JlIHJ1bm5pbmcgb24gTm9kZSlcbiAgICAgKiAtIGBpbXBvcnQgJ29wZW5haS9zaGltcy93ZWInYCAob3RoZXJ3aXNlKVxuICAgICAqL1xuICAgIGFzUmVzcG9uc2UoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlc3BvbnNlUHJvbWlzZS50aGVuKChwKSA9PiBwLnJlc3BvbnNlKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0cyB0aGUgcGFyc2VkIHJlc3BvbnNlIGRhdGEsIHRoZSByYXcgYFJlc3BvbnNlYCBpbnN0YW5jZSBhbmQgdGhlIElEIG9mIHRoZSByZXF1ZXN0LFxuICAgICAqIHJldHVybmVkIHZpYSB0aGUgWC1SZXF1ZXN0LUlEIGhlYWRlciB3aGljaCBpcyB1c2VmdWwgZm9yIGRlYnVnZ2luZyByZXF1ZXN0cyBhbmQgcmVwb3J0aW5nXG4gICAgICogaXNzdWVzIHRvIE9wZW5BSS5cbiAgICAgKlxuICAgICAqIElmIHlvdSBqdXN0IHdhbnQgdG8gZ2V0IHRoZSByYXcgYFJlc3BvbnNlYCBpbnN0YW5jZSB3aXRob3V0IHBhcnNpbmcgaXQsXG4gICAgICogeW91IGNhbiB1c2Uge0BsaW5rIGFzUmVzcG9uc2UoKX0uXG4gICAgICpcbiAgICAgKlxuICAgICAqIPCfkYsgR2V0dGluZyB0aGUgd3JvbmcgVHlwZVNjcmlwdCB0eXBlIGZvciBgUmVzcG9uc2VgP1xuICAgICAqIFRyeSBzZXR0aW5nIGBcIm1vZHVsZVJlc29sdXRpb25cIjogXCJOb2RlTmV4dFwiYCBpZiB5b3UgY2FuLFxuICAgICAqIG9yIGFkZCBvbmUgb2YgdGhlc2UgaW1wb3J0cyBiZWZvcmUgeW91ciBmaXJzdCBgaW1wb3J0IOKApiBmcm9tICdvcGVuYWknYDpcbiAgICAgKiAtIGBpbXBvcnQgJ29wZW5haS9zaGltcy9ub2RlJ2AgKGlmIHlvdSdyZSBydW5uaW5nIG9uIE5vZGUpXG4gICAgICogLSBgaW1wb3J0ICdvcGVuYWkvc2hpbXMvd2ViJ2AgKG90aGVyd2lzZSlcbiAgICAgKi9cbiAgICBhc3luYyB3aXRoUmVzcG9uc2UoKSB7XG4gICAgICAgIGNvbnN0IFtkYXRhLCByZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbdGhpcy5wYXJzZSgpLCB0aGlzLmFzUmVzcG9uc2UoKV0pO1xuICAgICAgICByZXR1cm4geyBkYXRhLCByZXNwb25zZSwgcmVxdWVzdF9pZDogcmVzcG9uc2UuaGVhZGVycy5nZXQoJ3gtcmVxdWVzdC1pZCcpIH07XG4gICAgfVxuICAgIHBhcnNlKCkge1xuICAgICAgICBpZiAoIXRoaXMucGFyc2VkUHJvbWlzZSkge1xuICAgICAgICAgICAgdGhpcy5wYXJzZWRQcm9taXNlID0gdGhpcy5yZXNwb25zZVByb21pc2UudGhlbih0aGlzLnBhcnNlUmVzcG9uc2UpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnBhcnNlZFByb21pc2U7XG4gICAgfVxuICAgIHRoZW4ob25mdWxmaWxsZWQsIG9ucmVqZWN0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2UoKS50aGVuKG9uZnVsZmlsbGVkLCBvbnJlamVjdGVkKTtcbiAgICB9XG4gICAgY2F0Y2gob25yZWplY3RlZCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wYXJzZSgpLmNhdGNoKG9ucmVqZWN0ZWQpO1xuICAgIH1cbiAgICBmaW5hbGx5KG9uZmluYWxseSkge1xuICAgICAgICByZXR1cm4gdGhpcy5wYXJzZSgpLmZpbmFsbHkob25maW5hbGx5KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQVBJQ2xpZW50IHtcbiAgICBjb25zdHJ1Y3Rvcih7IGJhc2VVUkwsIG1heFJldHJpZXMgPSAyLCB0aW1lb3V0ID0gNjAwMDAwLCAvLyAxMCBtaW51dGVzXG4gICAgaHR0cEFnZW50LCBmZXRjaDogb3ZlcnJpZGRlbkZldGNoLCB9KSB7XG4gICAgICAgIHRoaXMuYmFzZVVSTCA9IGJhc2VVUkw7XG4gICAgICAgIHRoaXMubWF4UmV0cmllcyA9IHZhbGlkYXRlUG9zaXRpdmVJbnRlZ2VyKCdtYXhSZXRyaWVzJywgbWF4UmV0cmllcyk7XG4gICAgICAgIHRoaXMudGltZW91dCA9IHZhbGlkYXRlUG9zaXRpdmVJbnRlZ2VyKCd0aW1lb3V0JywgdGltZW91dCk7XG4gICAgICAgIHRoaXMuaHR0cEFnZW50ID0gaHR0cEFnZW50O1xuICAgICAgICB0aGlzLmZldGNoID0gb3ZlcnJpZGRlbkZldGNoID8/IGZldGNoO1xuICAgIH1cbiAgICBhdXRoSGVhZGVycyhvcHRzKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogT3ZlcnJpZGUgdGhpcyB0byBhZGQgeW91ciBvd24gZGVmYXVsdCBoZWFkZXJzLCBmb3IgZXhhbXBsZTpcbiAgICAgKlxuICAgICAqICB7XG4gICAgICogICAgLi4uc3VwZXIuZGVmYXVsdEhlYWRlcnMoKSxcbiAgICAgKiAgICBBdXRob3JpemF0aW9uOiAnQmVhcmVyIDEyMycsXG4gICAgICogIH1cbiAgICAgKi9cbiAgICBkZWZhdWx0SGVhZGVycyhvcHRzKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBBY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAnVXNlci1BZ2VudCc6IHRoaXMuZ2V0VXNlckFnZW50KCksXG4gICAgICAgICAgICAuLi5nZXRQbGF0Zm9ybUhlYWRlcnMoKSxcbiAgICAgICAgICAgIC4uLnRoaXMuYXV0aEhlYWRlcnMob3B0cyksXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE92ZXJyaWRlIHRoaXMgdG8gYWRkIHlvdXIgb3duIGhlYWRlcnMgdmFsaWRhdGlvbjpcbiAgICAgKi9cbiAgICB2YWxpZGF0ZUhlYWRlcnMoaGVhZGVycywgY3VzdG9tSGVhZGVycykgeyB9XG4gICAgZGVmYXVsdElkZW1wb3RlbmN5S2V5KCkge1xuICAgICAgICByZXR1cm4gYHN0YWlubGVzcy1ub2RlLXJldHJ5LSR7dXVpZDQoKX1gO1xuICAgIH1cbiAgICBnZXQocGF0aCwgb3B0cykge1xuICAgICAgICByZXR1cm4gdGhpcy5tZXRob2RSZXF1ZXN0KCdnZXQnLCBwYXRoLCBvcHRzKTtcbiAgICB9XG4gICAgcG9zdChwYXRoLCBvcHRzKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm1ldGhvZFJlcXVlc3QoJ3Bvc3QnLCBwYXRoLCBvcHRzKTtcbiAgICB9XG4gICAgcGF0Y2gocGF0aCwgb3B0cykge1xuICAgICAgICByZXR1cm4gdGhpcy5tZXRob2RSZXF1ZXN0KCdwYXRjaCcsIHBhdGgsIG9wdHMpO1xuICAgIH1cbiAgICBwdXQocGF0aCwgb3B0cykge1xuICAgICAgICByZXR1cm4gdGhpcy5tZXRob2RSZXF1ZXN0KCdwdXQnLCBwYXRoLCBvcHRzKTtcbiAgICB9XG4gICAgZGVsZXRlKHBhdGgsIG9wdHMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubWV0aG9kUmVxdWVzdCgnZGVsZXRlJywgcGF0aCwgb3B0cyk7XG4gICAgfVxuICAgIG1ldGhvZFJlcXVlc3QobWV0aG9kLCBwYXRoLCBvcHRzKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoUHJvbWlzZS5yZXNvbHZlKG9wdHMpLnRoZW4oYXN5bmMgKG9wdHMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGJvZHkgPSBvcHRzICYmIGlzQmxvYkxpa2Uob3B0cz8uYm9keSkgPyBuZXcgRGF0YVZpZXcoYXdhaXQgb3B0cy5ib2R5LmFycmF5QnVmZmVyKCkpXG4gICAgICAgICAgICAgICAgOiBvcHRzPy5ib2R5IGluc3RhbmNlb2YgRGF0YVZpZXcgPyBvcHRzLmJvZHlcbiAgICAgICAgICAgICAgICAgICAgOiBvcHRzPy5ib2R5IGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgPyBuZXcgRGF0YVZpZXcob3B0cy5ib2R5KVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBvcHRzICYmIEFycmF5QnVmZmVyLmlzVmlldyhvcHRzPy5ib2R5KSA/IG5ldyBEYXRhVmlldyhvcHRzLmJvZHkuYnVmZmVyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogb3B0cz8uYm9keTtcbiAgICAgICAgICAgIHJldHVybiB7IG1ldGhvZCwgcGF0aCwgLi4ub3B0cywgYm9keSB9O1xuICAgICAgICB9KSk7XG4gICAgfVxuICAgIGdldEFQSUxpc3QocGF0aCwgUGFnZSwgb3B0cykge1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0QVBJTGlzdChQYWdlLCB7IG1ldGhvZDogJ2dldCcsIHBhdGgsIC4uLm9wdHMgfSk7XG4gICAgfVxuICAgIGNhbGN1bGF0ZUNvbnRlbnRMZW5ndGgoYm9keSkge1xuICAgICAgICBpZiAodHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIEJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gQnVmZmVyLmJ5dGVMZW5ndGgoYm9keSwgJ3V0ZjgnKS50b1N0cmluZygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVvZiBUZXh0RW5jb2RlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZW5jb2RlZCA9IGVuY29kZXIuZW5jb2RlKGJvZHkpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlbmNvZGVkLmxlbmd0aC50b1N0cmluZygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhib2R5KSkge1xuICAgICAgICAgICAgcmV0dXJuIGJvZHkuYnl0ZUxlbmd0aC50b1N0cmluZygpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBidWlsZFJlcXVlc3QoaW5wdXRPcHRpb25zLCB7IHJldHJ5Q291bnQgPSAwIH0gPSB7fSkge1xuICAgICAgICBjb25zdCBvcHRpb25zID0geyAuLi5pbnB1dE9wdGlvbnMgfTtcbiAgICAgICAgY29uc3QgeyBtZXRob2QsIHBhdGgsIHF1ZXJ5LCBoZWFkZXJzOiBoZWFkZXJzID0ge30gfSA9IG9wdGlvbnM7XG4gICAgICAgIGNvbnN0IGJvZHkgPSBBcnJheUJ1ZmZlci5pc1ZpZXcob3B0aW9ucy5ib2R5KSB8fCAob3B0aW9ucy5fX2JpbmFyeVJlcXVlc3QgJiYgdHlwZW9mIG9wdGlvbnMuYm9keSA9PT0gJ3N0cmluZycpID9cbiAgICAgICAgICAgIG9wdGlvbnMuYm9keVxuICAgICAgICAgICAgOiBpc011bHRpcGFydEJvZHkob3B0aW9ucy5ib2R5KSA/IG9wdGlvbnMuYm9keS5ib2R5XG4gICAgICAgICAgICAgICAgOiBvcHRpb25zLmJvZHkgPyBKU09OLnN0cmluZ2lmeShvcHRpb25zLmJvZHksIG51bGwsIDIpXG4gICAgICAgICAgICAgICAgICAgIDogbnVsbDtcbiAgICAgICAgY29uc3QgY29udGVudExlbmd0aCA9IHRoaXMuY2FsY3VsYXRlQ29udGVudExlbmd0aChib2R5KTtcbiAgICAgICAgY29uc3QgdXJsID0gdGhpcy5idWlsZFVSTChwYXRoLCBxdWVyeSk7XG4gICAgICAgIGlmICgndGltZW91dCcgaW4gb3B0aW9ucylcbiAgICAgICAgICAgIHZhbGlkYXRlUG9zaXRpdmVJbnRlZ2VyKCd0aW1lb3V0Jywgb3B0aW9ucy50aW1lb3V0KTtcbiAgICAgICAgb3B0aW9ucy50aW1lb3V0ID0gb3B0aW9ucy50aW1lb3V0ID8/IHRoaXMudGltZW91dDtcbiAgICAgICAgY29uc3QgaHR0cEFnZW50ID0gb3B0aW9ucy5odHRwQWdlbnQgPz8gdGhpcy5odHRwQWdlbnQgPz8gZ2V0RGVmYXVsdEFnZW50KHVybCk7XG4gICAgICAgIGNvbnN0IG1pbkFnZW50VGltZW91dCA9IG9wdGlvbnMudGltZW91dCArIDEwMDA7XG4gICAgICAgIGlmICh0eXBlb2YgaHR0cEFnZW50Py5vcHRpb25zPy50aW1lb3V0ID09PSAnbnVtYmVyJyAmJlxuICAgICAgICAgICAgbWluQWdlbnRUaW1lb3V0ID4gKGh0dHBBZ2VudC5vcHRpb25zLnRpbWVvdXQgPz8gMCkpIHtcbiAgICAgICAgICAgIC8vIEFsbG93IGFueSBnaXZlbiByZXF1ZXN0IHRvIGJ1bXAgb3VyIGFnZW50IGFjdGl2ZSBzb2NrZXQgdGltZW91dC5cbiAgICAgICAgICAgIC8vIFRoaXMgbWF5IHNlZW0gc3RyYW5nZSwgYnV0IGxlYWtpbmcgYWN0aXZlIHNvY2tldHMgc2hvdWxkIGJlIHJhcmUgYW5kIG5vdCBwYXJ0aWN1bGFybHkgcHJvYmxlbWF0aWMsXG4gICAgICAgICAgICAvLyBhbmQgd2l0aG91dCBtdXRhdGluZyBhZ2VudCB3ZSB3b3VsZCBuZWVkIHRvIGNyZWF0ZSBtb3JlIG9mIHRoZW0uXG4gICAgICAgICAgICAvLyBUaGlzIHRyYWRlb2ZmIG9wdGltaXplcyBmb3IgcGVyZm9ybWFuY2UuXG4gICAgICAgICAgICBodHRwQWdlbnQub3B0aW9ucy50aW1lb3V0ID0gbWluQWdlbnRUaW1lb3V0O1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmlkZW1wb3RlbmN5SGVhZGVyICYmIG1ldGhvZCAhPT0gJ2dldCcpIHtcbiAgICAgICAgICAgIGlmICghaW5wdXRPcHRpb25zLmlkZW1wb3RlbmN5S2V5KVxuICAgICAgICAgICAgICAgIGlucHV0T3B0aW9ucy5pZGVtcG90ZW5jeUtleSA9IHRoaXMuZGVmYXVsdElkZW1wb3RlbmN5S2V5KCk7XG4gICAgICAgICAgICBoZWFkZXJzW3RoaXMuaWRlbXBvdGVuY3lIZWFkZXJdID0gaW5wdXRPcHRpb25zLmlkZW1wb3RlbmN5S2V5O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlcUhlYWRlcnMgPSB0aGlzLmJ1aWxkSGVhZGVycyh7IG9wdGlvbnMsIGhlYWRlcnMsIGNvbnRlbnRMZW5ndGgsIHJldHJ5Q291bnQgfSk7XG4gICAgICAgIGNvbnN0IHJlcSA9IHtcbiAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgIC4uLihib2R5ICYmIHsgYm9keTogYm9keSB9KSxcbiAgICAgICAgICAgIGhlYWRlcnM6IHJlcUhlYWRlcnMsXG4gICAgICAgICAgICAuLi4oaHR0cEFnZW50ICYmIHsgYWdlbnQ6IGh0dHBBZ2VudCB9KSxcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmUgbm9kZS1mZXRjaCB1c2VzIGEgY3VzdG9tIEFib3J0U2lnbmFsIHR5cGUgdGhhdCBpc1xuICAgICAgICAgICAgLy8gbm90IGNvbXBhdGlibGUgd2l0aCBzdGFuZGFyZCB3ZWIgdHlwZXNcbiAgICAgICAgICAgIHNpZ25hbDogb3B0aW9ucy5zaWduYWwgPz8gbnVsbCxcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIHsgcmVxLCB1cmwsIHRpbWVvdXQ6IG9wdGlvbnMudGltZW91dCB9O1xuICAgIH1cbiAgICBidWlsZEhlYWRlcnMoeyBvcHRpb25zLCBoZWFkZXJzLCBjb250ZW50TGVuZ3RoLCByZXRyeUNvdW50LCB9KSB7XG4gICAgICAgIGNvbnN0IHJlcUhlYWRlcnMgPSB7fTtcbiAgICAgICAgaWYgKGNvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICAgIHJlcUhlYWRlcnNbJ2NvbnRlbnQtbGVuZ3RoJ10gPSBjb250ZW50TGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRlZmF1bHRIZWFkZXJzID0gdGhpcy5kZWZhdWx0SGVhZGVycyhvcHRpb25zKTtcbiAgICAgICAgYXBwbHlIZWFkZXJzTXV0KHJlcUhlYWRlcnMsIGRlZmF1bHRIZWFkZXJzKTtcbiAgICAgICAgYXBwbHlIZWFkZXJzTXV0KHJlcUhlYWRlcnMsIGhlYWRlcnMpO1xuICAgICAgICAvLyBsZXQgYnVpbHRpbiBmZXRjaCBzZXQgdGhlIENvbnRlbnQtVHlwZSBmb3IgbXVsdGlwYXJ0IGJvZGllc1xuICAgICAgICBpZiAoaXNNdWx0aXBhcnRCb2R5KG9wdGlvbnMuYm9keSkgJiYgc2hpbXNLaW5kICE9PSAnbm9kZScpIHtcbiAgICAgICAgICAgIGRlbGV0ZSByZXFIZWFkZXJzWydjb250ZW50LXR5cGUnXTtcbiAgICAgICAgfVxuICAgICAgICAvLyBEb24ndCBzZXQgdGhlc2VzIGhlYWRlcnMgaWYgdGhleSB3ZXJlIGFscmVhZHkgc2V0IG9yIHJlbW92ZWQgdGhyb3VnaCBkZWZhdWx0IGhlYWRlcnMgb3IgYnkgdGhlIGNhbGxlci5cbiAgICAgICAgLy8gV2UgY2hlY2sgYGRlZmF1bHRIZWFkZXJzYCBhbmQgYGhlYWRlcnNgLCB3aGljaCBjYW4gY29udGFpbiBudWxscywgaW5zdGVhZCBvZiBgcmVxSGVhZGVyc2AgdG8gYWNjb3VudFxuICAgICAgICAvLyBmb3IgdGhlIHJlbW92YWwgY2FzZS5cbiAgICAgICAgaWYgKGdldEhlYWRlcihkZWZhdWx0SGVhZGVycywgJ3gtc3RhaW5sZXNzLXJldHJ5LWNvdW50JykgPT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICAgZ2V0SGVhZGVyKGhlYWRlcnMsICd4LXN0YWlubGVzcy1yZXRyeS1jb3VudCcpID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJlcUhlYWRlcnNbJ3gtc3RhaW5sZXNzLXJldHJ5LWNvdW50J10gPSBTdHJpbmcocmV0cnlDb3VudCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGdldEhlYWRlcihkZWZhdWx0SGVhZGVycywgJ3gtc3RhaW5sZXNzLXRpbWVvdXQnKSA9PT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICBnZXRIZWFkZXIoaGVhZGVycywgJ3gtc3RhaW5sZXNzLXRpbWVvdXQnKSA9PT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICBvcHRpb25zLnRpbWVvdXQpIHtcbiAgICAgICAgICAgIHJlcUhlYWRlcnNbJ3gtc3RhaW5sZXNzLXRpbWVvdXQnXSA9IFN0cmluZyhNYXRoLnRydW5jKG9wdGlvbnMudGltZW91dCAvIDEwMDApKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZhbGlkYXRlSGVhZGVycyhyZXFIZWFkZXJzLCBoZWFkZXJzKTtcbiAgICAgICAgcmV0dXJuIHJlcUhlYWRlcnM7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFVzZWQgYXMgYSBjYWxsYmFjayBmb3IgbXV0YXRpbmcgdGhlIGdpdmVuIGBGaW5hbFJlcXVlc3RPcHRpb25zYCBvYmplY3QuXG4gICAgICovXG4gICAgYXN5bmMgcHJlcGFyZU9wdGlvbnMob3B0aW9ucykgeyB9XG4gICAgLyoqXG4gICAgICogVXNlZCBhcyBhIGNhbGxiYWNrIGZvciBtdXRhdGluZyB0aGUgZ2l2ZW4gYFJlcXVlc3RJbml0YCBvYmplY3QuXG4gICAgICpcbiAgICAgKiBUaGlzIGlzIHVzZWZ1bCBmb3IgY2FzZXMgd2hlcmUgeW91IHdhbnQgdG8gYWRkIGNlcnRhaW4gaGVhZGVycyBiYXNlZCBvZmYgb2ZcbiAgICAgKiB0aGUgcmVxdWVzdCBwcm9wZXJ0aWVzLCBlLmcuIGBtZXRob2RgIG9yIGB1cmxgLlxuICAgICAqL1xuICAgIGFzeW5jIHByZXBhcmVSZXF1ZXN0KHJlcXVlc3QsIHsgdXJsLCBvcHRpb25zIH0pIHsgfVxuICAgIHBhcnNlSGVhZGVycyhoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiAoIWhlYWRlcnMgPyB7fVxuICAgICAgICAgICAgOiBTeW1ib2wuaXRlcmF0b3IgaW4gaGVhZGVycyA/XG4gICAgICAgICAgICAgICAgT2JqZWN0LmZyb21FbnRyaWVzKEFycmF5LmZyb20oaGVhZGVycykubWFwKChoZWFkZXIpID0+IFsuLi5oZWFkZXJdKSlcbiAgICAgICAgICAgICAgICA6IHsgLi4uaGVhZGVycyB9KTtcbiAgICB9XG4gICAgbWFrZVN0YXR1c0Vycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIEFQSUVycm9yLmdlbmVyYXRlKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgIH1cbiAgICByZXF1ZXN0KG9wdGlvbnMsIHJlbWFpbmluZ1JldHJpZXMgPSBudWxsKSB7XG4gICAgICAgIHJldHVybiBuZXcgQVBJUHJvbWlzZSh0aGlzLm1ha2VSZXF1ZXN0KG9wdGlvbnMsIHJlbWFpbmluZ1JldHJpZXMpKTtcbiAgICB9XG4gICAgYXN5bmMgbWFrZVJlcXVlc3Qob3B0aW9uc0lucHV0LCByZXRyaWVzUmVtYWluaW5nKSB7XG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSBhd2FpdCBvcHRpb25zSW5wdXQ7XG4gICAgICAgIGNvbnN0IG1heFJldHJpZXMgPSBvcHRpb25zLm1heFJldHJpZXMgPz8gdGhpcy5tYXhSZXRyaWVzO1xuICAgICAgICBpZiAocmV0cmllc1JlbWFpbmluZyA9PSBudWxsKSB7XG4gICAgICAgICAgICByZXRyaWVzUmVtYWluaW5nID0gbWF4UmV0cmllcztcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCB0aGlzLnByZXBhcmVPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCB7IHJlcSwgdXJsLCB0aW1lb3V0IH0gPSB0aGlzLmJ1aWxkUmVxdWVzdChvcHRpb25zLCB7IHJldHJ5Q291bnQ6IG1heFJldHJpZXMgLSByZXRyaWVzUmVtYWluaW5nIH0pO1xuICAgICAgICBhd2FpdCB0aGlzLnByZXBhcmVSZXF1ZXN0KHJlcSwgeyB1cmwsIG9wdGlvbnMgfSk7XG4gICAgICAgIGRlYnVnKCdyZXF1ZXN0JywgdXJsLCBvcHRpb25zLCByZXEuaGVhZGVycyk7XG4gICAgICAgIGlmIChvcHRpb25zLnNpZ25hbD8uYWJvcnRlZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEFQSVVzZXJBYm9ydEVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmZldGNoV2l0aFRpbWVvdXQodXJsLCByZXEsIHRpbWVvdXQsIGNvbnRyb2xsZXIpLmNhdGNoKGNhc3RUb0Vycm9yKTtcbiAgICAgICAgaWYgKHJlc3BvbnNlIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLnNpZ25hbD8uYWJvcnRlZCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJldHJpZXNSZW1haW5pbmcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yZXRyeVJlcXVlc3Qob3B0aW9ucywgcmV0cmllc1JlbWFpbmluZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzcG9uc2UubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IG5ldyBBUElDb25uZWN0aW9uRXJyb3IoeyBjYXVzZTogcmVzcG9uc2UgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gY3JlYXRlUmVzcG9uc2VIZWFkZXJzKHJlc3BvbnNlLmhlYWRlcnMpO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICBpZiAocmV0cmllc1JlbWFpbmluZyAmJiB0aGlzLnNob3VsZFJldHJ5KHJlc3BvbnNlKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJldHJ5TWVzc2FnZSA9IGByZXRyeWluZywgJHtyZXRyaWVzUmVtYWluaW5nfSBhdHRlbXB0cyByZW1haW5pbmdgO1xuICAgICAgICAgICAgICAgIGRlYnVnKGByZXNwb25zZSAoZXJyb3I7ICR7cmV0cnlNZXNzYWdlfSlgLCByZXNwb25zZS5zdGF0dXMsIHVybCwgcmVzcG9uc2VIZWFkZXJzKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yZXRyeVJlcXVlc3Qob3B0aW9ucywgcmV0cmllc1JlbWFpbmluZywgcmVzcG9uc2VIZWFkZXJzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGVyclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCkuY2F0Y2goKGUpID0+IGNhc3RUb0Vycm9yKGUpLm1lc3NhZ2UpO1xuICAgICAgICAgICAgY29uc3QgZXJySlNPTiA9IHNhZmVKU09OKGVyclRleHQpO1xuICAgICAgICAgICAgY29uc3QgZXJyTWVzc2FnZSA9IGVyckpTT04gPyB1bmRlZmluZWQgOiBlcnJUZXh0O1xuICAgICAgICAgICAgY29uc3QgcmV0cnlNZXNzYWdlID0gcmV0cmllc1JlbWFpbmluZyA/IGAoZXJyb3I7IG5vIG1vcmUgcmV0cmllcyBsZWZ0KWAgOiBgKGVycm9yOyBub3QgcmV0cnlhYmxlKWA7XG4gICAgICAgICAgICBkZWJ1ZyhgcmVzcG9uc2UgKGVycm9yOyAke3JldHJ5TWVzc2FnZX0pYCwgcmVzcG9uc2Uuc3RhdHVzLCB1cmwsIHJlc3BvbnNlSGVhZGVycywgZXJyTWVzc2FnZSk7XG4gICAgICAgICAgICBjb25zdCBlcnIgPSB0aGlzLm1ha2VTdGF0dXNFcnJvcihyZXNwb25zZS5zdGF0dXMsIGVyckpTT04sIGVyck1lc3NhZ2UsIHJlc3BvbnNlSGVhZGVycyk7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgcmVzcG9uc2UsIG9wdGlvbnMsIGNvbnRyb2xsZXIgfTtcbiAgICB9XG4gICAgcmVxdWVzdEFQSUxpc3QoUGFnZSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCByZXF1ZXN0ID0gdGhpcy5tYWtlUmVxdWVzdChvcHRpb25zLCBudWxsKTtcbiAgICAgICAgcmV0dXJuIG5ldyBQYWdlUHJvbWlzZSh0aGlzLCByZXF1ZXN0LCBQYWdlKTtcbiAgICB9XG4gICAgYnVpbGRVUkwocGF0aCwgcXVlcnkpIHtcbiAgICAgICAgY29uc3QgdXJsID0gaXNBYnNvbHV0ZVVSTChwYXRoKSA/XG4gICAgICAgICAgICBuZXcgVVJMKHBhdGgpXG4gICAgICAgICAgICA6IG5ldyBVUkwodGhpcy5iYXNlVVJMICsgKHRoaXMuYmFzZVVSTC5lbmRzV2l0aCgnLycpICYmIHBhdGguc3RhcnRzV2l0aCgnLycpID8gcGF0aC5zbGljZSgxKSA6IHBhdGgpKTtcbiAgICAgICAgY29uc3QgZGVmYXVsdFF1ZXJ5ID0gdGhpcy5kZWZhdWx0UXVlcnkoKTtcbiAgICAgICAgaWYgKCFpc0VtcHR5T2JqKGRlZmF1bHRRdWVyeSkpIHtcbiAgICAgICAgICAgIHF1ZXJ5ID0geyAuLi5kZWZhdWx0UXVlcnksIC4uLnF1ZXJ5IH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBxdWVyeSA9PT0gJ29iamVjdCcgJiYgcXVlcnkgJiYgIUFycmF5LmlzQXJyYXkocXVlcnkpKSB7XG4gICAgICAgICAgICB1cmwuc2VhcmNoID0gdGhpcy5zdHJpbmdpZnlRdWVyeShxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVybC50b1N0cmluZygpO1xuICAgIH1cbiAgICBzdHJpbmdpZnlRdWVyeShxdWVyeSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMocXVlcnkpXG4gICAgICAgICAgICAuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnKVxuICAgICAgICAgICAgLm1hcCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGAke2VuY29kZVVSSUNvbXBvbmVudChrZXkpfT0ke2VuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSl9YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBgJHtlbmNvZGVVUklDb21wb25lbnQoa2V5KX09YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgQ2Fubm90IHN0cmluZ2lmeSB0eXBlICR7dHlwZW9mIHZhbHVlfTsgRXhwZWN0ZWQgc3RyaW5nLCBudW1iZXIsIGJvb2xlYW4sIG9yIG51bGwuIElmIHlvdSBuZWVkIHRvIHBhc3MgbmVzdGVkIHF1ZXJ5IHBhcmFtZXRlcnMsIHlvdSBjYW4gbWFudWFsbHkgZW5jb2RlIHRoZW0sIGUuZy4geyBxdWVyeTogeyAnZm9vW2tleTFdJzogdmFsdWUxLCAnZm9vW2tleTJdJzogdmFsdWUyIH0gfSwgYW5kIHBsZWFzZSBvcGVuIGEgR2l0SHViIGlzc3VlIHJlcXVlc3RpbmcgYmV0dGVyIHN1cHBvcnQgZm9yIHlvdXIgdXNlIGNhc2UuYCk7XG4gICAgICAgIH0pXG4gICAgICAgICAgICAuam9pbignJicpO1xuICAgIH1cbiAgICBhc3luYyBmZXRjaFdpdGhUaW1lb3V0KHVybCwgaW5pdCwgbXMsIGNvbnRyb2xsZXIpIHtcbiAgICAgICAgY29uc3QgeyBzaWduYWwsIC4uLm9wdGlvbnMgfSA9IGluaXQgfHwge307XG4gICAgICAgIGlmIChzaWduYWwpXG4gICAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiBjb250cm9sbGVyLmFib3J0KCkpO1xuICAgICAgICBjb25zdCB0aW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIG1zKTtcbiAgICAgICAgY29uc3QgZmV0Y2hPcHRpb25zID0ge1xuICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIH07XG4gICAgICAgIGlmIChmZXRjaE9wdGlvbnMubWV0aG9kKSB7XG4gICAgICAgICAgICAvLyBDdXN0b20gbWV0aG9kcyBsaWtlICdwYXRjaCcgbmVlZCB0byBiZSB1cHBlcmNhc2VkXG4gICAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL25vZGVqcy91bmRpY2kvaXNzdWVzLzIyOTRcbiAgICAgICAgICAgIGZldGNoT3B0aW9ucy5tZXRob2QgPSBmZXRjaE9wdGlvbnMubWV0aG9kLnRvVXBwZXJDYXNlKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgLy8gdXNlIHVuZGVmaW5lZCB0aGlzIGJpbmRpbmc7IGZldGNoIGVycm9ycyBpZiBib3VuZCB0byBzb21ldGhpbmcgZWxzZSBpbiBicm93c2VyL2Nsb3VkZmxhcmVcbiAgICAgICAgdGhpcy5mZXRjaC5jYWxsKHVuZGVmaW5lZCwgdXJsLCBmZXRjaE9wdGlvbnMpLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgICAgICB9KSk7XG4gICAgfVxuICAgIHNob3VsZFJldHJ5KHJlc3BvbnNlKSB7XG4gICAgICAgIC8vIE5vdGUgdGhpcyBpcyBub3QgYSBzdGFuZGFyZCBoZWFkZXIuXG4gICAgICAgIGNvbnN0IHNob3VsZFJldHJ5SGVhZGVyID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ3gtc2hvdWxkLXJldHJ5Jyk7XG4gICAgICAgIC8vIElmIHRoZSBzZXJ2ZXIgZXhwbGljaXRseSBzYXlzIHdoZXRoZXIgb3Igbm90IHRvIHJldHJ5LCBvYmV5LlxuICAgICAgICBpZiAoc2hvdWxkUmV0cnlIZWFkZXIgPT09ICd0cnVlJylcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICBpZiAoc2hvdWxkUmV0cnlIZWFkZXIgPT09ICdmYWxzZScpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIC8vIFJldHJ5IG9uIHJlcXVlc3QgdGltZW91dHMuXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwOClcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAvLyBSZXRyeSBvbiBsb2NrIHRpbWVvdXRzLlxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDkpXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgLy8gUmV0cnkgb24gcmF0ZSBsaW1pdHMuXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQyOSlcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAvLyBSZXRyeSBpbnRlcm5hbCBlcnJvcnMuXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNTAwKVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgYXN5bmMgcmV0cnlSZXF1ZXN0KG9wdGlvbnMsIHJldHJpZXNSZW1haW5pbmcsIHJlc3BvbnNlSGVhZGVycykge1xuICAgICAgICBsZXQgdGltZW91dE1pbGxpcztcbiAgICAgICAgLy8gTm90ZSB0aGUgYHJldHJ5LWFmdGVyLW1zYCBoZWFkZXIgbWF5IG5vdCBiZSBzdGFuZGFyZCwgYnV0IGlzIGEgZ29vZCBpZGVhIGFuZCB3ZSdkIGxpa2UgcHJvYWN0aXZlIHN1cHBvcnQgZm9yIGl0LlxuICAgICAgICBjb25zdCByZXRyeUFmdGVyTWlsbGlzSGVhZGVyID0gcmVzcG9uc2VIZWFkZXJzPy5bJ3JldHJ5LWFmdGVyLW1zJ107XG4gICAgICAgIGlmIChyZXRyeUFmdGVyTWlsbGlzSGVhZGVyKSB7XG4gICAgICAgICAgICBjb25zdCB0aW1lb3V0TXMgPSBwYXJzZUZsb2F0KHJldHJ5QWZ0ZXJNaWxsaXNIZWFkZXIpO1xuICAgICAgICAgICAgaWYgKCFOdW1iZXIuaXNOYU4odGltZW91dE1zKSkge1xuICAgICAgICAgICAgICAgIHRpbWVvdXRNaWxsaXMgPSB0aW1lb3V0TXM7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWJvdXQgdGhlIFJldHJ5LUFmdGVyIGhlYWRlcjogaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSFRUUC9IZWFkZXJzL1JldHJ5LUFmdGVyXG4gICAgICAgIGNvbnN0IHJldHJ5QWZ0ZXJIZWFkZXIgPSByZXNwb25zZUhlYWRlcnM/LlsncmV0cnktYWZ0ZXInXTtcbiAgICAgICAgaWYgKHJldHJ5QWZ0ZXJIZWFkZXIgJiYgIXRpbWVvdXRNaWxsaXMpIHtcbiAgICAgICAgICAgIGNvbnN0IHRpbWVvdXRTZWNvbmRzID0gcGFyc2VGbG9hdChyZXRyeUFmdGVySGVhZGVyKTtcbiAgICAgICAgICAgIGlmICghTnVtYmVyLmlzTmFOKHRpbWVvdXRTZWNvbmRzKSkge1xuICAgICAgICAgICAgICAgIHRpbWVvdXRNaWxsaXMgPSB0aW1lb3V0U2Vjb25kcyAqIDEwMDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aW1lb3V0TWlsbGlzID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVySGVhZGVyKSAtIERhdGUubm93KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlIEFQSSBhc2tzIHVzIHRvIHdhaXQgYSBjZXJ0YWluIGFtb3VudCBvZiB0aW1lIChhbmQgaXQncyBhIHJlYXNvbmFibGUgYW1vdW50KSxcbiAgICAgICAgLy8ganVzdCBkbyB3aGF0IGl0IHNheXMsIGJ1dCBvdGhlcndpc2UgY2FsY3VsYXRlIGEgZGVmYXVsdFxuICAgICAgICBpZiAoISh0aW1lb3V0TWlsbGlzICYmIDAgPD0gdGltZW91dE1pbGxpcyAmJiB0aW1lb3V0TWlsbGlzIDwgNjAgKiAxMDAwKSkge1xuICAgICAgICAgICAgY29uc3QgbWF4UmV0cmllcyA9IG9wdGlvbnMubWF4UmV0cmllcyA/PyB0aGlzLm1heFJldHJpZXM7XG4gICAgICAgICAgICB0aW1lb3V0TWlsbGlzID0gdGhpcy5jYWxjdWxhdGVEZWZhdWx0UmV0cnlUaW1lb3V0TWlsbGlzKHJldHJpZXNSZW1haW5pbmcsIG1heFJldHJpZXMpO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IHNsZWVwKHRpbWVvdXRNaWxsaXMpO1xuICAgICAgICByZXR1cm4gdGhpcy5tYWtlUmVxdWVzdChvcHRpb25zLCByZXRyaWVzUmVtYWluaW5nIC0gMSk7XG4gICAgfVxuICAgIGNhbGN1bGF0ZURlZmF1bHRSZXRyeVRpbWVvdXRNaWxsaXMocmV0cmllc1JlbWFpbmluZywgbWF4UmV0cmllcykge1xuICAgICAgICBjb25zdCBpbml0aWFsUmV0cnlEZWxheSA9IDAuNTtcbiAgICAgICAgY29uc3QgbWF4UmV0cnlEZWxheSA9IDguMDtcbiAgICAgICAgY29uc3QgbnVtUmV0cmllcyA9IG1heFJldHJpZXMgLSByZXRyaWVzUmVtYWluaW5nO1xuICAgICAgICAvLyBBcHBseSBleHBvbmVudGlhbCBiYWNrb2ZmLCBidXQgbm90IG1vcmUgdGhhbiB0aGUgbWF4LlxuICAgICAgICBjb25zdCBzbGVlcFNlY29uZHMgPSBNYXRoLm1pbihpbml0aWFsUmV0cnlEZWxheSAqIE1hdGgucG93KDIsIG51bVJldHJpZXMpLCBtYXhSZXRyeURlbGF5KTtcbiAgICAgICAgLy8gQXBwbHkgc29tZSBqaXR0ZXIsIHRha2UgdXAgdG8gYXQgbW9zdCAyNSBwZXJjZW50IG9mIHRoZSByZXRyeSB0aW1lLlxuICAgICAgICBjb25zdCBqaXR0ZXIgPSAxIC0gTWF0aC5yYW5kb20oKSAqIDAuMjU7XG4gICAgICAgIHJldHVybiBzbGVlcFNlY29uZHMgKiBqaXR0ZXIgKiAxMDAwO1xuICAgIH1cbiAgICBnZXRVc2VyQWdlbnQoKSB7XG4gICAgICAgIHJldHVybiBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9L0pTICR7VkVSU0lPTn1gO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBYnN0cmFjdFBhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGNsaWVudCwgcmVzcG9uc2UsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgX0Fic3RyYWN0UGFnZV9jbGllbnQuc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0Fic3RyYWN0UGFnZV9jbGllbnQsIGNsaWVudCwgXCJmXCIpO1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgICAgICB0aGlzLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgICAgIHRoaXMuYm9keSA9IGJvZHk7XG4gICAgfVxuICAgIGhhc05leHRQYWdlKCkge1xuICAgICAgICBjb25zdCBpdGVtcyA9IHRoaXMuZ2V0UGFnaW5hdGVkSXRlbXMoKTtcbiAgICAgICAgaWYgKCFpdGVtcy5sZW5ndGgpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIHJldHVybiB0aGlzLm5leHRQYWdlSW5mbygpICE9IG51bGw7XG4gICAgfVxuICAgIGFzeW5jIGdldE5leHRQYWdlKCkge1xuICAgICAgICBjb25zdCBuZXh0SW5mbyA9IHRoaXMubmV4dFBhZ2VJbmZvKCk7XG4gICAgICAgIGlmICghbmV4dEluZm8pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcignTm8gbmV4dCBwYWdlIGV4cGVjdGVkOyBwbGVhc2UgY2hlY2sgYC5oYXNOZXh0UGFnZSgpYCBiZWZvcmUgY2FsbGluZyBgLmdldE5leHRQYWdlKClgLicpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHRPcHRpb25zID0geyAuLi50aGlzLm9wdGlvbnMgfTtcbiAgICAgICAgaWYgKCdwYXJhbXMnIGluIG5leHRJbmZvICYmIHR5cGVvZiBuZXh0T3B0aW9ucy5xdWVyeSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIG5leHRPcHRpb25zLnF1ZXJ5ID0geyAuLi5uZXh0T3B0aW9ucy5xdWVyeSwgLi4ubmV4dEluZm8ucGFyYW1zIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoJ3VybCcgaW4gbmV4dEluZm8pIHtcbiAgICAgICAgICAgIGNvbnN0IHBhcmFtcyA9IFsuLi5PYmplY3QuZW50cmllcyhuZXh0T3B0aW9ucy5xdWVyeSB8fCB7fSksIC4uLm5leHRJbmZvLnVybC5zZWFyY2hQYXJhbXMuZW50cmllcygpXTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHBhcmFtcykge1xuICAgICAgICAgICAgICAgIG5leHRJbmZvLnVybC5zZWFyY2hQYXJhbXMuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbmV4dE9wdGlvbnMucXVlcnkgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBuZXh0T3B0aW9ucy5wYXRoID0gbmV4dEluZm8udXJsLnRvU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGF3YWl0IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fic3RyYWN0UGFnZV9jbGllbnQsIFwiZlwiKS5yZXF1ZXN0QVBJTGlzdCh0aGlzLmNvbnN0cnVjdG9yLCBuZXh0T3B0aW9ucyk7XG4gICAgfVxuICAgIGFzeW5jICppdGVyUGFnZXMoKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdGhpcy1hbGlhc1xuICAgICAgICBsZXQgcGFnZSA9IHRoaXM7XG4gICAgICAgIHlpZWxkIHBhZ2U7XG4gICAgICAgIHdoaWxlIChwYWdlLmhhc05leHRQYWdlKCkpIHtcbiAgICAgICAgICAgIHBhZ2UgPSBhd2FpdCBwYWdlLmdldE5leHRQYWdlKCk7XG4gICAgICAgICAgICB5aWVsZCBwYWdlO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jICpbKF9BYnN0cmFjdFBhZ2VfY2xpZW50ID0gbmV3IFdlYWtNYXAoKSwgU3ltYm9sLmFzeW5jSXRlcmF0b3IpXSgpIHtcbiAgICAgICAgZm9yIGF3YWl0IChjb25zdCBwYWdlIG9mIHRoaXMuaXRlclBhZ2VzKCkpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBwYWdlLmdldFBhZ2luYXRlZEl0ZW1zKCkpIHtcbiAgICAgICAgICAgICAgICB5aWVsZCBpdGVtO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuLyoqXG4gKiBUaGlzIHN1YmNsYXNzIG9mIFByb21pc2Ugd2lsbCByZXNvbHZlIHRvIGFuIGluc3RhbnRpYXRlZCBQYWdlIG9uY2UgdGhlIHJlcXVlc3QgY29tcGxldGVzLlxuICpcbiAqIEl0IGFsc28gaW1wbGVtZW50cyBBc3luY0l0ZXJhYmxlIHRvIGFsbG93IGF1dG8tcGFnaW5hdGluZyBpdGVyYXRpb24gb24gYW4gdW5hd2FpdGVkIGxpc3QgY2FsbCwgZWc6XG4gKlxuICogICAgZm9yIGF3YWl0IChjb25zdCBpdGVtIG9mIGNsaWVudC5pdGVtcy5saXN0KCkpIHtcbiAqICAgICAgY29uc29sZS5sb2coaXRlbSlcbiAqICAgIH1cbiAqL1xuZXhwb3J0IGNsYXNzIFBhZ2VQcm9taXNlIGV4dGVuZHMgQVBJUHJvbWlzZSB7XG4gICAgY29uc3RydWN0b3IoY2xpZW50LCByZXF1ZXN0LCBQYWdlKSB7XG4gICAgICAgIHN1cGVyKHJlcXVlc3QsIGFzeW5jIChwcm9wcykgPT4gbmV3IFBhZ2UoY2xpZW50LCBwcm9wcy5yZXNwb25zZSwgYXdhaXQgZGVmYXVsdFBhcnNlUmVzcG9uc2UocHJvcHMpLCBwcm9wcy5vcHRpb25zKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFsbG93IGF1dG8tcGFnaW5hdGluZyBpdGVyYXRpb24gb24gYW4gdW5hd2FpdGVkIGxpc3QgY2FsbCwgZWc6XG4gICAgICpcbiAgICAgKiAgICBmb3IgYXdhaXQgKGNvbnN0IGl0ZW0gb2YgY2xpZW50Lml0ZW1zLmxpc3QoKSkge1xuICAgICAqICAgICAgY29uc29sZS5sb2coaXRlbSlcbiAgICAgKiAgICB9XG4gICAgICovXG4gICAgYXN5bmMgKltTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKSB7XG4gICAgICAgIGNvbnN0IHBhZ2UgPSBhd2FpdCB0aGlzO1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IGl0ZW0gb2YgcGFnZSkge1xuICAgICAgICAgICAgeWllbGQgaXRlbTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmV4cG9ydCBjb25zdCBjcmVhdGVSZXNwb25zZUhlYWRlcnMgPSAoaGVhZGVycykgPT4ge1xuICAgIHJldHVybiBuZXcgUHJveHkoT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBoZWFkZXJzLmVudHJpZXMoKSksIHtcbiAgICAgICAgZ2V0KHRhcmdldCwgbmFtZSkge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0gbmFtZS50b1N0cmluZygpO1xuICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtrZXkudG9Mb3dlckNhc2UoKV0gfHwgdGFyZ2V0W2tleV07XG4gICAgICAgIH0sXG4gICAgfSk7XG59O1xuLy8gVGhpcyBpcyByZXF1aXJlZCBzbyB0aGF0IHdlIGNhbiBkZXRlcm1pbmUgaWYgYSBnaXZlbiBvYmplY3QgbWF0Y2hlcyB0aGUgUmVxdWVzdE9wdGlvbnNcbi8vIHR5cGUgYXQgcnVudGltZS4gV2hpbGUgdGhpcyByZXF1aXJlcyBkdXBsaWNhdGlvbiwgaXQgaXMgZW5mb3JjZWQgYnkgdGhlIFR5cGVTY3JpcHRcbi8vIGNvbXBpbGVyIHN1Y2ggdGhhdCBhbnkgbWlzc2luZyAvIGV4dHJhbmVvdXMga2V5cyB3aWxsIGNhdXNlIGFuIGVycm9yLlxuY29uc3QgcmVxdWVzdE9wdGlvbnNLZXlzID0ge1xuICAgIG1ldGhvZDogdHJ1ZSxcbiAgICBwYXRoOiB0cnVlLFxuICAgIHF1ZXJ5OiB0cnVlLFxuICAgIGJvZHk6IHRydWUsXG4gICAgaGVhZGVyczogdHJ1ZSxcbiAgICBtYXhSZXRyaWVzOiB0cnVlLFxuICAgIHN0cmVhbTogdHJ1ZSxcbiAgICB0aW1lb3V0OiB0cnVlLFxuICAgIGh0dHBBZ2VudDogdHJ1ZSxcbiAgICBzaWduYWw6IHRydWUsXG4gICAgaWRlbXBvdGVuY3lLZXk6IHRydWUsXG4gICAgX19tZXRhZGF0YTogdHJ1ZSxcbiAgICBfX2JpbmFyeVJlcXVlc3Q6IHRydWUsXG4gICAgX19iaW5hcnlSZXNwb25zZTogdHJ1ZSxcbiAgICBfX3N0cmVhbUNsYXNzOiB0cnVlLFxufTtcbmV4cG9ydCBjb25zdCBpc1JlcXVlc3RPcHRpb25zID0gKG9iaikgPT4ge1xuICAgIHJldHVybiAodHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgb2JqICE9PSBudWxsICYmXG4gICAgICAgICFpc0VtcHR5T2JqKG9iaikgJiZcbiAgICAgICAgT2JqZWN0LmtleXMob2JqKS5ldmVyeSgoaykgPT4gaGFzT3duKHJlcXVlc3RPcHRpb25zS2V5cywgaykpKTtcbn07XG5jb25zdCBnZXRQbGF0Zm9ybVByb3BlcnRpZXMgPSAoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBEZW5vICE9PSAndW5kZWZpbmVkJyAmJiBEZW5vLmJ1aWxkICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLU9TJzogbm9ybWFsaXplUGxhdGZvcm0oRGVuby5idWlsZC5vcyksXG4gICAgICAgICAgICAnWC1TdGFpbmxlc3MtQXJjaCc6IG5vcm1hbGl6ZUFyY2goRGVuby5idWlsZC5hcmNoKSxcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lJzogJ2Rlbm8nLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6IHR5cGVvZiBEZW5vLnZlcnNpb24gPT09ICdzdHJpbmcnID8gRGVuby52ZXJzaW9uIDogRGVuby52ZXJzaW9uPy5kZW5vID8/ICd1bmtub3duJyxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBFZGdlUnVudGltZSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLU9TJzogJ1Vua25vd24nLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLUFyY2gnOiBgb3RoZXI6JHtFZGdlUnVudGltZX1gLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUnOiAnZWRnZScsXG4gICAgICAgICAgICAnWC1TdGFpbmxlc3MtUnVudGltZS1WZXJzaW9uJzogcHJvY2Vzcy52ZXJzaW9uLFxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBDaGVjayBpZiBOb2RlLmpzXG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgPyBwcm9jZXNzIDogMCkgPT09ICdbb2JqZWN0IHByb2Nlc3NdJykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLUxhbmcnOiAnanMnLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLVBhY2thZ2UtVmVyc2lvbic6IFZFUlNJT04sXG4gICAgICAgICAgICAnWC1TdGFpbmxlc3MtT1MnOiBub3JtYWxpemVQbGF0Zm9ybShwcm9jZXNzLnBsYXRmb3JtKSxcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1BcmNoJzogbm9ybWFsaXplQXJjaChwcm9jZXNzLmFyY2gpLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUnOiAnbm9kZScsXG4gICAgICAgICAgICAnWC1TdGFpbmxlc3MtUnVudGltZS1WZXJzaW9uJzogcHJvY2Vzcy52ZXJzaW9uLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBicm93c2VySW5mbyA9IGdldEJyb3dzZXJJbmZvKCk7XG4gICAgaWYgKGJyb3dzZXJJbmZvKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAnWC1TdGFpbmxlc3MtTGFuZyc6ICdqcycsXG4gICAgICAgICAgICAnWC1TdGFpbmxlc3MtUGFja2FnZS1WZXJzaW9uJzogVkVSU0lPTixcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1PUyc6ICdVbmtub3duJyxcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1BcmNoJzogJ3Vua25vd24nLFxuICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUnOiBgYnJvd3Nlcjoke2Jyb3dzZXJJbmZvLmJyb3dzZXJ9YCxcbiAgICAgICAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lLVZlcnNpb24nOiBicm93c2VySW5mby52ZXJzaW9uLFxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBUT0RPIGFkZCBzdXBwb3J0IGZvciBDbG91ZGZsYXJlIHdvcmtlcnMsIGV0Yy5cbiAgICByZXR1cm4ge1xuICAgICAgICAnWC1TdGFpbmxlc3MtTGFuZyc6ICdqcycsXG4gICAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgICAnWC1TdGFpbmxlc3MtT1MnOiAnVW5rbm93bicsXG4gICAgICAgICdYLVN0YWlubGVzcy1BcmNoJzogJ3Vua25vd24nLFxuICAgICAgICAnWC1TdGFpbmxlc3MtUnVudGltZSc6ICd1bmtub3duJyxcbiAgICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6ICd1bmtub3duJyxcbiAgICB9O1xufTtcbi8vIE5vdGU6IG1vZGlmaWVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL0pTLURldlRvb2xzL2hvc3QtZW52aXJvbm1lbnQvYmxvYi9iMWFiNzllY2RlMzdkYjVkNmUxNjNjMDUwZTU0ZmU3ZDI4N2Q3YzkyL3NyYy9pc29tb3JwaGljLmJyb3dzZXIudHNcbmZ1bmN0aW9uIGdldEJyb3dzZXJJbmZvKCkge1xuICAgIGlmICh0eXBlb2YgbmF2aWdhdG9yID09PSAndW5kZWZpbmVkJyB8fCAhbmF2aWdhdG9yKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICAvLyBOT1RFOiBUaGUgb3JkZXIgbWF0dGVycyBoZXJlIVxuICAgIGNvbnN0IGJyb3dzZXJQYXR0ZXJucyA9IFtcbiAgICAgICAgeyBrZXk6ICdlZGdlJywgcGF0dGVybjogL0VkZ2UoPzpcXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICAgICAgeyBrZXk6ICdpZScsIHBhdHRlcm46IC9NU0lFKD86XFxXKyhcXGQrKVxcLihcXGQrKSg/OlxcLihcXGQrKSk/KT8vIH0sXG4gICAgICAgIHsga2V5OiAnaWUnLCBwYXR0ZXJuOiAvVHJpZGVudCg/Oi4qcnZcXDooXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/LyB9LFxuICAgICAgICB7IGtleTogJ2Nocm9tZScsIHBhdHRlcm46IC9DaHJvbWUoPzpcXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICAgICAgeyBrZXk6ICdmaXJlZm94JywgcGF0dGVybjogL0ZpcmVmb3goPzpcXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICAgICAgeyBrZXk6ICdzYWZhcmknLCBwYXR0ZXJuOiAvKD86VmVyc2lvblxcVysoXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/KD86XFxXK01vYmlsZVxcUyopP1xcVytTYWZhcmkvIH0sXG4gICAgXTtcbiAgICAvLyBGaW5kIHRoZSBGSVJTVCBtYXRjaGluZyBicm93c2VyXG4gICAgZm9yIChjb25zdCB7IGtleSwgcGF0dGVybiB9IG9mIGJyb3dzZXJQYXR0ZXJucykge1xuICAgICAgICBjb25zdCBtYXRjaCA9IHBhdHRlcm4uZXhlYyhuYXZpZ2F0b3IudXNlckFnZW50KTtcbiAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgICBjb25zdCBtYWpvciA9IG1hdGNoWzFdIHx8IDA7XG4gICAgICAgICAgICBjb25zdCBtaW5vciA9IG1hdGNoWzJdIHx8IDA7XG4gICAgICAgICAgICBjb25zdCBwYXRjaCA9IG1hdGNoWzNdIHx8IDA7XG4gICAgICAgICAgICByZXR1cm4geyBicm93c2VyOiBrZXksIHZlcnNpb246IGAke21ham9yfS4ke21pbm9yfS4ke3BhdGNofWAgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cbmNvbnN0IG5vcm1hbGl6ZUFyY2ggPSAoYXJjaCkgPT4ge1xuICAgIC8vIE5vZGUgZG9jczpcbiAgICAvLyAtIGh0dHBzOi8vbm9kZWpzLm9yZy9hcGkvcHJvY2Vzcy5odG1sI3Byb2Nlc3NhcmNoXG4gICAgLy8gRGVubyBkb2NzOlxuICAgIC8vIC0gaHR0cHM6Ly9kb2MuZGVuby5sYW5kL2Rlbm8vc3RhYmxlL34vRGVuby5idWlsZFxuICAgIGlmIChhcmNoID09PSAneDMyJylcbiAgICAgICAgcmV0dXJuICd4MzInO1xuICAgIGlmIChhcmNoID09PSAneDg2XzY0JyB8fCBhcmNoID09PSAneDY0JylcbiAgICAgICAgcmV0dXJuICd4NjQnO1xuICAgIGlmIChhcmNoID09PSAnYXJtJylcbiAgICAgICAgcmV0dXJuICdhcm0nO1xuICAgIGlmIChhcmNoID09PSAnYWFyY2g2NCcgfHwgYXJjaCA9PT0gJ2FybTY0JylcbiAgICAgICAgcmV0dXJuICdhcm02NCc7XG4gICAgaWYgKGFyY2gpXG4gICAgICAgIHJldHVybiBgb3RoZXI6JHthcmNofWA7XG4gICAgcmV0dXJuICd1bmtub3duJztcbn07XG5jb25zdCBub3JtYWxpemVQbGF0Zm9ybSA9IChwbGF0Zm9ybSkgPT4ge1xuICAgIC8vIE5vZGUgcGxhdGZvcm1zOlxuICAgIC8vIC0gaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9wcm9jZXNzLmh0bWwjcHJvY2Vzc3BsYXRmb3JtXG4gICAgLy8gRGVubyBwbGF0Zm9ybXM6XG4gICAgLy8gLSBodHRwczovL2RvYy5kZW5vLmxhbmQvZGVuby9zdGFibGUvfi9EZW5vLmJ1aWxkXG4gICAgLy8gLSBodHRwczovL2dpdGh1Yi5jb20vZGVub2xhbmQvZGVuby9pc3N1ZXMvMTQ3OTlcbiAgICBwbGF0Zm9ybSA9IHBsYXRmb3JtLnRvTG93ZXJDYXNlKCk7XG4gICAgLy8gTk9URTogdGhpcyBpT1MgY2hlY2sgaXMgdW50ZXN0ZWQgYW5kIG1heSBub3Qgd29ya1xuICAgIC8vIE5vZGUgZG9lcyBub3Qgd29yayBuYXRpdmVseSBvbiBJT1MsIHRoZXJlIGlzIGEgZm9yayBhdFxuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9ub2RlanMtbW9iaWxlL25vZGVqcy1tb2JpbGVcbiAgICAvLyBob3dldmVyIGl0IGlzIHVua25vd24gYXQgdGhlIHRpbWUgb2Ygd3JpdGluZyBob3cgdG8gZGV0ZWN0IGlmIGl0IGlzIHJ1bm5pbmdcbiAgICBpZiAocGxhdGZvcm0uaW5jbHVkZXMoJ2lvcycpKVxuICAgICAgICByZXR1cm4gJ2lPUyc7XG4gICAgaWYgKHBsYXRmb3JtID09PSAnYW5kcm9pZCcpXG4gICAgICAgIHJldHVybiAnQW5kcm9pZCc7XG4gICAgaWYgKHBsYXRmb3JtID09PSAnZGFyd2luJylcbiAgICAgICAgcmV0dXJuICdNYWNPUyc7XG4gICAgaWYgKHBsYXRmb3JtID09PSAnd2luMzInKVxuICAgICAgICByZXR1cm4gJ1dpbmRvd3MnO1xuICAgIGlmIChwbGF0Zm9ybSA9PT0gJ2ZyZWVic2QnKVxuICAgICAgICByZXR1cm4gJ0ZyZWVCU0QnO1xuICAgIGlmIChwbGF0Zm9ybSA9PT0gJ29wZW5ic2QnKVxuICAgICAgICByZXR1cm4gJ09wZW5CU0QnO1xuICAgIGlmIChwbGF0Zm9ybSA9PT0gJ2xpbnV4JylcbiAgICAgICAgcmV0dXJuICdMaW51eCc7XG4gICAgaWYgKHBsYXRmb3JtKVxuICAgICAgICByZXR1cm4gYE90aGVyOiR7cGxhdGZvcm19YDtcbiAgICByZXR1cm4gJ1Vua25vd24nO1xufTtcbmxldCBfcGxhdGZvcm1IZWFkZXJzO1xuY29uc3QgZ2V0UGxhdGZvcm1IZWFkZXJzID0gKCkgPT4ge1xuICAgIHJldHVybiAoX3BsYXRmb3JtSGVhZGVycyA/PyAoX3BsYXRmb3JtSGVhZGVycyA9IGdldFBsYXRmb3JtUHJvcGVydGllcygpKSk7XG59O1xuZXhwb3J0IGNvbnN0IHNhZmVKU09OID0gKHRleHQpID0+IHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycikge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbn07XG4vLyBodHRwczovL3VybC5zcGVjLndoYXR3Zy5vcmcvI3VybC1zY2hlbWUtc3RyaW5nXG5jb25zdCBzdGFydHNXaXRoU2NoZW1lUmVnZXhwID0gL15bYS16XVthLXowLTkrLi1dKjovaTtcbmNvbnN0IGlzQWJzb2x1dGVVUkwgPSAodXJsKSA9PiB7XG4gICAgcmV0dXJuIHN0YXJ0c1dpdGhTY2hlbWVSZWdleHAudGVzdCh1cmwpO1xufTtcbmV4cG9ydCBjb25zdCBzbGVlcCA9IChtcykgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgbXMpKTtcbmNvbnN0IHZhbGlkYXRlUG9zaXRpdmVJbnRlZ2VyID0gKG5hbWUsIG4pID0+IHtcbiAgICBpZiAodHlwZW9mIG4gIT09ICdudW1iZXInIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKG4pKSB7XG4gICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGFuIGludGVnZXJgKTtcbiAgICB9XG4gICAgaWYgKG4gPCAwKSB7XG4gICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGEgcG9zaXRpdmUgaW50ZWdlcmApO1xuICAgIH1cbiAgICByZXR1cm4gbjtcbn07XG5leHBvcnQgY29uc3QgY2FzdFRvRXJyb3IgPSAoZXJyKSA9PiB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKVxuICAgICAgICByZXR1cm4gZXJyO1xuICAgIGlmICh0eXBlb2YgZXJyID09PSAnb2JqZWN0JyAmJiBlcnIgIT09IG51bGwpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggeyB9XG4gICAgfVxuICAgIHJldHVybiBuZXcgRXJyb3IoZXJyKTtcbn07XG5leHBvcnQgY29uc3QgZW5zdXJlUHJlc2VudCA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKVxuICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYEV4cGVjdGVkIGEgdmFsdWUgdG8gYmUgZ2l2ZW4gYnV0IHJlY2VpdmVkICR7dmFsdWV9IGluc3RlYWQuYCk7XG4gICAgcmV0dXJuIHZhbHVlO1xufTtcbi8qKlxuICogUmVhZCBhbiBlbnZpcm9ubWVudCB2YXJpYWJsZS5cbiAqXG4gKiBUcmltcyBiZWdpbm5pbmcgYW5kIHRyYWlsaW5nIHdoaXRlc3BhY2UuXG4gKlxuICogV2lsbCByZXR1cm4gdW5kZWZpbmVkIGlmIHRoZSBlbnZpcm9ubWVudCB2YXJpYWJsZSBkb2Vzbid0IGV4aXN0IG9yIGNhbm5vdCBiZSBhY2Nlc3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlYWRFbnYgPSAoZW52KSA9PiB7XG4gICAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gcHJvY2Vzcy5lbnY/LltlbnZdPy50cmltKCkgPz8gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIERlbm8gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHJldHVybiBEZW5vLmVudj8uZ2V0Py4oZW52KT8udHJpbSgpO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbmV4cG9ydCBjb25zdCBjb2VyY2VJbnRlZ2VyID0gKHZhbHVlKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpXG4gICAgICAgIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlKTtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJylcbiAgICAgICAgcmV0dXJuIHBhcnNlSW50KHZhbHVlLCAxMCk7XG4gICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBDb3VsZCBub3QgY29lcmNlICR7dmFsdWV9ICh0eXBlOiAke3R5cGVvZiB2YWx1ZX0pIGludG8gYSBudW1iZXJgKTtcbn07XG5leHBvcnQgY29uc3QgY29lcmNlRmxvYXQgPSAodmFsdWUpID0+IHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJylcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKVxuICAgICAgICByZXR1cm4gcGFyc2VGbG9hdCh2YWx1ZSk7XG4gICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBDb3VsZCBub3QgY29lcmNlICR7dmFsdWV9ICh0eXBlOiAke3R5cGVvZiB2YWx1ZX0pIGludG8gYSBudW1iZXJgKTtcbn07XG5leHBvcnQgY29uc3QgY29lcmNlQm9vbGVhbiA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJylcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKVxuICAgICAgICByZXR1cm4gdmFsdWUgPT09ICd0cnVlJztcbiAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG59O1xuZXhwb3J0IGNvbnN0IG1heWJlQ29lcmNlSW50ZWdlciA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHJldHVybiBjb2VyY2VJbnRlZ2VyKHZhbHVlKTtcbn07XG5leHBvcnQgY29uc3QgbWF5YmVDb2VyY2VGbG9hdCA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHJldHVybiBjb2VyY2VGbG9hdCh2YWx1ZSk7XG59O1xuZXhwb3J0IGNvbnN0IG1heWJlQ29lcmNlQm9vbGVhbiA9ICh2YWx1ZSkgPT4ge1xuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHJldHVybiBjb2VyY2VCb29sZWFuKHZhbHVlKTtcbn07XG4vLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMzQ0OTEyODdcbmV4cG9ydCBmdW5jdGlvbiBpc0VtcHR5T2JqKG9iaikge1xuICAgIGlmICghb2JqKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICBmb3IgKGNvbnN0IF9rIGluIG9iailcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiB0cnVlO1xufVxuLy8gaHR0cHM6Ly9lc2xpbnQub3JnL2RvY3MvbGF0ZXN0L3J1bGVzL25vLXByb3RvdHlwZS1idWlsdGluc1xuZXhwb3J0IGZ1bmN0aW9uIGhhc093bihvYmosIGtleSkge1xuICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpO1xufVxuLyoqXG4gKiBDb3BpZXMgaGVhZGVycyBmcm9tIFwibmV3SGVhZGVyc1wiIG9udG8gXCJ0YXJnZXRIZWFkZXJzXCIsXG4gKiB1c2luZyBsb3dlci1jYXNlIGZvciBhbGwgcHJvcGVydGllcyxcbiAqIGlnbm9yaW5nIGFueSBrZXlzIHdpdGggdW5kZWZpbmVkIHZhbHVlcyxcbiAqIGFuZCBkZWxldGluZyBhbnkga2V5cyB3aXRoIG51bGwgdmFsdWVzLlxuICovXG5mdW5jdGlvbiBhcHBseUhlYWRlcnNNdXQodGFyZ2V0SGVhZGVycywgbmV3SGVhZGVycykge1xuICAgIGZvciAoY29uc3QgayBpbiBuZXdIZWFkZXJzKSB7XG4gICAgICAgIGlmICghaGFzT3duKG5ld0hlYWRlcnMsIGspKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIGNvbnN0IGxvd2VyS2V5ID0gay50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoIWxvd2VyS2V5KVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIGNvbnN0IHZhbCA9IG5ld0hlYWRlcnNba107XG4gICAgICAgIGlmICh2YWwgPT09IG51bGwpIHtcbiAgICAgICAgICAgIGRlbGV0ZSB0YXJnZXRIZWFkZXJzW2xvd2VyS2V5XTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh2YWwgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGFyZ2V0SGVhZGVyc1tsb3dlcktleV0gPSB2YWw7XG4gICAgICAgIH1cbiAgICB9XG59XG5jb25zdCBTRU5TSVRJVkVfSEVBREVSUyA9IG5ldyBTZXQoWydhdXRob3JpemF0aW9uJywgJ2FwaS1rZXknXSk7XG5leHBvcnQgZnVuY3Rpb24gZGVidWcoYWN0aW9uLCAuLi5hcmdzKSB7XG4gICAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJyAmJiBwcm9jZXNzPy5lbnY/LlsnREVCVUcnXSA9PT0gJ3RydWUnKSB7XG4gICAgICAgIGNvbnN0IG1vZGlmaWVkQXJncyA9IGFyZ3MubWFwKChhcmcpID0+IHtcbiAgICAgICAgICAgIGlmICghYXJnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGFyZztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIENoZWNrIGZvciBzZW5zaXRpdmUgaGVhZGVycyBpbiByZXF1ZXN0IGJvZHkgJ2hlYWRlcnMnIG9iamVjdFxuICAgICAgICAgICAgaWYgKGFyZ1snaGVhZGVycyddKSB7XG4gICAgICAgICAgICAgICAgLy8gY2xvbmUgc28gd2UgZG9uJ3QgbXV0YXRlXG4gICAgICAgICAgICAgICAgY29uc3QgbW9kaWZpZWRBcmcgPSB7IC4uLmFyZywgaGVhZGVyczogeyAuLi5hcmdbJ2hlYWRlcnMnXSB9IH07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBoZWFkZXIgaW4gYXJnWydoZWFkZXJzJ10pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFNFTlNJVElWRV9IRUFERVJTLmhhcyhoZWFkZXIudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vZGlmaWVkQXJnWydoZWFkZXJzJ11baGVhZGVyXSA9ICdSRURBQ1RFRCc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1vZGlmaWVkQXJnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IG1vZGlmaWVkQXJnID0gbnVsbDtcbiAgICAgICAgICAgIC8vIENoZWNrIGZvciBzZW5zaXRpdmUgaGVhZGVycyBpbiBoZWFkZXJzIG9iamVjdFxuICAgICAgICAgICAgZm9yIChjb25zdCBoZWFkZXIgaW4gYXJnKSB7XG4gICAgICAgICAgICAgICAgaWYgKFNFTlNJVElWRV9IRUFERVJTLmhhcyhoZWFkZXIudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gYXZvaWQgbWFraW5nIGEgY29weSB1bnRpbCB3ZSBuZWVkIHRvXG4gICAgICAgICAgICAgICAgICAgIG1vZGlmaWVkQXJnID8/IChtb2RpZmllZEFyZyA9IHsgLi4uYXJnIH0pO1xuICAgICAgICAgICAgICAgICAgICBtb2RpZmllZEFyZ1toZWFkZXJdID0gJ1JFREFDVEVEJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbW9kaWZpZWRBcmcgPz8gYXJnO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc29sZS5sb2coYE9wZW5BSTpERUJVRzoke2FjdGlvbn1gLCAuLi5tb2RpZmllZEFyZ3MpO1xuICAgIH1cbn1cbi8qKlxuICogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9hLzIxMTc1MjNcbiAqL1xuY29uc3QgdXVpZDQgPSAoKSA9PiB7XG4gICAgcmV0dXJuICd4eHh4eHh4eC14eHh4LTR4eHgteXh4eC14eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgKGMpID0+IHtcbiAgICAgICAgY29uc3QgciA9IChNYXRoLnJhbmRvbSgpICogMTYpIHwgMDtcbiAgICAgICAgY29uc3QgdiA9IGMgPT09ICd4JyA/IHIgOiAociAmIDB4MykgfCAweDg7XG4gICAgICAgIHJldHVybiB2LnRvU3RyaW5nKDE2KTtcbiAgICB9KTtcbn07XG5leHBvcnQgY29uc3QgaXNSdW5uaW5nSW5Ccm93c2VyID0gKCkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgdHlwZW9mIHdpbmRvdy5kb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICB0eXBlb2YgbmF2aWdhdG9yICE9PSAndW5kZWZpbmVkJyk7XG59O1xuZXhwb3J0IGNvbnN0IGlzSGVhZGVyc1Byb3RvY29sID0gKGhlYWRlcnMpID0+IHtcbiAgICByZXR1cm4gdHlwZW9mIGhlYWRlcnM/LmdldCA9PT0gJ2Z1bmN0aW9uJztcbn07XG5leHBvcnQgY29uc3QgZ2V0UmVxdWlyZWRIZWFkZXIgPSAoaGVhZGVycywgaGVhZGVyKSA9PiB7XG4gICAgY29uc3QgZm91bmRIZWFkZXIgPSBnZXRIZWFkZXIoaGVhZGVycywgaGVhZGVyKTtcbiAgICBpZiAoZm91bmRIZWFkZXIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENvdWxkIG5vdCBmaW5kICR7aGVhZGVyfSBoZWFkZXJgKTtcbiAgICB9XG4gICAgcmV0dXJuIGZvdW5kSGVhZGVyO1xufTtcbmV4cG9ydCBjb25zdCBnZXRIZWFkZXIgPSAoaGVhZGVycywgaGVhZGVyKSA9PiB7XG4gICAgY29uc3QgbG93ZXJDYXNlZEhlYWRlciA9IGhlYWRlci50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChpc0hlYWRlcnNQcm90b2NvbChoZWFkZXJzKSkge1xuICAgICAgICAvLyB0byBkZWFsIHdpdGggdGhlIGNhc2Ugd2hlcmUgdGhlIGhlYWRlciBsb29rcyBsaWtlIFN0YWlubGVzcy1FdmVudC1JZFxuICAgICAgICBjb25zdCBpbnRlcmNhcHNIZWFkZXIgPSBoZWFkZXJbMF0/LnRvVXBwZXJDYXNlKCkgK1xuICAgICAgICAgICAgaGVhZGVyLnN1YnN0cmluZygxKS5yZXBsYWNlKC8oW15cXHddKShcXHcpL2csIChfbSwgZzEsIGcyKSA9PiBnMSArIGcyLnRvVXBwZXJDYXNlKCkpO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBbaGVhZGVyLCBsb3dlckNhc2VkSGVhZGVyLCBoZWFkZXIudG9VcHBlckNhc2UoKSwgaW50ZXJjYXBzSGVhZGVyXSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBoZWFkZXJzLmdldChrZXkpO1xuICAgICAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGhlYWRlcnMpKSB7XG4gICAgICAgIGlmIChrZXkudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJDYXNlZEhlYWRlcikge1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA8PSAxKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWVbMF07XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBSZWNlaXZlZCAke3ZhbHVlLmxlbmd0aH0gZW50cmllcyBmb3IgdGhlICR7aGVhZGVyfSBoZWFkZXIsIHVzaW5nIHRoZSBmaXJzdCBlbnRyeS5gKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWVbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG4vKipcbiAqIEVuY29kZXMgYSBzdHJpbmcgdG8gQmFzZTY0IGZvcm1hdC5cbiAqL1xuZXhwb3J0IGNvbnN0IHRvQmFzZTY0ID0gKHN0cikgPT4ge1xuICAgIGlmICghc3RyKVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHJldHVybiBCdWZmZXIuZnJvbShzdHIpLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBidG9hICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gYnRvYShzdHIpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoJ0Nhbm5vdCBnZW5lcmF0ZSBiNjQgc3RyaW5nOyBFeHBlY3RlZCBgQnVmZmVyYCBvciBgYnRvYWAgdG8gYmUgZGVmaW5lZCcpO1xufTtcbi8qKlxuICogQ29udmVydHMgYSBCYXNlNjQgZW5jb2RlZCBzdHJpbmcgdG8gYSBGbG9hdDMyQXJyYXkuXG4gKiBAcGFyYW0gYmFzZTY0U3RyIC0gVGhlIEJhc2U2NCBlbmNvZGVkIHN0cmluZy5cbiAqIEByZXR1cm5zIEFuIEFycmF5IG9mIG51bWJlcnMgaW50ZXJwcmV0ZWQgYXMgRmxvYXQzMiB2YWx1ZXMuXG4gKi9cbmV4cG9ydCBjb25zdCB0b0Zsb2F0MzJBcnJheSA9IChiYXNlNjRTdHIpID0+IHtcbiAgICBpZiAodHlwZW9mIEJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgLy8gZm9yIE5vZGUuanMgZW52aXJvbm1lbnRcbiAgICAgICAgY29uc3QgYnVmID0gQnVmZmVyLmZyb20oYmFzZTY0U3RyLCAnYmFzZTY0Jyk7XG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKG5ldyBGbG9hdDMyQXJyYXkoYnVmLmJ1ZmZlciwgYnVmLmJ5dGVPZmZzZXQsIGJ1Zi5sZW5ndGggLyBGbG9hdDMyQXJyYXkuQllURVNfUEVSX0VMRU1FTlQpKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIGZvciBsZWdhY3kgd2ViIHBsYXRmb3JtIEFQSXNcbiAgICAgICAgY29uc3QgYmluYXJ5U3RyID0gYXRvYihiYXNlNjRTdHIpO1xuICAgICAgICBjb25zdCBsZW4gPSBiaW5hcnlTdHIubGVuZ3RoO1xuICAgICAgICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGxlbik7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgIGJ5dGVzW2ldID0gYmluYXJ5U3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20obmV3IEZsb2F0MzJBcnJheShieXRlcy5idWZmZXIpKTtcbiAgICB9XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGlzT2JqKG9iaikge1xuICAgIHJldHVybiBvYmogIT0gbnVsbCAmJiB0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheShvYmopO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29yZS5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFic3RyYWN0UGFnZSB9IGZyb20gXCIuL2NvcmUubWpzXCI7XG4vKipcbiAqIE5vdGU6IG5vIHBhZ2luYXRpb24gYWN0dWFsbHkgb2NjdXJzIHlldCwgdGhpcyBpcyBmb3IgZm9yd2FyZHMtY29tcGF0aWJpbGl0eS5cbiAqL1xuZXhwb3J0IGNsYXNzIFBhZ2UgZXh0ZW5kcyBBYnN0cmFjdFBhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGNsaWVudCwgcmVzcG9uc2UsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgc3VwZXIoY2xpZW50LCByZXNwb25zZSwgYm9keSwgb3B0aW9ucyk7XG4gICAgICAgIHRoaXMuZGF0YSA9IGJvZHkuZGF0YSB8fCBbXTtcbiAgICAgICAgdGhpcy5vYmplY3QgPSBib2R5Lm9iamVjdDtcbiAgICB9XG4gICAgZ2V0UGFnaW5hdGVkSXRlbXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmRhdGEgPz8gW107XG4gICAgfVxuICAgIC8vIEBkZXByZWNhdGVkIFBsZWFzZSB1c2UgYG5leHRQYWdlSW5mbygpYCBpbnN0ZWFkXG4gICAgLyoqXG4gICAgICogVGhpcyBwYWdlIHJlcHJlc2VudHMgYSByZXNwb25zZSB0aGF0IGlzbid0IGFjdHVhbGx5IHBhZ2luYXRlZCBhdCB0aGUgQVBJIGxldmVsXG4gICAgICogc28gdGhlcmUgd2lsbCBuZXZlciBiZSBhbnkgbmV4dCBwYWdlIHBhcmFtcy5cbiAgICAgKi9cbiAgICBuZXh0UGFnZVBhcmFtcygpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIG5leHRQYWdlSW5mbygpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEN1cnNvclBhZ2UgZXh0ZW5kcyBBYnN0cmFjdFBhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKGNsaWVudCwgcmVzcG9uc2UsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgc3VwZXIoY2xpZW50LCByZXNwb25zZSwgYm9keSwgb3B0aW9ucyk7XG4gICAgICAgIHRoaXMuZGF0YSA9IGJvZHkuZGF0YSB8fCBbXTtcbiAgICAgICAgdGhpcy5oYXNfbW9yZSA9IGJvZHkuaGFzX21vcmUgfHwgZmFsc2U7XG4gICAgfVxuICAgIGdldFBhZ2luYXRlZEl0ZW1zKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5kYXRhID8/IFtdO1xuICAgIH1cbiAgICBoYXNOZXh0UGFnZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuaGFzX21vcmUgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN1cGVyLmhhc05leHRQYWdlKCk7XG4gICAgfVxuICAgIC8vIEBkZXByZWNhdGVkIFBsZWFzZSB1c2UgYG5leHRQYWdlSW5mbygpYCBpbnN0ZWFkXG4gICAgbmV4dFBhZ2VQYXJhbXMoKSB7XG4gICAgICAgIGNvbnN0IGluZm8gPSB0aGlzLm5leHRQYWdlSW5mbygpO1xuICAgICAgICBpZiAoIWluZm8pXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKCdwYXJhbXMnIGluIGluZm8pXG4gICAgICAgICAgICByZXR1cm4gaW5mby5wYXJhbXM7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IE9iamVjdC5mcm9tRW50cmllcyhpbmZvLnVybC5zZWFyY2hQYXJhbXMpO1xuICAgICAgICBpZiAoIU9iamVjdC5rZXlzKHBhcmFtcykubGVuZ3RoKVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiBwYXJhbXM7XG4gICAgfVxuICAgIG5leHRQYWdlSW5mbygpIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHRoaXMuZ2V0UGFnaW5hdGVkSXRlbXMoKTtcbiAgICAgICAgaWYgKCFkYXRhLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaWQgPSBkYXRhW2RhdGEubGVuZ3RoIC0gMV0/LmlkO1xuICAgICAgICBpZiAoIWlkKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBwYXJhbXM6IHsgYWZ0ZXI6IGlkIH0gfTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYWdpbmF0aW9uLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuZXhwb3J0IGNsYXNzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcihjbGllbnQpIHtcbiAgICAgICAgdGhpcy5fY2xpZW50ID0gY2xpZW50O1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc291cmNlLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBDaGF0Q29tcGxldGlvblN0b3JlTWVzc2FnZXNQYWdlIH0gZnJvbSBcIi4vY29tcGxldGlvbnMubWpzXCI7XG5leHBvcnQgY2xhc3MgTWVzc2FnZXMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgbGlzdChjb21wbGV0aW9uSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KGNvbXBsZXRpb25JZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC9jaGF0L2NvbXBsZXRpb25zLyR7Y29tcGxldGlvbklkfS9tZXNzYWdlc2AsIENoYXRDb21wbGV0aW9uU3RvcmVNZXNzYWdlc1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxufVxuZXhwb3J0IHsgQ2hhdENvbXBsZXRpb25TdG9yZU1lc3NhZ2VzUGFnZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWVzc2FnZXMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCB7IGlzUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vLi4vLi4vY29yZS5tanNcIjtcbmltcG9ydCAqIGFzIE1lc3NhZ2VzQVBJIGZyb20gXCIuL21lc3NhZ2VzLm1qc1wiO1xuaW1wb3J0IHsgTWVzc2FnZXMgfSBmcm9tIFwiLi9tZXNzYWdlcy5tanNcIjtcbmltcG9ydCB7IEN1cnNvclBhZ2UgfSBmcm9tIFwiLi4vLi4vLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBDb21wbGV0aW9ucyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5tZXNzYWdlcyA9IG5ldyBNZXNzYWdlc0FQSS5NZXNzYWdlcyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbiAgICBjcmVhdGUoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9jaGF0L2NvbXBsZXRpb25zJywgeyBib2R5LCAuLi5vcHRpb25zLCBzdHJlYW06IGJvZHkuc3RyZWFtID8/IGZhbHNlIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBHZXQgYSBzdG9yZWQgY2hhdCBjb21wbGV0aW9uLiBPbmx5IENoYXQgQ29tcGxldGlvbnMgdGhhdCBoYXZlIGJlZW4gY3JlYXRlZCB3aXRoXG4gICAgICogdGhlIGBzdG9yZWAgcGFyYW1ldGVyIHNldCB0byBgdHJ1ZWAgd2lsbCBiZSByZXR1cm5lZC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBjaGF0Q29tcGxldGlvbiA9XG4gICAgICogICBhd2FpdCBjbGllbnQuY2hhdC5jb21wbGV0aW9ucy5yZXRyaWV2ZSgnY29tcGxldGlvbl9pZCcpO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIHJldHJpZXZlKGNvbXBsZXRpb25JZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL2NoYXQvY29tcGxldGlvbnMvJHtjb21wbGV0aW9uSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE1vZGlmeSBhIHN0b3JlZCBjaGF0IGNvbXBsZXRpb24uIE9ubHkgQ2hhdCBDb21wbGV0aW9ucyB0aGF0IGhhdmUgYmVlbiBjcmVhdGVkXG4gICAgICogd2l0aCB0aGUgYHN0b3JlYCBwYXJhbWV0ZXIgc2V0IHRvIGB0cnVlYCBjYW4gYmUgbW9kaWZpZWQuIEN1cnJlbnRseSwgdGhlIG9ubHlcbiAgICAgKiBzdXBwb3J0ZWQgbW9kaWZpY2F0aW9uIGlzIHRvIHVwZGF0ZSB0aGUgYG1ldGFkYXRhYCBmaWVsZC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBjaGF0Q29tcGxldGlvbiA9IGF3YWl0IGNsaWVudC5jaGF0LmNvbXBsZXRpb25zLnVwZGF0ZShcbiAgICAgKiAgICdjb21wbGV0aW9uX2lkJyxcbiAgICAgKiAgIHsgbWV0YWRhdGE6IHsgZm9vOiAnc3RyaW5nJyB9IH0sXG4gICAgICogKTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICB1cGRhdGUoY29tcGxldGlvbklkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL2NoYXQvY29tcGxldGlvbnMvJHtjb21wbGV0aW9uSWR9YCwgeyBib2R5LCAuLi5vcHRpb25zIH0pO1xuICAgIH1cbiAgICBsaXN0KHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KHt9LCBxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXRBUElMaXN0KCcvY2hhdC9jb21wbGV0aW9ucycsIENoYXRDb21wbGV0aW9uc1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERlbGV0ZSBhIHN0b3JlZCBjaGF0IGNvbXBsZXRpb24uIE9ubHkgQ2hhdCBDb21wbGV0aW9ucyB0aGF0IGhhdmUgYmVlbiBjcmVhdGVkXG4gICAgICogd2l0aCB0aGUgYHN0b3JlYCBwYXJhbWV0ZXIgc2V0IHRvIGB0cnVlYCBjYW4gYmUgZGVsZXRlZC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBjaGF0Q29tcGxldGlvbkRlbGV0ZWQgPVxuICAgICAqICAgYXdhaXQgY2xpZW50LmNoYXQuY29tcGxldGlvbnMuZGVsKCdjb21wbGV0aW9uX2lkJyk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgZGVsKGNvbXBsZXRpb25JZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmRlbGV0ZShgL2NoYXQvY29tcGxldGlvbnMvJHtjb21wbGV0aW9uSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIENoYXRDb21wbGV0aW9uc1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbmV4cG9ydCBjbGFzcyBDaGF0Q29tcGxldGlvblN0b3JlTWVzc2FnZXNQYWdlIGV4dGVuZHMgQ3Vyc29yUGFnZSB7XG59XG5Db21wbGV0aW9ucy5DaGF0Q29tcGxldGlvbnNQYWdlID0gQ2hhdENvbXBsZXRpb25zUGFnZTtcbkNvbXBsZXRpb25zLk1lc3NhZ2VzID0gTWVzc2FnZXM7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21wbGV0aW9ucy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tcGxldGlvbnNBUEkgZnJvbSBcIi4vY29tcGxldGlvbnMvY29tcGxldGlvbnMubWpzXCI7XG5pbXBvcnQgeyBDaGF0Q29tcGxldGlvbnNQYWdlLCBDb21wbGV0aW9ucywgfSBmcm9tIFwiLi9jb21wbGV0aW9ucy9jb21wbGV0aW9ucy5tanNcIjtcbmV4cG9ydCBjbGFzcyBDaGF0IGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmNvbXBsZXRpb25zID0gbmV3IENvbXBsZXRpb25zQVBJLkNvbXBsZXRpb25zKHRoaXMuX2NsaWVudCk7XG4gICAgfVxufVxuQ2hhdC5Db21wbGV0aW9ucyA9IENvbXBsZXRpb25zO1xuQ2hhdC5DaGF0Q29tcGxldGlvbnNQYWdlID0gQ2hhdENvbXBsZXRpb25zUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoYXQubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmV4cG9ydCBjbGFzcyBTcGVlY2ggZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogR2VuZXJhdGVzIGF1ZGlvIGZyb20gdGhlIGlucHV0IHRleHQuXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3Qgc3BlZWNoID0gYXdhaXQgY2xpZW50LmF1ZGlvLnNwZWVjaC5jcmVhdGUoe1xuICAgICAqICAgaW5wdXQ6ICdpbnB1dCcsXG4gICAgICogICBtb2RlbDogJ3N0cmluZycsXG4gICAgICogICB2b2ljZTogJ2FzaCcsXG4gICAgICogfSk7XG4gICAgICpcbiAgICAgKiBjb25zdCBjb250ZW50ID0gYXdhaXQgc3BlZWNoLmJsb2IoKTtcbiAgICAgKiBjb25zb2xlLmxvZyhjb250ZW50KTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBjcmVhdGUoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9hdWRpby9zcGVlY2gnLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgQWNjZXB0OiAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICAgICAgX19iaW5hcnlSZXNwb25zZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3BlZWNoLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgKiBhcyBDb3JlIGZyb20gXCIuLi8uLi9jb3JlLm1qc1wiO1xuZXhwb3J0IGNsYXNzIFRyYW5zY3JpcHRpb25zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2F1ZGlvL3RyYW5zY3JpcHRpb25zJywgQ29yZS5tdWx0aXBhcnRGb3JtUmVxdWVzdE9wdGlvbnMoe1xuICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBzdHJlYW06IGJvZHkuc3RyZWFtID8/IGZhbHNlLFxuICAgICAgICAgICAgX19tZXRhZGF0YTogeyBtb2RlbDogYm9keS5tb2RlbCB9LFxuICAgICAgICB9KSk7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHJhbnNjcmlwdGlvbnMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4uLy4uL2NvcmUubWpzXCI7XG5leHBvcnQgY2xhc3MgVHJhbnNsYXRpb25zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2F1ZGlvL3RyYW5zbGF0aW9ucycsIENvcmUubXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zKHsgYm9keSwgLi4ub3B0aW9ucywgX19tZXRhZGF0YTogeyBtb2RlbDogYm9keS5tb2RlbCB9IH0pKTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD10cmFuc2xhdGlvbnMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCAqIGFzIFNwZWVjaEFQSSBmcm9tIFwiLi9zcGVlY2gubWpzXCI7XG5pbXBvcnQgeyBTcGVlY2ggfSBmcm9tIFwiLi9zcGVlY2gubWpzXCI7XG5pbXBvcnQgKiBhcyBUcmFuc2NyaXB0aW9uc0FQSSBmcm9tIFwiLi90cmFuc2NyaXB0aW9ucy5tanNcIjtcbmltcG9ydCB7IFRyYW5zY3JpcHRpb25zLCB9IGZyb20gXCIuL3RyYW5zY3JpcHRpb25zLm1qc1wiO1xuaW1wb3J0ICogYXMgVHJhbnNsYXRpb25zQVBJIGZyb20gXCIuL3RyYW5zbGF0aW9ucy5tanNcIjtcbmltcG9ydCB7IFRyYW5zbGF0aW9ucywgfSBmcm9tIFwiLi90cmFuc2xhdGlvbnMubWpzXCI7XG5leHBvcnQgY2xhc3MgQXVkaW8gZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMudHJhbnNjcmlwdGlvbnMgPSBuZXcgVHJhbnNjcmlwdGlvbnNBUEkuVHJhbnNjcmlwdGlvbnModGhpcy5fY2xpZW50KTtcbiAgICAgICAgdGhpcy50cmFuc2xhdGlvbnMgPSBuZXcgVHJhbnNsYXRpb25zQVBJLlRyYW5zbGF0aW9ucyh0aGlzLl9jbGllbnQpO1xuICAgICAgICB0aGlzLnNwZWVjaCA9IG5ldyBTcGVlY2hBUEkuU3BlZWNoKHRoaXMuX2NsaWVudCk7XG4gICAgfVxufVxuQXVkaW8uVHJhbnNjcmlwdGlvbnMgPSBUcmFuc2NyaXB0aW9ucztcbkF1ZGlvLlRyYW5zbGF0aW9ucyA9IFRyYW5zbGF0aW9ucztcbkF1ZGlvLlNwZWVjaCA9IFNwZWVjaDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWF1ZGlvLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBDdXJzb3JQYWdlIH0gZnJvbSBcIi4uL3BhZ2luYXRpb24ubWpzXCI7XG5leHBvcnQgY2xhc3MgQmF0Y2hlcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGFuZCBleGVjdXRlcyBhIGJhdGNoIGZyb20gYW4gdXBsb2FkZWQgZmlsZSBvZiByZXF1ZXN0c1xuICAgICAqL1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2JhdGNoZXMnLCB7IGJvZHksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIGJhdGNoLlxuICAgICAqL1xuICAgIHJldHJpZXZlKGJhdGNoSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC9iYXRjaGVzLyR7YmF0Y2hJZH1gLCBvcHRpb25zKTtcbiAgICB9XG4gICAgbGlzdChxdWVyeSA9IHt9LCBvcHRpb25zKSB7XG4gICAgICAgIGlmIChpc1JlcXVlc3RPcHRpb25zKHF1ZXJ5KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMubGlzdCh7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdCgnL2JhdGNoZXMnLCBCYXRjaGVzUGFnZSwgeyBxdWVyeSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ2FuY2VscyBhbiBpbi1wcm9ncmVzcyBiYXRjaC4gVGhlIGJhdGNoIHdpbGwgYmUgaW4gc3RhdHVzIGBjYW5jZWxsaW5nYCBmb3IgdXAgdG9cbiAgICAgKiAxMCBtaW51dGVzLCBiZWZvcmUgY2hhbmdpbmcgdG8gYGNhbmNlbGxlZGAsIHdoZXJlIGl0IHdpbGwgaGF2ZSBwYXJ0aWFsIHJlc3VsdHNcbiAgICAgKiAoaWYgYW55KSBhdmFpbGFibGUgaW4gdGhlIG91dHB1dCBmaWxlLlxuICAgICAqL1xuICAgIGNhbmNlbChiYXRjaElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL2JhdGNoZXMvJHtiYXRjaElkfS9jYW5jZWxgLCBvcHRpb25zKTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQmF0Y2hlc1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbkJhdGNoZXMuQmF0Y2hlc1BhZ2UgPSBCYXRjaGVzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJhdGNoZXMubWpzLm1hcCIsInZhciBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0ID0gKHRoaXMgJiYgdGhpcy5fX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KSB8fCBmdW5jdGlvbiAocmVjZWl2ZXIsIHN0YXRlLCB2YWx1ZSwga2luZCwgZikge1xuICAgIGlmIChraW5kID09PSBcIm1cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgbWV0aG9kIGlzIG5vdCB3cml0YWJsZVwiKTtcbiAgICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBzZXR0ZXJcIik7XG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3Qgd3JpdGUgcHJpdmF0ZSBtZW1iZXIgdG8gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcbiAgICByZXR1cm4gKGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyLCB2YWx1ZSkgOiBmID8gZi52YWx1ZSA9IHZhbHVlIDogc3RhdGUuc2V0KHJlY2VpdmVyLCB2YWx1ZSkpLCB2YWx1ZTtcbn07XG52YXIgX19jbGFzc1ByaXZhdGVGaWVsZEdldCA9ICh0aGlzICYmIHRoaXMuX19jbGFzc1ByaXZhdGVGaWVsZEdldCkgfHwgZnVuY3Rpb24gKHJlY2VpdmVyLCBzdGF0ZSwga2luZCwgZikge1xuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcbiAgICBpZiAodHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciAhPT0gc3RhdGUgfHwgIWYgOiAhc3RhdGUuaGFzKHJlY2VpdmVyKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCByZWFkIHByaXZhdGUgbWVtYmVyIGZyb20gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcbiAgICByZXR1cm4ga2luZCA9PT0gXCJtXCIgPyBmIDoga2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIpIDogZiA/IGYudmFsdWUgOiBzdGF0ZS5nZXQocmVjZWl2ZXIpO1xufTtcbnZhciBfRXZlbnRTdHJlYW1faW5zdGFuY2VzLCBfRXZlbnRTdHJlYW1fY29ubmVjdGVkUHJvbWlzZSwgX0V2ZW50U3RyZWFtX3Jlc29sdmVDb25uZWN0ZWRQcm9taXNlLCBfRXZlbnRTdHJlYW1fcmVqZWN0Q29ubmVjdGVkUHJvbWlzZSwgX0V2ZW50U3RyZWFtX2VuZFByb21pc2UsIF9FdmVudFN0cmVhbV9yZXNvbHZlRW5kUHJvbWlzZSwgX0V2ZW50U3RyZWFtX3JlamVjdEVuZFByb21pc2UsIF9FdmVudFN0cmVhbV9saXN0ZW5lcnMsIF9FdmVudFN0cmVhbV9lbmRlZCwgX0V2ZW50U3RyZWFtX2Vycm9yZWQsIF9FdmVudFN0cmVhbV9hYm9ydGVkLCBfRXZlbnRTdHJlYW1fY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCwgX0V2ZW50U3RyZWFtX2hhbmRsZUVycm9yO1xuaW1wb3J0IHsgQVBJVXNlckFib3J0RXJyb3IsIE9wZW5BSUVycm9yIH0gZnJvbSBcIi4uL2Vycm9yLm1qc1wiO1xuZXhwb3J0IGNsYXNzIEV2ZW50U3RyZWFtIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgX0V2ZW50U3RyZWFtX2luc3RhbmNlcy5hZGQodGhpcyk7XG4gICAgICAgIHRoaXMuY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgX0V2ZW50U3RyZWFtX2Nvbm5lY3RlZFByb21pc2Uuc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9FdmVudFN0cmVhbV9yZXNvbHZlQ29ubmVjdGVkUHJvbWlzZS5zZXQodGhpcywgKCkgPT4geyB9KTtcbiAgICAgICAgX0V2ZW50U3RyZWFtX3JlamVjdENvbm5lY3RlZFByb21pc2Uuc2V0KHRoaXMsICgpID0+IHsgfSk7XG4gICAgICAgIF9FdmVudFN0cmVhbV9lbmRQcm9taXNlLnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfRXZlbnRTdHJlYW1fcmVzb2x2ZUVuZFByb21pc2Uuc2V0KHRoaXMsICgpID0+IHsgfSk7XG4gICAgICAgIF9FdmVudFN0cmVhbV9yZWplY3RFbmRQcm9taXNlLnNldCh0aGlzLCAoKSA9PiB7IH0pO1xuICAgICAgICBfRXZlbnRTdHJlYW1fbGlzdGVuZXJzLnNldCh0aGlzLCB7fSk7XG4gICAgICAgIF9FdmVudFN0cmVhbV9lbmRlZC5zZXQodGhpcywgZmFsc2UpO1xuICAgICAgICBfRXZlbnRTdHJlYW1fZXJyb3JlZC5zZXQodGhpcywgZmFsc2UpO1xuICAgICAgICBfRXZlbnRTdHJlYW1fYWJvcnRlZC5zZXQodGhpcywgZmFsc2UpO1xuICAgICAgICBfRXZlbnRTdHJlYW1fY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZC5zZXQodGhpcywgZmFsc2UpO1xuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9FdmVudFN0cmVhbV9jb25uZWN0ZWRQcm9taXNlLCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9FdmVudFN0cmVhbV9yZXNvbHZlQ29ubmVjdGVkUHJvbWlzZSwgcmVzb2x2ZSwgXCJmXCIpO1xuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfRXZlbnRTdHJlYW1fcmVqZWN0Q29ubmVjdGVkUHJvbWlzZSwgcmVqZWN0LCBcImZcIik7XG4gICAgICAgIH0pLCBcImZcIik7XG4gICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0V2ZW50U3RyZWFtX2VuZFByb21pc2UsIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0V2ZW50U3RyZWFtX3Jlc29sdmVFbmRQcm9taXNlLCByZXNvbHZlLCBcImZcIik7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9FdmVudFN0cmVhbV9yZWplY3RFbmRQcm9taXNlLCByZWplY3QsIFwiZlwiKTtcbiAgICAgICAgfSksIFwiZlwiKTtcbiAgICAgICAgLy8gRG9uJ3QgbGV0IHRoZXNlIHByb21pc2VzIGNhdXNlIHVuaGFuZGxlZCByZWplY3Rpb24gZXJyb3JzLlxuICAgICAgICAvLyB3ZSB3aWxsIG1hbnVhbGx5IGNhdXNlIGFuIHVuaGFuZGxlZCByZWplY3Rpb24gZXJyb3IgbGF0ZXJcbiAgICAgICAgLy8gaWYgdGhlIHVzZXIgaGFzbid0IHJlZ2lzdGVyZWQgYW55IGVycm9yIGxpc3RlbmVyIG9yIGNhbGxlZFxuICAgICAgICAvLyBhbnkgcHJvbWlzZS1yZXR1cm5pbmcgbWV0aG9kLlxuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9jb25uZWN0ZWRQcm9taXNlLCBcImZcIikuY2F0Y2goKCkgPT4geyB9KTtcbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fZW5kUHJvbWlzZSwgXCJmXCIpLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgfVxuICAgIF9ydW4oZXhlY3V0b3IpIHtcbiAgICAgICAgLy8gVW5mb3J0dW5hdGVseSBpZiB3ZSBjYWxsIGBleGVjdXRvcigpYCBpbW1lZGlhdGVseSB3ZSBnZXQgcnVudGltZSBlcnJvcnMgYWJvdXRcbiAgICAgICAgLy8gcmVmZXJlbmNlcyB0byBgdGhpc2AgYmVmb3JlIHRoZSBgc3VwZXIoKWAgY29uc3RydWN0b3IgY2FsbCByZXR1cm5zLlxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGV4ZWN1dG9yKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdEZpbmFsKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgnZW5kJyk7XG4gICAgICAgICAgICB9LCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfRXZlbnRTdHJlYW1faGFuZGxlRXJyb3IpLmJpbmQodGhpcykpO1xuICAgICAgICB9LCAwKTtcbiAgICB9XG4gICAgX2Nvbm5lY3RlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuZW5kZWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX3Jlc29sdmVDb25uZWN0ZWRQcm9taXNlLCBcImZcIikuY2FsbCh0aGlzKTtcbiAgICAgICAgdGhpcy5fZW1pdCgnY29ubmVjdCcpO1xuICAgIH1cbiAgICBnZXQgZW5kZWQoKSB7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9lbmRlZCwgXCJmXCIpO1xuICAgIH1cbiAgICBnZXQgZXJyb3JlZCgpIHtcbiAgICAgICAgcmV0dXJuIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX2Vycm9yZWQsIFwiZlwiKTtcbiAgICB9XG4gICAgZ2V0IGFib3J0ZWQoKSB7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9hYm9ydGVkLCBcImZcIik7XG4gICAgfVxuICAgIGFib3J0KCkge1xuICAgICAgICB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQWRkcyB0aGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gdGhlIGVuZCBvZiB0aGUgbGlzdGVuZXJzIGFycmF5IGZvciB0aGUgZXZlbnQuXG4gICAgICogTm8gY2hlY2tzIGFyZSBtYWRlIHRvIHNlZSBpZiB0aGUgbGlzdGVuZXIgaGFzIGFscmVhZHkgYmVlbiBhZGRlZC4gTXVsdGlwbGUgY2FsbHMgcGFzc2luZ1xuICAgICAqIHRoZSBzYW1lIGNvbWJpbmF0aW9uIG9mIGV2ZW50IGFuZCBsaXN0ZW5lciB3aWxsIHJlc3VsdCBpbiB0aGUgbGlzdGVuZXIgYmVpbmcgYWRkZWQsIGFuZFxuICAgICAqIGNhbGxlZCwgbXVsdGlwbGUgdGltZXMuXG4gICAgICogQHJldHVybnMgdGhpcyBDaGF0Q29tcGxldGlvblN0cmVhbSwgc28gdGhhdCBjYWxscyBjYW4gYmUgY2hhaW5lZFxuICAgICAqL1xuICAgIG9uKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9saXN0ZW5lcnMsIFwiZlwiKVtldmVudF0gfHwgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX2xpc3RlbmVycywgXCJmXCIpW2V2ZW50XSA9IFtdKTtcbiAgICAgICAgbGlzdGVuZXJzLnB1c2goeyBsaXN0ZW5lciB9KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJlbW92ZXMgdGhlIHNwZWNpZmllZCBsaXN0ZW5lciBmcm9tIHRoZSBsaXN0ZW5lciBhcnJheSBmb3IgdGhlIGV2ZW50LlxuICAgICAqIG9mZigpIHdpbGwgcmVtb3ZlLCBhdCBtb3N0LCBvbmUgaW5zdGFuY2Ugb2YgYSBsaXN0ZW5lciBmcm9tIHRoZSBsaXN0ZW5lciBhcnJheS4gSWYgYW55IHNpbmdsZVxuICAgICAqIGxpc3RlbmVyIGhhcyBiZWVuIGFkZGVkIG11bHRpcGxlIHRpbWVzIHRvIHRoZSBsaXN0ZW5lciBhcnJheSBmb3IgdGhlIHNwZWNpZmllZCBldmVudCwgdGhlblxuICAgICAqIG9mZigpIG11c3QgYmUgY2FsbGVkIG11bHRpcGxlIHRpbWVzIHRvIHJlbW92ZSBlYWNoIGluc3RhbmNlLlxuICAgICAqIEByZXR1cm5zIHRoaXMgQ2hhdENvbXBsZXRpb25TdHJlYW0sIHNvIHRoYXQgY2FsbHMgY2FuIGJlIGNoYWluZWRcbiAgICAgKi9cbiAgICBvZmYoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgICAgIGNvbnN0IGxpc3RlbmVycyA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX2xpc3RlbmVycywgXCJmXCIpW2V2ZW50XTtcbiAgICAgICAgaWYgKCFsaXN0ZW5lcnMpXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgY29uc3QgaW5kZXggPSBsaXN0ZW5lcnMuZmluZEluZGV4KChsKSA9PiBsLmxpc3RlbmVyID09PSBsaXN0ZW5lcik7XG4gICAgICAgIGlmIChpbmRleCA+PSAwKVxuICAgICAgICAgICAgbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBZGRzIGEgb25lLXRpbWUgbGlzdGVuZXIgZnVuY3Rpb24gZm9yIHRoZSBldmVudC4gVGhlIG5leHQgdGltZSB0aGUgZXZlbnQgaXMgdHJpZ2dlcmVkLFxuICAgICAqIHRoaXMgbGlzdGVuZXIgaXMgcmVtb3ZlZCBhbmQgdGhlbiBpbnZva2VkLlxuICAgICAqIEByZXR1cm5zIHRoaXMgQ2hhdENvbXBsZXRpb25TdHJlYW0sIHNvIHRoYXQgY2FsbHMgY2FuIGJlIGNoYWluZWRcbiAgICAgKi9cbiAgICBvbmNlKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9saXN0ZW5lcnMsIFwiZlwiKVtldmVudF0gfHwgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX2xpc3RlbmVycywgXCJmXCIpW2V2ZW50XSA9IFtdKTtcbiAgICAgICAgbGlzdGVuZXJzLnB1c2goeyBsaXN0ZW5lciwgb25jZTogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFRoaXMgaXMgc2ltaWxhciB0byBgLm9uY2UoKWAsIGJ1dCByZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRoZSBuZXh0IHRpbWVcbiAgICAgKiB0aGUgZXZlbnQgaXMgdHJpZ2dlcmVkLCBpbnN0ZWFkIG9mIGNhbGxpbmcgYSBsaXN0ZW5lciBjYWxsYmFjay5cbiAgICAgKiBAcmV0dXJucyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyB0aGUgbmV4dCB0aW1lIGdpdmVuIGV2ZW50IGlzIHRyaWdnZXJlZCxcbiAgICAgKiBvciByZWplY3RzIGlmIGFuIGVycm9yIGlzIGVtaXR0ZWQuICAoSWYgeW91IHJlcXVlc3QgdGhlICdlcnJvcicgZXZlbnQsXG4gICAgICogcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBlcnJvcikuXG4gICAgICpcbiAgICAgKiBFeGFtcGxlOlxuICAgICAqXG4gICAgICogICBjb25zdCBtZXNzYWdlID0gYXdhaXQgc3RyZWFtLmVtaXR0ZWQoJ21lc3NhZ2UnKSAvLyByZWplY3RzIGlmIHRoZSBzdHJlYW0gZXJyb3JzXG4gICAgICovXG4gICAgZW1pdHRlZChldmVudCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfRXZlbnRTdHJlYW1fY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCwgdHJ1ZSwgXCJmXCIpO1xuICAgICAgICAgICAgaWYgKGV2ZW50ICE9PSAnZXJyb3InKVxuICAgICAgICAgICAgICAgIHRoaXMub25jZSgnZXJyb3InLCByZWplY3QpO1xuICAgICAgICAgICAgdGhpcy5vbmNlKGV2ZW50LCByZXNvbHZlKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGFzeW5jIGRvbmUoKSB7XG4gICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0V2ZW50U3RyZWFtX2NhdGNoaW5nUHJvbWlzZUNyZWF0ZWQsIHRydWUsIFwiZlwiKTtcbiAgICAgICAgYXdhaXQgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fZW5kUHJvbWlzZSwgXCJmXCIpO1xuICAgIH1cbiAgICBfZW1pdChldmVudCwgLi4uYXJncykge1xuICAgICAgICAvLyBtYWtlIHN1cmUgd2UgZG9uJ3QgZW1pdCBhbnkgZXZlbnRzIGFmdGVyIGVuZFxuICAgICAgICBpZiAoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fZW5kZWQsIFwiZlwiKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChldmVudCA9PT0gJ2VuZCcpIHtcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0V2ZW50U3RyZWFtX2VuZGVkLCB0cnVlLCBcImZcIik7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9yZXNvbHZlRW5kUHJvbWlzZSwgXCJmXCIpLmNhbGwodGhpcyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbGlzdGVuZXJzID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fbGlzdGVuZXJzLCBcImZcIilbZXZlbnRdO1xuICAgICAgICBpZiAobGlzdGVuZXJzKSB7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9saXN0ZW5lcnMsIFwiZlwiKVtldmVudF0gPSBsaXN0ZW5lcnMuZmlsdGVyKChsKSA9PiAhbC5vbmNlKTtcbiAgICAgICAgICAgIGxpc3RlbmVycy5mb3JFYWNoKCh7IGxpc3RlbmVyIH0pID0+IGxpc3RlbmVyKC4uLmFyZ3MpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZXZlbnQgPT09ICdhYm9ydCcpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gYXJnc1swXTtcbiAgICAgICAgICAgIGlmICghX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCwgXCJmXCIpICYmICFsaXN0ZW5lcnM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX3JlamVjdENvbm5lY3RlZFByb21pc2UsIFwiZlwiKS5jYWxsKHRoaXMsIGVycm9yKTtcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0V2ZW50U3RyZWFtX3JlamVjdEVuZFByb21pc2UsIFwiZlwiKS5jYWxsKHRoaXMsIGVycm9yKTtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2VuZCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChldmVudCA9PT0gJ2Vycm9yJykge1xuICAgICAgICAgICAgLy8gTk9URTogX2VtaXQoJ2Vycm9yJywgZXJyb3IpIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBmcm9tICNoYW5kbGVFcnJvcigpLlxuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBhcmdzWzBdO1xuICAgICAgICAgICAgaWYgKCFfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9FdmVudFN0cmVhbV9jYXRjaGluZ1Byb21pc2VDcmVhdGVkLCBcImZcIikgJiYgIWxpc3RlbmVycz8ubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgLy8gVHJpZ2dlciBhbiB1bmhhbmRsZWQgcmVqZWN0aW9uIGlmIHRoZSB1c2VyIGhhc24ndCByZWdpc3RlcmVkIGFueSBlcnJvciBoYW5kbGVycy5cbiAgICAgICAgICAgICAgICAvLyBJZiB5b3UgYXJlIHNlZWluZyBzdGFjayB0cmFjZXMgaGVyZSwgbWFrZSBzdXJlIHRvIGhhbmRsZSBlcnJvcnMgdmlhIGVpdGhlcjpcbiAgICAgICAgICAgICAgICAvLyAtIHJ1bm5lci5vbignZXJyb3InLCAoKSA9PiAuLi4pXG4gICAgICAgICAgICAgICAgLy8gLSBhd2FpdCBydW5uZXIuZG9uZSgpXG4gICAgICAgICAgICAgICAgLy8gLSBhd2FpdCBydW5uZXIuZmluYWxDaGF0Q29tcGxldGlvbigpXG4gICAgICAgICAgICAgICAgLy8gLSBldGMuXG4gICAgICAgICAgICAgICAgUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fcmVqZWN0Q29ubmVjdGVkUHJvbWlzZSwgXCJmXCIpLmNhbGwodGhpcywgZXJyb3IpO1xuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfRXZlbnRTdHJlYW1fcmVqZWN0RW5kUHJvbWlzZSwgXCJmXCIpLmNhbGwodGhpcywgZXJyb3IpO1xuICAgICAgICAgICAgdGhpcy5fZW1pdCgnZW5kJyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgX2VtaXRGaW5hbCgpIHsgfVxufVxuX0V2ZW50U3RyZWFtX2Nvbm5lY3RlZFByb21pc2UgPSBuZXcgV2Vha01hcCgpLCBfRXZlbnRTdHJlYW1fcmVzb2x2ZUNvbm5lY3RlZFByb21pc2UgPSBuZXcgV2Vha01hcCgpLCBfRXZlbnRTdHJlYW1fcmVqZWN0Q29ubmVjdGVkUHJvbWlzZSA9IG5ldyBXZWFrTWFwKCksIF9FdmVudFN0cmVhbV9lbmRQcm9taXNlID0gbmV3IFdlYWtNYXAoKSwgX0V2ZW50U3RyZWFtX3Jlc29sdmVFbmRQcm9taXNlID0gbmV3IFdlYWtNYXAoKSwgX0V2ZW50U3RyZWFtX3JlamVjdEVuZFByb21pc2UgPSBuZXcgV2Vha01hcCgpLCBfRXZlbnRTdHJlYW1fbGlzdGVuZXJzID0gbmV3IFdlYWtNYXAoKSwgX0V2ZW50U3RyZWFtX2VuZGVkID0gbmV3IFdlYWtNYXAoKSwgX0V2ZW50U3RyZWFtX2Vycm9yZWQgPSBuZXcgV2Vha01hcCgpLCBfRXZlbnRTdHJlYW1fYWJvcnRlZCA9IG5ldyBXZWFrTWFwKCksIF9FdmVudFN0cmVhbV9jYXRjaGluZ1Byb21pc2VDcmVhdGVkID0gbmV3IFdlYWtNYXAoKSwgX0V2ZW50U3RyZWFtX2luc3RhbmNlcyA9IG5ldyBXZWFrU2V0KCksIF9FdmVudFN0cmVhbV9oYW5kbGVFcnJvciA9IGZ1bmN0aW9uIF9FdmVudFN0cmVhbV9oYW5kbGVFcnJvcihlcnJvcikge1xuICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0V2ZW50U3RyZWFtX2Vycm9yZWQsIHRydWUsIFwiZlwiKTtcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnJvci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgICAgZXJyb3IgPSBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICB9XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQVBJVXNlckFib3J0RXJyb3IpIHtcbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfRXZlbnRTdHJlYW1fYWJvcnRlZCwgdHJ1ZSwgXCJmXCIpO1xuICAgICAgICByZXR1cm4gdGhpcy5fZW1pdCgnYWJvcnQnLCBlcnJvcik7XG4gICAgfVxuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIE9wZW5BSUVycm9yKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9lbWl0KCdlcnJvcicsIGVycm9yKTtcbiAgICB9XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgY29uc3Qgb3BlbkFJRXJyb3IgPSBuZXcgT3BlbkFJRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgb3BlbkFJRXJyb3IuY2F1c2UgPSBlcnJvcjtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2VtaXQoJ2Vycm9yJywgb3BlbkFJRXJyb3IpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZW1pdCgnZXJyb3InLCBuZXcgT3BlbkFJRXJyb3IoU3RyaW5nKGVycm9yKSkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUV2ZW50U3RyZWFtLm1qcy5tYXAiLCJ2YXIgX19jbGFzc1ByaXZhdGVGaWVsZEdldCA9ICh0aGlzICYmIHRoaXMuX19jbGFzc1ByaXZhdGVGaWVsZEdldCkgfHwgZnVuY3Rpb24gKHJlY2VpdmVyLCBzdGF0ZSwga2luZCwgZikge1xuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcbiAgICBpZiAodHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciAhPT0gc3RhdGUgfHwgIWYgOiAhc3RhdGUuaGFzKHJlY2VpdmVyKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCByZWFkIHByaXZhdGUgbWVtYmVyIGZyb20gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcbiAgICByZXR1cm4ga2luZCA9PT0gXCJtXCIgPyBmIDoga2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIpIDogZiA/IGYudmFsdWUgOiBzdGF0ZS5nZXQocmVjZWl2ZXIpO1xufTtcbnZhciBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0ID0gKHRoaXMgJiYgdGhpcy5fX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KSB8fCBmdW5jdGlvbiAocmVjZWl2ZXIsIHN0YXRlLCB2YWx1ZSwga2luZCwgZikge1xuICAgIGlmIChraW5kID09PSBcIm1cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgbWV0aG9kIGlzIG5vdCB3cml0YWJsZVwiKTtcbiAgICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBzZXR0ZXJcIik7XG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3Qgd3JpdGUgcHJpdmF0ZSBtZW1iZXIgdG8gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcbiAgICByZXR1cm4gKGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyLCB2YWx1ZSkgOiBmID8gZi52YWx1ZSA9IHZhbHVlIDogc3RhdGUuc2V0KHJlY2VpdmVyLCB2YWx1ZSkpLCB2YWx1ZTtcbn07XG52YXIgX0Fzc2lzdGFudFN0cmVhbV9pbnN0YW5jZXMsIF9Bc3Npc3RhbnRTdHJlYW1fZXZlbnRzLCBfQXNzaXN0YW50U3RyZWFtX3J1blN0ZXBTbmFwc2hvdHMsIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90cywgX0Fzc2lzdGFudFN0cmVhbV9tZXNzYWdlU25hcHNob3QsIF9Bc3Npc3RhbnRTdHJlYW1fZmluYWxSdW4sIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudENvbnRlbnRJbmRleCwgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50Q29udGVudCwgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGxJbmRleCwgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGwsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudEV2ZW50LCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRSdW5TbmFwc2hvdCwgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50UnVuU3RlcFNuYXBzaG90LCBfQXNzaXN0YW50U3RyZWFtX2FkZEV2ZW50LCBfQXNzaXN0YW50U3RyZWFtX2VuZFJlcXVlc3QsIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlTWVzc2FnZSwgX0Fzc2lzdGFudFN0cmVhbV9oYW5kbGVSdW5TdGVwLCBfQXNzaXN0YW50U3RyZWFtX2hhbmRsZUV2ZW50LCBfQXNzaXN0YW50U3RyZWFtX2FjY3VtdWxhdGVSdW5TdGVwLCBfQXNzaXN0YW50U3RyZWFtX2FjY3VtdWxhdGVNZXNzYWdlLCBfQXNzaXN0YW50U3RyZWFtX2FjY3VtdWxhdGVDb250ZW50LCBfQXNzaXN0YW50U3RyZWFtX2hhbmRsZVJ1bjtcbmltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBTdHJlYW0gfSBmcm9tIFwiLi4vc3RyZWFtaW5nLm1qc1wiO1xuaW1wb3J0IHsgQVBJVXNlckFib3J0RXJyb3IsIE9wZW5BSUVycm9yIH0gZnJvbSBcIi4uL2Vycm9yLm1qc1wiO1xuaW1wb3J0IHsgRXZlbnRTdHJlYW0gfSBmcm9tIFwiLi9FdmVudFN0cmVhbS5tanNcIjtcbmV4cG9ydCBjbGFzcyBBc3Npc3RhbnRTdHJlYW0gZXh0ZW5kcyBFdmVudFN0cmVhbSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzLmFkZCh0aGlzKTtcbiAgICAgICAgLy9UcmFjayBhbGwgZXZlbnRzIGluIGEgc2luZ2xlIGxpc3QgZm9yIHJlZmVyZW5jZVxuICAgICAgICBfQXNzaXN0YW50U3RyZWFtX2V2ZW50cy5zZXQodGhpcywgW10pO1xuICAgICAgICAvL1VzZWQgdG8gYWNjdW11bGF0ZSBkZWx0YXNcbiAgICAgICAgLy9XZSBhcmUgYWNjdW11bGF0aW5nIG1hbnkgdHlwZXMgc28gdGhlIHZhbHVlIGhlcmUgaXMgbm90IHN0cmljdFxuICAgICAgICBfQXNzaXN0YW50U3RyZWFtX3J1blN0ZXBTbmFwc2hvdHMuc2V0KHRoaXMsIHt9KTtcbiAgICAgICAgX0Fzc2lzdGFudFN0cmVhbV9tZXNzYWdlU25hcHNob3RzLnNldCh0aGlzLCB7fSk7XG4gICAgICAgIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90LnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfQXNzaXN0YW50U3RyZWFtX2ZpbmFsUnVuLnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50SW5kZXguc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudENvbnRlbnQuc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsSW5kZXguc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsLnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICAvL0ZvciBjdXJyZW50IHNuYXBzaG90IG1ldGhvZHNcbiAgICAgICAgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50RXZlbnQuc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFJ1blNuYXBzaG90LnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRSdW5TdGVwU25hcHNob3Quc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgfVxuICAgIFsoX0Fzc2lzdGFudFN0cmVhbV9ldmVudHMgPSBuZXcgV2Vha01hcCgpLCBfQXNzaXN0YW50U3RyZWFtX3J1blN0ZXBTbmFwc2hvdHMgPSBuZXcgV2Vha01hcCgpLCBfQXNzaXN0YW50U3RyZWFtX21lc3NhZ2VTbmFwc2hvdHMgPSBuZXcgV2Vha01hcCgpLCBfQXNzaXN0YW50U3RyZWFtX21lc3NhZ2VTbmFwc2hvdCA9IG5ldyBXZWFrTWFwKCksIF9Bc3Npc3RhbnRTdHJlYW1fZmluYWxSdW4gPSBuZXcgV2Vha01hcCgpLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50SW5kZXggPSBuZXcgV2Vha01hcCgpLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50ID0gbmV3IFdlYWtNYXAoKSwgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGxJbmRleCA9IG5ldyBXZWFrTWFwKCksIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsID0gbmV3IFdlYWtNYXAoKSwgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50RXZlbnQgPSBuZXcgV2Vha01hcCgpLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRSdW5TbmFwc2hvdCA9IG5ldyBXZWFrTWFwKCksIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFJ1blN0ZXBTbmFwc2hvdCA9IG5ldyBXZWFrTWFwKCksIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzID0gbmV3IFdlYWtTZXQoKSwgU3ltYm9sLmFzeW5jSXRlcmF0b3IpXSgpIHtcbiAgICAgICAgY29uc3QgcHVzaFF1ZXVlID0gW107XG4gICAgICAgIGNvbnN0IHJlYWRRdWV1ZSA9IFtdO1xuICAgICAgICBsZXQgZG9uZSA9IGZhbHNlO1xuICAgICAgICAvL0NhdGNoIGFsbCBmb3IgcGFzc2luZyBhbG9uZyBhbGwgZXZlbnRzXG4gICAgICAgIHRoaXMub24oJ2V2ZW50JywgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSByZWFkUXVldWUuc2hpZnQoKTtcbiAgICAgICAgICAgIGlmIChyZWFkZXIpIHtcbiAgICAgICAgICAgICAgICByZWFkZXIucmVzb2x2ZShldmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBwdXNoUXVldWUucHVzaChldmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICAgICAgICBkb25lID0gdHJ1ZTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcmVhZGVyIG9mIHJlYWRRdWV1ZSkge1xuICAgICAgICAgICAgICAgIHJlYWRlci5yZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZWFkUXVldWUubGVuZ3RoID0gMDtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMub24oJ2Fib3J0JywgKGVycikgPT4ge1xuICAgICAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlYWRlciBvZiByZWFkUXVldWUpIHtcbiAgICAgICAgICAgICAgICByZWFkZXIucmVqZWN0KGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZWFkUXVldWUubGVuZ3RoID0gMDtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMub24oJ2Vycm9yJywgKGVycikgPT4ge1xuICAgICAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlYWRlciBvZiByZWFkUXVldWUpIHtcbiAgICAgICAgICAgICAgICByZWFkZXIucmVqZWN0KGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZWFkUXVldWUubGVuZ3RoID0gMDtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBuZXh0OiBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFwdXNoUXVldWUubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiB0cnVlIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHJlYWRRdWV1ZS5wdXNoKHsgcmVzb2x2ZSwgcmVqZWN0IH0pKS50aGVuKChjaHVuaykgPT4gKGNodW5rID8geyB2YWx1ZTogY2h1bmssIGRvbmU6IGZhbHNlIH0gOiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBjaHVuayA9IHB1c2hRdWV1ZS5zaGlmdCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBjaHVuaywgZG9uZTogZmFsc2UgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXR1cm46IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmFib3J0KCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgc3RhdGljIGZyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pIHtcbiAgICAgICAgY29uc3QgcnVubmVyID0gbmV3IEFzc2lzdGFudFN0cmVhbSgpO1xuICAgICAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX2Zyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pKTtcbiAgICAgICAgcmV0dXJuIHJ1bm5lcjtcbiAgICB9XG4gICAgYXN5bmMgX2Zyb21SZWFkYWJsZVN0cmVhbShyZWFkYWJsZVN0cmVhbSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBzaWduYWwgPSBvcHRpb25zPy5zaWduYWw7XG4gICAgICAgIGlmIChzaWduYWwpIHtcbiAgICAgICAgICAgIGlmIChzaWduYWwuYWJvcnRlZClcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHRoaXMuY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9jb25uZWN0ZWQoKTtcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gU3RyZWFtLmZyb21SZWFkYWJsZVN0cmVhbShyZWFkYWJsZVN0cmVhbSwgdGhpcy5jb250cm9sbGVyKTtcbiAgICAgICAgZm9yIGF3YWl0IChjb25zdCBldmVudCBvZiBzdHJlYW0pIHtcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfQXNzaXN0YW50U3RyZWFtX2FkZEV2ZW50KS5jYWxsKHRoaXMsIGV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RyZWFtLmNvbnRyb2xsZXIuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fYWRkUnVuKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfQXNzaXN0YW50U3RyZWFtX2VuZFJlcXVlc3QpLmNhbGwodGhpcykpO1xuICAgIH1cbiAgICB0b1JlYWRhYmxlU3RyZWFtKCkge1xuICAgICAgICBjb25zdCBzdHJlYW0gPSBuZXcgU3RyZWFtKHRoaXNbU3ltYm9sLmFzeW5jSXRlcmF0b3JdLmJpbmQodGhpcyksIHRoaXMuY29udHJvbGxlcik7XG4gICAgICAgIHJldHVybiBzdHJlYW0udG9SZWFkYWJsZVN0cmVhbSgpO1xuICAgIH1cbiAgICBzdGF0aWMgY3JlYXRlVG9vbEFzc2lzdGFudFN0cmVhbSh0aHJlYWRJZCwgcnVuSWQsIHJ1bnMsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBydW5uZXIgPSBuZXcgQXNzaXN0YW50U3RyZWFtKCk7XG4gICAgICAgIHJ1bm5lci5fcnVuKCgpID0+IHJ1bm5lci5fcnVuVG9vbEFzc2lzdGFudFN0cmVhbSh0aHJlYWRJZCwgcnVuSWQsIHJ1bnMsIHBhcmFtcywge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgLi4ub3B0aW9ucz8uaGVhZGVycywgJ1gtU3RhaW5sZXNzLUhlbHBlci1NZXRob2QnOiAnc3RyZWFtJyB9LFxuICAgICAgICB9KSk7XG4gICAgICAgIHJldHVybiBydW5uZXI7XG4gICAgfVxuICAgIGFzeW5jIF9jcmVhdGVUb29sQXNzaXN0YW50U3RyZWFtKHJ1biwgdGhyZWFkSWQsIHJ1bklkLCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgc2lnbmFsID0gb3B0aW9ucz8uc2lnbmFsO1xuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sbGVyLmFib3J0KCk7XG4gICAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYm9keSA9IHsgLi4ucGFyYW1zLCBzdHJlYW06IHRydWUgfTtcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgcnVuLnN1Ym1pdFRvb2xPdXRwdXRzKHRocmVhZElkLCBydW5JZCwgYm9keSwge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIHNpZ25hbDogdGhpcy5jb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuX2Nvbm5lY3RlZCgpO1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IGV2ZW50IG9mIHN0cmVhbSkge1xuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1fYWRkRXZlbnQpLmNhbGwodGhpcywgZXZlbnQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdHJlYW0uY29udHJvbGxlci5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9hZGRSdW4oX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1fZW5kUmVxdWVzdCkuY2FsbCh0aGlzKSk7XG4gICAgfVxuICAgIHN0YXRpYyBjcmVhdGVUaHJlYWRBc3Npc3RhbnRTdHJlYW0ocGFyYW1zLCB0aHJlYWQsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgcnVubmVyID0gbmV3IEFzc2lzdGFudFN0cmVhbSgpO1xuICAgICAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX3RocmVhZEFzc2lzdGFudFN0cmVhbShwYXJhbXMsIHRocmVhZCwge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgLi4ub3B0aW9ucz8uaGVhZGVycywgJ1gtU3RhaW5sZXNzLUhlbHBlci1NZXRob2QnOiAnc3RyZWFtJyB9LFxuICAgICAgICB9KSk7XG4gICAgICAgIHJldHVybiBydW5uZXI7XG4gICAgfVxuICAgIHN0YXRpYyBjcmVhdGVBc3Npc3RhbnRTdHJlYW0odGhyZWFkSWQsIHJ1bnMsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBydW5uZXIgPSBuZXcgQXNzaXN0YW50U3RyZWFtKCk7XG4gICAgICAgIHJ1bm5lci5fcnVuKCgpID0+IHJ1bm5lci5fcnVuQXNzaXN0YW50U3RyZWFtKHRocmVhZElkLCBydW5zLCBwYXJhbXMsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7IC4uLm9wdGlvbnM/LmhlYWRlcnMsICdYLVN0YWlubGVzcy1IZWxwZXItTWV0aG9kJzogJ3N0cmVhbScgfSxcbiAgICAgICAgfSkpO1xuICAgICAgICByZXR1cm4gcnVubmVyO1xuICAgIH1cbiAgICBjdXJyZW50RXZlbnQoKSB7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudEV2ZW50LCBcImZcIik7XG4gICAgfVxuICAgIGN1cnJlbnRSdW4oKSB7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFJ1blNuYXBzaG90LCBcImZcIik7XG4gICAgfVxuICAgIGN1cnJlbnRNZXNzYWdlU25hcHNob3QoKSB7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90LCBcImZcIik7XG4gICAgfVxuICAgIGN1cnJlbnRSdW5TdGVwU25hcHNob3QoKSB7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFJ1blN0ZXBTbmFwc2hvdCwgXCJmXCIpO1xuICAgIH1cbiAgICBhc3luYyBmaW5hbFJ1blN0ZXBzKCkge1xuICAgICAgICBhd2FpdCB0aGlzLmRvbmUoKTtcbiAgICAgICAgcmV0dXJuIE9iamVjdC52YWx1ZXMoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX3J1blN0ZXBTbmFwc2hvdHMsIFwiZlwiKSk7XG4gICAgfVxuICAgIGFzeW5jIGZpbmFsTWVzc2FnZXMoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICByZXR1cm4gT2JqZWN0LnZhbHVlcyhfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90cywgXCJmXCIpKTtcbiAgICB9XG4gICAgYXN5bmMgZmluYWxSdW4oKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICBpZiAoIV9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9maW5hbFJ1biwgXCJmXCIpKVxuICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ0ZpbmFsIHJ1biB3YXMgbm90IHJlY2VpdmVkLicpO1xuICAgICAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2ZpbmFsUnVuLCBcImZcIik7XG4gICAgfVxuICAgIGFzeW5jIF9jcmVhdGVUaHJlYWRBc3Npc3RhbnRTdHJlYW0odGhyZWFkLCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgc2lnbmFsID0gb3B0aW9ucz8uc2lnbmFsO1xuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sbGVyLmFib3J0KCk7XG4gICAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYm9keSA9IHsgLi4ucGFyYW1zLCBzdHJlYW06IHRydWUgfTtcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgdGhyZWFkLmNyZWF0ZUFuZFJ1bihib2R5LCB7IC4uLm9wdGlvbnMsIHNpZ25hbDogdGhpcy5jb250cm9sbGVyLnNpZ25hbCB9KTtcbiAgICAgICAgdGhpcy5fY29ubmVjdGVkKCk7XG4gICAgICAgIGZvciBhd2FpdCAoY29uc3QgZXZlbnQgb2Ygc3RyZWFtKSB7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0Fzc2lzdGFudFN0cmVhbV9hZGRFdmVudCkuY2FsbCh0aGlzLCBldmVudCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0cmVhbS5jb250cm9sbGVyLnNpZ25hbD8uYWJvcnRlZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEFQSVVzZXJBYm9ydEVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2FkZFJ1bihfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0Fzc2lzdGFudFN0cmVhbV9lbmRSZXF1ZXN0KS5jYWxsKHRoaXMpKTtcbiAgICB9XG4gICAgYXN5bmMgX2NyZWF0ZUFzc2lzdGFudFN0cmVhbShydW4sIHRocmVhZElkLCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgc2lnbmFsID0gb3B0aW9ucz8uc2lnbmFsO1xuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sbGVyLmFib3J0KCk7XG4gICAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYm9keSA9IHsgLi4ucGFyYW1zLCBzdHJlYW06IHRydWUgfTtcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgcnVuLmNyZWF0ZSh0aHJlYWRJZCwgYm9keSwgeyAuLi5vcHRpb25zLCBzaWduYWw6IHRoaXMuY29udHJvbGxlci5zaWduYWwgfSk7XG4gICAgICAgIHRoaXMuX2Nvbm5lY3RlZCgpO1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IGV2ZW50IG9mIHN0cmVhbSkge1xuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1fYWRkRXZlbnQpLmNhbGwodGhpcywgZXZlbnQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdHJlYW0uY29udHJvbGxlci5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9hZGRSdW4oX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1fZW5kUmVxdWVzdCkuY2FsbCh0aGlzKSk7XG4gICAgfVxuICAgIHN0YXRpYyBhY2N1bXVsYXRlRGVsdGEoYWNjLCBkZWx0YSkge1xuICAgICAgICBmb3IgKGNvbnN0IFtrZXksIGRlbHRhVmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGRlbHRhKSkge1xuICAgICAgICAgICAgaWYgKCFhY2MuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgICAgICAgIGFjY1trZXldID0gZGVsdGFWYWx1ZTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBhY2NWYWx1ZSA9IGFjY1trZXldO1xuICAgICAgICAgICAgaWYgKGFjY1ZhbHVlID09PSBudWxsIHx8IGFjY1ZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBhY2Nba2V5XSA9IGRlbHRhVmFsdWU7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBXZSBkb24ndCBhY2N1bXVsYXRlIHRoZXNlIHNwZWNpYWwgcHJvcGVydGllc1xuICAgICAgICAgICAgaWYgKGtleSA9PT0gJ2luZGV4JyB8fCBrZXkgPT09ICd0eXBlJykge1xuICAgICAgICAgICAgICAgIGFjY1trZXldID0gZGVsdGFWYWx1ZTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFR5cGUtc3BlY2lmaWMgYWNjdW11bGF0aW9uIGxvZ2ljXG4gICAgICAgICAgICBpZiAodHlwZW9mIGFjY1ZhbHVlID09PSAnc3RyaW5nJyAmJiB0eXBlb2YgZGVsdGFWYWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICBhY2NWYWx1ZSArPSBkZWx0YVZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGFjY1ZhbHVlID09PSAnbnVtYmVyJyAmJiB0eXBlb2YgZGVsdGFWYWx1ZSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICBhY2NWYWx1ZSArPSBkZWx0YVZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoQ29yZS5pc09iaihhY2NWYWx1ZSkgJiYgQ29yZS5pc09iaihkZWx0YVZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGFjY1ZhbHVlID0gdGhpcy5hY2N1bXVsYXRlRGVsdGEoYWNjVmFsdWUsIGRlbHRhVmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShhY2NWYWx1ZSkgJiYgQXJyYXkuaXNBcnJheShkZWx0YVZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGlmIChhY2NWYWx1ZS5ldmVyeSgoeCkgPT4gdHlwZW9mIHggPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB4ID09PSAnbnVtYmVyJykpIHtcbiAgICAgICAgICAgICAgICAgICAgYWNjVmFsdWUucHVzaCguLi5kZWx0YVZhbHVlKTsgLy8gVXNlIHNwcmVhZCBzeW50YXggZm9yIGVmZmljaWVudCBhZGRpdGlvblxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBkZWx0YUVudHJ5IG9mIGRlbHRhVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFDb3JlLmlzT2JqKGRlbHRhRW50cnkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGFycmF5IGRlbHRhIGVudHJ5IHRvIGJlIGFuIG9iamVjdCBidXQgZ290OiAke2RlbHRhRW50cnl9YCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5kZXggPSBkZWx0YUVudHJ5WydpbmRleCddO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW5kZXggPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihkZWx0YUVudHJ5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXhwZWN0ZWQgYXJyYXkgZGVsdGEgZW50cnkgdG8gaGF2ZSBhbiBgaW5kZXhgIHByb3BlcnR5Jyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBpbmRleCAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXJyYXkgZGVsdGEgZW50cnkgXFxgaW5kZXhcXGAgcHJvcGVydHkgdG8gYmUgYSBudW1iZXIgYnV0IGdvdCAke2luZGV4fWApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFjY0VudHJ5ID0gYWNjVmFsdWVbaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICBpZiAoYWNjRW50cnkgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYWNjVmFsdWUucHVzaChkZWx0YUVudHJ5KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY1ZhbHVlW2luZGV4XSA9IHRoaXMuYWNjdW11bGF0ZURlbHRhKGFjY0VudHJ5LCBkZWx0YUVudHJ5KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRocm93IEVycm9yKGBVbmhhbmRsZWQgcmVjb3JkIHR5cGU6ICR7a2V5fSwgZGVsdGFWYWx1ZTogJHtkZWx0YVZhbHVlfSwgYWNjVmFsdWU6ICR7YWNjVmFsdWV9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhY2Nba2V5XSA9IGFjY1ZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhY2M7XG4gICAgfVxuICAgIF9hZGRSdW4ocnVuKSB7XG4gICAgICAgIHJldHVybiBydW47XG4gICAgfVxuICAgIGFzeW5jIF90aHJlYWRBc3Npc3RhbnRTdHJlYW0ocGFyYW1zLCB0aHJlYWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2NyZWF0ZVRocmVhZEFzc2lzdGFudFN0cmVhbSh0aHJlYWQsIHBhcmFtcywgb3B0aW9ucyk7XG4gICAgfVxuICAgIGFzeW5jIF9ydW5Bc3Npc3RhbnRTdHJlYW0odGhyZWFkSWQsIHJ1bnMsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fY3JlYXRlQXNzaXN0YW50U3RyZWFtKHJ1bnMsIHRocmVhZElkLCBwYXJhbXMsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBhc3luYyBfcnVuVG9vbEFzc2lzdGFudFN0cmVhbSh0aHJlYWRJZCwgcnVuSWQsIHJ1bnMsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5fY3JlYXRlVG9vbEFzc2lzdGFudFN0cmVhbShydW5zLCB0aHJlYWRJZCwgcnVuSWQsIHBhcmFtcywgb3B0aW9ucyk7XG4gICAgfVxufVxuX0Fzc2lzdGFudFN0cmVhbV9hZGRFdmVudCA9IGZ1bmN0aW9uIF9Bc3Npc3RhbnRTdHJlYW1fYWRkRXZlbnQoZXZlbnQpIHtcbiAgICBpZiAodGhpcy5lbmRlZClcbiAgICAgICAgcmV0dXJuO1xuICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50RXZlbnQsIGV2ZW50LCBcImZcIik7XG4gICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlRXZlbnQpLmNhbGwodGhpcywgZXZlbnQpO1xuICAgIHN3aXRjaCAoZXZlbnQuZXZlbnQpIHtcbiAgICAgICAgY2FzZSAndGhyZWFkLmNyZWF0ZWQnOlxuICAgICAgICAgICAgLy9ObyBhY3Rpb24gb24gdGhpcyBldmVudC5cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aHJlYWQucnVuLmNyZWF0ZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnF1ZXVlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uaW5fcHJvZ3Jlc3MnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnJlcXVpcmVzX2FjdGlvbic6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uY29tcGxldGVkJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5pbmNvbXBsZXRlJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5mYWlsZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLmNhbmNlbGxpbmcnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLmNhbmNlbGxlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uZXhwaXJlZCc6XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0Fzc2lzdGFudFN0cmVhbV9oYW5kbGVSdW4pLmNhbGwodGhpcywgZXZlbnQpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5jcmVhdGVkJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmluX3Byb2dyZXNzJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmRlbHRhJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmNvbXBsZXRlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5mYWlsZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnN0ZXAuY2FuY2VsbGVkJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmV4cGlyZWQnOlxuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlUnVuU3RlcCkuY2FsbCh0aGlzLCBldmVudCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAndGhyZWFkLm1lc3NhZ2UuY3JlYXRlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5tZXNzYWdlLmluX3Byb2dyZXNzJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLm1lc3NhZ2UuZGVsdGEnOlxuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5jb21wbGV0ZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5pbmNvbXBsZXRlJzpcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfQXNzaXN0YW50U3RyZWFtX2hhbmRsZU1lc3NhZ2UpLmNhbGwodGhpcywgZXZlbnQpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2Vycm9yJzpcbiAgICAgICAgICAgIC8vVGhpcyBpcyBpbmNsdWRlZCBmb3IgY29tcGxldGVuZXNzLCBidXQgZXJyb3JzIGFyZSBwcm9jZXNzZWQgaW4gdGhlIFNTRSBldmVudCBwcm9jZXNzaW5nIHNvIHRoaXMgc2hvdWxkIG5vdCBvY2N1clxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFbmNvdW50ZXJlZCBhbiBlcnJvciBldmVudCBpbiBldmVudCBwcm9jZXNzaW5nIC0gZXJyb3JzIHNob3VsZCBiZSBwcm9jZXNzZWQgZWFybGllcicpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgYXNzZXJ0TmV2ZXIoZXZlbnQpO1xuICAgIH1cbn0sIF9Bc3Npc3RhbnRTdHJlYW1fZW5kUmVxdWVzdCA9IGZ1bmN0aW9uIF9Bc3Npc3RhbnRTdHJlYW1fZW5kUmVxdWVzdCgpIHtcbiAgICBpZiAodGhpcy5lbmRlZCkge1xuICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYHN0cmVhbSBoYXMgZW5kZWQsIHRoaXMgc2hvdWxkbid0IGhhcHBlbmApO1xuICAgIH1cbiAgICBpZiAoIV9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9maW5hbFJ1biwgXCJmXCIpKVxuICAgICAgICB0aHJvdyBFcnJvcignRmluYWwgcnVuIGhhcyBub3QgYmVlbiByZWNlaXZlZCcpO1xuICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fZmluYWxSdW4sIFwiZlwiKTtcbn0sIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlTWVzc2FnZSA9IGZ1bmN0aW9uIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlTWVzc2FnZShldmVudCkge1xuICAgIGNvbnN0IFthY2N1bXVsYXRlZE1lc3NhZ2UsIG5ld0NvbnRlbnRdID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9Bc3Npc3RhbnRTdHJlYW1fYWNjdW11bGF0ZU1lc3NhZ2UpLmNhbGwodGhpcywgZXZlbnQsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9tZXNzYWdlU25hcHNob3QsIFwiZlwiKSk7XG4gICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX21lc3NhZ2VTbmFwc2hvdCwgYWNjdW11bGF0ZWRNZXNzYWdlLCBcImZcIik7XG4gICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX21lc3NhZ2VTbmFwc2hvdHMsIFwiZlwiKVthY2N1bXVsYXRlZE1lc3NhZ2UuaWRdID0gYWNjdW11bGF0ZWRNZXNzYWdlO1xuICAgIGZvciAoY29uc3QgY29udGVudCBvZiBuZXdDb250ZW50KSB7XG4gICAgICAgIGNvbnN0IHNuYXBzaG90Q29udGVudCA9IGFjY3VtdWxhdGVkTWVzc2FnZS5jb250ZW50W2NvbnRlbnQuaW5kZXhdO1xuICAgICAgICBpZiAoc25hcHNob3RDb250ZW50Py50eXBlID09ICd0ZXh0Jykge1xuICAgICAgICAgICAgdGhpcy5fZW1pdCgndGV4dENyZWF0ZWQnLCBzbmFwc2hvdENvbnRlbnQudGV4dCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc3dpdGNoIChldmVudC5ldmVudCkge1xuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5jcmVhdGVkJzpcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ21lc3NhZ2VDcmVhdGVkJywgZXZlbnQuZGF0YSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAndGhyZWFkLm1lc3NhZ2UuaW5fcHJvZ3Jlc3MnOlxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5tZXNzYWdlLmRlbHRhJzpcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ21lc3NhZ2VEZWx0YScsIGV2ZW50LmRhdGEuZGVsdGEsIGFjY3VtdWxhdGVkTWVzc2FnZSk7XG4gICAgICAgICAgICBpZiAoZXZlbnQuZGF0YS5kZWx0YS5jb250ZW50KSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBjb250ZW50IG9mIGV2ZW50LmRhdGEuZGVsdGEuY29udGVudCkge1xuICAgICAgICAgICAgICAgICAgICAvL0lmIGl0IGlzIHRleHQgZGVsdGEsIGVtaXQgYSB0ZXh0IGRlbHRhIGV2ZW50XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50LnR5cGUgPT0gJ3RleHQnICYmIGNvbnRlbnQudGV4dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRleHREZWx0YSA9IGNvbnRlbnQudGV4dDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzbmFwc2hvdCA9IGFjY3VtdWxhdGVkTWVzc2FnZS5jb250ZW50W2NvbnRlbnQuaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNuYXBzaG90ICYmIHNuYXBzaG90LnR5cGUgPT0gJ3RleHQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgndGV4dERlbHRhJywgdGV4dERlbHRhLCBzbmFwc2hvdC50ZXh0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdUaGUgc25hcHNob3QgYXNzb2NpYXRlZCB3aXRoIHRoaXMgdGV4dCBkZWx0YSBpcyBub3QgdGV4dCBvciBtaXNzaW5nJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnQuaW5kZXggIT0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50SW5kZXgsIFwiZlwiKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9TZWUgaWYgd2UgaGF2ZSBpbiBwcm9ncmVzcyBjb250ZW50XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50LCBcImZcIikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50Q29udGVudCwgXCJmXCIpLnR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAndGV4dCc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCd0ZXh0RG9uZScsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50Q29udGVudCwgXCJmXCIpLnRleHQsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9tZXNzYWdlU25hcHNob3QsIFwiZlwiKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnaW1hZ2VfZmlsZSc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCdpbWFnZUZpbGVEb25lJywgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50LCBcImZcIikuaW1hZ2VfZmlsZSwgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX21lc3NhZ2VTbmFwc2hvdCwgXCJmXCIpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50Q29udGVudEluZGV4LCBjb250ZW50LmluZGV4LCBcImZcIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRDb250ZW50LCBhY2N1bXVsYXRlZE1lc3NhZ2UuY29udGVudFtjb250ZW50LmluZGV4XSwgXCJmXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5jb21wbGV0ZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5pbmNvbXBsZXRlJzpcbiAgICAgICAgICAgIC8vV2UgZW1pdCB0aGUgbGF0ZXN0IGNvbnRlbnQgd2Ugd2VyZSB3b3JraW5nIG9uIG9uIGNvbXBsZXRpb24gKGluY2x1ZGluZyBpbmNvbXBsZXRlKVxuICAgICAgICAgICAgaWYgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50Q29udGVudEluZGV4LCBcImZcIikgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRDb250ZW50ID0gZXZlbnQuZGF0YS5jb250ZW50W19fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50Q29udGVudEluZGV4LCBcImZcIildO1xuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50Q29udGVudCkge1xuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKGN1cnJlbnRDb250ZW50LnR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ2ltYWdlX2ZpbGUnOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2ltYWdlRmlsZURvbmUnLCBjdXJyZW50Q29udGVudC5pbWFnZV9maWxlLCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90LCBcImZcIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAndGV4dCc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgndGV4dERvbmUnLCBjdXJyZW50Q29udGVudC50ZXh0LCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90LCBcImZcIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9tZXNzYWdlU25hcHNob3QsIFwiZlwiKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ21lc3NhZ2VEb25lJywgZXZlbnQuZGF0YSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fbWVzc2FnZVNuYXBzaG90LCB1bmRlZmluZWQsIFwiZlwiKTtcbiAgICB9XG59LCBfQXNzaXN0YW50U3RyZWFtX2hhbmRsZVJ1blN0ZXAgPSBmdW5jdGlvbiBfQXNzaXN0YW50U3RyZWFtX2hhbmRsZVJ1blN0ZXAoZXZlbnQpIHtcbiAgICBjb25zdCBhY2N1bXVsYXRlZFJ1blN0ZXAgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0Fzc2lzdGFudFN0cmVhbV9hY2N1bXVsYXRlUnVuU3RlcCkuY2FsbCh0aGlzLCBldmVudCk7XG4gICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRSdW5TdGVwU25hcHNob3QsIGFjY3VtdWxhdGVkUnVuU3RlcCwgXCJmXCIpO1xuICAgIHN3aXRjaCAoZXZlbnQuZXZlbnQpIHtcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmNyZWF0ZWQnOlxuICAgICAgICAgICAgdGhpcy5fZW1pdCgncnVuU3RlcENyZWF0ZWQnLCBldmVudC5kYXRhKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnN0ZXAuZGVsdGEnOlxuICAgICAgICAgICAgY29uc3QgZGVsdGEgPSBldmVudC5kYXRhLmRlbHRhO1xuICAgICAgICAgICAgaWYgKGRlbHRhLnN0ZXBfZGV0YWlscyAmJlxuICAgICAgICAgICAgICAgIGRlbHRhLnN0ZXBfZGV0YWlscy50eXBlID09ICd0b29sX2NhbGxzJyAmJlxuICAgICAgICAgICAgICAgIGRlbHRhLnN0ZXBfZGV0YWlscy50b29sX2NhbGxzICYmXG4gICAgICAgICAgICAgICAgYWNjdW11bGF0ZWRSdW5TdGVwLnN0ZXBfZGV0YWlscy50eXBlID09ICd0b29sX2NhbGxzJykge1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgdG9vbENhbGwgb2YgZGVsdGEuc3RlcF9kZXRhaWxzLnRvb2xfY2FsbHMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRvb2xDYWxsLmluZGV4ID09IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGxJbmRleCwgXCJmXCIpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCd0b29sQ2FsbERlbHRhJywgdG9vbENhbGwsIGFjY3VtdWxhdGVkUnVuU3RlcC5zdGVwX2RldGFpbHMudG9vbF9jYWxsc1t0b29sQ2FsbC5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGwsIFwiZlwiKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ3Rvb2xDYWxsRG9uZScsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGwsIFwiZlwiKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsSW5kZXgsIHRvb2xDYWxsLmluZGV4LCBcImZcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsLCBhY2N1bXVsYXRlZFJ1blN0ZXAuc3RlcF9kZXRhaWxzLnRvb2xfY2FsbHNbdG9vbENhbGwuaW5kZXhdLCBcImZcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2N1cnJlbnRUb29sQ2FsbCwgXCJmXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ3Rvb2xDYWxsQ3JlYXRlZCcsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGwsIFwiZlwiKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdydW5TdGVwRGVsdGEnLCBldmVudC5kYXRhLmRlbHRhLCBhY2N1bXVsYXRlZFJ1blN0ZXApO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5jb21wbGV0ZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnN0ZXAuZmFpbGVkJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmNhbmNlbGxlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5leHBpcmVkJzpcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50UnVuU3RlcFNuYXBzaG90LCB1bmRlZmluZWQsIFwiZlwiKTtcbiAgICAgICAgICAgIGNvbnN0IGRldGFpbHMgPSBldmVudC5kYXRhLnN0ZXBfZGV0YWlscztcbiAgICAgICAgICAgIGlmIChkZXRhaWxzLnR5cGUgPT0gJ3Rvb2xfY2FsbHMnKSB7XG4gICAgICAgICAgICAgICAgaWYgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGwsIFwiZlwiKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCd0b29sQ2FsbERvbmUnLCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsLCBcImZcIikpO1xuICAgICAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsLCB1bmRlZmluZWQsIFwiZlwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdydW5TdGVwRG9uZScsIGV2ZW50LmRhdGEsIGFjY3VtdWxhdGVkUnVuU3RlcCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmluX3Byb2dyZXNzJzpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbn0sIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlRXZlbnQgPSBmdW5jdGlvbiBfQXNzaXN0YW50U3RyZWFtX2hhbmRsZUV2ZW50KGV2ZW50KSB7XG4gICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX2V2ZW50cywgXCJmXCIpLnB1c2goZXZlbnQpO1xuICAgIHRoaXMuX2VtaXQoJ2V2ZW50JywgZXZlbnQpO1xufSwgX0Fzc2lzdGFudFN0cmVhbV9hY2N1bXVsYXRlUnVuU3RlcCA9IGZ1bmN0aW9uIF9Bc3Npc3RhbnRTdHJlYW1fYWNjdW11bGF0ZVJ1blN0ZXAoZXZlbnQpIHtcbiAgICBzd2l0Y2ggKGV2ZW50LmV2ZW50KSB7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5jcmVhdGVkJzpcbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9ydW5TdGVwU25hcHNob3RzLCBcImZcIilbZXZlbnQuZGF0YS5pZF0gPSBldmVudC5kYXRhO1xuICAgICAgICAgICAgcmV0dXJuIGV2ZW50LmRhdGE7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5kZWx0YSc6XG4gICAgICAgICAgICBsZXQgc25hcHNob3QgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fcnVuU3RlcFNuYXBzaG90cywgXCJmXCIpW2V2ZW50LmRhdGEuaWRdO1xuICAgICAgICAgICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdSZWNlaXZlZCBhIFJ1blN0ZXBEZWx0YSBiZWZvcmUgY3JlYXRpb24gb2YgYSBzbmFwc2hvdCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGRhdGEgPSBldmVudC5kYXRhO1xuICAgICAgICAgICAgaWYgKGRhdGEuZGVsdGEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhY2N1bXVsYXRlZCA9IEFzc2lzdGFudFN0cmVhbS5hY2N1bXVsYXRlRGVsdGEoc25hcHNob3QsIGRhdGEuZGVsdGEpO1xuICAgICAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9ydW5TdGVwU25hcHNob3RzLCBcImZcIilbZXZlbnQuZGF0YS5pZF0gPSBhY2N1bXVsYXRlZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fcnVuU3RlcFNuYXBzaG90cywgXCJmXCIpW2V2ZW50LmRhdGEuaWRdO1xuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnN0ZXAuY29tcGxldGVkJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5zdGVwLmZhaWxlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5jYW5jZWxsZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnN0ZXAuZXhwaXJlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uc3RlcC5pbl9wcm9ncmVzcyc6XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fcnVuU3RlcFNuYXBzaG90cywgXCJmXCIpW2V2ZW50LmRhdGEuaWRdID0gZXZlbnQuZGF0YTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBpZiAoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQXNzaXN0YW50U3RyZWFtX3J1blN0ZXBTbmFwc2hvdHMsIFwiZlwiKVtldmVudC5kYXRhLmlkXSlcbiAgICAgICAgcmV0dXJuIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9ydW5TdGVwU25hcHNob3RzLCBcImZcIilbZXZlbnQuZGF0YS5pZF07XG4gICAgdGhyb3cgbmV3IEVycm9yKCdObyBzbmFwc2hvdCBhdmFpbGFibGUnKTtcbn0sIF9Bc3Npc3RhbnRTdHJlYW1fYWNjdW11bGF0ZU1lc3NhZ2UgPSBmdW5jdGlvbiBfQXNzaXN0YW50U3RyZWFtX2FjY3VtdWxhdGVNZXNzYWdlKGV2ZW50LCBzbmFwc2hvdCkge1xuICAgIGxldCBuZXdDb250ZW50ID0gW107XG4gICAgc3dpdGNoIChldmVudC5ldmVudCkge1xuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5jcmVhdGVkJzpcbiAgICAgICAgICAgIC8vT24gY3JlYXRpb24gdGhlIHNuYXBzaG90IGlzIGp1c3QgdGhlIGluaXRpYWwgbWVzc2FnZVxuICAgICAgICAgICAgcmV0dXJuIFtldmVudC5kYXRhLCBuZXdDb250ZW50XTtcbiAgICAgICAgY2FzZSAndGhyZWFkLm1lc3NhZ2UuZGVsdGEnOlxuICAgICAgICAgICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgICAgICAgICAgIHRocm93IEVycm9yKCdSZWNlaXZlZCBhIGRlbHRhIHdpdGggbm8gZXhpc3Rpbmcgc25hcHNob3QgKHRoZXJlIHNob3VsZCBiZSBvbmUgZnJvbSBtZXNzYWdlIGNyZWF0aW9uKScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGRhdGEgPSBldmVudC5kYXRhO1xuICAgICAgICAgICAgLy9JZiB0aGlzIGRlbHRhIGRvZXMgbm90IGhhdmUgY29udGVudCwgbm90aGluZyB0byBwcm9jZXNzXG4gICAgICAgICAgICBpZiAoZGF0YS5kZWx0YS5jb250ZW50KSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBjb250ZW50RWxlbWVudCBvZiBkYXRhLmRlbHRhLmNvbnRlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRFbGVtZW50LmluZGV4IGluIHNuYXBzaG90LmNvbnRlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjdXJyZW50Q29udGVudCA9IHNuYXBzaG90LmNvbnRlbnRbY29udGVudEVsZW1lbnQuaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAgICAgc25hcHNob3QuY29udGVudFtjb250ZW50RWxlbWVudC5pbmRleF0gPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0Fzc2lzdGFudFN0cmVhbV9hY2N1bXVsYXRlQ29udGVudCkuY2FsbCh0aGlzLCBjb250ZW50RWxlbWVudCwgY3VycmVudENvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc25hcHNob3QuY29udGVudFtjb250ZW50RWxlbWVudC5pbmRleF0gPSBjb250ZW50RWxlbWVudDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBuZXcgZWxlbWVudFxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3Q29udGVudC5wdXNoKGNvbnRlbnRFbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBbc25hcHNob3QsIG5ld0NvbnRlbnRdO1xuICAgICAgICBjYXNlICd0aHJlYWQubWVzc2FnZS5pbl9wcm9ncmVzcyc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5tZXNzYWdlLmNvbXBsZXRlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5tZXNzYWdlLmluY29tcGxldGUnOlxuICAgICAgICAgICAgLy9ObyBjaGFuZ2VzIG9uIG90aGVyIHRocmVhZCBldmVudHNcbiAgICAgICAgICAgIGlmIChzbmFwc2hvdCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBbc25hcHNob3QsIG5ld0NvbnRlbnRdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ1JlY2VpdmVkIHRocmVhZCBtZXNzYWdlIGV2ZW50IHdpdGggbm8gZXhpc3Rpbmcgc25hcHNob3QnKTtcbiAgICAgICAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgRXJyb3IoJ1RyaWVkIHRvIGFjY3VtdWxhdGUgYSBub24tbWVzc2FnZSBldmVudCcpO1xufSwgX0Fzc2lzdGFudFN0cmVhbV9hY2N1bXVsYXRlQ29udGVudCA9IGZ1bmN0aW9uIF9Bc3Npc3RhbnRTdHJlYW1fYWNjdW11bGF0ZUNvbnRlbnQoY29udGVudEVsZW1lbnQsIGN1cnJlbnRDb250ZW50KSB7XG4gICAgcmV0dXJuIEFzc2lzdGFudFN0cmVhbS5hY2N1bXVsYXRlRGVsdGEoY3VycmVudENvbnRlbnQsIGNvbnRlbnRFbGVtZW50KTtcbn0sIF9Bc3Npc3RhbnRTdHJlYW1faGFuZGxlUnVuID0gZnVuY3Rpb24gX0Fzc2lzdGFudFN0cmVhbV9oYW5kbGVSdW4oZXZlbnQpIHtcbiAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFJ1blNuYXBzaG90LCBldmVudC5kYXRhLCBcImZcIik7XG4gICAgc3dpdGNoIChldmVudC5ldmVudCkge1xuICAgICAgICBjYXNlICd0aHJlYWQucnVuLmNyZWF0ZWQnOlxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4ucXVldWVkJzpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aHJlYWQucnVuLmluX3Byb2dyZXNzJzpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aHJlYWQucnVuLnJlcXVpcmVzX2FjdGlvbic6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uY2FuY2VsbGVkJzpcbiAgICAgICAgY2FzZSAndGhyZWFkLnJ1bi5mYWlsZWQnOlxuICAgICAgICBjYXNlICd0aHJlYWQucnVuLmNvbXBsZXRlZCc6XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uZXhwaXJlZCc6XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fZmluYWxSdW4sIGV2ZW50LmRhdGEsIFwiZlwiKTtcbiAgICAgICAgICAgIGlmIChfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsLCBcImZcIikpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCd0b29sQ2FsbERvbmUnLCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9Bc3Npc3RhbnRTdHJlYW1fY3VycmVudFRvb2xDYWxsLCBcImZcIikpO1xuICAgICAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRTZXQodGhpcywgX0Fzc2lzdGFudFN0cmVhbV9jdXJyZW50VG9vbENhbGwsIHVuZGVmaW5lZCwgXCJmXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3RocmVhZC5ydW4uY2FuY2VsbGluZyc6XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG59O1xuZnVuY3Rpb24gYXNzZXJ0TmV2ZXIoX3gpIHsgfVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QXNzaXN0YW50U3RyZWFtLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBDdXJzb3JQYWdlIH0gZnJvbSBcIi4uLy4uL3BhZ2luYXRpb24ubWpzXCI7XG5pbXBvcnQgeyBBc3Npc3RhbnRTdHJlYW0gfSBmcm9tIFwiLi4vLi4vbGliL0Fzc2lzdGFudFN0cmVhbS5tanNcIjtcbmV4cG9ydCBjbGFzcyBBc3Npc3RhbnRzIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZSBhbiBhc3Npc3RhbnQgd2l0aCBhIG1vZGVsIGFuZCBpbnN0cnVjdGlvbnMuXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgYXNzaXN0YW50ID0gYXdhaXQgY2xpZW50LmJldGEuYXNzaXN0YW50cy5jcmVhdGUoe1xuICAgICAqICAgbW9kZWw6ICdncHQtNG8nLFxuICAgICAqIH0pO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2Fzc2lzdGFudHMnLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZXMgYW4gYXNzaXN0YW50LlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IGFzc2lzdGFudCA9IGF3YWl0IGNsaWVudC5iZXRhLmFzc2lzdGFudHMucmV0cmlldmUoXG4gICAgICogICAnYXNzaXN0YW50X2lkJyxcbiAgICAgKiApO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIHJldHJpZXZlKGFzc2lzdGFudElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0KGAvYXNzaXN0YW50cy8ke2Fzc2lzdGFudElkfWAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogTW9kaWZpZXMgYW4gYXNzaXN0YW50LlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IGFzc2lzdGFudCA9IGF3YWl0IGNsaWVudC5iZXRhLmFzc2lzdGFudHMudXBkYXRlKFxuICAgICAqICAgJ2Fzc2lzdGFudF9pZCcsXG4gICAgICogKTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICB1cGRhdGUoYXNzaXN0YW50SWQsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KGAvYXNzaXN0YW50cy8ke2Fzc2lzdGFudElkfWAsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGxpc3QocXVlcnkgPSB7fSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0T3B0aW9ucyhxdWVyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxpc3Qoe30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoJy9hc3Npc3RhbnRzJywgQXNzaXN0YW50c1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYW4gYXNzaXN0YW50LlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IGFzc2lzdGFudERlbGV0ZWQgPSBhd2FpdCBjbGllbnQuYmV0YS5hc3Npc3RhbnRzLmRlbChcbiAgICAgKiAgICdhc3Npc3RhbnRfaWQnLFxuICAgICAqICk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgZGVsKGFzc2lzdGFudElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZGVsZXRlKGAvYXNzaXN0YW50cy8ke2Fzc2lzdGFudElkfWAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQXNzaXN0YW50c1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbkFzc2lzdGFudHMuQXNzaXN0YW50c1BhZ2UgPSBBc3Npc3RhbnRzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFzc2lzdGFudHMubWpzLm1hcCIsImV4cG9ydCBmdW5jdGlvbiBpc1J1bm5hYmxlRnVuY3Rpb25XaXRoUGFyc2UoZm4pIHtcbiAgICByZXR1cm4gdHlwZW9mIGZuLnBhcnNlID09PSAnZnVuY3Rpb24nO1xufVxuLyoqXG4gKiBUaGlzIGlzIGhlbHBlciBjbGFzcyBmb3IgcGFzc2luZyBhIGBmdW5jdGlvbmAgYW5kIGBwYXJzZWAgd2hlcmUgdGhlIGBmdW5jdGlvbmBcbiAqIGFyZ3VtZW50IHR5cGUgbWF0Y2hlcyB0aGUgYHBhcnNlYCByZXR1cm4gdHlwZS5cbiAqXG4gKiBAZGVwcmVjYXRlZCAtIHBsZWFzZSB1c2UgUGFyc2luZ1Rvb2xGdW5jdGlvbiBpbnN0ZWFkLlxuICovXG5leHBvcnQgY2xhc3MgUGFyc2luZ0Z1bmN0aW9uIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dCkge1xuICAgICAgICB0aGlzLmZ1bmN0aW9uID0gaW5wdXQuZnVuY3Rpb247XG4gICAgICAgIHRoaXMucGFyc2UgPSBpbnB1dC5wYXJzZTtcbiAgICAgICAgdGhpcy5wYXJhbWV0ZXJzID0gaW5wdXQucGFyYW1ldGVycztcbiAgICAgICAgdGhpcy5kZXNjcmlwdGlvbiA9IGlucHV0LmRlc2NyaXB0aW9uO1xuICAgICAgICB0aGlzLm5hbWUgPSBpbnB1dC5uYW1lO1xuICAgIH1cbn1cbi8qKlxuICogVGhpcyBpcyBoZWxwZXIgY2xhc3MgZm9yIHBhc3NpbmcgYSBgZnVuY3Rpb25gIGFuZCBgcGFyc2VgIHdoZXJlIHRoZSBgZnVuY3Rpb25gXG4gKiBhcmd1bWVudCB0eXBlIG1hdGNoZXMgdGhlIGBwYXJzZWAgcmV0dXJuIHR5cGUuXG4gKi9cbmV4cG9ydCBjbGFzcyBQYXJzaW5nVG9vbEZ1bmN0aW9uIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dCkge1xuICAgICAgICB0aGlzLnR5cGUgPSAnZnVuY3Rpb24nO1xuICAgICAgICB0aGlzLmZ1bmN0aW9uID0gaW5wdXQ7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UnVubmFibGVGdW5jdGlvbi5tanMubWFwIiwiZXhwb3J0IGNvbnN0IGlzQXNzaXN0YW50TWVzc2FnZSA9IChtZXNzYWdlKSA9PiB7XG4gICAgcmV0dXJuIG1lc3NhZ2U/LnJvbGUgPT09ICdhc3Npc3RhbnQnO1xufTtcbmV4cG9ydCBjb25zdCBpc0Z1bmN0aW9uTWVzc2FnZSA9IChtZXNzYWdlKSA9PiB7XG4gICAgcmV0dXJuIG1lc3NhZ2U/LnJvbGUgPT09ICdmdW5jdGlvbic7XG59O1xuZXhwb3J0IGNvbnN0IGlzVG9vbE1lc3NhZ2UgPSAobWVzc2FnZSkgPT4ge1xuICAgIHJldHVybiBtZXNzYWdlPy5yb2xlID09PSAndG9vbCc7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGlzUHJlc2VudChvYmopIHtcbiAgICByZXR1cm4gb2JqICE9IG51bGw7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jaGF0Q29tcGxldGlvblV0aWxzLm1qcy5tYXAiLCJpbXBvcnQgeyBDb250ZW50RmlsdGVyRmluaXNoUmVhc29uRXJyb3IsIExlbmd0aEZpbmlzaFJlYXNvbkVycm9yLCBPcGVuQUlFcnJvciB9IGZyb20gXCIuLi9lcnJvci5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBtYWtlUGFyc2VhYmxlUmVzcG9uc2VGb3JtYXQocmVzcG9uc2VfZm9ybWF0LCBwYXJzZXIpIHtcbiAgICBjb25zdCBvYmogPSB7IC4uLnJlc3BvbnNlX2Zvcm1hdCB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iaiwge1xuICAgICAgICAkYnJhbmQ6IHtcbiAgICAgICAgICAgIHZhbHVlOiAnYXV0by1wYXJzZWFibGUtcmVzcG9uc2UtZm9ybWF0JyxcbiAgICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICAkcGFyc2VSYXc6IHtcbiAgICAgICAgICAgIHZhbHVlOiBwYXJzZXIsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICB9KTtcbiAgICByZXR1cm4gb2JqO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1ha2VQYXJzZWFibGVUZXh0Rm9ybWF0KHJlc3BvbnNlX2Zvcm1hdCwgcGFyc2VyKSB7XG4gICAgY29uc3Qgb2JqID0geyAuLi5yZXNwb25zZV9mb3JtYXQgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhvYmosIHtcbiAgICAgICAgJGJyYW5kOiB7XG4gICAgICAgICAgICB2YWx1ZTogJ2F1dG8tcGFyc2VhYmxlLXJlc3BvbnNlLWZvcm1hdCcsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgJHBhcnNlUmF3OiB7XG4gICAgICAgICAgICB2YWx1ZTogcGFyc2VyLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIG9iajtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0F1dG9QYXJzYWJsZVJlc3BvbnNlRm9ybWF0KHJlc3BvbnNlX2Zvcm1hdCkge1xuICAgIHJldHVybiByZXNwb25zZV9mb3JtYXQ/LlsnJGJyYW5kJ10gPT09ICdhdXRvLXBhcnNlYWJsZS1yZXNwb25zZS1mb3JtYXQnO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1ha2VQYXJzZWFibGVUb29sKHRvb2wsIHsgcGFyc2VyLCBjYWxsYmFjaywgfSkge1xuICAgIGNvbnN0IG9iaiA9IHsgLi4udG9vbCB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iaiwge1xuICAgICAgICAkYnJhbmQ6IHtcbiAgICAgICAgICAgIHZhbHVlOiAnYXV0by1wYXJzZWFibGUtdG9vbCcsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgJHBhcnNlUmF3OiB7XG4gICAgICAgICAgICB2YWx1ZTogcGFyc2VyLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgICRjYWxsYmFjazoge1xuICAgICAgICAgICAgdmFsdWU6IGNhbGxiYWNrLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIG9iajtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0F1dG9QYXJzYWJsZVRvb2wodG9vbCkge1xuICAgIHJldHVybiB0b29sPy5bJyRicmFuZCddID09PSAnYXV0by1wYXJzZWFibGUtdG9vbCc7XG59XG5leHBvcnQgZnVuY3Rpb24gbWF5YmVQYXJzZUNoYXRDb21wbGV0aW9uKGNvbXBsZXRpb24sIHBhcmFtcykge1xuICAgIGlmICghcGFyYW1zIHx8ICFoYXNBdXRvUGFyc2VhYmxlSW5wdXQocGFyYW1zKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uY29tcGxldGlvbixcbiAgICAgICAgICAgIGNob2ljZXM6IGNvbXBsZXRpb24uY2hvaWNlcy5tYXAoKGNob2ljZSkgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5jaG9pY2UsXG4gICAgICAgICAgICAgICAgbWVzc2FnZToge1xuICAgICAgICAgICAgICAgICAgICAuLi5jaG9pY2UubWVzc2FnZSxcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAuLi4oY2hvaWNlLm1lc3NhZ2UudG9vbF9jYWxscyA/XG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9vbF9jYWxsczogY2hvaWNlLm1lc3NhZ2UudG9vbF9jYWxscyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gcGFyc2VDaGF0Q29tcGxldGlvbihjb21wbGV0aW9uLCBwYXJhbXMpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQ2hhdENvbXBsZXRpb24oY29tcGxldGlvbiwgcGFyYW1zKSB7XG4gICAgY29uc3QgY2hvaWNlcyA9IGNvbXBsZXRpb24uY2hvaWNlcy5tYXAoKGNob2ljZSkgPT4ge1xuICAgICAgICBpZiAoY2hvaWNlLmZpbmlzaF9yZWFzb24gPT09ICdsZW5ndGgnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTGVuZ3RoRmluaXNoUmVhc29uRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hvaWNlLmZpbmlzaF9yZWFzb24gPT09ICdjb250ZW50X2ZpbHRlcicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBDb250ZW50RmlsdGVyRmluaXNoUmVhc29uRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uY2hvaWNlLFxuICAgICAgICAgICAgbWVzc2FnZToge1xuICAgICAgICAgICAgICAgIC4uLmNob2ljZS5tZXNzYWdlLFxuICAgICAgICAgICAgICAgIC4uLihjaG9pY2UubWVzc2FnZS50b29sX2NhbGxzID9cbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9vbF9jYWxsczogY2hvaWNlLm1lc3NhZ2UudG9vbF9jYWxscz8ubWFwKCh0b29sQ2FsbCkgPT4gcGFyc2VUb29sQ2FsbChwYXJhbXMsIHRvb2xDYWxsKSkgPz8gdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkKSxcbiAgICAgICAgICAgICAgICBwYXJzZWQ6IGNob2ljZS5tZXNzYWdlLmNvbnRlbnQgJiYgIWNob2ljZS5tZXNzYWdlLnJlZnVzYWwgP1xuICAgICAgICAgICAgICAgICAgICBwYXJzZVJlc3BvbnNlRm9ybWF0KHBhcmFtcywgY2hvaWNlLm1lc3NhZ2UuY29udGVudClcbiAgICAgICAgICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICB9KTtcbiAgICByZXR1cm4geyAuLi5jb21wbGV0aW9uLCBjaG9pY2VzIH07XG59XG5mdW5jdGlvbiBwYXJzZVJlc3BvbnNlRm9ybWF0KHBhcmFtcywgY29udGVudCkge1xuICAgIGlmIChwYXJhbXMucmVzcG9uc2VfZm9ybWF0Py50eXBlICE9PSAnanNvbl9zY2hlbWEnKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAocGFyYW1zLnJlc3BvbnNlX2Zvcm1hdD8udHlwZSA9PT0gJ2pzb25fc2NoZW1hJykge1xuICAgICAgICBpZiAoJyRwYXJzZVJhdycgaW4gcGFyYW1zLnJlc3BvbnNlX2Zvcm1hdCkge1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VfZm9ybWF0ID0gcGFyYW1zLnJlc3BvbnNlX2Zvcm1hdDtcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZV9mb3JtYXQuJHBhcnNlUmF3KGNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKGNvbnRlbnQpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIHBhcnNlVG9vbENhbGwocGFyYW1zLCB0b29sQ2FsbCkge1xuICAgIGNvbnN0IGlucHV0VG9vbCA9IHBhcmFtcy50b29scz8uZmluZCgoaW5wdXRUb29sKSA9PiBpbnB1dFRvb2wuZnVuY3Rpb24/Lm5hbWUgPT09IHRvb2xDYWxsLmZ1bmN0aW9uLm5hbWUpO1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLnRvb2xDYWxsLFxuICAgICAgICBmdW5jdGlvbjoge1xuICAgICAgICAgICAgLi4udG9vbENhbGwuZnVuY3Rpb24sXG4gICAgICAgICAgICBwYXJzZWRfYXJndW1lbnRzOiBpc0F1dG9QYXJzYWJsZVRvb2woaW5wdXRUb29sKSA/IGlucHV0VG9vbC4kcGFyc2VSYXcodG9vbENhbGwuZnVuY3Rpb24uYXJndW1lbnRzKVxuICAgICAgICAgICAgICAgIDogaW5wdXRUb29sPy5mdW5jdGlvbi5zdHJpY3QgPyBKU09OLnBhcnNlKHRvb2xDYWxsLmZ1bmN0aW9uLmFyZ3VtZW50cylcbiAgICAgICAgICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICB9LFxuICAgIH07XG59XG5leHBvcnQgZnVuY3Rpb24gc2hvdWxkUGFyc2VUb29sQ2FsbChwYXJhbXMsIHRvb2xDYWxsKSB7XG4gICAgaWYgKCFwYXJhbXMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBpbnB1dFRvb2wgPSBwYXJhbXMudG9vbHM/LmZpbmQoKGlucHV0VG9vbCkgPT4gaW5wdXRUb29sLmZ1bmN0aW9uPy5uYW1lID09PSB0b29sQ2FsbC5mdW5jdGlvbi5uYW1lKTtcbiAgICByZXR1cm4gaXNBdXRvUGFyc2FibGVUb29sKGlucHV0VG9vbCkgfHwgaW5wdXRUb29sPy5mdW5jdGlvbi5zdHJpY3QgfHwgZmFsc2U7XG59XG5leHBvcnQgZnVuY3Rpb24gaGFzQXV0b1BhcnNlYWJsZUlucHV0KHBhcmFtcykge1xuICAgIGlmIChpc0F1dG9QYXJzYWJsZVJlc3BvbnNlRm9ybWF0KHBhcmFtcy5yZXNwb25zZV9mb3JtYXQpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gKHBhcmFtcy50b29scz8uc29tZSgodCkgPT4gaXNBdXRvUGFyc2FibGVUb29sKHQpIHx8ICh0LnR5cGUgPT09ICdmdW5jdGlvbicgJiYgdC5mdW5jdGlvbi5zdHJpY3QgPT09IHRydWUpKSA/PyBmYWxzZSk7XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVJbnB1dFRvb2xzKHRvb2xzKSB7XG4gICAgZm9yIChjb25zdCB0b29sIG9mIHRvb2xzID8/IFtdKSB7XG4gICAgICAgIGlmICh0b29sLnR5cGUgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgQ3VycmVudGx5IG9ubHkgXFxgZnVuY3Rpb25cXGAgdG9vbCB0eXBlcyBzdXBwb3J0IGF1dG8tcGFyc2luZzsgUmVjZWl2ZWQgXFxgJHt0b29sLnR5cGV9XFxgYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRvb2wuZnVuY3Rpb24uc3RyaWN0ICE9PSB0cnVlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYFRoZSBcXGAke3Rvb2wuZnVuY3Rpb24ubmFtZX1cXGAgdG9vbCBpcyBub3QgbWFya2VkIHdpdGggXFxgc3RyaWN0OiB0cnVlXFxgLiBPbmx5IHN0cmljdCBmdW5jdGlvbiB0b29scyBjYW4gYmUgYXV0by1wYXJzZWRgKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhcnNlci5tanMubWFwIiwidmFyIF9fY2xhc3NQcml2YXRlRmllbGRHZXQgPSAodGhpcyAmJiB0aGlzLl9fY2xhc3NQcml2YXRlRmllbGRHZXQpIHx8IGZ1bmN0aW9uIChyZWNlaXZlciwgc3RhdGUsIGtpbmQsIGYpIHtcbiAgICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBnZXR0ZXJcIik7XG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgcmVhZCBwcml2YXRlIG1lbWJlciBmcm9tIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gICAgcmV0dXJuIGtpbmQgPT09IFwibVwiID8gZiA6IGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyKSA6IGYgPyBmLnZhbHVlIDogc3RhdGUuZ2V0KHJlY2VpdmVyKTtcbn07XG52YXIgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfaW5zdGFuY2VzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbENvbnRlbnQsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsTWVzc2FnZSwgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxGdW5jdGlvbkNhbGwsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsRnVuY3Rpb25DYWxsUmVzdWx0LCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9jYWxjdWxhdGVUb3RhbFVzYWdlLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl92YWxpZGF0ZVBhcmFtcywgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfc3RyaW5naWZ5RnVuY3Rpb25DYWxsUmVzdWx0O1xuaW1wb3J0IHsgT3BlbkFJRXJyb3IgfSBmcm9tIFwiLi4vZXJyb3IubWpzXCI7XG5pbXBvcnQgeyBpc1J1bm5hYmxlRnVuY3Rpb25XaXRoUGFyc2UsIH0gZnJvbSBcIi4vUnVubmFibGVGdW5jdGlvbi5tanNcIjtcbmltcG9ydCB7IGlzQXNzaXN0YW50TWVzc2FnZSwgaXNGdW5jdGlvbk1lc3NhZ2UsIGlzVG9vbE1lc3NhZ2UgfSBmcm9tIFwiLi9jaGF0Q29tcGxldGlvblV0aWxzLm1qc1wiO1xuaW1wb3J0IHsgRXZlbnRTdHJlYW0gfSBmcm9tIFwiLi9FdmVudFN0cmVhbS5tanNcIjtcbmltcG9ydCB7IGlzQXV0b1BhcnNhYmxlVG9vbCwgcGFyc2VDaGF0Q29tcGxldGlvbiB9IGZyb20gXCIuLi9saWIvcGFyc2VyLm1qc1wiO1xuY29uc3QgREVGQVVMVF9NQVhfQ0hBVF9DT01QTEVUSU9OUyA9IDEwO1xuZXhwb3J0IGNsYXNzIEFic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXIgZXh0ZW5kcyBFdmVudFN0cmVhbSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2luc3RhbmNlcy5hZGQodGhpcyk7XG4gICAgICAgIHRoaXMuX2NoYXRDb21wbGV0aW9ucyA9IFtdO1xuICAgICAgICB0aGlzLm1lc3NhZ2VzID0gW107XG4gICAgfVxuICAgIF9hZGRDaGF0Q29tcGxldGlvbihjaGF0Q29tcGxldGlvbikge1xuICAgICAgICB0aGlzLl9jaGF0Q29tcGxldGlvbnMucHVzaChjaGF0Q29tcGxldGlvbik7XG4gICAgICAgIHRoaXMuX2VtaXQoJ2NoYXRDb21wbGV0aW9uJywgY2hhdENvbXBsZXRpb24pO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gY2hhdENvbXBsZXRpb24uY2hvaWNlc1swXT8ubWVzc2FnZTtcbiAgICAgICAgaWYgKG1lc3NhZ2UpXG4gICAgICAgICAgICB0aGlzLl9hZGRNZXNzYWdlKG1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4gY2hhdENvbXBsZXRpb247XG4gICAgfVxuICAgIF9hZGRNZXNzYWdlKG1lc3NhZ2UsIGVtaXQgPSB0cnVlKSB7XG4gICAgICAgIGlmICghKCdjb250ZW50JyBpbiBtZXNzYWdlKSlcbiAgICAgICAgICAgIG1lc3NhZ2UuY29udGVudCA9IG51bGw7XG4gICAgICAgIHRoaXMubWVzc2FnZXMucHVzaChtZXNzYWdlKTtcbiAgICAgICAgaWYgKGVtaXQpIHtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ21lc3NhZ2UnLCBtZXNzYWdlKTtcbiAgICAgICAgICAgIGlmICgoaXNGdW5jdGlvbk1lc3NhZ2UobWVzc2FnZSkgfHwgaXNUb29sTWVzc2FnZShtZXNzYWdlKSkgJiYgbWVzc2FnZS5jb250ZW50KSB7XG4gICAgICAgICAgICAgICAgLy8gTm90ZSwgdGhpcyBhc3N1bWVzIHRoYXQge3JvbGU6ICd0b29sJywgY29udGVudDog4oCmfSBpcyBhbHdheXMgdGhlIHJlc3VsdCBvZiBhIGNhbGwgb2YgdG9vbCBvZiB0eXBlPWZ1bmN0aW9uLlxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2Z1bmN0aW9uQ2FsbFJlc3VsdCcsIG1lc3NhZ2UuY29udGVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc0Fzc2lzdGFudE1lc3NhZ2UobWVzc2FnZSkgJiYgbWVzc2FnZS5mdW5jdGlvbl9jYWxsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgnZnVuY3Rpb25DYWxsJywgbWVzc2FnZS5mdW5jdGlvbl9jYWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzQXNzaXN0YW50TWVzc2FnZShtZXNzYWdlKSAmJiBtZXNzYWdlLnRvb2xfY2FsbHMpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHRvb2xfY2FsbCBvZiBtZXNzYWdlLnRvb2xfY2FsbHMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRvb2xfY2FsbC50eXBlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCdmdW5jdGlvbkNhbGwnLCB0b29sX2NhbGwuZnVuY3Rpb24pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGZpbmFsIENoYXRDb21wbGV0aW9uLCBvciByZWplY3RzXG4gICAgICogaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIENoYXRDb21wbGV0aW9uLlxuICAgICAqL1xuICAgIGFzeW5jIGZpbmFsQ2hhdENvbXBsZXRpb24oKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICBjb25zdCBjb21wbGV0aW9uID0gdGhpcy5fY2hhdENvbXBsZXRpb25zW3RoaXMuX2NoYXRDb21wbGV0aW9ucy5sZW5ndGggLSAxXTtcbiAgICAgICAgaWYgKCFjb21wbGV0aW9uKVxuICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKCdzdHJlYW0gZW5kZWQgd2l0aG91dCBwcm9kdWNpbmcgYSBDaGF0Q29tcGxldGlvbicpO1xuICAgICAgICByZXR1cm4gY29tcGxldGlvbjtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgY29udGVudCBvZiB0aGUgZmluYWwgQ2hhdENvbXBsZXRpb25NZXNzYWdlLCBvciByZWplY3RzXG4gICAgICogaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIENoYXRDb21wbGV0aW9uTWVzc2FnZS5cbiAgICAgKi9cbiAgICBhc3luYyBmaW5hbENvbnRlbnQoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9pbnN0YW5jZXMsIFwibVwiLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbENvbnRlbnQpLmNhbGwodGhpcyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHRoZSBmaW5hbCBhc3Npc3RhbnQgQ2hhdENvbXBsZXRpb25NZXNzYWdlIHJlc3BvbnNlLFxuICAgICAqIG9yIHJlamVjdHMgaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIENoYXRDb21wbGV0aW9uTWVzc2FnZS5cbiAgICAgKi9cbiAgICBhc3luYyBmaW5hbE1lc3NhZ2UoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9pbnN0YW5jZXMsIFwibVwiLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbE1lc3NhZ2UpLmNhbGwodGhpcyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGNvbnRlbnQgb2YgdGhlIGZpbmFsIEZ1bmN0aW9uQ2FsbCwgb3IgcmVqZWN0c1xuICAgICAqIGlmIGFuIGVycm9yIG9jY3VycmVkIG9yIHRoZSBzdHJlYW0gZW5kZWQgcHJlbWF0dXJlbHkgd2l0aG91dCBwcm9kdWNpbmcgYSBDaGF0Q29tcGxldGlvbk1lc3NhZ2UuXG4gICAgICovXG4gICAgYXN5bmMgZmluYWxGdW5jdGlvbkNhbGwoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9pbnN0YW5jZXMsIFwibVwiLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbEZ1bmN0aW9uQ2FsbCkuY2FsbCh0aGlzKTtcbiAgICB9XG4gICAgYXN5bmMgZmluYWxGdW5jdGlvbkNhbGxSZXN1bHQoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9pbnN0YW5jZXMsIFwibVwiLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbEZ1bmN0aW9uQ2FsbFJlc3VsdCkuY2FsbCh0aGlzKTtcbiAgICB9XG4gICAgYXN5bmMgdG90YWxVc2FnZSgpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5kb25lKCk7XG4gICAgICAgIHJldHVybiBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2luc3RhbmNlcywgXCJtXCIsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2NhbGN1bGF0ZVRvdGFsVXNhZ2UpLmNhbGwodGhpcyk7XG4gICAgfVxuICAgIGFsbENoYXRDb21wbGV0aW9ucygpIHtcbiAgICAgICAgcmV0dXJuIFsuLi50aGlzLl9jaGF0Q29tcGxldGlvbnNdO1xuICAgIH1cbiAgICBfZW1pdEZpbmFsKCkge1xuICAgICAgICBjb25zdCBjb21wbGV0aW9uID0gdGhpcy5fY2hhdENvbXBsZXRpb25zW3RoaXMuX2NoYXRDb21wbGV0aW9ucy5sZW5ndGggLSAxXTtcbiAgICAgICAgaWYgKGNvbXBsZXRpb24pXG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdmaW5hbENoYXRDb21wbGV0aW9uJywgY29tcGxldGlvbik7XG4gICAgICAgIGNvbnN0IGZpbmFsTWVzc2FnZSA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfaW5zdGFuY2VzLCBcIm1cIiwgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxNZXNzYWdlKS5jYWxsKHRoaXMpO1xuICAgICAgICBpZiAoZmluYWxNZXNzYWdlKVxuICAgICAgICAgICAgdGhpcy5fZW1pdCgnZmluYWxNZXNzYWdlJywgZmluYWxNZXNzYWdlKTtcbiAgICAgICAgY29uc3QgZmluYWxDb250ZW50ID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9pbnN0YW5jZXMsIFwibVwiLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbENvbnRlbnQpLmNhbGwodGhpcyk7XG4gICAgICAgIGlmIChmaW5hbENvbnRlbnQpXG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdmaW5hbENvbnRlbnQnLCBmaW5hbENvbnRlbnQpO1xuICAgICAgICBjb25zdCBmaW5hbEZ1bmN0aW9uQ2FsbCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfaW5zdGFuY2VzLCBcIm1cIiwgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxGdW5jdGlvbkNhbGwpLmNhbGwodGhpcyk7XG4gICAgICAgIGlmIChmaW5hbEZ1bmN0aW9uQ2FsbClcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2ZpbmFsRnVuY3Rpb25DYWxsJywgZmluYWxGdW5jdGlvbkNhbGwpO1xuICAgICAgICBjb25zdCBmaW5hbEZ1bmN0aW9uQ2FsbFJlc3VsdCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfaW5zdGFuY2VzLCBcIm1cIiwgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxGdW5jdGlvbkNhbGxSZXN1bHQpLmNhbGwodGhpcyk7XG4gICAgICAgIGlmIChmaW5hbEZ1bmN0aW9uQ2FsbFJlc3VsdCAhPSBudWxsKVxuICAgICAgICAgICAgdGhpcy5fZW1pdCgnZmluYWxGdW5jdGlvbkNhbGxSZXN1bHQnLCBmaW5hbEZ1bmN0aW9uQ2FsbFJlc3VsdCk7XG4gICAgICAgIGlmICh0aGlzLl9jaGF0Q29tcGxldGlvbnMuc29tZSgoYykgPT4gYy51c2FnZSkpIHtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ3RvdGFsVXNhZ2UnLCBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2luc3RhbmNlcywgXCJtXCIsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2NhbGN1bGF0ZVRvdGFsVXNhZ2UpLmNhbGwodGhpcykpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIF9jcmVhdGVDaGF0Q29tcGxldGlvbihjbGllbnQsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBzaWduYWwgPSBvcHRpb25zPy5zaWduYWw7XG4gICAgICAgIGlmIChzaWduYWwpIHtcbiAgICAgICAgICAgIGlmIChzaWduYWwuYWJvcnRlZClcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHRoaXMuY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICAgICAgfVxuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2luc3RhbmNlcywgXCJtXCIsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX3ZhbGlkYXRlUGFyYW1zKS5jYWxsKHRoaXMsIHBhcmFtcyk7XG4gICAgICAgIGNvbnN0IGNoYXRDb21wbGV0aW9uID0gYXdhaXQgY2xpZW50LmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHsgLi4ucGFyYW1zLCBzdHJlYW06IGZhbHNlIH0sIHsgLi4ub3B0aW9ucywgc2lnbmFsOiB0aGlzLmNvbnRyb2xsZXIuc2lnbmFsIH0pO1xuICAgICAgICB0aGlzLl9jb25uZWN0ZWQoKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2FkZENoYXRDb21wbGV0aW9uKHBhcnNlQ2hhdENvbXBsZXRpb24oY2hhdENvbXBsZXRpb24sIHBhcmFtcykpO1xuICAgIH1cbiAgICBhc3luYyBfcnVuQ2hhdENvbXBsZXRpb24oY2xpZW50LCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgZm9yIChjb25zdCBtZXNzYWdlIG9mIHBhcmFtcy5tZXNzYWdlcykge1xuICAgICAgICAgICAgdGhpcy5fYWRkTWVzc2FnZShtZXNzYWdlLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2NyZWF0ZUNoYXRDb21wbGV0aW9uKGNsaWVudCwgcGFyYW1zLCBvcHRpb25zKTtcbiAgICB9XG4gICAgYXN5bmMgX3J1bkZ1bmN0aW9ucyhjbGllbnQsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCByb2xlID0gJ2Z1bmN0aW9uJztcbiAgICAgICAgY29uc3QgeyBmdW5jdGlvbl9jYWxsID0gJ2F1dG8nLCBzdHJlYW0sIC4uLnJlc3RQYXJhbXMgfSA9IHBhcmFtcztcbiAgICAgICAgY29uc3Qgc2luZ2xlRnVuY3Rpb25Ub0NhbGwgPSB0eXBlb2YgZnVuY3Rpb25fY2FsbCAhPT0gJ3N0cmluZycgJiYgZnVuY3Rpb25fY2FsbD8ubmFtZTtcbiAgICAgICAgY29uc3QgeyBtYXhDaGF0Q29tcGxldGlvbnMgPSBERUZBVUxUX01BWF9DSEFUX0NPTVBMRVRJT05TIH0gPSBvcHRpb25zIHx8IHt9O1xuICAgICAgICBjb25zdCBmdW5jdGlvbnNCeU5hbWUgPSB7fTtcbiAgICAgICAgZm9yIChjb25zdCBmIG9mIHBhcmFtcy5mdW5jdGlvbnMpIHtcbiAgICAgICAgICAgIGZ1bmN0aW9uc0J5TmFtZVtmLm5hbWUgfHwgZi5mdW5jdGlvbi5uYW1lXSA9IGY7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZnVuY3Rpb25zID0gcGFyYW1zLmZ1bmN0aW9ucy5tYXAoKGYpID0+ICh7XG4gICAgICAgICAgICBuYW1lOiBmLm5hbWUgfHwgZi5mdW5jdGlvbi5uYW1lLFxuICAgICAgICAgICAgcGFyYW1ldGVyczogZi5wYXJhbWV0ZXJzLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGYuZGVzY3JpcHRpb24sXG4gICAgICAgIH0pKTtcbiAgICAgICAgZm9yIChjb25zdCBtZXNzYWdlIG9mIHBhcmFtcy5tZXNzYWdlcykge1xuICAgICAgICAgICAgdGhpcy5fYWRkTWVzc2FnZShtZXNzYWdlLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXhDaGF0Q29tcGxldGlvbnM7ICsraSkge1xuICAgICAgICAgICAgY29uc3QgY2hhdENvbXBsZXRpb24gPSBhd2FpdCB0aGlzLl9jcmVhdGVDaGF0Q29tcGxldGlvbihjbGllbnQsIHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0UGFyYW1zLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uX2NhbGwsXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2VzOiBbLi4udGhpcy5tZXNzYWdlc10sXG4gICAgICAgICAgICB9LCBvcHRpb25zKTtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBjaGF0Q29tcGxldGlvbi5jaG9pY2VzWzBdPy5tZXNzYWdlO1xuICAgICAgICAgICAgaWYgKCFtZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIG1lc3NhZ2UgaW4gQ2hhdENvbXBsZXRpb24gcmVzcG9uc2VgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghbWVzc2FnZS5mdW5jdGlvbl9jYWxsKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIGNvbnN0IHsgbmFtZSwgYXJndW1lbnRzOiBhcmdzIH0gPSBtZXNzYWdlLmZ1bmN0aW9uX2NhbGw7XG4gICAgICAgICAgICBjb25zdCBmbiA9IGZ1bmN0aW9uc0J5TmFtZVtuYW1lXTtcbiAgICAgICAgICAgIGlmICghZm4pIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50ID0gYEludmFsaWQgZnVuY3Rpb25fY2FsbDogJHtKU09OLnN0cmluZ2lmeShuYW1lKX0uIEF2YWlsYWJsZSBvcHRpb25zIGFyZTogJHtmdW5jdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgoZikgPT4gSlNPTi5zdHJpbmdpZnkoZi5uYW1lKSlcbiAgICAgICAgICAgICAgICAgICAgLmpvaW4oJywgJyl9LiBQbGVhc2UgdHJ5IGFnYWluYDtcbiAgICAgICAgICAgICAgICB0aGlzLl9hZGRNZXNzYWdlKHsgcm9sZSwgbmFtZSwgY29udGVudCB9KTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHNpbmdsZUZ1bmN0aW9uVG9DYWxsICYmIHNpbmdsZUZ1bmN0aW9uVG9DYWxsICE9PSBuYW1lKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY29udGVudCA9IGBJbnZhbGlkIGZ1bmN0aW9uX2NhbGw6ICR7SlNPTi5zdHJpbmdpZnkobmFtZSl9LiAke0pTT04uc3RyaW5naWZ5KHNpbmdsZUZ1bmN0aW9uVG9DYWxsKX0gcmVxdWVzdGVkLiBQbGVhc2UgdHJ5IGFnYWluYDtcbiAgICAgICAgICAgICAgICB0aGlzLl9hZGRNZXNzYWdlKHsgcm9sZSwgbmFtZSwgY29udGVudCB9KTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBwYXJzZWQ7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHBhcnNlZCA9IGlzUnVubmFibGVGdW5jdGlvbldpdGhQYXJzZShmbikgPyBhd2FpdCBmbi5wYXJzZShhcmdzKSA6IGFyZ3M7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9hZGRNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICAgICAgcm9sZSxcbiAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciBpdCBjYW4ndCBydWxlIG91dCBgbmV2ZXJgIHR5cGUuXG4gICAgICAgICAgICBjb25zdCByYXdDb250ZW50ID0gYXdhaXQgZm4uZnVuY3Rpb24ocGFyc2VkLCB0aGlzKTtcbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2luc3RhbmNlcywgXCJtXCIsIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX3N0cmluZ2lmeUZ1bmN0aW9uQ2FsbFJlc3VsdCkuY2FsbCh0aGlzLCByYXdDb250ZW50KTtcbiAgICAgICAgICAgIHRoaXMuX2FkZE1lc3NhZ2UoeyByb2xlLCBuYW1lLCBjb250ZW50IH0pO1xuICAgICAgICAgICAgaWYgKHNpbmdsZUZ1bmN0aW9uVG9DYWxsKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBfcnVuVG9vbHMoY2xpZW50LCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgcm9sZSA9ICd0b29sJztcbiAgICAgICAgY29uc3QgeyB0b29sX2Nob2ljZSA9ICdhdXRvJywgc3RyZWFtLCAuLi5yZXN0UGFyYW1zIH0gPSBwYXJhbXM7XG4gICAgICAgIGNvbnN0IHNpbmdsZUZ1bmN0aW9uVG9DYWxsID0gdHlwZW9mIHRvb2xfY2hvaWNlICE9PSAnc3RyaW5nJyAmJiB0b29sX2Nob2ljZT8uZnVuY3Rpb24/Lm5hbWU7XG4gICAgICAgIGNvbnN0IHsgbWF4Q2hhdENvbXBsZXRpb25zID0gREVGQVVMVF9NQVhfQ0hBVF9DT01QTEVUSU9OUyB9ID0gb3B0aW9ucyB8fCB7fTtcbiAgICAgICAgLy8gVE9ETyhzb21lZGF5KTogY2xlYW4gdGhpcyBsb2dpYyB1cFxuICAgICAgICBjb25zdCBpbnB1dFRvb2xzID0gcGFyYW1zLnRvb2xzLm1hcCgodG9vbCkgPT4ge1xuICAgICAgICAgICAgaWYgKGlzQXV0b1BhcnNhYmxlVG9vbCh0b29sKSkge1xuICAgICAgICAgICAgICAgIGlmICghdG9vbC4kY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKCdUb29sIGdpdmVuIHRvIGAucnVuVG9vbHMoKWAgdGhhdCBkb2VzIG5vdCBoYXZlIGFuIGFzc29jaWF0ZWQgZnVuY3Rpb24nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2Z1bmN0aW9uJyxcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uOiB0b29sLiRjYWxsYmFjayxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHRvb2wuZnVuY3Rpb24ubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiB0b29sLmZ1bmN0aW9uLmRlc2NyaXB0aW9uIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1ldGVyczogdG9vbC5mdW5jdGlvbi5wYXJhbWV0ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2U6IHRvb2wuJHBhcnNlUmF3LFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaWN0OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdG9vbDtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGZ1bmN0aW9uc0J5TmFtZSA9IHt9O1xuICAgICAgICBmb3IgKGNvbnN0IGYgb2YgaW5wdXRUb29scykge1xuICAgICAgICAgICAgaWYgKGYudHlwZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uc0J5TmFtZVtmLmZ1bmN0aW9uLm5hbWUgfHwgZi5mdW5jdGlvbi5mdW5jdGlvbi5uYW1lXSA9IGYuZnVuY3Rpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdG9vbHMgPSAndG9vbHMnIGluIHBhcmFtcyA/XG4gICAgICAgICAgICBpbnB1dFRvb2xzLm1hcCgodCkgPT4gdC50eXBlID09PSAnZnVuY3Rpb24nID9cbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdmdW5jdGlvbicsXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiB0LmZ1bmN0aW9uLm5hbWUgfHwgdC5mdW5jdGlvbi5mdW5jdGlvbi5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1ldGVyczogdC5mdW5jdGlvbi5wYXJhbWV0ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHQuZnVuY3Rpb24uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJpY3Q6IHQuZnVuY3Rpb24uc3RyaWN0LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA6IHQpXG4gICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgICAgZm9yIChjb25zdCBtZXNzYWdlIG9mIHBhcmFtcy5tZXNzYWdlcykge1xuICAgICAgICAgICAgdGhpcy5fYWRkTWVzc2FnZShtZXNzYWdlLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXhDaGF0Q29tcGxldGlvbnM7ICsraSkge1xuICAgICAgICAgICAgY29uc3QgY2hhdENvbXBsZXRpb24gPSBhd2FpdCB0aGlzLl9jcmVhdGVDaGF0Q29tcGxldGlvbihjbGllbnQsIHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0UGFyYW1zLFxuICAgICAgICAgICAgICAgIHRvb2xfY2hvaWNlLFxuICAgICAgICAgICAgICAgIHRvb2xzLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2VzOiBbLi4udGhpcy5tZXNzYWdlc10sXG4gICAgICAgICAgICB9LCBvcHRpb25zKTtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBjaGF0Q29tcGxldGlvbi5jaG9pY2VzWzBdPy5tZXNzYWdlO1xuICAgICAgICAgICAgaWYgKCFtZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIG1lc3NhZ2UgaW4gQ2hhdENvbXBsZXRpb24gcmVzcG9uc2VgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghbWVzc2FnZS50b29sX2NhbGxzPy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHRvb2xfY2FsbCBvZiBtZXNzYWdlLnRvb2xfY2FsbHMpIHtcbiAgICAgICAgICAgICAgICBpZiAodG9vbF9jYWxsLnR5cGUgIT09ICdmdW5jdGlvbicpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRvb2xfY2FsbF9pZCA9IHRvb2xfY2FsbC5pZDtcbiAgICAgICAgICAgICAgICBjb25zdCB7IG5hbWUsIGFyZ3VtZW50czogYXJncyB9ID0gdG9vbF9jYWxsLmZ1bmN0aW9uO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZuID0gZnVuY3Rpb25zQnlOYW1lW25hbWVdO1xuICAgICAgICAgICAgICAgIGlmICghZm4pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29udGVudCA9IGBJbnZhbGlkIHRvb2xfY2FsbDogJHtKU09OLnN0cmluZ2lmeShuYW1lKX0uIEF2YWlsYWJsZSBvcHRpb25zIGFyZTogJHtPYmplY3Qua2V5cyhmdW5jdGlvbnNCeU5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKChuYW1lKSA9PiBKU09OLnN0cmluZ2lmeShuYW1lKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5qb2luKCcsICcpfS4gUGxlYXNlIHRyeSBhZ2FpbmA7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2FkZE1lc3NhZ2UoeyByb2xlLCB0b29sX2NhbGxfaWQsIGNvbnRlbnQgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChzaW5nbGVGdW5jdGlvblRvQ2FsbCAmJiBzaW5nbGVGdW5jdGlvblRvQ2FsbCAhPT0gbmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50ID0gYEludmFsaWQgdG9vbF9jYWxsOiAke0pTT04uc3RyaW5naWZ5KG5hbWUpfS4gJHtKU09OLnN0cmluZ2lmeShzaW5nbGVGdW5jdGlvblRvQ2FsbCl9IHJlcXVlc3RlZC4gUGxlYXNlIHRyeSBhZ2FpbmA7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2FkZE1lc3NhZ2UoeyByb2xlLCB0b29sX2NhbGxfaWQsIGNvbnRlbnQgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsZXQgcGFyc2VkO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZCA9IGlzUnVubmFibGVGdW5jdGlvbldpdGhQYXJzZShmbikgPyBhd2FpdCBmbi5wYXJzZShhcmdzKSA6IGFyZ3M7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50ID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9hZGRNZXNzYWdlKHsgcm9sZSwgdG9vbF9jYWxsX2lkLCBjb250ZW50IH0pO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciBpdCBjYW4ndCBydWxlIG91dCBgbmV2ZXJgIHR5cGUuXG4gICAgICAgICAgICAgICAgY29uc3QgcmF3Q29udGVudCA9IGF3YWl0IGZuLmZ1bmN0aW9uKHBhcnNlZCwgdGhpcyk7XG4gICAgICAgICAgICAgICAgY29uc3QgY29udGVudCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfaW5zdGFuY2VzLCBcIm1cIiwgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfc3RyaW5naWZ5RnVuY3Rpb25DYWxsUmVzdWx0KS5jYWxsKHRoaXMsIHJhd0NvbnRlbnQpO1xuICAgICAgICAgICAgICAgIHRoaXMuX2FkZE1lc3NhZ2UoeyByb2xlLCB0b29sX2NhbGxfaWQsIGNvbnRlbnQgfSk7XG4gICAgICAgICAgICAgICAgaWYgKHNpbmdsZUZ1bmN0aW9uVG9DYWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbn1cbl9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2luc3RhbmNlcyA9IG5ldyBXZWFrU2V0KCksIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsQ29udGVudCA9IGZ1bmN0aW9uIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsQ29udGVudCgpIHtcbiAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9pbnN0YW5jZXMsIFwibVwiLCBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbE1lc3NhZ2UpLmNhbGwodGhpcykuY29udGVudCA/PyBudWxsO1xufSwgX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxNZXNzYWdlID0gZnVuY3Rpb24gX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxNZXNzYWdlKCkge1xuICAgIGxldCBpID0gdGhpcy5tZXNzYWdlcy5sZW5ndGg7XG4gICAgd2hpbGUgKGktLSA+IDApIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IHRoaXMubWVzc2FnZXNbaV07XG4gICAgICAgIGlmIChpc0Fzc2lzdGFudE1lc3NhZ2UobWVzc2FnZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZnVuY3Rpb25fY2FsbCwgLi4ucmVzdCB9ID0gbWVzc2FnZTtcbiAgICAgICAgICAgIC8vIFRPRE86IHN1cHBvcnQgYXVkaW8gaGVyZVxuICAgICAgICAgICAgY29uc3QgcmV0ID0ge1xuICAgICAgICAgICAgICAgIC4uLnJlc3QsXG4gICAgICAgICAgICAgICAgY29udGVudDogbWVzc2FnZS5jb250ZW50ID8/IG51bGwsXG4gICAgICAgICAgICAgICAgcmVmdXNhbDogbWVzc2FnZS5yZWZ1c2FsID8/IG51bGwsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKGZ1bmN0aW9uX2NhbGwpIHtcbiAgICAgICAgICAgICAgICByZXQuZnVuY3Rpb25fY2FsbCA9IGZ1bmN0aW9uX2NhbGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmV0O1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcignc3RyZWFtIGVuZGVkIHdpdGhvdXQgcHJvZHVjaW5nIGEgQ2hhdENvbXBsZXRpb25NZXNzYWdlIHdpdGggcm9sZT1hc3Npc3RhbnQnKTtcbn0sIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsRnVuY3Rpb25DYWxsID0gZnVuY3Rpb24gX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxGdW5jdGlvbkNhbGwoKSB7XG4gICAgZm9yIChsZXQgaSA9IHRoaXMubWVzc2FnZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IHRoaXMubWVzc2FnZXNbaV07XG4gICAgICAgIGlmIChpc0Fzc2lzdGFudE1lc3NhZ2UobWVzc2FnZSkgJiYgbWVzc2FnZT8uZnVuY3Rpb25fY2FsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2UuZnVuY3Rpb25fY2FsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNBc3Npc3RhbnRNZXNzYWdlKG1lc3NhZ2UpICYmIG1lc3NhZ2U/LnRvb2xfY2FsbHM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2UudG9vbF9jYWxscy5hdCgtMSk/LmZ1bmN0aW9uO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybjtcbn0sIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsRnVuY3Rpb25DYWxsUmVzdWx0ID0gZnVuY3Rpb24gX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfZ2V0RmluYWxGdW5jdGlvbkNhbGxSZXN1bHQoKSB7XG4gICAgZm9yIChsZXQgaSA9IHRoaXMubWVzc2FnZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IHRoaXMubWVzc2FnZXNbaV07XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uTWVzc2FnZShtZXNzYWdlKSAmJiBtZXNzYWdlLmNvbnRlbnQgIT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2UuY29udGVudDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNUb29sTWVzc2FnZShtZXNzYWdlKSAmJlxuICAgICAgICAgICAgbWVzc2FnZS5jb250ZW50ICE9IG51bGwgJiZcbiAgICAgICAgICAgIHR5cGVvZiBtZXNzYWdlLmNvbnRlbnQgPT09ICdzdHJpbmcnICYmXG4gICAgICAgICAgICB0aGlzLm1lc3NhZ2VzLnNvbWUoKHgpID0+IHgucm9sZSA9PT0gJ2Fzc2lzdGFudCcgJiZcbiAgICAgICAgICAgICAgICB4LnRvb2xfY2FsbHM/LnNvbWUoKHkpID0+IHkudHlwZSA9PT0gJ2Z1bmN0aW9uJyAmJiB5LmlkID09PSBtZXNzYWdlLnRvb2xfY2FsbF9pZCkpKSB7XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZS5jb250ZW50O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybjtcbn0sIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2NhbGN1bGF0ZVRvdGFsVXNhZ2UgPSBmdW5jdGlvbiBfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9jYWxjdWxhdGVUb3RhbFVzYWdlKCkge1xuICAgIGNvbnN0IHRvdGFsID0ge1xuICAgICAgICBjb21wbGV0aW9uX3Rva2VuczogMCxcbiAgICAgICAgcHJvbXB0X3Rva2VuczogMCxcbiAgICAgICAgdG90YWxfdG9rZW5zOiAwLFxuICAgIH07XG4gICAgZm9yIChjb25zdCB7IHVzYWdlIH0gb2YgdGhpcy5fY2hhdENvbXBsZXRpb25zKSB7XG4gICAgICAgIGlmICh1c2FnZSkge1xuICAgICAgICAgICAgdG90YWwuY29tcGxldGlvbl90b2tlbnMgKz0gdXNhZ2UuY29tcGxldGlvbl90b2tlbnM7XG4gICAgICAgICAgICB0b3RhbC5wcm9tcHRfdG9rZW5zICs9IHVzYWdlLnByb21wdF90b2tlbnM7XG4gICAgICAgICAgICB0b3RhbC50b3RhbF90b2tlbnMgKz0gdXNhZ2UudG90YWxfdG9rZW5zO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0b3RhbDtcbn0sIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX3ZhbGlkYXRlUGFyYW1zID0gZnVuY3Rpb24gX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfdmFsaWRhdGVQYXJhbXMocGFyYW1zKSB7XG4gICAgaWYgKHBhcmFtcy5uICE9IG51bGwgJiYgcGFyYW1zLm4gPiAxKSB7XG4gICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcignQ2hhdENvbXBsZXRpb24gY29udmVuaWVuY2UgaGVscGVycyBvbmx5IHN1cHBvcnQgbj0xIGF0IHRoaXMgdGltZS4gVG8gdXNlIG4+MSwgcGxlYXNlIHVzZSBjaGF0LmNvbXBsZXRpb25zLmNyZWF0ZSgpIGRpcmVjdGx5LicpO1xuICAgIH1cbn0sIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX3N0cmluZ2lmeUZ1bmN0aW9uQ2FsbFJlc3VsdCA9IGZ1bmN0aW9uIF9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX3N0cmluZ2lmeUZ1bmN0aW9uQ2FsbFJlc3VsdChyYXdDb250ZW50KSB7XG4gICAgcmV0dXJuICh0eXBlb2YgcmF3Q29udGVudCA9PT0gJ3N0cmluZycgPyByYXdDb250ZW50XG4gICAgICAgIDogcmF3Q29udGVudCA9PT0gdW5kZWZpbmVkID8gJ3VuZGVmaW5lZCdcbiAgICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkocmF3Q29udGVudCkpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUFic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXIubWpzLm1hcCIsImltcG9ydCB7IEFic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXIsIH0gZnJvbSBcIi4vQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lci5tanNcIjtcbmltcG9ydCB7IGlzQXNzaXN0YW50TWVzc2FnZSB9IGZyb20gXCIuL2NoYXRDb21wbGV0aW9uVXRpbHMubWpzXCI7XG5leHBvcnQgY2xhc3MgQ2hhdENvbXBsZXRpb25SdW5uZXIgZXh0ZW5kcyBBYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyIHtcbiAgICAvKiogQGRlcHJlY2F0ZWQgLSBwbGVhc2UgdXNlIGBydW5Ub29sc2AgaW5zdGVhZC4gKi9cbiAgICBzdGF0aWMgcnVuRnVuY3Rpb25zKGNsaWVudCwgcGFyYW1zLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHJ1bm5lciA9IG5ldyBDaGF0Q29tcGxldGlvblJ1bm5lcigpO1xuICAgICAgICBjb25zdCBvcHRzID0ge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgLi4ub3B0aW9ucz8uaGVhZGVycywgJ1gtU3RhaW5sZXNzLUhlbHBlci1NZXRob2QnOiAncnVuRnVuY3Rpb25zJyB9LFxuICAgICAgICB9O1xuICAgICAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX3J1bkZ1bmN0aW9ucyhjbGllbnQsIHBhcmFtcywgb3B0cykpO1xuICAgICAgICByZXR1cm4gcnVubmVyO1xuICAgIH1cbiAgICBzdGF0aWMgcnVuVG9vbHMoY2xpZW50LCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgcnVubmVyID0gbmV3IENoYXRDb21wbGV0aW9uUnVubmVyKCk7XG4gICAgICAgIGNvbnN0IG9wdHMgPSB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAuLi5vcHRpb25zPy5oZWFkZXJzLCAnWC1TdGFpbmxlc3MtSGVscGVyLU1ldGhvZCc6ICdydW5Ub29scycgfSxcbiAgICAgICAgfTtcbiAgICAgICAgcnVubmVyLl9ydW4oKCkgPT4gcnVubmVyLl9ydW5Ub29scyhjbGllbnQsIHBhcmFtcywgb3B0cykpO1xuICAgICAgICByZXR1cm4gcnVubmVyO1xuICAgIH1cbiAgICBfYWRkTWVzc2FnZShtZXNzYWdlLCBlbWl0ID0gdHJ1ZSkge1xuICAgICAgICBzdXBlci5fYWRkTWVzc2FnZShtZXNzYWdlLCBlbWl0KTtcbiAgICAgICAgaWYgKGlzQXNzaXN0YW50TWVzc2FnZShtZXNzYWdlKSAmJiBtZXNzYWdlLmNvbnRlbnQpIHtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2NvbnRlbnQnLCBtZXNzYWdlLmNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2hhdENvbXBsZXRpb25SdW5uZXIubWpzLm1hcCIsImNvbnN0IFNUUiA9IDBiMDAwMDAwMDAxO1xuY29uc3QgTlVNID0gMGIwMDAwMDAwMTA7XG5jb25zdCBBUlIgPSAwYjAwMDAwMDEwMDtcbmNvbnN0IE9CSiA9IDBiMDAwMDAxMDAwO1xuY29uc3QgTlVMTCA9IDBiMDAwMDEwMDAwO1xuY29uc3QgQk9PTCA9IDBiMDAwMTAwMDAwO1xuY29uc3QgTkFOID0gMGIwMDEwMDAwMDA7XG5jb25zdCBJTkZJTklUWSA9IDBiMDEwMDAwMDAwO1xuY29uc3QgTUlOVVNfSU5GSU5JVFkgPSAwYjEwMDAwMDAwMDtcbmNvbnN0IElORiA9IElORklOSVRZIHwgTUlOVVNfSU5GSU5JVFk7XG5jb25zdCBTUEVDSUFMID0gTlVMTCB8IEJPT0wgfCBJTkYgfCBOQU47XG5jb25zdCBBVE9NID0gU1RSIHwgTlVNIHwgU1BFQ0lBTDtcbmNvbnN0IENPTExFQ1RJT04gPSBBUlIgfCBPQko7XG5jb25zdCBBTEwgPSBBVE9NIHwgQ09MTEVDVElPTjtcbmNvbnN0IEFsbG93ID0ge1xuICAgIFNUUixcbiAgICBOVU0sXG4gICAgQVJSLFxuICAgIE9CSixcbiAgICBOVUxMLFxuICAgIEJPT0wsXG4gICAgTkFOLFxuICAgIElORklOSVRZLFxuICAgIE1JTlVTX0lORklOSVRZLFxuICAgIElORixcbiAgICBTUEVDSUFMLFxuICAgIEFUT00sXG4gICAgQ09MTEVDVElPTixcbiAgICBBTEwsXG59O1xuLy8gVGhlIEpTT04gc3RyaW5nIHNlZ21lbnQgd2FzIHVuYWJsZSB0byBiZSBwYXJzZWQgY29tcGxldGVseVxuY2xhc3MgUGFydGlhbEpTT04gZXh0ZW5kcyBFcnJvciB7XG59XG5jbGFzcyBNYWxmb3JtZWRKU09OIGV4dGVuZHMgRXJyb3Ige1xufVxuLyoqXG4gKiBQYXJzZSBpbmNvbXBsZXRlIEpTT05cbiAqIEBwYXJhbSB7c3RyaW5nfSBqc29uU3RyaW5nIFBhcnRpYWwgSlNPTiB0byBiZSBwYXJzZWRcbiAqIEBwYXJhbSB7bnVtYmVyfSBhbGxvd1BhcnRpYWwgU3BlY2lmeSB3aGF0IHR5cGVzIGFyZSBhbGxvd2VkIHRvIGJlIHBhcnRpYWwsIHNlZSB7QGxpbmsgQWxsb3d9IGZvciBkZXRhaWxzXG4gKiBAcmV0dXJucyBUaGUgcGFyc2VkIEpTT05cbiAqIEB0aHJvd3Mge1BhcnRpYWxKU09OfSBJZiB0aGUgSlNPTiBpcyBpbmNvbXBsZXRlIChyZWxhdGVkIHRvIHRoZSBgYWxsb3dgIHBhcmFtZXRlcilcbiAqIEB0aHJvd3Mge01hbGZvcm1lZEpTT059IElmIHRoZSBKU09OIGlzIG1hbGZvcm1lZFxuICovXG5mdW5jdGlvbiBwYXJzZUpTT04oanNvblN0cmluZywgYWxsb3dQYXJ0aWFsID0gQWxsb3cuQUxMKSB7XG4gICAgaWYgKHR5cGVvZiBqc29uU3RyaW5nICE9PSAnc3RyaW5nJykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBleHBlY3Rpbmcgc3RyLCBnb3QgJHt0eXBlb2YganNvblN0cmluZ31gKTtcbiAgICB9XG4gICAgaWYgKCFqc29uU3RyaW5nLnRyaW0oKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7anNvblN0cmluZ30gaXMgZW1wdHlgKTtcbiAgICB9XG4gICAgcmV0dXJuIF9wYXJzZUpTT04oanNvblN0cmluZy50cmltKCksIGFsbG93UGFydGlhbCk7XG59XG5jb25zdCBfcGFyc2VKU09OID0gKGpzb25TdHJpbmcsIGFsbG93KSA9PiB7XG4gICAgY29uc3QgbGVuZ3RoID0ganNvblN0cmluZy5sZW5ndGg7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBjb25zdCBtYXJrUGFydGlhbEpTT04gPSAobXNnKSA9PiB7XG4gICAgICAgIHRocm93IG5ldyBQYXJ0aWFsSlNPTihgJHttc2d9IGF0IHBvc2l0aW9uICR7aW5kZXh9YCk7XG4gICAgfTtcbiAgICBjb25zdCB0aHJvd01hbGZvcm1lZEVycm9yID0gKG1zZykgPT4ge1xuICAgICAgICB0aHJvdyBuZXcgTWFsZm9ybWVkSlNPTihgJHttc2d9IGF0IHBvc2l0aW9uICR7aW5kZXh9YCk7XG4gICAgfTtcbiAgICBjb25zdCBwYXJzZUFueSA9ICgpID0+IHtcbiAgICAgICAgc2tpcEJsYW5rKCk7XG4gICAgICAgIGlmIChpbmRleCA+PSBsZW5ndGgpXG4gICAgICAgICAgICBtYXJrUGFydGlhbEpTT04oJ1VuZXhwZWN0ZWQgZW5kIG9mIGlucHV0Jyk7XG4gICAgICAgIGlmIChqc29uU3RyaW5nW2luZGV4XSA9PT0gJ1wiJylcbiAgICAgICAgICAgIHJldHVybiBwYXJzZVN0cigpO1xuICAgICAgICBpZiAoanNvblN0cmluZ1tpbmRleF0gPT09ICd7JylcbiAgICAgICAgICAgIHJldHVybiBwYXJzZU9iaigpO1xuICAgICAgICBpZiAoanNvblN0cmluZ1tpbmRleF0gPT09ICdbJylcbiAgICAgICAgICAgIHJldHVybiBwYXJzZUFycigpO1xuICAgICAgICBpZiAoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgsIGluZGV4ICsgNCkgPT09ICdudWxsJyB8fFxuICAgICAgICAgICAgKEFsbG93Lk5VTEwgJiBhbGxvdyAmJiBsZW5ndGggLSBpbmRleCA8IDQgJiYgJ251bGwnLnN0YXJ0c1dpdGgoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgpKSkpIHtcbiAgICAgICAgICAgIGluZGV4ICs9IDQ7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgsIGluZGV4ICsgNCkgPT09ICd0cnVlJyB8fFxuICAgICAgICAgICAgKEFsbG93LkJPT0wgJiBhbGxvdyAmJiBsZW5ndGggLSBpbmRleCA8IDQgJiYgJ3RydWUnLnN0YXJ0c1dpdGgoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgpKSkpIHtcbiAgICAgICAgICAgIGluZGV4ICs9IDQ7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgsIGluZGV4ICsgNSkgPT09ICdmYWxzZScgfHxcbiAgICAgICAgICAgIChBbGxvdy5CT09MICYgYWxsb3cgJiYgbGVuZ3RoIC0gaW5kZXggPCA1ICYmICdmYWxzZScuc3RhcnRzV2l0aChqc29uU3RyaW5nLnN1YnN0cmluZyhpbmRleCkpKSkge1xuICAgICAgICAgICAgaW5kZXggKz0gNTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgsIGluZGV4ICsgOCkgPT09ICdJbmZpbml0eScgfHxcbiAgICAgICAgICAgIChBbGxvdy5JTkZJTklUWSAmIGFsbG93ICYmIGxlbmd0aCAtIGluZGV4IDwgOCAmJiAnSW5maW5pdHknLnN0YXJ0c1dpdGgoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgpKSkpIHtcbiAgICAgICAgICAgIGluZGV4ICs9IDg7XG4gICAgICAgICAgICByZXR1cm4gSW5maW5pdHk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGpzb25TdHJpbmcuc3Vic3RyaW5nKGluZGV4LCBpbmRleCArIDkpID09PSAnLUluZmluaXR5JyB8fFxuICAgICAgICAgICAgKEFsbG93Lk1JTlVTX0lORklOSVRZICYgYWxsb3cgJiZcbiAgICAgICAgICAgICAgICAxIDwgbGVuZ3RoIC0gaW5kZXggJiZcbiAgICAgICAgICAgICAgICBsZW5ndGggLSBpbmRleCA8IDkgJiZcbiAgICAgICAgICAgICAgICAnLUluZmluaXR5Jy5zdGFydHNXaXRoKGpzb25TdHJpbmcuc3Vic3RyaW5nKGluZGV4KSkpKSB7XG4gICAgICAgICAgICBpbmRleCArPSA5O1xuICAgICAgICAgICAgcmV0dXJuIC1JbmZpbml0eTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgsIGluZGV4ICsgMykgPT09ICdOYU4nIHx8XG4gICAgICAgICAgICAoQWxsb3cuTkFOICYgYWxsb3cgJiYgbGVuZ3RoIC0gaW5kZXggPCAzICYmICdOYU4nLnN0YXJ0c1dpdGgoanNvblN0cmluZy5zdWJzdHJpbmcoaW5kZXgpKSkpIHtcbiAgICAgICAgICAgIGluZGV4ICs9IDM7XG4gICAgICAgICAgICByZXR1cm4gTmFOO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwYXJzZU51bSgpO1xuICAgIH07XG4gICAgY29uc3QgcGFyc2VTdHIgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gaW5kZXg7XG4gICAgICAgIGxldCBlc2NhcGUgPSBmYWxzZTtcbiAgICAgICAgaW5kZXgrKzsgLy8gc2tpcCBpbml0aWFsIHF1b3RlXG4gICAgICAgIHdoaWxlIChpbmRleCA8IGxlbmd0aCAmJiAoanNvblN0cmluZ1tpbmRleF0gIT09ICdcIicgfHwgKGVzY2FwZSAmJiBqc29uU3RyaW5nW2luZGV4IC0gMV0gPT09ICdcXFxcJykpKSB7XG4gICAgICAgICAgICBlc2NhcGUgPSBqc29uU3RyaW5nW2luZGV4XSA9PT0gJ1xcXFwnID8gIWVzY2FwZSA6IGZhbHNlO1xuICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgfVxuICAgICAgICBpZiAoanNvblN0cmluZy5jaGFyQXQoaW5kZXgpID09ICdcIicpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoanNvblN0cmluZy5zdWJzdHJpbmcoc3RhcnQsICsraW5kZXggLSBOdW1iZXIoZXNjYXBlKSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICB0aHJvd01hbGZvcm1lZEVycm9yKFN0cmluZyhlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoQWxsb3cuU1RSICYgYWxsb3cpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoanNvblN0cmluZy5zdWJzdHJpbmcoc3RhcnQsIGluZGV4IC0gTnVtYmVyKGVzY2FwZSkpICsgJ1wiJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIC8vIFN5bnRheEVycm9yOiBJbnZhbGlkIGVzY2FwZSBzZXF1ZW5jZVxuICAgICAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKGpzb25TdHJpbmcuc3Vic3RyaW5nKHN0YXJ0LCBqc29uU3RyaW5nLmxhc3RJbmRleE9mKCdcXFxcJykpICsgJ1wiJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbWFya1BhcnRpYWxKU09OKCdVbnRlcm1pbmF0ZWQgc3RyaW5nIGxpdGVyYWwnKTtcbiAgICB9O1xuICAgIGNvbnN0IHBhcnNlT2JqID0gKCkgPT4ge1xuICAgICAgICBpbmRleCsrOyAvLyBza2lwIGluaXRpYWwgYnJhY2VcbiAgICAgICAgc2tpcEJsYW5rKCk7XG4gICAgICAgIGNvbnN0IG9iaiA9IHt9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgd2hpbGUgKGpzb25TdHJpbmdbaW5kZXhdICE9PSAnfScpIHtcbiAgICAgICAgICAgICAgICBza2lwQmxhbmsoKTtcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggPj0gbGVuZ3RoICYmIEFsbG93Lk9CSiAmIGFsbG93KVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICAgICAgICAgIGNvbnN0IGtleSA9IHBhcnNlU3RyKCk7XG4gICAgICAgICAgICAgICAgc2tpcEJsYW5rKCk7XG4gICAgICAgICAgICAgICAgaW5kZXgrKzsgLy8gc2tpcCBjb2xvblxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gcGFyc2VBbnkoKTtcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7IHZhbHVlLCB3cml0YWJsZTogdHJ1ZSwgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoQWxsb3cuT0JKICYgYWxsb3cpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBza2lwQmxhbmsoKTtcbiAgICAgICAgICAgICAgICBpZiAoanNvblN0cmluZ1tpbmRleF0gPT09ICcsJylcbiAgICAgICAgICAgICAgICAgICAgaW5kZXgrKzsgLy8gc2tpcCBjb21tYVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICBpZiAoQWxsb3cuT0JKICYgYWxsb3cpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iajtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBtYXJrUGFydGlhbEpTT04oXCJFeHBlY3RlZCAnfScgYXQgZW5kIG9mIG9iamVjdFwiKTtcbiAgICAgICAgfVxuICAgICAgICBpbmRleCsrOyAvLyBza2lwIGZpbmFsIGJyYWNlXG4gICAgICAgIHJldHVybiBvYmo7XG4gICAgfTtcbiAgICBjb25zdCBwYXJzZUFyciA9ICgpID0+IHtcbiAgICAgICAgaW5kZXgrKzsgLy8gc2tpcCBpbml0aWFsIGJyYWNrZXRcbiAgICAgICAgY29uc3QgYXJyID0gW107XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB3aGlsZSAoanNvblN0cmluZ1tpbmRleF0gIT09ICddJykge1xuICAgICAgICAgICAgICAgIGFyci5wdXNoKHBhcnNlQW55KCkpO1xuICAgICAgICAgICAgICAgIHNraXBCbGFuaygpO1xuICAgICAgICAgICAgICAgIGlmIChqc29uU3RyaW5nW2luZGV4XSA9PT0gJywnKSB7XG4gICAgICAgICAgICAgICAgICAgIGluZGV4Kys7IC8vIHNraXAgY29tbWFcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGlmIChBbGxvdy5BUlIgJiBhbGxvdykge1xuICAgICAgICAgICAgICAgIHJldHVybiBhcnI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtYXJrUGFydGlhbEpTT04oXCJFeHBlY3RlZCAnXScgYXQgZW5kIG9mIGFycmF5XCIpO1xuICAgICAgICB9XG4gICAgICAgIGluZGV4Kys7IC8vIHNraXAgZmluYWwgYnJhY2tldFxuICAgICAgICByZXR1cm4gYXJyO1xuICAgIH07XG4gICAgY29uc3QgcGFyc2VOdW0gPSAoKSA9PiB7XG4gICAgICAgIGlmIChpbmRleCA9PT0gMCkge1xuICAgICAgICAgICAgaWYgKGpzb25TdHJpbmcgPT09ICctJyAmJiBBbGxvdy5OVU0gJiBhbGxvdylcbiAgICAgICAgICAgICAgICBtYXJrUGFydGlhbEpTT04oXCJOb3Qgc3VyZSB3aGF0ICctJyBpc1wiKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoanNvblN0cmluZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGlmIChBbGxvdy5OVU0gJiBhbGxvdykge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCcuJyA9PT0ganNvblN0cmluZ1tqc29uU3RyaW5nLmxlbmd0aCAtIDFdKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKGpzb25TdHJpbmcuc3Vic3RyaW5nKDAsIGpzb25TdHJpbmcubGFzdEluZGV4T2YoJy4nKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoanNvblN0cmluZy5zdWJzdHJpbmcoMCwganNvblN0cmluZy5sYXN0SW5kZXhPZignZScpKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHsgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aHJvd01hbGZvcm1lZEVycm9yKFN0cmluZyhlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RhcnQgPSBpbmRleDtcbiAgICAgICAgaWYgKGpzb25TdHJpbmdbaW5kZXhdID09PSAnLScpXG4gICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICB3aGlsZSAoanNvblN0cmluZ1tpbmRleF0gJiYgIScsXX0nLmluY2x1ZGVzKGpzb25TdHJpbmdbaW5kZXhdKSlcbiAgICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgIGlmIChpbmRleCA9PSBsZW5ndGggJiYgIShBbGxvdy5OVU0gJiBhbGxvdykpXG4gICAgICAgICAgICBtYXJrUGFydGlhbEpTT04oJ1VudGVybWluYXRlZCBudW1iZXIgbGl0ZXJhbCcpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoanNvblN0cmluZy5zdWJzdHJpbmcoc3RhcnQsIGluZGV4KSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGlmIChqc29uU3RyaW5nLnN1YnN0cmluZyhzdGFydCwgaW5kZXgpID09PSAnLScgJiYgQWxsb3cuTlVNICYgYWxsb3cpXG4gICAgICAgICAgICAgICAgbWFya1BhcnRpYWxKU09OKFwiTm90IHN1cmUgd2hhdCAnLScgaXNcIik7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKGpzb25TdHJpbmcuc3Vic3RyaW5nKHN0YXJ0LCBqc29uU3RyaW5nLmxhc3RJbmRleE9mKCdlJykpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgdGhyb3dNYWxmb3JtZWRFcnJvcihTdHJpbmcoZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBza2lwQmxhbmsgPSAoKSA9PiB7XG4gICAgICAgIHdoaWxlIChpbmRleCA8IGxlbmd0aCAmJiAnIFxcblxcclxcdCcuaW5jbHVkZXMoanNvblN0cmluZ1tpbmRleF0pKSB7XG4gICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gcGFyc2VBbnkoKTtcbn07XG4vLyB1c2luZyB0aGlzIGZ1bmN0aW9uIHdpdGggbWFsZm9ybWVkIEpTT04gaXMgdW5kZWZpbmVkIGJlaGF2aW9yXG5jb25zdCBwYXJ0aWFsUGFyc2UgPSAoaW5wdXQpID0+IHBhcnNlSlNPTihpbnB1dCwgQWxsb3cuQUxMIF4gQWxsb3cuTlVNKTtcbmV4cG9ydCB7IHBhcnRpYWxQYXJzZSwgUGFydGlhbEpTT04sIE1hbGZvcm1lZEpTT04gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhcnNlci5tanMubWFwIiwidmFyIF9fY2xhc3NQcml2YXRlRmllbGRTZXQgPSAodGhpcyAmJiB0aGlzLl9fY2xhc3NQcml2YXRlRmllbGRTZXQpIHx8IGZ1bmN0aW9uIChyZWNlaXZlciwgc3RhdGUsIHZhbHVlLCBraW5kLCBmKSB7XG4gICAgaWYgKGtpbmQgPT09IFwibVwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBtZXRob2QgaXMgbm90IHdyaXRhYmxlXCIpO1xuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIHNldHRlclwiKTtcbiAgICBpZiAodHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciAhPT0gc3RhdGUgfHwgIWYgOiAhc3RhdGUuaGFzKHJlY2VpdmVyKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCB3cml0ZSBwcml2YXRlIG1lbWJlciB0byBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xuICAgIHJldHVybiAoa2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIsIHZhbHVlKSA6IGYgPyBmLnZhbHVlID0gdmFsdWUgOiBzdGF0ZS5zZXQocmVjZWl2ZXIsIHZhbHVlKSksIHZhbHVlO1xufTtcbnZhciBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0ID0gKHRoaXMgJiYgdGhpcy5fX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KSB8fCBmdW5jdGlvbiAocmVjZWl2ZXIsIHN0YXRlLCBraW5kLCBmKSB7XG4gICAgaWYgKGtpbmQgPT09IFwiYVwiICYmICFmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBhY2Nlc3NvciB3YXMgZGVmaW5lZCB3aXRob3V0IGEgZ2V0dGVyXCIpO1xuICAgIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHJlYWQgcHJpdmF0ZSBtZW1iZXIgZnJvbSBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xuICAgIHJldHVybiBraW5kID09PSBcIm1cIiA/IGYgOiBraW5kID09PSBcImFcIiA/IGYuY2FsbChyZWNlaXZlcikgOiBmID8gZi52YWx1ZSA6IHN0YXRlLmdldChyZWNlaXZlcik7XG59O1xudmFyIF9DaGF0Q29tcGxldGlvblN0cmVhbV9pbnN0YW5jZXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9wYXJhbXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9jaG9pY2VFdmVudFN0YXRlcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2N1cnJlbnRDaGF0Q29tcGxldGlvblNuYXBzaG90LCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fYmVnaW5SZXF1ZXN0LCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZ2V0Q2hvaWNlRXZlbnRTdGF0ZSwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2FkZENodW5rLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdFRvb2xDYWxsRG9uZUV2ZW50LCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdENvbnRlbnREb25lRXZlbnRzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW5kUmVxdWVzdCwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2dldEF1dG9QYXJzZWFibGVSZXNwb25zZUZvcm1hdCwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2FjY3VtdWxhdGVDaGF0Q29tcGxldGlvbjtcbmltcG9ydCB7IE9wZW5BSUVycm9yLCBBUElVc2VyQWJvcnRFcnJvciwgTGVuZ3RoRmluaXNoUmVhc29uRXJyb3IsIENvbnRlbnRGaWx0ZXJGaW5pc2hSZWFzb25FcnJvciwgfSBmcm9tIFwiLi4vZXJyb3IubWpzXCI7XG5pbXBvcnQgeyBBYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyLCB9IGZyb20gXCIuL0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXIubWpzXCI7XG5pbXBvcnQgeyBTdHJlYW0gfSBmcm9tIFwiLi4vc3RyZWFtaW5nLm1qc1wiO1xuaW1wb3J0IHsgaGFzQXV0b1BhcnNlYWJsZUlucHV0LCBpc0F1dG9QYXJzYWJsZVJlc3BvbnNlRm9ybWF0LCBpc0F1dG9QYXJzYWJsZVRvb2wsIG1heWJlUGFyc2VDaGF0Q29tcGxldGlvbiwgc2hvdWxkUGFyc2VUb29sQ2FsbCwgfSBmcm9tIFwiLi4vbGliL3BhcnNlci5tanNcIjtcbmltcG9ydCB7IHBhcnRpYWxQYXJzZSB9IGZyb20gXCIuLi9fdmVuZG9yL3BhcnRpYWwtanNvbi1wYXJzZXIvcGFyc2VyLm1qc1wiO1xuZXhwb3J0IGNsYXNzIENoYXRDb21wbGV0aW9uU3RyZWFtIGV4dGVuZHMgQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lciB7XG4gICAgY29uc3RydWN0b3IocGFyYW1zKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIF9DaGF0Q29tcGxldGlvblN0cmVhbV9pbnN0YW5jZXMuYWRkKHRoaXMpO1xuICAgICAgICBfQ2hhdENvbXBsZXRpb25TdHJlYW1fcGFyYW1zLnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY2hvaWNlRXZlbnRTdGF0ZXMuc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9DaGF0Q29tcGxldGlvblN0cmVhbV9jdXJyZW50Q2hhdENvbXBsZXRpb25TbmFwc2hvdC5zZXQodGhpcywgdm9pZCAwKTtcbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fcGFyYW1zLCBwYXJhbXMsIFwiZlwiKTtcbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY2hvaWNlRXZlbnRTdGF0ZXMsIFtdLCBcImZcIik7XG4gICAgfVxuICAgIGdldCBjdXJyZW50Q2hhdENvbXBsZXRpb25TbmFwc2hvdCgpIHtcbiAgICAgICAgcmV0dXJuIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2N1cnJlbnRDaGF0Q29tcGxldGlvblNuYXBzaG90LCBcImZcIik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEludGVuZGVkIGZvciB1c2Ugb24gdGhlIGZyb250ZW5kLCBjb25zdW1pbmcgYSBzdHJlYW0gcHJvZHVjZWQgd2l0aFxuICAgICAqIGAudG9SZWFkYWJsZVN0cmVhbSgpYCBvbiB0aGUgYmFja2VuZC5cbiAgICAgKlxuICAgICAqIE5vdGUgdGhhdCBtZXNzYWdlcyBzZW50IHRvIHRoZSBtb2RlbCBkbyBub3QgYXBwZWFyIGluIGAub24oJ21lc3NhZ2UnKWBcbiAgICAgKiBpbiB0aGlzIGNvbnRleHQuXG4gICAgICovXG4gICAgc3RhdGljIGZyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pIHtcbiAgICAgICAgY29uc3QgcnVubmVyID0gbmV3IENoYXRDb21wbGV0aW9uU3RyZWFtKG51bGwpO1xuICAgICAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX2Zyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pKTtcbiAgICAgICAgcmV0dXJuIHJ1bm5lcjtcbiAgICB9XG4gICAgc3RhdGljIGNyZWF0ZUNoYXRDb21wbGV0aW9uKGNsaWVudCwgcGFyYW1zLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHJ1bm5lciA9IG5ldyBDaGF0Q29tcGxldGlvblN0cmVhbShwYXJhbXMpO1xuICAgICAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX3J1bkNoYXRDb21wbGV0aW9uKGNsaWVudCwgeyAuLi5wYXJhbXMsIHN0cmVhbTogdHJ1ZSB9LCB7IC4uLm9wdGlvbnMsIGhlYWRlcnM6IHsgLi4ub3B0aW9ucz8uaGVhZGVycywgJ1gtU3RhaW5sZXNzLUhlbHBlci1NZXRob2QnOiAnc3RyZWFtJyB9IH0pKTtcbiAgICAgICAgcmV0dXJuIHJ1bm5lcjtcbiAgICB9XG4gICAgYXN5bmMgX2NyZWF0ZUNoYXRDb21wbGV0aW9uKGNsaWVudCwgcGFyYW1zLCBvcHRpb25zKSB7XG4gICAgICAgIHN1cGVyLl9jcmVhdGVDaGF0Q29tcGxldGlvbjtcbiAgICAgICAgY29uc3Qgc2lnbmFsID0gb3B0aW9ucz8uc2lnbmFsO1xuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sbGVyLmFib3J0KCk7XG4gICAgICAgICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgICAgIH1cbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2JlZ2luUmVxdWVzdCkuY2FsbCh0aGlzKTtcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgY2xpZW50LmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHsgLi4ucGFyYW1zLCBzdHJlYW06IHRydWUgfSwgeyAuLi5vcHRpb25zLCBzaWduYWw6IHRoaXMuY29udHJvbGxlci5zaWduYWwgfSk7XG4gICAgICAgIHRoaXMuX2Nvbm5lY3RlZCgpO1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHN0cmVhbSkge1xuICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2FkZENodW5rKS5jYWxsKHRoaXMsIGNodW5rKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RyZWFtLmNvbnRyb2xsZXIuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fYWRkQ2hhdENvbXBsZXRpb24oX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2VuZFJlcXVlc3QpLmNhbGwodGhpcykpO1xuICAgIH1cbiAgICBhc3luYyBfZnJvbVJlYWRhYmxlU3RyZWFtKHJlYWRhYmxlU3RyZWFtLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHNpZ25hbCA9IG9wdGlvbnM/LnNpZ25hbDtcbiAgICAgICAgaWYgKHNpZ25hbCkge1xuICAgICAgICAgICAgaWYgKHNpZ25hbC5hYm9ydGVkKVxuICAgICAgICAgICAgICAgIHRoaXMuY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgKCkgPT4gdGhpcy5jb250cm9sbGVyLmFib3J0KCkpO1xuICAgICAgICB9XG4gICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9iZWdpblJlcXVlc3QpLmNhbGwodGhpcyk7XG4gICAgICAgIHRoaXMuX2Nvbm5lY3RlZCgpO1xuICAgICAgICBjb25zdCBzdHJlYW0gPSBTdHJlYW0uZnJvbVJlYWRhYmxlU3RyZWFtKHJlYWRhYmxlU3RyZWFtLCB0aGlzLmNvbnRyb2xsZXIpO1xuICAgICAgICBsZXQgY2hhdElkO1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHN0cmVhbSkge1xuICAgICAgICAgICAgaWYgKGNoYXRJZCAmJiBjaGF0SWQgIT09IGNodW5rLmlkKSB7XG4gICAgICAgICAgICAgICAgLy8gQSBuZXcgcmVxdWVzdCBoYXMgYmVlbiBtYWRlLlxuICAgICAgICAgICAgICAgIHRoaXMuX2FkZENoYXRDb21wbGV0aW9uKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9lbmRSZXF1ZXN0KS5jYWxsKHRoaXMpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9hZGRDaHVuaykuY2FsbCh0aGlzLCBjaHVuayk7XG4gICAgICAgICAgICBjaGF0SWQgPSBjaHVuay5pZDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RyZWFtLmNvbnRyb2xsZXIuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fYWRkQ2hhdENvbXBsZXRpb24oX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2VuZFJlcXVlc3QpLmNhbGwodGhpcykpO1xuICAgIH1cbiAgICBbKF9DaGF0Q29tcGxldGlvblN0cmVhbV9wYXJhbXMgPSBuZXcgV2Vha01hcCgpLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY2hvaWNlRXZlbnRTdGF0ZXMgPSBuZXcgV2Vha01hcCgpLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY3VycmVudENoYXRDb21wbGV0aW9uU25hcHNob3QgPSBuZXcgV2Vha01hcCgpLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzID0gbmV3IFdlYWtTZXQoKSwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2JlZ2luUmVxdWVzdCA9IGZ1bmN0aW9uIF9DaGF0Q29tcGxldGlvblN0cmVhbV9iZWdpblJlcXVlc3QoKSB7XG4gICAgICAgIGlmICh0aGlzLmVuZGVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9jdXJyZW50Q2hhdENvbXBsZXRpb25TbmFwc2hvdCwgdW5kZWZpbmVkLCBcImZcIik7XG4gICAgfSwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2dldENob2ljZUV2ZW50U3RhdGUgPSBmdW5jdGlvbiBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZ2V0Q2hvaWNlRXZlbnRTdGF0ZShjaG9pY2UpIHtcbiAgICAgICAgbGV0IHN0YXRlID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY2hvaWNlRXZlbnRTdGF0ZXMsIFwiZlwiKVtjaG9pY2UuaW5kZXhdO1xuICAgICAgICBpZiAoc3RhdGUpIHtcbiAgICAgICAgICAgIHJldHVybiBzdGF0ZTtcbiAgICAgICAgfVxuICAgICAgICBzdGF0ZSA9IHtcbiAgICAgICAgICAgIGNvbnRlbnRfZG9uZTogZmFsc2UsXG4gICAgICAgICAgICByZWZ1c2FsX2RvbmU6IGZhbHNlLFxuICAgICAgICAgICAgbG9ncHJvYnNfY29udGVudF9kb25lOiBmYWxzZSxcbiAgICAgICAgICAgIGxvZ3Byb2JzX3JlZnVzYWxfZG9uZTogZmFsc2UsXG4gICAgICAgICAgICBkb25lX3Rvb2xfY2FsbHM6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIGN1cnJlbnRfdG9vbF9jYWxsX2luZGV4OiBudWxsLFxuICAgICAgICB9O1xuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9jaG9pY2VFdmVudFN0YXRlcywgXCJmXCIpW2Nob2ljZS5pbmRleF0gPSBzdGF0ZTtcbiAgICAgICAgcmV0dXJuIHN0YXRlO1xuICAgIH0sIF9DaGF0Q29tcGxldGlvblN0cmVhbV9hZGRDaHVuayA9IGZ1bmN0aW9uIF9DaGF0Q29tcGxldGlvblN0cmVhbV9hZGRDaHVuayhjaHVuaykge1xuICAgICAgICBpZiAodGhpcy5lbmRlZClcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc3QgY29tcGxldGlvbiA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9hY2N1bXVsYXRlQ2hhdENvbXBsZXRpb24pLmNhbGwodGhpcywgY2h1bmspO1xuICAgICAgICB0aGlzLl9lbWl0KCdjaHVuaycsIGNodW5rLCBjb21wbGV0aW9uKTtcbiAgICAgICAgZm9yIChjb25zdCBjaG9pY2Ugb2YgY2h1bmsuY2hvaWNlcykge1xuICAgICAgICAgICAgY29uc3QgY2hvaWNlU25hcHNob3QgPSBjb21wbGV0aW9uLmNob2ljZXNbY2hvaWNlLmluZGV4XTtcbiAgICAgICAgICAgIGlmIChjaG9pY2UuZGVsdGEuY29udGVudCAhPSBudWxsICYmXG4gICAgICAgICAgICAgICAgY2hvaWNlU25hcHNob3QubWVzc2FnZT8ucm9sZSA9PT0gJ2Fzc2lzdGFudCcgJiZcbiAgICAgICAgICAgICAgICBjaG9pY2VTbmFwc2hvdC5tZXNzYWdlPy5jb250ZW50KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgnY29udGVudCcsIGNob2ljZS5kZWx0YS5jb250ZW50LCBjaG9pY2VTbmFwc2hvdC5tZXNzYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2NvbnRlbnQuZGVsdGEnLCB7XG4gICAgICAgICAgICAgICAgICAgIGRlbHRhOiBjaG9pY2UuZGVsdGEuY29udGVudCxcbiAgICAgICAgICAgICAgICAgICAgc25hcHNob3Q6IGNob2ljZVNuYXBzaG90Lm1lc3NhZ2UuY29udGVudCxcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkOiBjaG9pY2VTbmFwc2hvdC5tZXNzYWdlLnBhcnNlZCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjaG9pY2UuZGVsdGEucmVmdXNhbCAhPSBudWxsICYmXG4gICAgICAgICAgICAgICAgY2hvaWNlU25hcHNob3QubWVzc2FnZT8ucm9sZSA9PT0gJ2Fzc2lzdGFudCcgJiZcbiAgICAgICAgICAgICAgICBjaG9pY2VTbmFwc2hvdC5tZXNzYWdlPy5yZWZ1c2FsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgncmVmdXNhbC5kZWx0YScsIHtcbiAgICAgICAgICAgICAgICAgICAgZGVsdGE6IGNob2ljZS5kZWx0YS5yZWZ1c2FsLFxuICAgICAgICAgICAgICAgICAgICBzbmFwc2hvdDogY2hvaWNlU25hcHNob3QubWVzc2FnZS5yZWZ1c2FsLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNob2ljZS5sb2dwcm9icz8uY29udGVudCAhPSBudWxsICYmIGNob2ljZVNuYXBzaG90Lm1lc3NhZ2U/LnJvbGUgPT09ICdhc3Npc3RhbnQnKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdCgnbG9ncHJvYnMuY29udGVudC5kZWx0YScsIHtcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogY2hvaWNlLmxvZ3Byb2JzPy5jb250ZW50LFxuICAgICAgICAgICAgICAgICAgICBzbmFwc2hvdDogY2hvaWNlU25hcHNob3QubG9ncHJvYnM/LmNvbnRlbnQgPz8gW10sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2hvaWNlLmxvZ3Byb2JzPy5yZWZ1c2FsICE9IG51bGwgJiYgY2hvaWNlU25hcHNob3QubWVzc2FnZT8ucm9sZSA9PT0gJ2Fzc2lzdGFudCcpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KCdsb2dwcm9icy5yZWZ1c2FsLmRlbHRhJywge1xuICAgICAgICAgICAgICAgICAgICByZWZ1c2FsOiBjaG9pY2UubG9ncHJvYnM/LnJlZnVzYWwsXG4gICAgICAgICAgICAgICAgICAgIHNuYXBzaG90OiBjaG9pY2VTbmFwc2hvdC5sb2dwcm9icz8ucmVmdXNhbCA/PyBbXSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2dldENob2ljZUV2ZW50U3RhdGUpLmNhbGwodGhpcywgY2hvaWNlU25hcHNob3QpO1xuICAgICAgICAgICAgaWYgKGNob2ljZVNuYXBzaG90LmZpbmlzaF9yZWFzb24pIHtcbiAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdENvbnRlbnREb25lRXZlbnRzKS5jYWxsKHRoaXMsIGNob2ljZVNuYXBzaG90KTtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdGUuY3VycmVudF90b29sX2NhbGxfaW5kZXggIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdFRvb2xDYWxsRG9uZUV2ZW50KS5jYWxsKHRoaXMsIGNob2ljZVNuYXBzaG90LCBzdGF0ZS5jdXJyZW50X3Rvb2xfY2FsbF9pbmRleCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChjb25zdCB0b29sQ2FsbCBvZiBjaG9pY2UuZGVsdGEudG9vbF9jYWxscyA/PyBbXSkge1xuICAgICAgICAgICAgICAgIGlmIChzdGF0ZS5jdXJyZW50X3Rvb2xfY2FsbF9pbmRleCAhPT0gdG9vbENhbGwuaW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2VtaXRDb250ZW50RG9uZUV2ZW50cykuY2FsbCh0aGlzLCBjaG9pY2VTbmFwc2hvdCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIG5ldyB0b29sIGNhbGwgc3RhcnRlZCwgdGhlIHByZXZpb3VzIG9uZSBpcyBkb25lXG4gICAgICAgICAgICAgICAgICAgIGlmIChzdGF0ZS5jdXJyZW50X3Rvb2xfY2FsbF9pbmRleCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdFRvb2xDYWxsRG9uZUV2ZW50KS5jYWxsKHRoaXMsIGNob2ljZVNuYXBzaG90LCBzdGF0ZS5jdXJyZW50X3Rvb2xfY2FsbF9pbmRleCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3RhdGUuY3VycmVudF90b29sX2NhbGxfaW5kZXggPSB0b29sQ2FsbC5pbmRleDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvciAoY29uc3QgdG9vbENhbGxEZWx0YSBvZiBjaG9pY2UuZGVsdGEudG9vbF9jYWxscyA/PyBbXSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRvb2xDYWxsU25hcHNob3QgPSBjaG9pY2VTbmFwc2hvdC5tZXNzYWdlLnRvb2xfY2FsbHM/Llt0b29sQ2FsbERlbHRhLmluZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAoIXRvb2xDYWxsU25hcHNob3Q/LnR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0b29sQ2FsbFNuYXBzaG90Py50eXBlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2VtaXQoJ3Rvb2xfY2FsbHMuZnVuY3Rpb24uYXJndW1lbnRzLmRlbHRhJywge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogdG9vbENhbGxTbmFwc2hvdC5mdW5jdGlvbj8ubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4OiB0b29sQ2FsbERlbHRhLmluZGV4LFxuICAgICAgICAgICAgICAgICAgICAgICAgYXJndW1lbnRzOiB0b29sQ2FsbFNuYXBzaG90LmZ1bmN0aW9uLmFyZ3VtZW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZF9hcmd1bWVudHM6IHRvb2xDYWxsU25hcHNob3QuZnVuY3Rpb24ucGFyc2VkX2FyZ3VtZW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3VtZW50c19kZWx0YTogdG9vbENhbGxEZWx0YS5mdW5jdGlvbj8uYXJndW1lbnRzID8/ICcnLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGFzc2VydE5ldmVyKHRvb2xDYWxsU25hcHNob3Q/LnR5cGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIF9DaGF0Q29tcGxldGlvblN0cmVhbV9lbWl0VG9vbENhbGxEb25lRXZlbnQgPSBmdW5jdGlvbiBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdFRvb2xDYWxsRG9uZUV2ZW50KGNob2ljZVNuYXBzaG90LCB0b29sQ2FsbEluZGV4KSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2dldENob2ljZUV2ZW50U3RhdGUpLmNhbGwodGhpcywgY2hvaWNlU25hcHNob3QpO1xuICAgICAgICBpZiAoc3RhdGUuZG9uZV90b29sX2NhbGxzLmhhcyh0b29sQ2FsbEluZGV4KSkge1xuICAgICAgICAgICAgLy8gd2UndmUgYWxyZWFkeSBmaXJlZCB0aGUgZG9uZSBldmVudFxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRvb2xDYWxsU25hcHNob3QgPSBjaG9pY2VTbmFwc2hvdC5tZXNzYWdlLnRvb2xfY2FsbHM/Llt0b29sQ2FsbEluZGV4XTtcbiAgICAgICAgaWYgKCF0b29sQ2FsbFNuYXBzaG90KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vIHRvb2wgY2FsbCBzbmFwc2hvdCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdG9vbENhbGxTbmFwc2hvdC50eXBlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3Rvb2wgY2FsbCBzbmFwc2hvdCBtaXNzaW5nIGB0eXBlYCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0b29sQ2FsbFNuYXBzaG90LnR5cGUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0VG9vbCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX3BhcmFtcywgXCJmXCIpPy50b29scz8uZmluZCgodG9vbCkgPT4gdG9vbC50eXBlID09PSAnZnVuY3Rpb24nICYmIHRvb2wuZnVuY3Rpb24ubmFtZSA9PT0gdG9vbENhbGxTbmFwc2hvdC5mdW5jdGlvbi5uYW1lKTtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ3Rvb2xfY2FsbHMuZnVuY3Rpb24uYXJndW1lbnRzLmRvbmUnLCB7XG4gICAgICAgICAgICAgICAgbmFtZTogdG9vbENhbGxTbmFwc2hvdC5mdW5jdGlvbi5uYW1lLFxuICAgICAgICAgICAgICAgIGluZGV4OiB0b29sQ2FsbEluZGV4LFxuICAgICAgICAgICAgICAgIGFyZ3VtZW50czogdG9vbENhbGxTbmFwc2hvdC5mdW5jdGlvbi5hcmd1bWVudHMsXG4gICAgICAgICAgICAgICAgcGFyc2VkX2FyZ3VtZW50czogaXNBdXRvUGFyc2FibGVUb29sKGlucHV0VG9vbCkgPyBpbnB1dFRvb2wuJHBhcnNlUmF3KHRvb2xDYWxsU25hcHNob3QuZnVuY3Rpb24uYXJndW1lbnRzKVxuICAgICAgICAgICAgICAgICAgICA6IGlucHV0VG9vbD8uZnVuY3Rpb24uc3RyaWN0ID8gSlNPTi5wYXJzZSh0b29sQ2FsbFNuYXBzaG90LmZ1bmN0aW9uLmFyZ3VtZW50cylcbiAgICAgICAgICAgICAgICAgICAgICAgIDogbnVsbCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYXNzZXJ0TmV2ZXIodG9vbENhbGxTbmFwc2hvdC50eXBlKTtcbiAgICAgICAgfVxuICAgIH0sIF9DaGF0Q29tcGxldGlvblN0cmVhbV9lbWl0Q29udGVudERvbmVFdmVudHMgPSBmdW5jdGlvbiBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdENvbnRlbnREb25lRXZlbnRzKGNob2ljZVNuYXBzaG90KSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2dldENob2ljZUV2ZW50U3RhdGUpLmNhbGwodGhpcywgY2hvaWNlU25hcHNob3QpO1xuICAgICAgICBpZiAoY2hvaWNlU25hcHNob3QubWVzc2FnZS5jb250ZW50ICYmICFzdGF0ZS5jb250ZW50X2RvbmUpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvbnRlbnRfZG9uZSA9IHRydWU7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZUZvcm1hdCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9nZXRBdXRvUGFyc2VhYmxlUmVzcG9uc2VGb3JtYXQpLmNhbGwodGhpcyk7XG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdjb250ZW50LmRvbmUnLCB7XG4gICAgICAgICAgICAgICAgY29udGVudDogY2hvaWNlU25hcHNob3QubWVzc2FnZS5jb250ZW50LFxuICAgICAgICAgICAgICAgIHBhcnNlZDogcmVzcG9uc2VGb3JtYXQgPyByZXNwb25zZUZvcm1hdC4kcGFyc2VSYXcoY2hvaWNlU25hcHNob3QubWVzc2FnZS5jb250ZW50KSA6IG51bGwsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hvaWNlU25hcHNob3QubWVzc2FnZS5yZWZ1c2FsICYmICFzdGF0ZS5yZWZ1c2FsX2RvbmUpIHtcbiAgICAgICAgICAgIHN0YXRlLnJlZnVzYWxfZG9uZSA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdyZWZ1c2FsLmRvbmUnLCB7IHJlZnVzYWw6IGNob2ljZVNuYXBzaG90Lm1lc3NhZ2UucmVmdXNhbCB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hvaWNlU25hcHNob3QubG9ncHJvYnM/LmNvbnRlbnQgJiYgIXN0YXRlLmxvZ3Byb2JzX2NvbnRlbnRfZG9uZSkge1xuICAgICAgICAgICAgc3RhdGUubG9ncHJvYnNfY29udGVudF9kb25lID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2xvZ3Byb2JzLmNvbnRlbnQuZG9uZScsIHsgY29udGVudDogY2hvaWNlU25hcHNob3QubG9ncHJvYnMuY29udGVudCB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hvaWNlU25hcHNob3QubG9ncHJvYnM/LnJlZnVzYWwgJiYgIXN0YXRlLmxvZ3Byb2JzX3JlZnVzYWxfZG9uZSkge1xuICAgICAgICAgICAgc3RhdGUubG9ncHJvYnNfcmVmdXNhbF9kb25lID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuX2VtaXQoJ2xvZ3Byb2JzLnJlZnVzYWwuZG9uZScsIHsgcmVmdXNhbDogY2hvaWNlU25hcHNob3QubG9ncHJvYnMucmVmdXNhbCB9KTtcbiAgICAgICAgfVxuICAgIH0sIF9DaGF0Q29tcGxldGlvblN0cmVhbV9lbmRSZXF1ZXN0ID0gZnVuY3Rpb24gX0NoYXRDb21wbGV0aW9uU3RyZWFtX2VuZFJlcXVlc3QoKSB7XG4gICAgICAgIGlmICh0aGlzLmVuZGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYHN0cmVhbSBoYXMgZW5kZWQsIHRoaXMgc2hvdWxkbid0IGhhcHBlbmApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNuYXBzaG90ID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY3VycmVudENoYXRDb21wbGV0aW9uU25hcHNob3QsIFwiZlwiKTtcbiAgICAgICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGByZXF1ZXN0IGVuZGVkIHdpdGhvdXQgc2VuZGluZyBhbnkgY2h1bmtzYCk7XG4gICAgICAgIH1cbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY3VycmVudENoYXRDb21wbGV0aW9uU25hcHNob3QsIHVuZGVmaW5lZCwgXCJmXCIpO1xuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9jaG9pY2VFdmVudFN0YXRlcywgW10sIFwiZlwiKTtcbiAgICAgICAgcmV0dXJuIGZpbmFsaXplQ2hhdENvbXBsZXRpb24oc25hcHNob3QsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX3BhcmFtcywgXCJmXCIpKTtcbiAgICB9LCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fZ2V0QXV0b1BhcnNlYWJsZVJlc3BvbnNlRm9ybWF0ID0gZnVuY3Rpb24gX0NoYXRDb21wbGV0aW9uU3RyZWFtX2dldEF1dG9QYXJzZWFibGVSZXNwb25zZUZvcm1hdCgpIHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VGb3JtYXQgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9wYXJhbXMsIFwiZlwiKT8ucmVzcG9uc2VfZm9ybWF0O1xuICAgICAgICBpZiAoaXNBdXRvUGFyc2FibGVSZXNwb25zZUZvcm1hdChyZXNwb25zZUZvcm1hdCkpIHtcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZUZvcm1hdDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9LCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fYWNjdW11bGF0ZUNoYXRDb21wbGV0aW9uID0gZnVuY3Rpb24gX0NoYXRDb21wbGV0aW9uU3RyZWFtX2FjY3VtdWxhdGVDaGF0Q29tcGxldGlvbihjaHVuaykge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2Q7XG4gICAgICAgIGxldCBzbmFwc2hvdCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2N1cnJlbnRDaGF0Q29tcGxldGlvblNuYXBzaG90LCBcImZcIik7XG4gICAgICAgIGNvbnN0IHsgY2hvaWNlcywgLi4ucmVzdCB9ID0gY2h1bms7XG4gICAgICAgIGlmICghc25hcHNob3QpIHtcbiAgICAgICAgICAgIHNuYXBzaG90ID0gX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fY3VycmVudENoYXRDb21wbGV0aW9uU25hcHNob3QsIHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0LFxuICAgICAgICAgICAgICAgIGNob2ljZXM6IFtdLFxuICAgICAgICAgICAgfSwgXCJmXCIpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihzbmFwc2hvdCwgcmVzdCk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCB7IGRlbHRhLCBmaW5pc2hfcmVhc29uLCBpbmRleCwgbG9ncHJvYnMgPSBudWxsLCAuLi5vdGhlciB9IG9mIGNodW5rLmNob2ljZXMpIHtcbiAgICAgICAgICAgIGxldCBjaG9pY2UgPSBzbmFwc2hvdC5jaG9pY2VzW2luZGV4XTtcbiAgICAgICAgICAgIGlmICghY2hvaWNlKSB7XG4gICAgICAgICAgICAgICAgY2hvaWNlID0gc25hcHNob3QuY2hvaWNlc1tpbmRleF0gPSB7IGZpbmlzaF9yZWFzb24sIGluZGV4LCBtZXNzYWdlOiB7fSwgbG9ncHJvYnMsIC4uLm90aGVyIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobG9ncHJvYnMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWNob2ljZS5sb2dwcm9icykge1xuICAgICAgICAgICAgICAgICAgICBjaG9pY2UubG9ncHJvYnMgPSBPYmplY3QuYXNzaWduKHt9LCBsb2dwcm9icyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB7IGNvbnRlbnQsIHJlZnVzYWwsIC4uLnJlc3QgfSA9IGxvZ3Byb2JzO1xuICAgICAgICAgICAgICAgICAgICBhc3NlcnRJc0VtcHR5KHJlc3QpO1xuICAgICAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKGNob2ljZS5sb2dwcm9icywgcmVzdCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAoX2EgPSBjaG9pY2UubG9ncHJvYnMpLmNvbnRlbnQgPz8gKF9hLmNvbnRlbnQgPSBbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaG9pY2UubG9ncHJvYnMuY29udGVudC5wdXNoKC4uLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZWZ1c2FsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAoX2IgPSBjaG9pY2UubG9ncHJvYnMpLnJlZnVzYWwgPz8gKF9iLnJlZnVzYWwgPSBbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaG9pY2UubG9ncHJvYnMucmVmdXNhbC5wdXNoKC4uLnJlZnVzYWwpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGZpbmlzaF9yZWFzb24pIHtcbiAgICAgICAgICAgICAgICBjaG9pY2UuZmluaXNoX3JlYXNvbiA9IGZpbmlzaF9yZWFzb247XG4gICAgICAgICAgICAgICAgaWYgKF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX3BhcmFtcywgXCJmXCIpICYmIGhhc0F1dG9QYXJzZWFibGVJbnB1dChfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9wYXJhbXMsIFwiZlwiKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpbmlzaF9yZWFzb24gPT09ICdsZW5ndGgnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTGVuZ3RoRmluaXNoUmVhc29uRXJyb3IoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoZmluaXNoX3JlYXNvbiA9PT0gJ2NvbnRlbnRfZmlsdGVyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IENvbnRlbnRGaWx0ZXJGaW5pc2hSZWFzb25FcnJvcigpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihjaG9pY2UsIG90aGVyKTtcbiAgICAgICAgICAgIGlmICghZGVsdGEpXG4gICAgICAgICAgICAgICAgY29udGludWU7IC8vIFNob3VsZG4ndCBoYXBwZW47IGp1c3QgaW4gY2FzZS5cbiAgICAgICAgICAgIGNvbnN0IHsgY29udGVudCwgcmVmdXNhbCwgZnVuY3Rpb25fY2FsbCwgcm9sZSwgdG9vbF9jYWxscywgLi4ucmVzdCB9ID0gZGVsdGE7XG4gICAgICAgICAgICBhc3NlcnRJc0VtcHR5KHJlc3QpO1xuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihjaG9pY2UubWVzc2FnZSwgcmVzdCk7XG4gICAgICAgICAgICBpZiAocmVmdXNhbCkge1xuICAgICAgICAgICAgICAgIGNob2ljZS5tZXNzYWdlLnJlZnVzYWwgPSAoY2hvaWNlLm1lc3NhZ2UucmVmdXNhbCB8fCAnJykgKyByZWZ1c2FsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJvbGUpXG4gICAgICAgICAgICAgICAgY2hvaWNlLm1lc3NhZ2Uucm9sZSA9IHJvbGU7XG4gICAgICAgICAgICBpZiAoZnVuY3Rpb25fY2FsbCkge1xuICAgICAgICAgICAgICAgIGlmICghY2hvaWNlLm1lc3NhZ2UuZnVuY3Rpb25fY2FsbCkge1xuICAgICAgICAgICAgICAgICAgICBjaG9pY2UubWVzc2FnZS5mdW5jdGlvbl9jYWxsID0gZnVuY3Rpb25fY2FsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmdW5jdGlvbl9jYWxsLm5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICBjaG9pY2UubWVzc2FnZS5mdW5jdGlvbl9jYWxsLm5hbWUgPSBmdW5jdGlvbl9jYWxsLm5hbWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmdW5jdGlvbl9jYWxsLmFyZ3VtZW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgKF9jID0gY2hvaWNlLm1lc3NhZ2UuZnVuY3Rpb25fY2FsbCkuYXJndW1lbnRzID8/IChfYy5hcmd1bWVudHMgPSAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaG9pY2UubWVzc2FnZS5mdW5jdGlvbl9jYWxsLmFyZ3VtZW50cyArPSBmdW5jdGlvbl9jYWxsLmFyZ3VtZW50cztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjb250ZW50KSB7XG4gICAgICAgICAgICAgICAgY2hvaWNlLm1lc3NhZ2UuY29udGVudCA9IChjaG9pY2UubWVzc2FnZS5jb250ZW50IHx8ICcnKSArIGNvbnRlbnQ7XG4gICAgICAgICAgICAgICAgaWYgKCFjaG9pY2UubWVzc2FnZS5yZWZ1c2FsICYmIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX0NoYXRDb21wbGV0aW9uU3RyZWFtX2luc3RhbmNlcywgXCJtXCIsIF9DaGF0Q29tcGxldGlvblN0cmVhbV9nZXRBdXRvUGFyc2VhYmxlUmVzcG9uc2VGb3JtYXQpLmNhbGwodGhpcykpIHtcbiAgICAgICAgICAgICAgICAgICAgY2hvaWNlLm1lc3NhZ2UucGFyc2VkID0gcGFydGlhbFBhcnNlKGNob2ljZS5tZXNzYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0b29sX2NhbGxzKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFjaG9pY2UubWVzc2FnZS50b29sX2NhbGxzKVxuICAgICAgICAgICAgICAgICAgICBjaG9pY2UubWVzc2FnZS50b29sX2NhbGxzID0gW107XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB7IGluZGV4LCBpZCwgdHlwZSwgZnVuY3Rpb246IGZuLCAuLi5yZXN0IH0gb2YgdG9vbF9jYWxscykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0b29sX2NhbGwgPSAoKF9kID0gY2hvaWNlLm1lc3NhZ2UudG9vbF9jYWxscylbaW5kZXhdID8/IChfZFtpbmRleF0gPSB7fSkpO1xuICAgICAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHRvb2xfY2FsbCwgcmVzdCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpZClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvb2xfY2FsbC5pZCA9IGlkO1xuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvb2xfY2FsbC50eXBlID0gdHlwZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZuKVxuICAgICAgICAgICAgICAgICAgICAgICAgdG9vbF9jYWxsLmZ1bmN0aW9uID8/ICh0b29sX2NhbGwuZnVuY3Rpb24gPSB7IG5hbWU6IGZuLm5hbWUgPz8gJycsIGFyZ3VtZW50czogJycgfSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmbj8ubmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvb2xfY2FsbC5mdW5jdGlvbi5uYW1lID0gZm4ubmFtZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZuPy5hcmd1bWVudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvb2xfY2FsbC5mdW5jdGlvbi5hcmd1bWVudHMgKz0gZm4uYXJndW1lbnRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNob3VsZFBhcnNlVG9vbENhbGwoX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfQ2hhdENvbXBsZXRpb25TdHJlYW1fcGFyYW1zLCBcImZcIiksIHRvb2xfY2FsbCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b29sX2NhbGwuZnVuY3Rpb24ucGFyc2VkX2FyZ3VtZW50cyA9IHBhcnRpYWxQYXJzZSh0b29sX2NhbGwuZnVuY3Rpb24uYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc25hcHNob3Q7XG4gICAgfSwgU3ltYm9sLmFzeW5jSXRlcmF0b3IpXSgpIHtcbiAgICAgICAgY29uc3QgcHVzaFF1ZXVlID0gW107XG4gICAgICAgIGNvbnN0IHJlYWRRdWV1ZSA9IFtdO1xuICAgICAgICBsZXQgZG9uZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm9uKCdjaHVuaycsIChjaHVuaykgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gcmVhZFF1ZXVlLnNoaWZ0KCk7XG4gICAgICAgICAgICBpZiAocmVhZGVyKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlc29sdmUoY2h1bmspO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcHVzaFF1ZXVlLnB1c2goY2h1bmspO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5vbignZW5kJywgKCkgPT4ge1xuICAgICAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlYWRlciBvZiByZWFkUXVldWUpIHtcbiAgICAgICAgICAgICAgICByZWFkZXIucmVzb2x2ZSh1bmRlZmluZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm9uKCdhYm9ydCcsIChlcnIpID0+IHtcbiAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCByZWFkZXIgb2YgcmVhZFF1ZXVlKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlamVjdChlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCByZWFkZXIgb2YgcmVhZFF1ZXVlKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlamVjdChlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbmV4dDogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghcHVzaFF1ZXVlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiByZWFkUXVldWUucHVzaCh7IHJlc29sdmUsIHJlamVjdCB9KSkudGhlbigoY2h1bmspID0+IChjaHVuayA/IHsgdmFsdWU6IGNodW5rLCBkb25lOiBmYWxzZSB9IDogeyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiB0cnVlIH0pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgY2h1bmsgPSBwdXNoUXVldWUuc2hpZnQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogY2h1bmssIGRvbmU6IGZhbHNlIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmV0dXJuOiBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5hYm9ydCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRvUmVhZGFibGVTdHJlYW0oKSB7XG4gICAgICAgIGNvbnN0IHN0cmVhbSA9IG5ldyBTdHJlYW0odGhpc1tTeW1ib2wuYXN5bmNJdGVyYXRvcl0uYmluZCh0aGlzKSwgdGhpcy5jb250cm9sbGVyKTtcbiAgICAgICAgcmV0dXJuIHN0cmVhbS50b1JlYWRhYmxlU3RyZWFtKCk7XG4gICAgfVxufVxuZnVuY3Rpb24gZmluYWxpemVDaGF0Q29tcGxldGlvbihzbmFwc2hvdCwgcGFyYW1zKSB7XG4gICAgY29uc3QgeyBpZCwgY2hvaWNlcywgY3JlYXRlZCwgbW9kZWwsIHN5c3RlbV9maW5nZXJwcmludCwgLi4ucmVzdCB9ID0gc25hcHNob3Q7XG4gICAgY29uc3QgY29tcGxldGlvbiA9IHtcbiAgICAgICAgLi4ucmVzdCxcbiAgICAgICAgaWQsXG4gICAgICAgIGNob2ljZXM6IGNob2ljZXMubWFwKCh7IG1lc3NhZ2UsIGZpbmlzaF9yZWFzb24sIGluZGV4LCBsb2dwcm9icywgLi4uY2hvaWNlUmVzdCB9KSA9PiB7XG4gICAgICAgICAgICBpZiAoIWZpbmlzaF9yZWFzb24pIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYG1pc3NpbmcgZmluaXNoX3JlYXNvbiBmb3IgY2hvaWNlICR7aW5kZXh9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB7IGNvbnRlbnQgPSBudWxsLCBmdW5jdGlvbl9jYWxsLCB0b29sX2NhbGxzLCAuLi5tZXNzYWdlUmVzdCB9ID0gbWVzc2FnZTtcbiAgICAgICAgICAgIGNvbnN0IHJvbGUgPSBtZXNzYWdlLnJvbGU7IC8vIHRoaXMgaXMgd2hhdCB3ZSBleHBlY3Q7IGluIHRoZW9yeSBpdCBjb3VsZCBiZSBkaWZmZXJlbnQgd2hpY2ggd291bGQgbWFrZSBvdXIgdHlwZXMgYSBzbGlnaHQgbGllIGJ1dCB3b3VsZCBiZSBmaW5lLlxuICAgICAgICAgICAgaWYgKCFyb2xlKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIHJvbGUgZm9yIGNob2ljZSAke2luZGV4fWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGZ1bmN0aW9uX2NhbGwpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGFyZ3VtZW50czogYXJncywgbmFtZSB9ID0gZnVuY3Rpb25fY2FsbDtcbiAgICAgICAgICAgICAgICBpZiAoYXJncyA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgbWlzc2luZyBmdW5jdGlvbl9jYWxsLmFyZ3VtZW50cyBmb3IgY2hvaWNlICR7aW5kZXh9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghbmFtZSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYG1pc3NpbmcgZnVuY3Rpb25fY2FsbC5uYW1lIGZvciBjaG9pY2UgJHtpbmRleH1gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uY2hvaWNlUmVzdCxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uX2NhbGw6IHsgYXJndW1lbnRzOiBhcmdzLCBuYW1lIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICByb2xlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVmdXNhbDogbWVzc2FnZS5yZWZ1c2FsID8/IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGZpbmlzaF9yZWFzb24sXG4gICAgICAgICAgICAgICAgICAgIGluZGV4LFxuICAgICAgICAgICAgICAgICAgICBsb2dwcm9icyxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRvb2xfY2FsbHMpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5jaG9pY2VSZXN0LFxuICAgICAgICAgICAgICAgICAgICBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgZmluaXNoX3JlYXNvbixcbiAgICAgICAgICAgICAgICAgICAgbG9ncHJvYnMsXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLm1lc3NhZ2VSZXN0LFxuICAgICAgICAgICAgICAgICAgICAgICAgcm9sZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICByZWZ1c2FsOiBtZXNzYWdlLnJlZnVzYWwgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvb2xfY2FsbHM6IHRvb2xfY2FsbHMubWFwKCh0b29sX2NhbGwsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB7IGZ1bmN0aW9uOiBmbiwgdHlwZSwgaWQsIC4uLnRvb2xSZXN0IH0gPSB0b29sX2NhbGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyBhcmd1bWVudHM6IGFyZ3MsIG5hbWUsIC4uLmZuUmVzdCB9ID0gZm4gfHwge307XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlkID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIGNob2ljZXNbJHtpbmRleH1dLnRvb2xfY2FsbHNbJHtpfV0uaWRcXG4ke3N0cihzbmFwc2hvdCl9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIGNob2ljZXNbJHtpbmRleH1dLnRvb2xfY2FsbHNbJHtpfV0udHlwZVxcbiR7c3RyKHNuYXBzaG90KX1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG5hbWUgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYG1pc3NpbmcgY2hvaWNlc1ske2luZGV4fV0udG9vbF9jYWxsc1ske2l9XS5mdW5jdGlvbi5uYW1lXFxuJHtzdHIoc25hcHNob3QpfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXJncyA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgbWlzc2luZyBjaG9pY2VzWyR7aW5kZXh9XS50b29sX2NhbGxzWyR7aX1dLmZ1bmN0aW9uLmFyZ3VtZW50c1xcbiR7c3RyKHNuYXBzaG90KX1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4udG9vbFJlc3QsIGlkLCB0eXBlLCBmdW5jdGlvbjogeyAuLi5mblJlc3QsIG5hbWUsIGFyZ3VtZW50czogYXJncyB9IH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5jaG9pY2VSZXN0LFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHsgLi4ubWVzc2FnZVJlc3QsIGNvbnRlbnQsIHJvbGUsIHJlZnVzYWw6IG1lc3NhZ2UucmVmdXNhbCA/PyBudWxsIH0sXG4gICAgICAgICAgICAgICAgZmluaXNoX3JlYXNvbixcbiAgICAgICAgICAgICAgICBpbmRleCxcbiAgICAgICAgICAgICAgICBsb2dwcm9icyxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pLFxuICAgICAgICBjcmVhdGVkLFxuICAgICAgICBtb2RlbCxcbiAgICAgICAgb2JqZWN0OiAnY2hhdC5jb21wbGV0aW9uJyxcbiAgICAgICAgLi4uKHN5c3RlbV9maW5nZXJwcmludCA/IHsgc3lzdGVtX2ZpbmdlcnByaW50IH0gOiB7fSksXG4gICAgfTtcbiAgICByZXR1cm4gbWF5YmVQYXJzZUNoYXRDb21wbGV0aW9uKGNvbXBsZXRpb24sIHBhcmFtcyk7XG59XG5mdW5jdGlvbiBzdHIoeCkge1xuICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh4KTtcbn1cbi8qKlxuICogRW5zdXJlcyB0aGUgZ2l2ZW4gYXJndW1lbnQgaXMgYW4gZW1wdHkgb2JqZWN0LCB1c2VmdWwgZm9yXG4gKiBhc3NlcnRpbmcgdGhhdCBhbGwga25vd24gcHJvcGVydGllcyBvbiBhbiBvYmplY3QgaGF2ZSBiZWVuXG4gKiBkZXN0cnVjdHVyZWQuXG4gKi9cbmZ1bmN0aW9uIGFzc2VydElzRW1wdHkob2JqKSB7XG4gICAgcmV0dXJuO1xufVxuZnVuY3Rpb24gYXNzZXJ0TmV2ZXIoX3gpIHsgfVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2hhdENvbXBsZXRpb25TdHJlYW0ubWpzLm1hcCIsImltcG9ydCB7IENoYXRDb21wbGV0aW9uU3RyZWFtIH0gZnJvbSBcIi4vQ2hhdENvbXBsZXRpb25TdHJlYW0ubWpzXCI7XG5leHBvcnQgY2xhc3MgQ2hhdENvbXBsZXRpb25TdHJlYW1pbmdSdW5uZXIgZXh0ZW5kcyBDaGF0Q29tcGxldGlvblN0cmVhbSB7XG4gICAgc3RhdGljIGZyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pIHtcbiAgICAgICAgY29uc3QgcnVubmVyID0gbmV3IENoYXRDb21wbGV0aW9uU3RyZWFtaW5nUnVubmVyKG51bGwpO1xuICAgICAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX2Zyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pKTtcbiAgICAgICAgcmV0dXJuIHJ1bm5lcjtcbiAgICB9XG4gICAgLyoqIEBkZXByZWNhdGVkIC0gcGxlYXNlIHVzZSBgcnVuVG9vbHNgIGluc3RlYWQuICovXG4gICAgc3RhdGljIHJ1bkZ1bmN0aW9ucyhjbGllbnQsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBydW5uZXIgPSBuZXcgQ2hhdENvbXBsZXRpb25TdHJlYW1pbmdSdW5uZXIobnVsbCk7XG4gICAgICAgIGNvbnN0IG9wdHMgPSB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAuLi5vcHRpb25zPy5oZWFkZXJzLCAnWC1TdGFpbmxlc3MtSGVscGVyLU1ldGhvZCc6ICdydW5GdW5jdGlvbnMnIH0sXG4gICAgICAgIH07XG4gICAgICAgIHJ1bm5lci5fcnVuKCgpID0+IHJ1bm5lci5fcnVuRnVuY3Rpb25zKGNsaWVudCwgcGFyYW1zLCBvcHRzKSk7XG4gICAgICAgIHJldHVybiBydW5uZXI7XG4gICAgfVxuICAgIHN0YXRpYyBydW5Ub29scyhjbGllbnQsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBydW5uZXIgPSBuZXcgQ2hhdENvbXBsZXRpb25TdHJlYW1pbmdSdW5uZXIoXG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgVE9ETyB0aGVzZSB0eXBlcyBhcmUgaW5jb21wYXRpYmxlXG4gICAgICAgIHBhcmFtcyk7XG4gICAgICAgIGNvbnN0IG9wdHMgPSB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAuLi5vcHRpb25zPy5oZWFkZXJzLCAnWC1TdGFpbmxlc3MtSGVscGVyLU1ldGhvZCc6ICdydW5Ub29scycgfSxcbiAgICAgICAgfTtcbiAgICAgICAgcnVubmVyLl9ydW4oKCkgPT4gcnVubmVyLl9ydW5Ub29scyhjbGllbnQsIHBhcmFtcywgb3B0cykpO1xuICAgICAgICByZXR1cm4gcnVubmVyO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNoYXRDb21wbGV0aW9uU3RyZWFtaW5nUnVubmVyLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBDaGF0Q29tcGxldGlvblJ1bm5lciB9IGZyb20gXCIuLi8uLi8uLi9saWIvQ2hhdENvbXBsZXRpb25SdW5uZXIubWpzXCI7XG5pbXBvcnQgeyBDaGF0Q29tcGxldGlvblN0cmVhbWluZ1J1bm5lciwgfSBmcm9tIFwiLi4vLi4vLi4vbGliL0NoYXRDb21wbGV0aW9uU3RyZWFtaW5nUnVubmVyLm1qc1wiO1xuaW1wb3J0IHsgQ2hhdENvbXBsZXRpb25TdHJlYW0gfSBmcm9tIFwiLi4vLi4vLi4vbGliL0NoYXRDb21wbGV0aW9uU3RyZWFtLm1qc1wiO1xuaW1wb3J0IHsgcGFyc2VDaGF0Q29tcGxldGlvbiwgdmFsaWRhdGVJbnB1dFRvb2xzIH0gZnJvbSBcIi4uLy4uLy4uL2xpYi9wYXJzZXIubWpzXCI7XG5leHBvcnQgeyBDaGF0Q29tcGxldGlvblN0cmVhbWluZ1J1bm5lciwgfSBmcm9tIFwiLi4vLi4vLi4vbGliL0NoYXRDb21wbGV0aW9uU3RyZWFtaW5nUnVubmVyLm1qc1wiO1xuZXhwb3J0IHsgUGFyc2luZ0Z1bmN0aW9uLCBQYXJzaW5nVG9vbEZ1bmN0aW9uLCB9IGZyb20gXCIuLi8uLi8uLi9saWIvUnVubmFibGVGdW5jdGlvbi5tanNcIjtcbmV4cG9ydCB7IENoYXRDb21wbGV0aW9uU3RyZWFtIH0gZnJvbSBcIi4uLy4uLy4uL2xpYi9DaGF0Q29tcGxldGlvblN0cmVhbS5tanNcIjtcbmV4cG9ydCB7IENoYXRDb21wbGV0aW9uUnVubmVyLCB9IGZyb20gXCIuLi8uLi8uLi9saWIvQ2hhdENvbXBsZXRpb25SdW5uZXIubWpzXCI7XG5leHBvcnQgY2xhc3MgQ29tcGxldGlvbnMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgcGFyc2UoYm9keSwgb3B0aW9ucykge1xuICAgICAgICB2YWxpZGF0ZUlucHV0VG9vbHMoYm9keS50b29scyk7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuY2hhdC5jb21wbGV0aW9uc1xuICAgICAgICAgICAgLmNyZWF0ZShib2R5LCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLm9wdGlvbnM/LmhlYWRlcnMsXG4gICAgICAgICAgICAgICAgJ1gtU3RhaW5sZXNzLUhlbHBlci1NZXRob2QnOiAnYmV0YS5jaGF0LmNvbXBsZXRpb25zLnBhcnNlJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pXG4gICAgICAgICAgICAuX3RoZW5VbndyYXAoKGNvbXBsZXRpb24pID0+IHBhcnNlQ2hhdENvbXBsZXRpb24oY29tcGxldGlvbiwgYm9keSkpO1xuICAgIH1cbiAgICBydW5GdW5jdGlvbnMoYm9keSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoYm9keS5zdHJlYW0pIHtcbiAgICAgICAgICAgIHJldHVybiBDaGF0Q29tcGxldGlvblN0cmVhbWluZ1J1bm5lci5ydW5GdW5jdGlvbnModGhpcy5fY2xpZW50LCBib2R5LCBvcHRpb25zKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gQ2hhdENvbXBsZXRpb25SdW5uZXIucnVuRnVuY3Rpb25zKHRoaXMuX2NsaWVudCwgYm9keSwgb3B0aW9ucyk7XG4gICAgfVxuICAgIHJ1blRvb2xzKGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGJvZHkuc3RyZWFtKSB7XG4gICAgICAgICAgICByZXR1cm4gQ2hhdENvbXBsZXRpb25TdHJlYW1pbmdSdW5uZXIucnVuVG9vbHModGhpcy5fY2xpZW50LCBib2R5LCBvcHRpb25zKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gQ2hhdENvbXBsZXRpb25SdW5uZXIucnVuVG9vbHModGhpcy5fY2xpZW50LCBib2R5LCBvcHRpb25zKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIGNoYXQgY29tcGxldGlvbiBzdHJlYW1cbiAgICAgKi9cbiAgICBzdHJlYW0oYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gQ2hhdENvbXBsZXRpb25TdHJlYW0uY3JlYXRlQ2hhdENvbXBsZXRpb24odGhpcy5fY2xpZW50LCBib2R5LCBvcHRpb25zKTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21wbGV0aW9ucy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tcGxldGlvbnNBUEkgZnJvbSBcIi4vY29tcGxldGlvbnMubWpzXCI7XG5leHBvcnQgY2xhc3MgQ2hhdCBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb21wbGV0aW9ucyA9IG5ldyBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9ucyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbn1cbihmdW5jdGlvbiAoQ2hhdCkge1xuICAgIENoYXQuQ29tcGxldGlvbnMgPSBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9ucztcbn0pKENoYXQgfHwgKENoYXQgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2hhdC5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuZXhwb3J0IGNsYXNzIFNlc3Npb25zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZSBhbiBlcGhlbWVyYWwgQVBJIHRva2VuIGZvciB1c2UgaW4gY2xpZW50LXNpZGUgYXBwbGljYXRpb25zIHdpdGggdGhlXG4gICAgICogUmVhbHRpbWUgQVBJLiBDYW4gYmUgY29uZmlndXJlZCB3aXRoIHRoZSBzYW1lIHNlc3Npb24gcGFyYW1ldGVycyBhcyB0aGVcbiAgICAgKiBgc2Vzc2lvbi51cGRhdGVgIGNsaWVudCBldmVudC5cbiAgICAgKlxuICAgICAqIEl0IHJlc3BvbmRzIHdpdGggYSBzZXNzaW9uIG9iamVjdCwgcGx1cyBhIGBjbGllbnRfc2VjcmV0YCBrZXkgd2hpY2ggY29udGFpbnMgYVxuICAgICAqIHVzYWJsZSBlcGhlbWVyYWwgQVBJIHRva2VuIHRoYXQgY2FuIGJlIHVzZWQgdG8gYXV0aGVudGljYXRlIGJyb3dzZXIgY2xpZW50cyBmb3JcbiAgICAgKiB0aGUgUmVhbHRpbWUgQVBJLlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IHNlc3Npb24gPVxuICAgICAqICAgYXdhaXQgY2xpZW50LmJldGEucmVhbHRpbWUuc2Vzc2lvbnMuY3JlYXRlKCk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgY3JlYXRlKGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvcmVhbHRpbWUvc2Vzc2lvbnMnLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlc3Npb25zLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5leHBvcnQgY2xhc3MgVHJhbnNjcmlwdGlvblNlc3Npb25zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZSBhbiBlcGhlbWVyYWwgQVBJIHRva2VuIGZvciB1c2UgaW4gY2xpZW50LXNpZGUgYXBwbGljYXRpb25zIHdpdGggdGhlXG4gICAgICogUmVhbHRpbWUgQVBJIHNwZWNpZmljYWxseSBmb3IgcmVhbHRpbWUgdHJhbnNjcmlwdGlvbnMuIENhbiBiZSBjb25maWd1cmVkIHdpdGhcbiAgICAgKiB0aGUgc2FtZSBzZXNzaW9uIHBhcmFtZXRlcnMgYXMgdGhlIGB0cmFuc2NyaXB0aW9uX3Nlc3Npb24udXBkYXRlYCBjbGllbnQgZXZlbnQuXG4gICAgICpcbiAgICAgKiBJdCByZXNwb25kcyB3aXRoIGEgc2Vzc2lvbiBvYmplY3QsIHBsdXMgYSBgY2xpZW50X3NlY3JldGAga2V5IHdoaWNoIGNvbnRhaW5zIGFcbiAgICAgKiB1c2FibGUgZXBoZW1lcmFsIEFQSSB0b2tlbiB0aGF0IGNhbiBiZSB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBicm93c2VyIGNsaWVudHMgZm9yXG4gICAgICogdGhlIFJlYWx0aW1lIEFQSS5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCB0cmFuc2NyaXB0aW9uU2Vzc2lvbiA9XG4gICAgICogICBhd2FpdCBjbGllbnQuYmV0YS5yZWFsdGltZS50cmFuc2NyaXB0aW9uU2Vzc2lvbnMuY3JlYXRlKCk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgY3JlYXRlKGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvcmVhbHRpbWUvdHJhbnNjcmlwdGlvbl9zZXNzaW9ucycsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHJhbnNjcmlwdGlvbi1zZXNzaW9ucy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0ICogYXMgU2Vzc2lvbnNBUEkgZnJvbSBcIi4vc2Vzc2lvbnMubWpzXCI7XG5pbXBvcnQgeyBTZXNzaW9ucywgfSBmcm9tIFwiLi9zZXNzaW9ucy5tanNcIjtcbmltcG9ydCAqIGFzIFRyYW5zY3JpcHRpb25TZXNzaW9uc0FQSSBmcm9tIFwiLi90cmFuc2NyaXB0aW9uLXNlc3Npb25zLm1qc1wiO1xuaW1wb3J0IHsgVHJhbnNjcmlwdGlvblNlc3Npb25zLCB9IGZyb20gXCIuL3RyYW5zY3JpcHRpb24tc2Vzc2lvbnMubWpzXCI7XG5leHBvcnQgY2xhc3MgUmVhbHRpbWUgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuc2Vzc2lvbnMgPSBuZXcgU2Vzc2lvbnNBUEkuU2Vzc2lvbnModGhpcy5fY2xpZW50KTtcbiAgICAgICAgdGhpcy50cmFuc2NyaXB0aW9uU2Vzc2lvbnMgPSBuZXcgVHJhbnNjcmlwdGlvblNlc3Npb25zQVBJLlRyYW5zY3JpcHRpb25TZXNzaW9ucyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbn1cblJlYWx0aW1lLlNlc3Npb25zID0gU2Vzc2lvbnM7XG5SZWFsdGltZS5UcmFuc2NyaXB0aW9uU2Vzc2lvbnMgPSBUcmFuc2NyaXB0aW9uU2Vzc2lvbnM7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZWFsdGltZS5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0IHsgaXNSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi8uLi8uLi9jb3JlLm1qc1wiO1xuaW1wb3J0IHsgQ3Vyc29yUGFnZSB9IGZyb20gXCIuLi8uLi8uLi9wYWdpbmF0aW9uLm1qc1wiO1xuLyoqXG4gKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICovXG5leHBvcnQgY2xhc3MgTWVzc2FnZXMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlIGEgbWVzc2FnZS5cbiAgICAgKlxuICAgICAqIEBkZXByZWNhdGVkIFRoZSBBc3Npc3RhbnRzIEFQSSBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHRoZSBSZXNwb25zZXMgQVBJXG4gICAgICovXG4gICAgY3JlYXRlKHRocmVhZElkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3RocmVhZHMvJHt0aHJlYWRJZH0vbWVzc2FnZXNgLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZSBhIG1lc3NhZ2UuXG4gICAgICpcbiAgICAgKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICAgICAqL1xuICAgIHJldHJpZXZlKHRocmVhZElkLCBtZXNzYWdlSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC90aHJlYWRzLyR7dGhyZWFkSWR9L21lc3NhZ2VzLyR7bWVzc2FnZUlkfWAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogTW9kaWZpZXMgYSBtZXNzYWdlLlxuICAgICAqXG4gICAgICogQGRlcHJlY2F0ZWQgVGhlIEFzc2lzdGFudHMgQVBJIGlzIGRlcHJlY2F0ZWQgaW4gZmF2b3Igb2YgdGhlIFJlc3BvbnNlcyBBUElcbiAgICAgKi9cbiAgICB1cGRhdGUodGhyZWFkSWQsIG1lc3NhZ2VJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC90aHJlYWRzLyR7dGhyZWFkSWR9L21lc3NhZ2VzLyR7bWVzc2FnZUlkfWAsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGxpc3QodGhyZWFkSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KHRocmVhZElkLCB7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdChgL3RocmVhZHMvJHt0aHJlYWRJZH0vbWVzc2FnZXNgLCBNZXNzYWdlc1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGVzIGEgbWVzc2FnZS5cbiAgICAgKlxuICAgICAqIEBkZXByZWNhdGVkIFRoZSBBc3Npc3RhbnRzIEFQSSBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHRoZSBSZXNwb25zZXMgQVBJXG4gICAgICovXG4gICAgZGVsKHRocmVhZElkLCBtZXNzYWdlSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5kZWxldGUoYC90aHJlYWRzLyR7dGhyZWFkSWR9L21lc3NhZ2VzLyR7bWVzc2FnZUlkfWAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgTWVzc2FnZXNQYWdlIGV4dGVuZHMgQ3Vyc29yUGFnZSB7XG59XG5NZXNzYWdlcy5NZXNzYWdlc1BhZ2UgPSBNZXNzYWdlc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tZXNzYWdlcy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0IHsgaXNSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb3JlLm1qc1wiO1xuaW1wb3J0IHsgQ3Vyc29yUGFnZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9wYWdpbmF0aW9uLm1qc1wiO1xuLyoqXG4gKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICovXG5leHBvcnQgY2xhc3MgU3RlcHMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgcmV0cmlldmUodGhyZWFkSWQsIHJ1bklkLCBzdGVwSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXRyaWV2ZSh0aHJlYWRJZCwgcnVuSWQsIHN0ZXBJZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL3RocmVhZHMvJHt0aHJlYWRJZH0vcnVucy8ke3J1bklkfS9zdGVwcy8ke3N0ZXBJZH1gLCB7XG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgbGlzdCh0aHJlYWRJZCwgcnVuSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KHRocmVhZElkLCBydW5JZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC90aHJlYWRzLyR7dGhyZWFkSWR9L3J1bnMvJHtydW5JZH0vc3RlcHNgLCBSdW5TdGVwc1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBSdW5TdGVwc1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cblN0ZXBzLlJ1blN0ZXBzUGFnZSA9IFJ1blN0ZXBzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0ZXBzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBBc3Npc3RhbnRTdHJlYW0gfSBmcm9tIFwiLi4vLi4vLi4vLi4vbGliL0Fzc2lzdGFudFN0cmVhbS5tanNcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgKiBhcyBTdGVwc0FQSSBmcm9tIFwiLi9zdGVwcy5tanNcIjtcbmltcG9ydCB7IFJ1blN0ZXBzUGFnZSwgU3RlcHMsIH0gZnJvbSBcIi4vc3RlcHMubWpzXCI7XG5pbXBvcnQgeyBDdXJzb3JQYWdlIH0gZnJvbSBcIi4uLy4uLy4uLy4uL3BhZ2luYXRpb24ubWpzXCI7XG4vKipcbiAqIEBkZXByZWNhdGVkIFRoZSBBc3Npc3RhbnRzIEFQSSBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHRoZSBSZXNwb25zZXMgQVBJXG4gKi9cbmV4cG9ydCBjbGFzcyBSdW5zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLnN0ZXBzID0gbmV3IFN0ZXBzQVBJLlN0ZXBzKHRoaXMuX2NsaWVudCk7XG4gICAgfVxuICAgIGNyZWF0ZSh0aHJlYWRJZCwgcGFyYW1zLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHsgaW5jbHVkZSwgLi4uYm9keSB9ID0gcGFyYW1zO1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC90aHJlYWRzLyR7dGhyZWFkSWR9L3J1bnNgLCB7XG4gICAgICAgICAgICBxdWVyeTogeyBpbmNsdWRlIH0sXG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgICAgICBzdHJlYW06IHBhcmFtcy5zdHJlYW0gPz8gZmFsc2UsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZXMgYSBydW4uXG4gICAgICpcbiAgICAgKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICAgICAqL1xuICAgIHJldHJpZXZlKHRocmVhZElkLCBydW5JZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL3RocmVhZHMvJHt0aHJlYWRJZH0vcnVucy8ke3J1bklkfWAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogTW9kaWZpZXMgYSBydW4uXG4gICAgICpcbiAgICAgKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICAgICAqL1xuICAgIHVwZGF0ZSh0aHJlYWRJZCwgcnVuSWQsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KGAvdGhyZWFkcy8ke3RocmVhZElkfS9ydW5zLyR7cnVuSWR9YCwge1xuICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgbGlzdCh0aHJlYWRJZCwgcXVlcnkgPSB7fSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0T3B0aW9ucyhxdWVyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxpc3QodGhyZWFkSWQsIHt9LCBxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXRBUElMaXN0KGAvdGhyZWFkcy8ke3RocmVhZElkfS9ydW5zYCwgUnVuc1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDYW5jZWxzIGEgcnVuIHRoYXQgaXMgYGluX3Byb2dyZXNzYC5cbiAgICAgKlxuICAgICAqIEBkZXByZWNhdGVkIFRoZSBBc3Npc3RhbnRzIEFQSSBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHRoZSBSZXNwb25zZXMgQVBJXG4gICAgICovXG4gICAgY2FuY2VsKHRocmVhZElkLCBydW5JZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC90aHJlYWRzLyR7dGhyZWFkSWR9L3J1bnMvJHtydW5JZH0vY2FuY2VsYCwge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBIGhlbHBlciB0byBjcmVhdGUgYSBydW4gYW4gcG9sbCBmb3IgYSB0ZXJtaW5hbCBzdGF0ZS4gTW9yZSBpbmZvcm1hdGlvbiBvbiBSdW5cbiAgICAgKiBsaWZlY3ljbGVzIGNhbiBiZSBmb3VuZCBoZXJlOlxuICAgICAqIGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2Fzc2lzdGFudHMvaG93LWl0LXdvcmtzL3J1bnMtYW5kLXJ1bi1zdGVwc1xuICAgICAqL1xuICAgIGFzeW5jIGNyZWF0ZUFuZFBvbGwodGhyZWFkSWQsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgcnVuID0gYXdhaXQgdGhpcy5jcmVhdGUodGhyZWFkSWQsIGJvZHksIG9wdGlvbnMpO1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5wb2xsKHRocmVhZElkLCBydW4uaWQsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGUgYSBSdW4gc3RyZWFtXG4gICAgICpcbiAgICAgKiBAZGVwcmVjYXRlZCB1c2UgYHN0cmVhbWAgaW5zdGVhZFxuICAgICAqL1xuICAgIGNyZWF0ZUFuZFN0cmVhbSh0aHJlYWRJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gQXNzaXN0YW50U3RyZWFtLmNyZWF0ZUFzc2lzdGFudFN0cmVhbSh0aHJlYWRJZCwgdGhpcy5fY2xpZW50LmJldGEudGhyZWFkcy5ydW5zLCBib2R5LCBvcHRpb25zKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQSBoZWxwZXIgdG8gcG9sbCBhIHJ1biBzdGF0dXMgdW50aWwgaXQgcmVhY2hlcyBhIHRlcm1pbmFsIHN0YXRlLiBNb3JlXG4gICAgICogaW5mb3JtYXRpb24gb24gUnVuIGxpZmVjeWNsZXMgY2FuIGJlIGZvdW5kIGhlcmU6XG4gICAgICogaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvYXNzaXN0YW50cy9ob3ctaXQtd29ya3MvcnVucy1hbmQtcnVuLXN0ZXBzXG4gICAgICovXG4gICAgYXN5bmMgcG9sbCh0aHJlYWRJZCwgcnVuSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgaGVhZGVycyA9IHsgLi4ub3B0aW9ucz8uaGVhZGVycywgJ1gtU3RhaW5sZXNzLVBvbGwtSGVscGVyJzogJ3RydWUnIH07XG4gICAgICAgIGlmIChvcHRpb25zPy5wb2xsSW50ZXJ2YWxNcykge1xuICAgICAgICAgICAgaGVhZGVyc1snWC1TdGFpbmxlc3MtQ3VzdG9tLVBvbGwtSW50ZXJ2YWwnXSA9IG9wdGlvbnMucG9sbEludGVydmFsTXMudG9TdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgeyBkYXRhOiBydW4sIHJlc3BvbnNlIH0gPSBhd2FpdCB0aGlzLnJldHJpZXZlKHRocmVhZElkLCBydW5JZCwge1xuICAgICAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgaGVhZGVyczogeyAuLi5vcHRpb25zPy5oZWFkZXJzLCAuLi5oZWFkZXJzIH0sXG4gICAgICAgICAgICB9KS53aXRoUmVzcG9uc2UoKTtcbiAgICAgICAgICAgIHN3aXRjaCAocnVuLnN0YXR1cykge1xuICAgICAgICAgICAgICAgIC8vSWYgd2UgYXJlIGluIGFueSBzb3J0IG9mIGludGVybWVkaWF0ZSBzdGF0ZSB3ZSBwb2xsXG4gICAgICAgICAgICAgICAgY2FzZSAncXVldWVkJzpcbiAgICAgICAgICAgICAgICBjYXNlICdpbl9wcm9ncmVzcyc6XG4gICAgICAgICAgICAgICAgY2FzZSAnY2FuY2VsbGluZyc6XG4gICAgICAgICAgICAgICAgICAgIGxldCBzbGVlcEludGVydmFsID0gNTAwMDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wdGlvbnM/LnBvbGxJbnRlcnZhbE1zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzbGVlcEludGVydmFsID0gb3B0aW9ucy5wb2xsSW50ZXJ2YWxNcztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGhlYWRlckludGVydmFsID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ29wZW5haS1wb2xsLWFmdGVyLW1zJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVhZGVySW50ZXJ2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBoZWFkZXJJbnRlcnZhbE1zID0gcGFyc2VJbnQoaGVhZGVySW50ZXJ2YWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNOYU4oaGVhZGVySW50ZXJ2YWxNcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2xlZXBJbnRlcnZhbCA9IGhlYWRlckludGVydmFsTXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHNsZWVwKHNsZWVwSW50ZXJ2YWwpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAvL1dlIHJldHVybiB0aGUgcnVuIGluIGFueSB0ZXJtaW5hbCBzdGF0ZS5cbiAgICAgICAgICAgICAgICBjYXNlICdyZXF1aXJlc19hY3Rpb24nOlxuICAgICAgICAgICAgICAgIGNhc2UgJ2luY29tcGxldGUnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ2NhbmNlbGxlZCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnY29tcGxldGVkJzpcbiAgICAgICAgICAgICAgICBjYXNlICdmYWlsZWQnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ2V4cGlyZWQnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcnVuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENyZWF0ZSBhIFJ1biBzdHJlYW1cbiAgICAgKi9cbiAgICBzdHJlYW0odGhyZWFkSWQsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIEFzc2lzdGFudFN0cmVhbS5jcmVhdGVBc3Npc3RhbnRTdHJlYW0odGhyZWFkSWQsIHRoaXMuX2NsaWVudC5iZXRhLnRocmVhZHMucnVucywgYm9keSwgb3B0aW9ucyk7XG4gICAgfVxuICAgIHN1Ym1pdFRvb2xPdXRwdXRzKHRocmVhZElkLCBydW5JZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC90aHJlYWRzLyR7dGhyZWFkSWR9L3J1bnMvJHtydW5JZH0vc3VibWl0X3Rvb2xfb3V0cHV0c2AsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgICAgIHN0cmVhbTogYm9keS5zdHJlYW0gPz8gZmFsc2UsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBIGhlbHBlciB0byBzdWJtaXQgYSB0b29sIG91dHB1dCB0byBhIHJ1biBhbmQgcG9sbCBmb3IgYSB0ZXJtaW5hbCBydW4gc3RhdGUuXG4gICAgICogTW9yZSBpbmZvcm1hdGlvbiBvbiBSdW4gbGlmZWN5Y2xlcyBjYW4gYmUgZm91bmQgaGVyZTpcbiAgICAgKiBodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hc3Npc3RhbnRzL2hvdy1pdC13b3Jrcy9ydW5zLWFuZC1ydW4tc3RlcHNcbiAgICAgKi9cbiAgICBhc3luYyBzdWJtaXRUb29sT3V0cHV0c0FuZFBvbGwodGhyZWFkSWQsIHJ1bklkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHJ1biA9IGF3YWl0IHRoaXMuc3VibWl0VG9vbE91dHB1dHModGhyZWFkSWQsIHJ1bklkLCBib2R5LCBvcHRpb25zKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMucG9sbCh0aHJlYWRJZCwgcnVuLmlkLCBvcHRpb25zKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogU3VibWl0IHRoZSB0b29sIG91dHB1dHMgZnJvbSBhIHByZXZpb3VzIHJ1biBhbmQgc3RyZWFtIHRoZSBydW4gdG8gYSB0ZXJtaW5hbFxuICAgICAqIHN0YXRlLiBNb3JlIGluZm9ybWF0aW9uIG9uIFJ1biBsaWZlY3ljbGVzIGNhbiBiZSBmb3VuZCBoZXJlOlxuICAgICAqIGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2Fzc2lzdGFudHMvaG93LWl0LXdvcmtzL3J1bnMtYW5kLXJ1bi1zdGVwc1xuICAgICAqL1xuICAgIHN1Ym1pdFRvb2xPdXRwdXRzU3RyZWFtKHRocmVhZElkLCBydW5JZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gQXNzaXN0YW50U3RyZWFtLmNyZWF0ZVRvb2xBc3Npc3RhbnRTdHJlYW0odGhyZWFkSWQsIHJ1bklkLCB0aGlzLl9jbGllbnQuYmV0YS50aHJlYWRzLnJ1bnMsIGJvZHksIG9wdGlvbnMpO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBSdW5zUGFnZSBleHRlbmRzIEN1cnNvclBhZ2Uge1xufVxuUnVucy5SdW5zUGFnZSA9IFJ1bnNQYWdlO1xuUnVucy5TdGVwcyA9IFN0ZXBzO1xuUnVucy5SdW5TdGVwc1BhZ2UgPSBSdW5TdGVwc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ydW5zLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBBc3Npc3RhbnRTdHJlYW0gfSBmcm9tIFwiLi4vLi4vLi4vbGliL0Fzc2lzdGFudFN0cmVhbS5tanNcIjtcbmltcG9ydCAqIGFzIE1lc3NhZ2VzQVBJIGZyb20gXCIuL21lc3NhZ2VzLm1qc1wiO1xuaW1wb3J0IHsgTWVzc2FnZXMsIE1lc3NhZ2VzUGFnZSwgfSBmcm9tIFwiLi9tZXNzYWdlcy5tanNcIjtcbmltcG9ydCAqIGFzIFJ1bnNBUEkgZnJvbSBcIi4vcnVucy9ydW5zLm1qc1wiO1xuaW1wb3J0IHsgUnVucywgUnVuc1BhZ2UsIH0gZnJvbSBcIi4vcnVucy9ydW5zLm1qc1wiO1xuLyoqXG4gKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICovXG5leHBvcnQgY2xhc3MgVGhyZWFkcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5ydW5zID0gbmV3IFJ1bnNBUEkuUnVucyh0aGlzLl9jbGllbnQpO1xuICAgICAgICB0aGlzLm1lc3NhZ2VzID0gbmV3IE1lc3NhZ2VzQVBJLk1lc3NhZ2VzKHRoaXMuX2NsaWVudCk7XG4gICAgfVxuICAgIGNyZWF0ZShib2R5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMoYm9keSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNyZWF0ZSh7fSwgYm9keSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvdGhyZWFkcycsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHRocmVhZC5cbiAgICAgKlxuICAgICAqIEBkZXByZWNhdGVkIFRoZSBBc3Npc3RhbnRzIEFQSSBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHRoZSBSZXNwb25zZXMgQVBJXG4gICAgICovXG4gICAgcmV0cmlldmUodGhyZWFkSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC90aHJlYWRzLyR7dGhyZWFkSWR9YCwge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBNb2RpZmllcyBhIHRocmVhZC5cbiAgICAgKlxuICAgICAqIEBkZXByZWNhdGVkIFRoZSBBc3Npc3RhbnRzIEFQSSBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHRoZSBSZXNwb25zZXMgQVBJXG4gICAgICovXG4gICAgdXBkYXRlKHRocmVhZElkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3RocmVhZHMvJHt0aHJlYWRJZH1gLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYSB0aHJlYWQuXG4gICAgICpcbiAgICAgKiBAZGVwcmVjYXRlZCBUaGUgQXNzaXN0YW50cyBBUEkgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiB0aGUgUmVzcG9uc2VzIEFQSVxuICAgICAqL1xuICAgIGRlbCh0aHJlYWRJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmRlbGV0ZShgL3RocmVhZHMvJHt0aHJlYWRJZH1gLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNyZWF0ZUFuZFJ1bihib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL3RocmVhZHMvcnVucycsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgICAgIHN0cmVhbTogYm9keS5zdHJlYW0gPz8gZmFsc2UsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBIGhlbHBlciB0byBjcmVhdGUgYSB0aHJlYWQsIHN0YXJ0IGEgcnVuIGFuZCB0aGVuIHBvbGwgZm9yIGEgdGVybWluYWwgc3RhdGUuXG4gICAgICogTW9yZSBpbmZvcm1hdGlvbiBvbiBSdW4gbGlmZWN5Y2xlcyBjYW4gYmUgZm91bmQgaGVyZTpcbiAgICAgKiBodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hc3Npc3RhbnRzL2hvdy1pdC13b3Jrcy9ydW5zLWFuZC1ydW4tc3RlcHNcbiAgICAgKi9cbiAgICBhc3luYyBjcmVhdGVBbmRSdW5Qb2xsKGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgcnVuID0gYXdhaXQgdGhpcy5jcmVhdGVBbmRSdW4oYm9keSwgb3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLnJ1bnMucG9sbChydW4udGhyZWFkX2lkLCBydW4uaWQsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGUgYSB0aHJlYWQgYW5kIHN0cmVhbSB0aGUgcnVuIGJhY2tcbiAgICAgKi9cbiAgICBjcmVhdGVBbmRSdW5TdHJlYW0oYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gQXNzaXN0YW50U3RyZWFtLmNyZWF0ZVRocmVhZEFzc2lzdGFudFN0cmVhbShib2R5LCB0aGlzLl9jbGllbnQuYmV0YS50aHJlYWRzLCBvcHRpb25zKTtcbiAgICB9XG59XG5UaHJlYWRzLlJ1bnMgPSBSdW5zO1xuVGhyZWFkcy5SdW5zUGFnZSA9IFJ1bnNQYWdlO1xuVGhyZWFkcy5NZXNzYWdlcyA9IE1lc3NhZ2VzO1xuVGhyZWFkcy5NZXNzYWdlc1BhZ2UgPSBNZXNzYWdlc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD10aHJlYWRzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgKiBhcyBBc3Npc3RhbnRzQVBJIGZyb20gXCIuL2Fzc2lzdGFudHMubWpzXCI7XG5pbXBvcnQgKiBhcyBDaGF0QVBJIGZyb20gXCIuL2NoYXQvY2hhdC5tanNcIjtcbmltcG9ydCB7IEFzc2lzdGFudHMsIEFzc2lzdGFudHNQYWdlLCB9IGZyb20gXCIuL2Fzc2lzdGFudHMubWpzXCI7XG5pbXBvcnQgKiBhcyBSZWFsdGltZUFQSSBmcm9tIFwiLi9yZWFsdGltZS9yZWFsdGltZS5tanNcIjtcbmltcG9ydCB7IFJlYWx0aW1lLCB9IGZyb20gXCIuL3JlYWx0aW1lL3JlYWx0aW1lLm1qc1wiO1xuaW1wb3J0ICogYXMgVGhyZWFkc0FQSSBmcm9tIFwiLi90aHJlYWRzL3RocmVhZHMubWpzXCI7XG5pbXBvcnQgeyBUaHJlYWRzLCB9IGZyb20gXCIuL3RocmVhZHMvdGhyZWFkcy5tanNcIjtcbmltcG9ydCB7IENoYXQgfSBmcm9tIFwiLi9jaGF0L2NoYXQubWpzXCI7XG5leHBvcnQgY2xhc3MgQmV0YSBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5yZWFsdGltZSA9IG5ldyBSZWFsdGltZUFQSS5SZWFsdGltZSh0aGlzLl9jbGllbnQpO1xuICAgICAgICB0aGlzLmNoYXQgPSBuZXcgQ2hhdEFQSS5DaGF0KHRoaXMuX2NsaWVudCk7XG4gICAgICAgIHRoaXMuYXNzaXN0YW50cyA9IG5ldyBBc3Npc3RhbnRzQVBJLkFzc2lzdGFudHModGhpcy5fY2xpZW50KTtcbiAgICAgICAgdGhpcy50aHJlYWRzID0gbmV3IFRocmVhZHNBUEkuVGhyZWFkcyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbn1cbkJldGEuUmVhbHRpbWUgPSBSZWFsdGltZTtcbkJldGEuQXNzaXN0YW50cyA9IEFzc2lzdGFudHM7XG5CZXRhLkFzc2lzdGFudHNQYWdlID0gQXNzaXN0YW50c1BhZ2U7XG5CZXRhLlRocmVhZHMgPSBUaHJlYWRzO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YmV0YS5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uL3Jlc291cmNlLm1qc1wiO1xuZXhwb3J0IGNsYXNzIENvbXBsZXRpb25zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2NvbXBsZXRpb25zJywgeyBib2R5LCAuLi5vcHRpb25zLCBzdHJlYW06IGJvZHkuc3RyZWFtID8/IGZhbHNlIH0pO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbXBsZXRpb25zLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5leHBvcnQgY2xhc3MgQ29udGVudCBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZSBDb250YWluZXIgRmlsZSBDb250ZW50XG4gICAgICovXG4gICAgcmV0cmlldmUoY29udGFpbmVySWQsIGZpbGVJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL2NvbnRhaW5lcnMvJHtjb250YWluZXJJZH0vZmlsZXMvJHtmaWxlSWR9L2NvbnRlbnRgLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyBBY2NlcHQ6ICdhcHBsaWNhdGlvbi9iaW5hcnknLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgICAgICBfX2JpbmFyeVJlc3BvbnNlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb250ZW50Lm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgKiBhcyBDb3JlIGZyb20gXCIuLi8uLi8uLi9jb3JlLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29udGVudEFQSSBmcm9tIFwiLi9jb250ZW50Lm1qc1wiO1xuaW1wb3J0IHsgQ29udGVudCB9IGZyb20gXCIuL2NvbnRlbnQubWpzXCI7XG5pbXBvcnQgeyBDdXJzb3JQYWdlIH0gZnJvbSBcIi4uLy4uLy4uL3BhZ2luYXRpb24ubWpzXCI7XG5leHBvcnQgY2xhc3MgRmlsZXMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29udGVudCA9IG5ldyBDb250ZW50QVBJLkNvbnRlbnQodGhpcy5fY2xpZW50KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ3JlYXRlIGEgQ29udGFpbmVyIEZpbGVcbiAgICAgKlxuICAgICAqIFlvdSBjYW4gc2VuZCBlaXRoZXIgYSBtdWx0aXBhcnQvZm9ybS1kYXRhIHJlcXVlc3Qgd2l0aCB0aGUgcmF3IGZpbGUgY29udGVudCwgb3JcbiAgICAgKiBhIEpTT04gcmVxdWVzdCB3aXRoIGEgZmlsZSBJRC5cbiAgICAgKi9cbiAgICBjcmVhdGUoY29udGFpbmVySWQsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KGAvY29udGFpbmVycy8ke2NvbnRhaW5lcklkfS9maWxlc2AsIENvcmUubXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zKHsgYm9keSwgLi4ub3B0aW9ucyB9KSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlIENvbnRhaW5lciBGaWxlXG4gICAgICovXG4gICAgcmV0cmlldmUoY29udGFpbmVySWQsIGZpbGVJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL2NvbnRhaW5lcnMvJHtjb250YWluZXJJZH0vZmlsZXMvJHtmaWxlSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGxpc3QoY29udGFpbmVySWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KGNvbnRhaW5lcklkLCB7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdChgL2NvbnRhaW5lcnMvJHtjb250YWluZXJJZH0vZmlsZXNgLCBGaWxlTGlzdFJlc3BvbnNlc1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERlbGV0ZSBDb250YWluZXIgRmlsZVxuICAgICAqL1xuICAgIGRlbChjb250YWluZXJJZCwgZmlsZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZGVsZXRlKGAvY29udGFpbmVycy8ke2NvbnRhaW5lcklkfS9maWxlcy8ke2ZpbGVJZH1gLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyBBY2NlcHQ6ICcqLyonLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBGaWxlTGlzdFJlc3BvbnNlc1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbkZpbGVzLkZpbGVMaXN0UmVzcG9uc2VzUGFnZSA9IEZpbGVMaXN0UmVzcG9uc2VzUGFnZTtcbkZpbGVzLkNvbnRlbnQgPSBDb250ZW50O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZmlsZXMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCB7IGlzUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vLi4vY29yZS5tanNcIjtcbmltcG9ydCAqIGFzIEZpbGVzQVBJIGZyb20gXCIuL2ZpbGVzL2ZpbGVzLm1qc1wiO1xuaW1wb3J0IHsgRmlsZUxpc3RSZXNwb25zZXNQYWdlLCBGaWxlcywgfSBmcm9tIFwiLi9maWxlcy9maWxlcy5tanNcIjtcbmltcG9ydCB7IEN1cnNvclBhZ2UgfSBmcm9tIFwiLi4vLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBDb250YWluZXJzIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmZpbGVzID0gbmV3IEZpbGVzQVBJLkZpbGVzKHRoaXMuX2NsaWVudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENyZWF0ZSBDb250YWluZXJcbiAgICAgKi9cbiAgICBjcmVhdGUoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9jb250YWluZXJzJywgeyBib2R5LCAuLi5vcHRpb25zIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZSBDb250YWluZXJcbiAgICAgKi9cbiAgICByZXRyaWV2ZShjb250YWluZXJJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL2NvbnRhaW5lcnMvJHtjb250YWluZXJJZH1gLCBvcHRpb25zKTtcbiAgICB9XG4gICAgbGlzdChxdWVyeSA9IHt9LCBvcHRpb25zKSB7XG4gICAgICAgIGlmIChpc1JlcXVlc3RPcHRpb25zKHF1ZXJ5KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMubGlzdCh7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdCgnL2NvbnRhaW5lcnMnLCBDb250YWluZXJMaXN0UmVzcG9uc2VzUGFnZSwgeyBxdWVyeSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRGVsZXRlIENvbnRhaW5lclxuICAgICAqL1xuICAgIGRlbChjb250YWluZXJJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmRlbGV0ZShgL2NvbnRhaW5lcnMvJHtjb250YWluZXJJZH1gLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyBBY2NlcHQ6ICcqLyonLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBDb250YWluZXJMaXN0UmVzcG9uc2VzUGFnZSBleHRlbmRzIEN1cnNvclBhZ2Uge1xufVxuQ29udGFpbmVycy5Db250YWluZXJMaXN0UmVzcG9uc2VzUGFnZSA9IENvbnRhaW5lckxpc3RSZXNwb25zZXNQYWdlO1xuQ29udGFpbmVycy5GaWxlcyA9IEZpbGVzO1xuQ29udGFpbmVycy5GaWxlTGlzdFJlc3BvbnNlc1BhZ2UgPSBGaWxlTGlzdFJlc3BvbnNlc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb250YWluZXJzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgKiBhcyBDb3JlIGZyb20gXCIuLi9jb3JlLm1qc1wiO1xuZXhwb3J0IGNsYXNzIEVtYmVkZGluZ3MgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbiBlbWJlZGRpbmcgdmVjdG9yIHJlcHJlc2VudGluZyB0aGUgaW5wdXQgdGV4dC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBjcmVhdGVFbWJlZGRpbmdSZXNwb25zZSA9XG4gICAgICogICBhd2FpdCBjbGllbnQuZW1iZWRkaW5ncy5jcmVhdGUoe1xuICAgICAqICAgICBpbnB1dDogJ1RoZSBxdWljayBicm93biBmb3gganVtcGVkIG92ZXIgdGhlIGxhenkgZG9nJyxcbiAgICAgKiAgICAgbW9kZWw6ICd0ZXh0LWVtYmVkZGluZy0zLXNtYWxsJyxcbiAgICAgKiAgIH0pO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IGhhc1VzZXJQcm92aWRlZEVuY29kaW5nRm9ybWF0ID0gISFib2R5LmVuY29kaW5nX2Zvcm1hdDtcbiAgICAgICAgLy8gTm8gZW5jb2RpbmdfZm9ybWF0IHNwZWNpZmllZCwgZGVmYXVsdGluZyB0byBiYXNlNjQgZm9yIHBlcmZvcm1hbmNlIHJlYXNvbnNcbiAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9vcGVuYWkvb3BlbmFpLW5vZGUvcHVsbC8xMzEyXG4gICAgICAgIGxldCBlbmNvZGluZ19mb3JtYXQgPSBoYXNVc2VyUHJvdmlkZWRFbmNvZGluZ0Zvcm1hdCA/IGJvZHkuZW5jb2RpbmdfZm9ybWF0IDogJ2Jhc2U2NCc7XG4gICAgICAgIGlmIChoYXNVc2VyUHJvdmlkZWRFbmNvZGluZ0Zvcm1hdCkge1xuICAgICAgICAgICAgQ29yZS5kZWJ1ZygnUmVxdWVzdCcsICdVc2VyIGRlZmluZWQgZW5jb2RpbmdfZm9ybWF0OicsIGJvZHkuZW5jb2RpbmdfZm9ybWF0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXNwb25zZSA9IHRoaXMuX2NsaWVudC5wb3N0KCcvZW1iZWRkaW5ncycsIHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgICAuLi5ib2R5LFxuICAgICAgICAgICAgICAgIGVuY29kaW5nX2Zvcm1hdDogZW5jb2RpbmdfZm9ybWF0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBpZiB0aGUgdXNlciBzcGVjaWZpZWQgYW4gZW5jb2RpbmdfZm9ybWF0LCByZXR1cm4gdGhlIHJlc3BvbnNlIGFzLWlzXG4gICAgICAgIGlmIChoYXNVc2VyUHJvdmlkZWRFbmNvZGluZ0Zvcm1hdCkge1xuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgICAgIC8vIGluIHRoaXMgc3RhZ2UsIHdlIGFyZSBzdXJlIHRoZSB1c2VyIGRpZCBub3Qgc3BlY2lmeSBhbiBlbmNvZGluZ19mb3JtYXRcbiAgICAgICAgLy8gYW5kIHdlIGRlZmF1bHRlZCB0byBiYXNlNjQgZm9yIHBlcmZvcm1hbmNlIHJlYXNvbnNcbiAgICAgICAgLy8gd2UgYXJlIHN1cmUgdGhlbiB0aGF0IHRoZSByZXNwb25zZSBpcyBiYXNlNjQgZW5jb2RlZCwgbGV0J3MgZGVjb2RlIGl0XG4gICAgICAgIC8vIHRoZSByZXR1cm5lZCByZXN1bHQgd2lsbCBiZSBhIGZsb2F0MzIgYXJyYXkgc2luY2UgdGhpcyBpcyBPcGVuQUkgQVBJJ3MgZGVmYXVsdCBlbmNvZGluZ1xuICAgICAgICBDb3JlLmRlYnVnKCdyZXNwb25zZScsICdEZWNvZGluZyBiYXNlNjQgZW1iZWRkaW5ncyB0byBmbG9hdDMyIGFycmF5Jyk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5fdGhlblVud3JhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSAmJiByZXNwb25zZS5kYXRhKSB7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UuZGF0YS5mb3JFYWNoKChlbWJlZGRpbmdCYXNlNjRPYmopID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZW1iZWRkaW5nQmFzZTY0U3RyID0gZW1iZWRkaW5nQmFzZTY0T2JqLmVtYmVkZGluZztcbiAgICAgICAgICAgICAgICAgICAgZW1iZWRkaW5nQmFzZTY0T2JqLmVtYmVkZGluZyA9IENvcmUudG9GbG9hdDMyQXJyYXkoZW1iZWRkaW5nQmFzZTY0U3RyKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZW1iZWRkaW5ncy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0IHsgaXNSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi8uLi8uLi9jb3JlLm1qc1wiO1xuaW1wb3J0IHsgQ3Vyc29yUGFnZSB9IGZyb20gXCIuLi8uLi8uLi9wYWdpbmF0aW9uLm1qc1wiO1xuZXhwb3J0IGNsYXNzIE91dHB1dEl0ZW1zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIC8qKlxuICAgICAqIEdldCBhbiBldmFsdWF0aW9uIHJ1biBvdXRwdXQgaXRlbSBieSBJRC5cbiAgICAgKi9cbiAgICByZXRyaWV2ZShldmFsSWQsIHJ1bklkLCBvdXRwdXRJdGVtSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC9ldmFscy8ke2V2YWxJZH0vcnVucy8ke3J1bklkfS9vdXRwdXRfaXRlbXMvJHtvdXRwdXRJdGVtSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGxpc3QoZXZhbElkLCBydW5JZCwgcXVlcnkgPSB7fSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0T3B0aW9ucyhxdWVyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxpc3QoZXZhbElkLCBydW5JZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC9ldmFscy8ke2V2YWxJZH0vcnVucy8ke3J1bklkfS9vdXRwdXRfaXRlbXNgLCBPdXRwdXRJdGVtTGlzdFJlc3BvbnNlc1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIE91dHB1dEl0ZW1MaXN0UmVzcG9uc2VzUGFnZSBleHRlbmRzIEN1cnNvclBhZ2Uge1xufVxuT3V0cHV0SXRlbXMuT3V0cHV0SXRlbUxpc3RSZXNwb25zZXNQYWdlID0gT3V0cHV0SXRlbUxpc3RSZXNwb25zZXNQYWdlO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b3V0cHV0LWl0ZW1zLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgKiBhcyBPdXRwdXRJdGVtc0FQSSBmcm9tIFwiLi9vdXRwdXQtaXRlbXMubWpzXCI7XG5pbXBvcnQgeyBPdXRwdXRJdGVtTGlzdFJlc3BvbnNlc1BhZ2UsIE91dHB1dEl0ZW1zLCB9IGZyb20gXCIuL291dHB1dC1pdGVtcy5tanNcIjtcbmltcG9ydCB7IEN1cnNvclBhZ2UgfSBmcm9tIFwiLi4vLi4vLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBSdW5zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm91dHB1dEl0ZW1zID0gbmV3IE91dHB1dEl0ZW1zQVBJLk91dHB1dEl0ZW1zKHRoaXMuX2NsaWVudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEtpY2tzIG9mZiBhIG5ldyBydW4gZm9yIGEgZ2l2ZW4gZXZhbHVhdGlvbiwgc3BlY2lmeWluZyB0aGUgZGF0YSBzb3VyY2UsIGFuZCB3aGF0XG4gICAgICogbW9kZWwgY29uZmlndXJhdGlvbiB0byB1c2UgdG8gdGVzdC4gVGhlIGRhdGFzb3VyY2Ugd2lsbCBiZSB2YWxpZGF0ZWQgYWdhaW5zdCB0aGVcbiAgICAgKiBzY2hlbWEgc3BlY2lmaWVkIGluIHRoZSBjb25maWcgb2YgdGhlIGV2YWx1YXRpb24uXG4gICAgICovXG4gICAgY3JlYXRlKGV2YWxJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC9ldmFscy8ke2V2YWxJZH0vcnVuc2AsIHsgYm9keSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0IGFuIGV2YWx1YXRpb24gcnVuIGJ5IElELlxuICAgICAqL1xuICAgIHJldHJpZXZlKGV2YWxJZCwgcnVuSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC9ldmFscy8ke2V2YWxJZH0vcnVucy8ke3J1bklkfWAsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBsaXN0KGV2YWxJZCwgcXVlcnkgPSB7fSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0T3B0aW9ucyhxdWVyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxpc3QoZXZhbElkLCB7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdChgL2V2YWxzLyR7ZXZhbElkfS9ydW5zYCwgUnVuTGlzdFJlc3BvbnNlc1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERlbGV0ZSBhbiBldmFsIHJ1bi5cbiAgICAgKi9cbiAgICBkZWwoZXZhbElkLCBydW5JZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmRlbGV0ZShgL2V2YWxzLyR7ZXZhbElkfS9ydW5zLyR7cnVuSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENhbmNlbCBhbiBvbmdvaW5nIGV2YWx1YXRpb24gcnVuLlxuICAgICAqL1xuICAgIGNhbmNlbChldmFsSWQsIHJ1bklkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL2V2YWxzLyR7ZXZhbElkfS9ydW5zLyR7cnVuSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFJ1bkxpc3RSZXNwb25zZXNQYWdlIGV4dGVuZHMgQ3Vyc29yUGFnZSB7XG59XG5SdW5zLlJ1bkxpc3RSZXNwb25zZXNQYWdlID0gUnVuTGlzdFJlc3BvbnNlc1BhZ2U7XG5SdW5zLk91dHB1dEl0ZW1zID0gT3V0cHV0SXRlbXM7XG5SdW5zLk91dHB1dEl0ZW1MaXN0UmVzcG9uc2VzUGFnZSA9IE91dHB1dEl0ZW1MaXN0UmVzcG9uc2VzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJ1bnMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCB7IGlzUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vLi4vY29yZS5tanNcIjtcbmltcG9ydCAqIGFzIFJ1bnNBUEkgZnJvbSBcIi4vcnVucy9ydW5zLm1qc1wiO1xuaW1wb3J0IHsgUnVuTGlzdFJlc3BvbnNlc1BhZ2UsIFJ1bnMsIH0gZnJvbSBcIi4vcnVucy9ydW5zLm1qc1wiO1xuaW1wb3J0IHsgQ3Vyc29yUGFnZSB9IGZyb20gXCIuLi8uLi9wYWdpbmF0aW9uLm1qc1wiO1xuZXhwb3J0IGNsYXNzIEV2YWxzIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLnJ1bnMgPSBuZXcgUnVuc0FQSS5SdW5zKHRoaXMuX2NsaWVudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENyZWF0ZSB0aGUgc3RydWN0dXJlIG9mIGFuIGV2YWx1YXRpb24gdGhhdCBjYW4gYmUgdXNlZCB0byB0ZXN0IGEgbW9kZWwnc1xuICAgICAqIHBlcmZvcm1hbmNlLiBBbiBldmFsdWF0aW9uIGlzIGEgc2V0IG9mIHRlc3RpbmcgY3JpdGVyaWEgYW5kIHRoZSBjb25maWcgZm9yIGFcbiAgICAgKiBkYXRhIHNvdXJjZSwgd2hpY2ggZGljdGF0ZXMgdGhlIHNjaGVtYSBvZiB0aGUgZGF0YSB1c2VkIGluIHRoZSBldmFsdWF0aW9uLiBBZnRlclxuICAgICAqIGNyZWF0aW5nIGFuIGV2YWx1YXRpb24sIHlvdSBjYW4gcnVuIGl0IG9uIGRpZmZlcmVudCBtb2RlbHMgYW5kIG1vZGVsIHBhcmFtZXRlcnMuXG4gICAgICogV2Ugc3VwcG9ydCBzZXZlcmFsIHR5cGVzIG9mIGdyYWRlcnMgYW5kIGRhdGFzb3VyY2VzLiBGb3IgbW9yZSBpbmZvcm1hdGlvbiwgc2VlXG4gICAgICogdGhlIFtFdmFscyBndWlkZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvZ3VpZGVzL2V2YWxzKS5cbiAgICAgKi9cbiAgICBjcmVhdGUoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9ldmFscycsIHsgYm9keSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0IGFuIGV2YWx1YXRpb24gYnkgSUQuXG4gICAgICovXG4gICAgcmV0cmlldmUoZXZhbElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0KGAvZXZhbHMvJHtldmFsSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSBjZXJ0YWluIHByb3BlcnRpZXMgb2YgYW4gZXZhbHVhdGlvbi5cbiAgICAgKi9cbiAgICB1cGRhdGUoZXZhbElkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL2V2YWxzLyR7ZXZhbElkfWAsIHsgYm9keSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG4gICAgbGlzdChxdWVyeSA9IHt9LCBvcHRpb25zKSB7XG4gICAgICAgIGlmIChpc1JlcXVlc3RPcHRpb25zKHF1ZXJ5KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMubGlzdCh7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdCgnL2V2YWxzJywgRXZhbExpc3RSZXNwb25zZXNQYWdlLCB7IHF1ZXJ5LCAuLi5vcHRpb25zIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYW4gZXZhbHVhdGlvbi5cbiAgICAgKi9cbiAgICBkZWwoZXZhbElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZGVsZXRlKGAvZXZhbHMvJHtldmFsSWR9YCwgb3B0aW9ucyk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEV2YWxMaXN0UmVzcG9uc2VzUGFnZSBleHRlbmRzIEN1cnNvclBhZ2Uge1xufVxuRXZhbHMuRXZhbExpc3RSZXNwb25zZXNQYWdlID0gRXZhbExpc3RSZXNwb25zZXNQYWdlO1xuRXZhbHMuUnVucyA9IFJ1bnM7XG5FdmFscy5SdW5MaXN0UmVzcG9uc2VzUGFnZSA9IFJ1bkxpc3RSZXNwb25zZXNQYWdlO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXZhbHMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCB7IGlzUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vY29yZS5tanNcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIi4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBBUElDb25uZWN0aW9uVGltZW91dEVycm9yIH0gZnJvbSBcIi4uL2Vycm9yLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29yZSBmcm9tIFwiLi4vY29yZS5tanNcIjtcbmltcG9ydCB7IEN1cnNvclBhZ2UgfSBmcm9tIFwiLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBGaWxlcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICAvKipcbiAgICAgKiBVcGxvYWQgYSBmaWxlIHRoYXQgY2FuIGJlIHVzZWQgYWNyb3NzIHZhcmlvdXMgZW5kcG9pbnRzLiBJbmRpdmlkdWFsIGZpbGVzIGNhbiBiZVxuICAgICAqIHVwIHRvIDUxMiBNQiwgYW5kIHRoZSBzaXplIG9mIGFsbCBmaWxlcyB1cGxvYWRlZCBieSBvbmUgb3JnYW5pemF0aW9uIGNhbiBiZSB1cFxuICAgICAqIHRvIDEwMCBHQi5cbiAgICAgKlxuICAgICAqIFRoZSBBc3Npc3RhbnRzIEFQSSBzdXBwb3J0cyBmaWxlcyB1cCB0byAyIG1pbGxpb24gdG9rZW5zIGFuZCBvZiBzcGVjaWZpYyBmaWxlXG4gICAgICogdHlwZXMuIFNlZSB0aGVcbiAgICAgKiBbQXNzaXN0YW50cyBUb29scyBndWlkZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvYXNzaXN0YW50cy90b29scykgZm9yXG4gICAgICogZGV0YWlscy5cbiAgICAgKlxuICAgICAqIFRoZSBGaW5lLXR1bmluZyBBUEkgb25seSBzdXBwb3J0cyBgLmpzb25sYCBmaWxlcy4gVGhlIGlucHV0IGFsc28gaGFzIGNlcnRhaW5cbiAgICAgKiByZXF1aXJlZCBmb3JtYXRzIGZvciBmaW5lLXR1bmluZ1xuICAgICAqIFtjaGF0XShodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hcGktcmVmZXJlbmNlL2ZpbmUtdHVuaW5nL2NoYXQtaW5wdXQpIG9yXG4gICAgICogW2NvbXBsZXRpb25zXShodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hcGktcmVmZXJlbmNlL2ZpbmUtdHVuaW5nL2NvbXBsZXRpb25zLWlucHV0KVxuICAgICAqIG1vZGVscy5cbiAgICAgKlxuICAgICAqIFRoZSBCYXRjaCBBUEkgb25seSBzdXBwb3J0cyBgLmpzb25sYCBmaWxlcyB1cCB0byAyMDAgTUIgaW4gc2l6ZS4gVGhlIGlucHV0IGFsc29cbiAgICAgKiBoYXMgYSBzcGVjaWZpYyByZXF1aXJlZFxuICAgICAqIFtmb3JtYXRdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2FwaS1yZWZlcmVuY2UvYmF0Y2gvcmVxdWVzdC1pbnB1dCkuXG4gICAgICpcbiAgICAgKiBQbGVhc2UgW2NvbnRhY3QgdXNdKGh0dHBzOi8vaGVscC5vcGVuYWkuY29tLykgaWYgeW91IG5lZWQgdG8gaW5jcmVhc2UgdGhlc2VcbiAgICAgKiBzdG9yYWdlIGxpbWl0cy5cbiAgICAgKi9cbiAgICBjcmVhdGUoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9maWxlcycsIENvcmUubXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zKHsgYm9keSwgLi4ub3B0aW9ucyB9KSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgaW5mb3JtYXRpb24gYWJvdXQgYSBzcGVjaWZpYyBmaWxlLlxuICAgICAqL1xuICAgIHJldHJpZXZlKGZpbGVJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL2ZpbGVzLyR7ZmlsZUlkfWAsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBsaXN0KHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KHt9LCBxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXRBUElMaXN0KCcvZmlsZXMnLCBGaWxlT2JqZWN0c1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERlbGV0ZSBhIGZpbGUuXG4gICAgICovXG4gICAgZGVsKGZpbGVJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmRlbGV0ZShgL2ZpbGVzLyR7ZmlsZUlkfWAsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBjb250ZW50cyBvZiB0aGUgc3BlY2lmaWVkIGZpbGUuXG4gICAgICovXG4gICAgY29udGVudChmaWxlSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC9maWxlcy8ke2ZpbGVJZH0vY29udGVudGAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7IEFjY2VwdDogJ2FwcGxpY2F0aW9uL2JpbmFyeScsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgICAgIF9fYmluYXJ5UmVzcG9uc2U6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBjb250ZW50cyBvZiB0aGUgc3BlY2lmaWVkIGZpbGUuXG4gICAgICpcbiAgICAgKiBAZGVwcmVjYXRlZCBUaGUgYC5jb250ZW50KClgIG1ldGhvZCBzaG91bGQgYmUgdXNlZCBpbnN0ZWFkXG4gICAgICovXG4gICAgcmV0cmlldmVDb250ZW50KGZpbGVJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL2ZpbGVzLyR7ZmlsZUlkfS9jb250ZW50YCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFdhaXRzIGZvciB0aGUgZ2l2ZW4gZmlsZSB0byBiZSBwcm9jZXNzZWQsIGRlZmF1bHQgdGltZW91dCBpcyAzMCBtaW5zLlxuICAgICAqL1xuICAgIGFzeW5jIHdhaXRGb3JQcm9jZXNzaW5nKGlkLCB7IHBvbGxJbnRlcnZhbCA9IDUwMDAsIG1heFdhaXQgPSAzMCAqIDYwICogMTAwMCB9ID0ge30pIHtcbiAgICAgICAgY29uc3QgVEVSTUlOQUxfU1RBVEVTID0gbmV3IFNldChbJ3Byb2Nlc3NlZCcsICdlcnJvcicsICdkZWxldGVkJ10pO1xuICAgICAgICBjb25zdCBzdGFydCA9IERhdGUubm93KCk7XG4gICAgICAgIGxldCBmaWxlID0gYXdhaXQgdGhpcy5yZXRyaWV2ZShpZCk7XG4gICAgICAgIHdoaWxlICghZmlsZS5zdGF0dXMgfHwgIVRFUk1JTkFMX1NUQVRFUy5oYXMoZmlsZS5zdGF0dXMpKSB7XG4gICAgICAgICAgICBhd2FpdCBzbGVlcChwb2xsSW50ZXJ2YWwpO1xuICAgICAgICAgICAgZmlsZSA9IGF3YWl0IHRoaXMucmV0cmlldmUoaWQpO1xuICAgICAgICAgICAgaWYgKERhdGUubm93KCkgLSBzdGFydCA+IG1heFdhaXQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGBHaXZpbmcgdXAgb24gd2FpdGluZyBmb3IgZmlsZSAke2lkfSB0byBmaW5pc2ggcHJvY2Vzc2luZyBhZnRlciAke21heFdhaXR9IG1pbGxpc2Vjb25kcy5gLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmaWxlO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBGaWxlT2JqZWN0c1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbkZpbGVzLkZpbGVPYmplY3RzUGFnZSA9IEZpbGVPYmplY3RzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZpbGVzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5leHBvcnQgY2xhc3MgTWV0aG9kcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1ldGhvZHMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi8uLi9yZXNvdXJjZS5tanNcIjtcbmV4cG9ydCBjbGFzcyBHcmFkZXJzIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIC8qKlxuICAgICAqIFJ1biBhIGdyYWRlci5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5maW5lVHVuaW5nLmFscGhhLmdyYWRlcnMucnVuKHtcbiAgICAgKiAgIGdyYWRlcjoge1xuICAgICAqICAgICBpbnB1dDogJ2lucHV0JyxcbiAgICAgKiAgICAgbmFtZTogJ25hbWUnLFxuICAgICAqICAgICBvcGVyYXRpb246ICdlcScsXG4gICAgICogICAgIHJlZmVyZW5jZTogJ3JlZmVyZW5jZScsXG4gICAgICogICAgIHR5cGU6ICdzdHJpbmdfY2hlY2snLFxuICAgICAqICAgfSxcbiAgICAgKiAgIG1vZGVsX3NhbXBsZTogJ21vZGVsX3NhbXBsZScsXG4gICAgICogICByZWZlcmVuY2VfYW5zd2VyOiAnc3RyaW5nJyxcbiAgICAgKiB9KTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBydW4oYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9maW5lX3R1bmluZy9hbHBoYS9ncmFkZXJzL3J1bicsIHsgYm9keSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogVmFsaWRhdGUgYSBncmFkZXIuXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgcmVzcG9uc2UgPVxuICAgICAqICAgYXdhaXQgY2xpZW50LmZpbmVUdW5pbmcuYWxwaGEuZ3JhZGVycy52YWxpZGF0ZSh7XG4gICAgICogICAgIGdyYWRlcjoge1xuICAgICAqICAgICAgIGlucHV0OiAnaW5wdXQnLFxuICAgICAqICAgICAgIG5hbWU6ICduYW1lJyxcbiAgICAgKiAgICAgICBvcGVyYXRpb246ICdlcScsXG4gICAgICogICAgICAgcmVmZXJlbmNlOiAncmVmZXJlbmNlJyxcbiAgICAgKiAgICAgICB0eXBlOiAnc3RyaW5nX2NoZWNrJyxcbiAgICAgKiAgICAgfSxcbiAgICAgKiAgIH0pO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIHZhbGlkYXRlKGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvZmluZV90dW5pbmcvYWxwaGEvZ3JhZGVycy92YWxpZGF0ZScsIHsgYm9keSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ncmFkZXJzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgKiBhcyBHcmFkZXJzQVBJIGZyb20gXCIuL2dyYWRlcnMubWpzXCI7XG5pbXBvcnQgeyBHcmFkZXJzLCB9IGZyb20gXCIuL2dyYWRlcnMubWpzXCI7XG5leHBvcnQgY2xhc3MgQWxwaGEgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuZ3JhZGVycyA9IG5ldyBHcmFkZXJzQVBJLkdyYWRlcnModGhpcy5fY2xpZW50KTtcbiAgICB9XG59XG5BbHBoYS5HcmFkZXJzID0gR3JhZGVycztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFscGhhLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcIi4uLy4uLy4uL3BhZ2luYXRpb24ubWpzXCI7XG5leHBvcnQgY2xhc3MgUGVybWlzc2lvbnMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogKipOT1RFOioqIENhbGxpbmcgdGhpcyBlbmRwb2ludCByZXF1aXJlcyBhbiBbYWRtaW4gQVBJIGtleV0oLi4vYWRtaW4tYXBpLWtleXMpLlxuICAgICAqXG4gICAgICogVGhpcyBlbmFibGVzIG9yZ2FuaXphdGlvbiBvd25lcnMgdG8gc2hhcmUgZmluZS10dW5lZCBtb2RlbHMgd2l0aCBvdGhlciBwcm9qZWN0c1xuICAgICAqIGluIHRoZWlyIG9yZ2FuaXphdGlvbi5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiAvLyBBdXRvbWF0aWNhbGx5IGZldGNoZXMgbW9yZSBwYWdlcyBhcyBuZWVkZWQuXG4gICAgICogZm9yIGF3YWl0IChjb25zdCBwZXJtaXNzaW9uQ3JlYXRlUmVzcG9uc2Ugb2YgY2xpZW50LmZpbmVUdW5pbmcuY2hlY2twb2ludHMucGVybWlzc2lvbnMuY3JlYXRlKFxuICAgICAqICAgJ2Z0OmdwdC00by1taW5pLTIwMjQtMDctMTg6b3JnOndlYXRoZXI6QjdSOVZqUWQnLFxuICAgICAqICAgeyBwcm9qZWN0X2lkczogWydzdHJpbmcnXSB9LFxuICAgICAqICkpIHtcbiAgICAgKiAgIC8vIC4uLlxuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBjcmVhdGUoZmluZVR1bmVkTW9kZWxDaGVja3BvaW50LCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdChgL2ZpbmVfdHVuaW5nL2NoZWNrcG9pbnRzLyR7ZmluZVR1bmVkTW9kZWxDaGVja3BvaW50fS9wZXJtaXNzaW9uc2AsIFBlcm1pc3Npb25DcmVhdGVSZXNwb25zZXNQYWdlLCB7IGJvZHksIG1ldGhvZDogJ3Bvc3QnLCAuLi5vcHRpb25zIH0pO1xuICAgIH1cbiAgICByZXRyaWV2ZShmaW5lVHVuZWRNb2RlbENoZWNrcG9pbnQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXRyaWV2ZShmaW5lVHVuZWRNb2RlbENoZWNrcG9pbnQsIHt9LCBxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC9maW5lX3R1bmluZy9jaGVja3BvaW50cy8ke2ZpbmVUdW5lZE1vZGVsQ2hlY2twb2ludH0vcGVybWlzc2lvbnNgLCB7XG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiAqKk5PVEU6KiogVGhpcyBlbmRwb2ludCByZXF1aXJlcyBhbiBbYWRtaW4gQVBJIGtleV0oLi4vYWRtaW4tYXBpLWtleXMpLlxuICAgICAqXG4gICAgICogT3JnYW5pemF0aW9uIG93bmVycyBjYW4gdXNlIHRoaXMgZW5kcG9pbnQgdG8gZGVsZXRlIGEgcGVybWlzc2lvbiBmb3IgYVxuICAgICAqIGZpbmUtdHVuZWQgbW9kZWwgY2hlY2twb2ludC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBwZXJtaXNzaW9uID1cbiAgICAgKiAgIGF3YWl0IGNsaWVudC5maW5lVHVuaW5nLmNoZWNrcG9pbnRzLnBlcm1pc3Npb25zLmRlbChcbiAgICAgKiAgICAgJ2Z0OmdwdC00by1taW5pLTIwMjQtMDctMTg6b3JnOndlYXRoZXI6QjdSOVZqUWQnLFxuICAgICAqICAgICAnY3BfemM0UTdNUDZYeHVsY1Z6ajRNWmR3c0FCJyxcbiAgICAgKiAgICk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgZGVsKGZpbmVUdW5lZE1vZGVsQ2hlY2twb2ludCwgcGVybWlzc2lvbklkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZGVsZXRlKGAvZmluZV90dW5pbmcvY2hlY2twb2ludHMvJHtmaW5lVHVuZWRNb2RlbENoZWNrcG9pbnR9L3Blcm1pc3Npb25zLyR7cGVybWlzc2lvbklkfWAsIG9wdGlvbnMpO1xuICAgIH1cbn1cbi8qKlxuICogTm90ZTogbm8gcGFnaW5hdGlvbiBhY3R1YWxseSBvY2N1cnMgeWV0LCB0aGlzIGlzIGZvciBmb3J3YXJkcy1jb21wYXRpYmlsaXR5LlxuICovXG5leHBvcnQgY2xhc3MgUGVybWlzc2lvbkNyZWF0ZVJlc3BvbnNlc1BhZ2UgZXh0ZW5kcyBQYWdlIHtcbn1cblBlcm1pc3Npb25zLlBlcm1pc3Npb25DcmVhdGVSZXNwb25zZXNQYWdlID0gUGVybWlzc2lvbkNyZWF0ZVJlc3BvbnNlc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wZXJtaXNzaW9ucy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0ICogYXMgUGVybWlzc2lvbnNBUEkgZnJvbSBcIi4vcGVybWlzc2lvbnMubWpzXCI7XG5pbXBvcnQgeyBQZXJtaXNzaW9uQ3JlYXRlUmVzcG9uc2VzUGFnZSwgUGVybWlzc2lvbnMsIH0gZnJvbSBcIi4vcGVybWlzc2lvbnMubWpzXCI7XG5leHBvcnQgY2xhc3MgQ2hlY2twb2ludHMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMucGVybWlzc2lvbnMgPSBuZXcgUGVybWlzc2lvbnNBUEkuUGVybWlzc2lvbnModGhpcy5fY2xpZW50KTtcbiAgICB9XG59XG5DaGVja3BvaW50cy5QZXJtaXNzaW9ucyA9IFBlcm1pc3Npb25zO1xuQ2hlY2twb2ludHMuUGVybWlzc2lvbkNyZWF0ZVJlc3BvbnNlc1BhZ2UgPSBQZXJtaXNzaW9uQ3JlYXRlUmVzcG9uc2VzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNoZWNrcG9pbnRzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBDdXJzb3JQYWdlIH0gZnJvbSBcIi4uLy4uLy4uL3BhZ2luYXRpb24ubWpzXCI7XG5leHBvcnQgY2xhc3MgQ2hlY2twb2ludHMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgbGlzdChmaW5lVHVuaW5nSm9iSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KGZpbmVUdW5pbmdKb2JJZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC9maW5lX3R1bmluZy9qb2JzLyR7ZmluZVR1bmluZ0pvYklkfS9jaGVja3BvaW50c2AsIEZpbmVUdW5pbmdKb2JDaGVja3BvaW50c1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEZpbmVUdW5pbmdKb2JDaGVja3BvaW50c1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbkNoZWNrcG9pbnRzLkZpbmVUdW5pbmdKb2JDaGVja3BvaW50c1BhZ2UgPSBGaW5lVHVuaW5nSm9iQ2hlY2twb2ludHNQYWdlO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2hlY2twb2ludHMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCB7IGlzUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vLi4vLi4vY29yZS5tanNcIjtcbmltcG9ydCAqIGFzIENoZWNrcG9pbnRzQVBJIGZyb20gXCIuL2NoZWNrcG9pbnRzLm1qc1wiO1xuaW1wb3J0IHsgQ2hlY2twb2ludHMsIEZpbmVUdW5pbmdKb2JDaGVja3BvaW50c1BhZ2UsIH0gZnJvbSBcIi4vY2hlY2twb2ludHMubWpzXCI7XG5pbXBvcnQgeyBDdXJzb3JQYWdlIH0gZnJvbSBcIi4uLy4uLy4uL3BhZ2luYXRpb24ubWpzXCI7XG5leHBvcnQgY2xhc3MgSm9icyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jaGVja3BvaW50cyA9IG5ldyBDaGVja3BvaW50c0FQSS5DaGVja3BvaW50cyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgZmluZS10dW5pbmcgam9iIHdoaWNoIGJlZ2lucyB0aGUgcHJvY2VzcyBvZiBjcmVhdGluZyBhIG5ldyBtb2RlbCBmcm9tXG4gICAgICogYSBnaXZlbiBkYXRhc2V0LlxuICAgICAqXG4gICAgICogUmVzcG9uc2UgaW5jbHVkZXMgZGV0YWlscyBvZiB0aGUgZW5xdWV1ZWQgam9iIGluY2x1ZGluZyBqb2Igc3RhdHVzIGFuZCB0aGUgbmFtZVxuICAgICAqIG9mIHRoZSBmaW5lLXR1bmVkIG1vZGVscyBvbmNlIGNvbXBsZXRlLlxuICAgICAqXG4gICAgICogW0xlYXJuIG1vcmUgYWJvdXQgZmluZS10dW5pbmddKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2d1aWRlcy9maW5lLXR1bmluZylcbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBmaW5lVHVuaW5nSm9iID0gYXdhaXQgY2xpZW50LmZpbmVUdW5pbmcuam9icy5jcmVhdGUoe1xuICAgICAqICAgbW9kZWw6ICdncHQtNG8tbWluaScsXG4gICAgICogICB0cmFpbmluZ19maWxlOiAnZmlsZS1hYmMxMjMnLFxuICAgICAqIH0pO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2ZpbmVfdHVuaW5nL2pvYnMnLCB7IGJvZHksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdldCBpbmZvIGFib3V0IGEgZmluZS10dW5pbmcgam9iLlxuICAgICAqXG4gICAgICogW0xlYXJuIG1vcmUgYWJvdXQgZmluZS10dW5pbmddKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2d1aWRlcy9maW5lLXR1bmluZylcbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBmaW5lVHVuaW5nSm9iID0gYXdhaXQgY2xpZW50LmZpbmVUdW5pbmcuam9icy5yZXRyaWV2ZShcbiAgICAgKiAgICdmdC1BRjFXb1JxZDNhSkFIc3FjOU5ZN2lMOEYnLFxuICAgICAqICk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgcmV0cmlldmUoZmluZVR1bmluZ0pvYklkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0KGAvZmluZV90dW5pbmcvam9icy8ke2ZpbmVUdW5pbmdKb2JJZH1gLCBvcHRpb25zKTtcbiAgICB9XG4gICAgbGlzdChxdWVyeSA9IHt9LCBvcHRpb25zKSB7XG4gICAgICAgIGlmIChpc1JlcXVlc3RPcHRpb25zKHF1ZXJ5KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMubGlzdCh7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdCgnL2ZpbmVfdHVuaW5nL2pvYnMnLCBGaW5lVHVuaW5nSm9ic1BhZ2UsIHsgcXVlcnksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEltbWVkaWF0ZWx5IGNhbmNlbCBhIGZpbmUtdHVuZSBqb2IuXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgZmluZVR1bmluZ0pvYiA9IGF3YWl0IGNsaWVudC5maW5lVHVuaW5nLmpvYnMuY2FuY2VsKFxuICAgICAqICAgJ2Z0LUFGMVdvUnFkM2FKQUhzcWM5Tlk3aUw4RicsXG4gICAgICogKTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBjYW5jZWwoZmluZVR1bmluZ0pvYklkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL2ZpbmVfdHVuaW5nL2pvYnMvJHtmaW5lVHVuaW5nSm9iSWR9L2NhbmNlbGAsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBsaXN0RXZlbnRzKGZpbmVUdW5pbmdKb2JJZCwgcXVlcnkgPSB7fSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0T3B0aW9ucyhxdWVyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxpc3RFdmVudHMoZmluZVR1bmluZ0pvYklkLCB7fSwgcXVlcnkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdChgL2ZpbmVfdHVuaW5nL2pvYnMvJHtmaW5lVHVuaW5nSm9iSWR9L2V2ZW50c2AsIEZpbmVUdW5pbmdKb2JFdmVudHNQYWdlLCB7XG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQYXVzZSBhIGZpbmUtdHVuZSBqb2IuXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgZmluZVR1bmluZ0pvYiA9IGF3YWl0IGNsaWVudC5maW5lVHVuaW5nLmpvYnMucGF1c2UoXG4gICAgICogICAnZnQtQUYxV29ScWQzYUpBSHNxYzlOWTdpTDhGJyxcbiAgICAgKiApO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIHBhdXNlKGZpbmVUdW5pbmdKb2JJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC9maW5lX3R1bmluZy9qb2JzLyR7ZmluZVR1bmluZ0pvYklkfS9wYXVzZWAsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXN1bWUgYSBmaW5lLXR1bmUgam9iLlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IGZpbmVUdW5pbmdKb2IgPSBhd2FpdCBjbGllbnQuZmluZVR1bmluZy5qb2JzLnJlc3VtZShcbiAgICAgKiAgICdmdC1BRjFXb1JxZDNhSkFIc3FjOU5ZN2lMOEYnLFxuICAgICAqICk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgcmVzdW1lKGZpbmVUdW5pbmdKb2JJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC9maW5lX3R1bmluZy9qb2JzLyR7ZmluZVR1bmluZ0pvYklkfS9yZXN1bWVgLCBvcHRpb25zKTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgRmluZVR1bmluZ0pvYnNQYWdlIGV4dGVuZHMgQ3Vyc29yUGFnZSB7XG59XG5leHBvcnQgY2xhc3MgRmluZVR1bmluZ0pvYkV2ZW50c1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbkpvYnMuRmluZVR1bmluZ0pvYnNQYWdlID0gRmluZVR1bmluZ0pvYnNQYWdlO1xuSm9icy5GaW5lVHVuaW5nSm9iRXZlbnRzUGFnZSA9IEZpbmVUdW5pbmdKb2JFdmVudHNQYWdlO1xuSm9icy5DaGVja3BvaW50cyA9IENoZWNrcG9pbnRzO1xuSm9icy5GaW5lVHVuaW5nSm9iQ2hlY2twb2ludHNQYWdlID0gRmluZVR1bmluZ0pvYkNoZWNrcG9pbnRzUGFnZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWpvYnMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCAqIGFzIE1ldGhvZHNBUEkgZnJvbSBcIi4vbWV0aG9kcy5tanNcIjtcbmltcG9ydCB7IE1ldGhvZHMsIH0gZnJvbSBcIi4vbWV0aG9kcy5tanNcIjtcbmltcG9ydCAqIGFzIEFscGhhQVBJIGZyb20gXCIuL2FscGhhL2FscGhhLm1qc1wiO1xuaW1wb3J0IHsgQWxwaGEgfSBmcm9tIFwiLi9hbHBoYS9hbHBoYS5tanNcIjtcbmltcG9ydCAqIGFzIENoZWNrcG9pbnRzQVBJIGZyb20gXCIuL2NoZWNrcG9pbnRzL2NoZWNrcG9pbnRzLm1qc1wiO1xuaW1wb3J0IHsgQ2hlY2twb2ludHMgfSBmcm9tIFwiLi9jaGVja3BvaW50cy9jaGVja3BvaW50cy5tanNcIjtcbmltcG9ydCAqIGFzIEpvYnNBUEkgZnJvbSBcIi4vam9icy9qb2JzLm1qc1wiO1xuaW1wb3J0IHsgRmluZVR1bmluZ0pvYkV2ZW50c1BhZ2UsIEZpbmVUdW5pbmdKb2JzUGFnZSwgSm9icywgfSBmcm9tIFwiLi9qb2JzL2pvYnMubWpzXCI7XG5leHBvcnQgY2xhc3MgRmluZVR1bmluZyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5tZXRob2RzID0gbmV3IE1ldGhvZHNBUEkuTWV0aG9kcyh0aGlzLl9jbGllbnQpO1xuICAgICAgICB0aGlzLmpvYnMgPSBuZXcgSm9ic0FQSS5Kb2JzKHRoaXMuX2NsaWVudCk7XG4gICAgICAgIHRoaXMuY2hlY2twb2ludHMgPSBuZXcgQ2hlY2twb2ludHNBUEkuQ2hlY2twb2ludHModGhpcy5fY2xpZW50KTtcbiAgICAgICAgdGhpcy5hbHBoYSA9IG5ldyBBbHBoYUFQSS5BbHBoYSh0aGlzLl9jbGllbnQpO1xuICAgIH1cbn1cbkZpbmVUdW5pbmcuTWV0aG9kcyA9IE1ldGhvZHM7XG5GaW5lVHVuaW5nLkpvYnMgPSBKb2JzO1xuRmluZVR1bmluZy5GaW5lVHVuaW5nSm9ic1BhZ2UgPSBGaW5lVHVuaW5nSm9ic1BhZ2U7XG5GaW5lVHVuaW5nLkZpbmVUdW5pbmdKb2JFdmVudHNQYWdlID0gRmluZVR1bmluZ0pvYkV2ZW50c1BhZ2U7XG5GaW5lVHVuaW5nLkNoZWNrcG9pbnRzID0gQ2hlY2twb2ludHM7XG5GaW5lVHVuaW5nLkFscGhhID0gQWxwaGE7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1maW5lLXR1bmluZy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uL3Jlc291cmNlLm1qc1wiO1xuZXhwb3J0IGNsYXNzIEdyYWRlck1vZGVscyBleHRlbmRzIEFQSVJlc291cmNlIHtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdyYWRlci1tb2RlbHMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCAqIGFzIEdyYWRlck1vZGVsc0FQSSBmcm9tIFwiLi9ncmFkZXItbW9kZWxzLm1qc1wiO1xuaW1wb3J0IHsgR3JhZGVyTW9kZWxzLCB9IGZyb20gXCIuL2dyYWRlci1tb2RlbHMubWpzXCI7XG5leHBvcnQgY2xhc3MgR3JhZGVycyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5ncmFkZXJNb2RlbHMgPSBuZXcgR3JhZGVyTW9kZWxzQVBJLkdyYWRlck1vZGVscyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbn1cbkdyYWRlcnMuR3JhZGVyTW9kZWxzID0gR3JhZGVyTW9kZWxzO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z3JhZGVycy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29yZSBmcm9tIFwiLi4vY29yZS5tanNcIjtcbmV4cG9ydCBjbGFzcyBJbWFnZXMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIHZhcmlhdGlvbiBvZiBhIGdpdmVuIGltYWdlLiBUaGlzIGVuZHBvaW50IG9ubHkgc3VwcG9ydHMgYGRhbGwtZS0yYC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBpbWFnZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5pbWFnZXMuY3JlYXRlVmFyaWF0aW9uKHtcbiAgICAgKiAgIGltYWdlOiBmcy5jcmVhdGVSZWFkU3RyZWFtKCdvdHRlci5wbmcnKSxcbiAgICAgKiB9KTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBjcmVhdGVWYXJpYXRpb24oYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9pbWFnZXMvdmFyaWF0aW9ucycsIENvcmUubXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zKHsgYm9keSwgLi4ub3B0aW9ucyB9KSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gZWRpdGVkIG9yIGV4dGVuZGVkIGltYWdlIGdpdmVuIG9uZSBvciBtb3JlIHNvdXJjZSBpbWFnZXMgYW5kIGFcbiAgICAgKiBwcm9tcHQuIFRoaXMgZW5kcG9pbnQgb25seSBzdXBwb3J0cyBgZ3B0LWltYWdlLTFgIGFuZCBgZGFsbC1lLTJgLlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IGltYWdlc1Jlc3BvbnNlID0gYXdhaXQgY2xpZW50LmltYWdlcy5lZGl0KHtcbiAgICAgKiAgIGltYWdlOiBmcy5jcmVhdGVSZWFkU3RyZWFtKCdwYXRoL3RvL2ZpbGUnKSxcbiAgICAgKiAgIHByb21wdDogJ0EgY3V0ZSBiYWJ5IHNlYSBvdHRlciB3ZWFyaW5nIGEgYmVyZXQnLFxuICAgICAqIH0pO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGVkaXQoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9pbWFnZXMvZWRpdHMnLCBDb3JlLm11bHRpcGFydEZvcm1SZXF1ZXN0T3B0aW9ucyh7IGJvZHksIC4uLm9wdGlvbnMgfSkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGFuIGltYWdlIGdpdmVuIGEgcHJvbXB0LlxuICAgICAqIFtMZWFybiBtb3JlXShodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9ndWlkZXMvaW1hZ2VzKS5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBpbWFnZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5pbWFnZXMuZ2VuZXJhdGUoe1xuICAgICAqICAgcHJvbXB0OiAnQSBjdXRlIGJhYnkgc2VhIG90dGVyJyxcbiAgICAgKiB9KTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBnZW5lcmF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL2ltYWdlcy9nZW5lcmF0aW9ucycsIHsgYm9keSwgLi4ub3B0aW9ucyB9KTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbWFnZXMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwiLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBNb2RlbHMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogUmV0cmlldmVzIGEgbW9kZWwgaW5zdGFuY2UsIHByb3ZpZGluZyBiYXNpYyBpbmZvcm1hdGlvbiBhYm91dCB0aGUgbW9kZWwgc3VjaCBhc1xuICAgICAqIHRoZSBvd25lciBhbmQgcGVybWlzc2lvbmluZy5cbiAgICAgKi9cbiAgICByZXRyaWV2ZShtb2RlbCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldChgL21vZGVscy8ke21vZGVsfWAsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBMaXN0cyB0aGUgY3VycmVudGx5IGF2YWlsYWJsZSBtb2RlbHMsIGFuZCBwcm92aWRlcyBiYXNpYyBpbmZvcm1hdGlvbiBhYm91dCBlYWNoXG4gICAgICogb25lIHN1Y2ggYXMgdGhlIG93bmVyIGFuZCBhdmFpbGFiaWxpdHkuXG4gICAgICovXG4gICAgbGlzdChvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdCgnL21vZGVscycsIE1vZGVsc1BhZ2UsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYSBmaW5lLXR1bmVkIG1vZGVsLiBZb3UgbXVzdCBoYXZlIHRoZSBPd25lciByb2xlIGluIHlvdXIgb3JnYW5pemF0aW9uIHRvXG4gICAgICogZGVsZXRlIGEgbW9kZWwuXG4gICAgICovXG4gICAgZGVsKG1vZGVsLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZGVsZXRlKGAvbW9kZWxzLyR7bW9kZWx9YCwgb3B0aW9ucyk7XG4gICAgfVxufVxuLyoqXG4gKiBOb3RlOiBubyBwYWdpbmF0aW9uIGFjdHVhbGx5IG9jY3VycyB5ZXQsIHRoaXMgaXMgZm9yIGZvcndhcmRzLWNvbXBhdGliaWxpdHkuXG4gKi9cbmV4cG9ydCBjbGFzcyBNb2RlbHNQYWdlIGV4dGVuZHMgUGFnZSB7XG59XG5Nb2RlbHMuTW9kZWxzUGFnZSA9IE1vZGVsc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tb2RlbHMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi9yZXNvdXJjZS5tanNcIjtcbmV4cG9ydCBjbGFzcyBNb2RlcmF0aW9ucyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICAvKipcbiAgICAgKiBDbGFzc2lmaWVzIGlmIHRleHQgYW5kL29yIGltYWdlIGlucHV0cyBhcmUgcG90ZW50aWFsbHkgaGFybWZ1bC4gTGVhcm4gbW9yZSBpblxuICAgICAqIHRoZSBbbW9kZXJhdGlvbiBndWlkZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvZ3VpZGVzL21vZGVyYXRpb24pLlxuICAgICAqL1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL21vZGVyYXRpb25zJywgeyBib2R5LCAuLi5vcHRpb25zIH0pO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1vZGVyYXRpb25zLm1qcy5tYXAiLCJpbXBvcnQgeyBPcGVuQUlFcnJvciB9IGZyb20gXCIuLi9lcnJvci5tanNcIjtcbmltcG9ydCB7IGlzQXV0b1BhcnNhYmxlUmVzcG9uc2VGb3JtYXQgfSBmcm9tIFwiLi4vbGliL3BhcnNlci5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBtYXliZVBhcnNlUmVzcG9uc2UocmVzcG9uc2UsIHBhcmFtcykge1xuICAgIGlmICghcGFyYW1zIHx8ICFoYXNBdXRvUGFyc2VhYmxlSW5wdXQocGFyYW1zKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4ucmVzcG9uc2UsXG4gICAgICAgICAgICBvdXRwdXRfcGFyc2VkOiBudWxsLFxuICAgICAgICAgICAgb3V0cHV0OiByZXNwb25zZS5vdXRwdXQubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gJ2Z1bmN0aW9uX2NhbGwnKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VkX2FyZ3VtZW50czogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gJ21lc3NhZ2UnKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudDogaXRlbS5jb250ZW50Lm1hcCgoY29udGVudCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5jb250ZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpdGVtO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gcGFyc2VSZXNwb25zZShyZXNwb25zZSwgcGFyYW1zKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVJlc3BvbnNlKHJlc3BvbnNlLCBwYXJhbXMpIHtcbiAgICBjb25zdCBvdXRwdXQgPSByZXNwb25zZS5vdXRwdXQubWFwKChpdGVtKSA9PiB7XG4gICAgICAgIGlmIChpdGVtLnR5cGUgPT09ICdmdW5jdGlvbl9jYWxsJykge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgICAgIHBhcnNlZF9hcmd1bWVudHM6IHBhcnNlVG9vbENhbGwocGFyYW1zLCBpdGVtKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gJ21lc3NhZ2UnKSB7XG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID0gaXRlbS5jb250ZW50Lm1hcCgoY29udGVudCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChjb250ZW50LnR5cGUgPT09ICdvdXRwdXRfdGV4dCcpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmNvbnRlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZWQ6IHBhcnNlVGV4dEZvcm1hdChwYXJhbXMsIGNvbnRlbnQudGV4dCksXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZW50O1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgY29udGVudCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgfSk7XG4gICAgY29uc3QgcGFyc2VkID0gT2JqZWN0LmFzc2lnbih7fSwgcmVzcG9uc2UsIHsgb3V0cHV0IH0pO1xuICAgIGlmICghT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihyZXNwb25zZSwgJ291dHB1dF90ZXh0JykpIHtcbiAgICAgICAgYWRkT3V0cHV0VGV4dChwYXJzZWQpO1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocGFyc2VkLCAnb3V0cHV0X3BhcnNlZCcsIHtcbiAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0KCkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBvdXRwdXQgb2YgcGFyc2VkLm91dHB1dCkge1xuICAgICAgICAgICAgICAgIGlmIChvdXRwdXQudHlwZSAhPT0gJ21lc3NhZ2UnKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGNvbnRlbnQgb2Ygb3V0cHV0LmNvbnRlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnQudHlwZSA9PT0gJ291dHB1dF90ZXh0JyAmJiBjb250ZW50LnBhcnNlZCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRlbnQucGFyc2VkO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIHBhcnNlZDtcbn1cbmZ1bmN0aW9uIHBhcnNlVGV4dEZvcm1hdChwYXJhbXMsIGNvbnRlbnQpIHtcbiAgICBpZiAocGFyYW1zLnRleHQ/LmZvcm1hdD8udHlwZSAhPT0gJ2pzb25fc2NoZW1hJykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKCckcGFyc2VSYXcnIGluIHBhcmFtcy50ZXh0Py5mb3JtYXQpIHtcbiAgICAgICAgY29uc3QgdGV4dF9mb3JtYXQgPSBwYXJhbXMudGV4dD8uZm9ybWF0O1xuICAgICAgICByZXR1cm4gdGV4dF9mb3JtYXQuJHBhcnNlUmF3KGNvbnRlbnQpO1xuICAgIH1cbiAgICByZXR1cm4gSlNPTi5wYXJzZShjb250ZW50KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBoYXNBdXRvUGFyc2VhYmxlSW5wdXQocGFyYW1zKSB7XG4gICAgaWYgKGlzQXV0b1BhcnNhYmxlUmVzcG9uc2VGb3JtYXQocGFyYW1zLnRleHQ/LmZvcm1hdCkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBtYWtlUGFyc2VhYmxlUmVzcG9uc2VUb29sKHRvb2wsIHsgcGFyc2VyLCBjYWxsYmFjaywgfSkge1xuICAgIGNvbnN0IG9iaiA9IHsgLi4udG9vbCB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iaiwge1xuICAgICAgICAkYnJhbmQ6IHtcbiAgICAgICAgICAgIHZhbHVlOiAnYXV0by1wYXJzZWFibGUtdG9vbCcsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgJHBhcnNlUmF3OiB7XG4gICAgICAgICAgICB2YWx1ZTogcGFyc2VyLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgICRjYWxsYmFjazoge1xuICAgICAgICAgICAgdmFsdWU6IGNhbGxiYWNrLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIG9iajtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0F1dG9QYXJzYWJsZVRvb2wodG9vbCkge1xuICAgIHJldHVybiB0b29sPy5bJyRicmFuZCddID09PSAnYXV0by1wYXJzZWFibGUtdG9vbCc7XG59XG5mdW5jdGlvbiBnZXRJbnB1dFRvb2xCeU5hbWUoaW5wdXRfdG9vbHMsIG5hbWUpIHtcbiAgICByZXR1cm4gaW5wdXRfdG9vbHMuZmluZCgodG9vbCkgPT4gdG9vbC50eXBlID09PSAnZnVuY3Rpb24nICYmIHRvb2wubmFtZSA9PT0gbmFtZSk7XG59XG5mdW5jdGlvbiBwYXJzZVRvb2xDYWxsKHBhcmFtcywgdG9vbENhbGwpIHtcbiAgICBjb25zdCBpbnB1dFRvb2wgPSBnZXRJbnB1dFRvb2xCeU5hbWUocGFyYW1zLnRvb2xzID8/IFtdLCB0b29sQ2FsbC5uYW1lKTtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi50b29sQ2FsbCxcbiAgICAgICAgLi4udG9vbENhbGwsXG4gICAgICAgIHBhcnNlZF9hcmd1bWVudHM6IGlzQXV0b1BhcnNhYmxlVG9vbChpbnB1dFRvb2wpID8gaW5wdXRUb29sLiRwYXJzZVJhdyh0b29sQ2FsbC5hcmd1bWVudHMpXG4gICAgICAgICAgICA6IGlucHV0VG9vbD8uc3RyaWN0ID8gSlNPTi5wYXJzZSh0b29sQ2FsbC5hcmd1bWVudHMpXG4gICAgICAgICAgICAgICAgOiBudWxsLFxuICAgIH07XG59XG5leHBvcnQgZnVuY3Rpb24gc2hvdWxkUGFyc2VUb29sQ2FsbChwYXJhbXMsIHRvb2xDYWxsKSB7XG4gICAgaWYgKCFwYXJhbXMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBpbnB1dFRvb2wgPSBnZXRJbnB1dFRvb2xCeU5hbWUocGFyYW1zLnRvb2xzID8/IFtdLCB0b29sQ2FsbC5uYW1lKTtcbiAgICByZXR1cm4gaXNBdXRvUGFyc2FibGVUb29sKGlucHV0VG9vbCkgfHwgaW5wdXRUb29sPy5zdHJpY3QgfHwgZmFsc2U7XG59XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVJbnB1dFRvb2xzKHRvb2xzKSB7XG4gICAgZm9yIChjb25zdCB0b29sIG9mIHRvb2xzID8/IFtdKSB7XG4gICAgICAgIGlmICh0b29sLnR5cGUgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgQ3VycmVudGx5IG9ubHkgXFxgZnVuY3Rpb25cXGAgdG9vbCB0eXBlcyBzdXBwb3J0IGF1dG8tcGFyc2luZzsgUmVjZWl2ZWQgXFxgJHt0b29sLnR5cGV9XFxgYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRvb2wuZnVuY3Rpb24uc3RyaWN0ICE9PSB0cnVlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYFRoZSBcXGAke3Rvb2wuZnVuY3Rpb24ubmFtZX1cXGAgdG9vbCBpcyBub3QgbWFya2VkIHdpdGggXFxgc3RyaWN0OiB0cnVlXFxgLiBPbmx5IHN0cmljdCBmdW5jdGlvbiB0b29scyBjYW4gYmUgYXV0by1wYXJzZWRgKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBhZGRPdXRwdXRUZXh0KHJzcCkge1xuICAgIGNvbnN0IHRleHRzID0gW107XG4gICAgZm9yIChjb25zdCBvdXRwdXQgb2YgcnNwLm91dHB1dCkge1xuICAgICAgICBpZiAob3V0cHV0LnR5cGUgIT09ICdtZXNzYWdlJykge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBjb250ZW50IG9mIG91dHB1dC5jb250ZW50KSB7XG4gICAgICAgICAgICBpZiAoY29udGVudC50eXBlID09PSAnb3V0cHV0X3RleHQnKSB7XG4gICAgICAgICAgICAgICAgdGV4dHMucHVzaChjb250ZW50LnRleHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJzcC5vdXRwdXRfdGV4dCA9IHRleHRzLmpvaW4oJycpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UmVzcG9uc2VzUGFyc2VyLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgeyBpc1JlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uLy4uL2NvcmUubWpzXCI7XG5pbXBvcnQgeyBSZXNwb25zZUl0ZW1zUGFnZSB9IGZyb20gXCIuL3Jlc3BvbnNlcy5tanNcIjtcbmV4cG9ydCBjbGFzcyBJbnB1dEl0ZW1zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIGxpc3QocmVzcG9uc2VJZCwgcXVlcnkgPSB7fSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0T3B0aW9ucyhxdWVyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxpc3QocmVzcG9uc2VJZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC9yZXNwb25zZXMvJHtyZXNwb25zZUlkfS9pbnB1dF9pdGVtc2AsIFJlc3BvbnNlSXRlbXNQYWdlLCB7XG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbmV4cG9ydCB7IFJlc3BvbnNlSXRlbXNQYWdlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbnB1dC1pdGVtcy5tanMubWFwIiwidmFyIF9fY2xhc3NQcml2YXRlRmllbGRTZXQgPSAodGhpcyAmJiB0aGlzLl9fY2xhc3NQcml2YXRlRmllbGRTZXQpIHx8IGZ1bmN0aW9uIChyZWNlaXZlciwgc3RhdGUsIHZhbHVlLCBraW5kLCBmKSB7XG4gICAgaWYgKGtpbmQgPT09IFwibVwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBtZXRob2QgaXMgbm90IHdyaXRhYmxlXCIpO1xuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIHNldHRlclwiKTtcbiAgICBpZiAodHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciAhPT0gc3RhdGUgfHwgIWYgOiAhc3RhdGUuaGFzKHJlY2VpdmVyKSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCB3cml0ZSBwcml2YXRlIG1lbWJlciB0byBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xuICAgIHJldHVybiAoa2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIsIHZhbHVlKSA6IGYgPyBmLnZhbHVlID0gdmFsdWUgOiBzdGF0ZS5zZXQocmVjZWl2ZXIsIHZhbHVlKSksIHZhbHVlO1xufTtcbnZhciBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0ID0gKHRoaXMgJiYgdGhpcy5fX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KSB8fCBmdW5jdGlvbiAocmVjZWl2ZXIsIHN0YXRlLCBraW5kLCBmKSB7XG4gICAgaWYgKGtpbmQgPT09IFwiYVwiICYmICFmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBhY2Nlc3NvciB3YXMgZGVmaW5lZCB3aXRob3V0IGEgZ2V0dGVyXCIpO1xuICAgIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHJlYWQgcHJpdmF0ZSBtZW1iZXIgZnJvbSBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xuICAgIHJldHVybiBraW5kID09PSBcIm1cIiA/IGYgOiBraW5kID09PSBcImFcIiA/IGYuY2FsbChyZWNlaXZlcikgOiBmID8gZi52YWx1ZSA6IHN0YXRlLmdldChyZWNlaXZlcik7XG59O1xudmFyIF9SZXNwb25zZVN0cmVhbV9pbnN0YW5jZXMsIF9SZXNwb25zZVN0cmVhbV9wYXJhbXMsIF9SZXNwb25zZVN0cmVhbV9jdXJyZW50UmVzcG9uc2VTbmFwc2hvdCwgX1Jlc3BvbnNlU3RyZWFtX2ZpbmFsUmVzcG9uc2UsIF9SZXNwb25zZVN0cmVhbV9iZWdpblJlcXVlc3QsIF9SZXNwb25zZVN0cmVhbV9hZGRFdmVudCwgX1Jlc3BvbnNlU3RyZWFtX2VuZFJlcXVlc3QsIF9SZXNwb25zZVN0cmVhbV9hY2N1bXVsYXRlUmVzcG9uc2U7XG5pbXBvcnQgeyBBUElVc2VyQWJvcnRFcnJvciwgT3BlbkFJRXJyb3IgfSBmcm9tIFwiLi4vLi4vZXJyb3IubWpzXCI7XG5pbXBvcnQgeyBFdmVudFN0cmVhbSB9IGZyb20gXCIuLi9FdmVudFN0cmVhbS5tanNcIjtcbmltcG9ydCB7IG1heWJlUGFyc2VSZXNwb25zZSB9IGZyb20gXCIuLi9SZXNwb25zZXNQYXJzZXIubWpzXCI7XG5leHBvcnQgY2xhc3MgUmVzcG9uc2VTdHJlYW0gZXh0ZW5kcyBFdmVudFN0cmVhbSB7XG4gICAgY29uc3RydWN0b3IocGFyYW1zKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIF9SZXNwb25zZVN0cmVhbV9pbnN0YW5jZXMuYWRkKHRoaXMpO1xuICAgICAgICBfUmVzcG9uc2VTdHJlYW1fcGFyYW1zLnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfUmVzcG9uc2VTdHJlYW1fY3VycmVudFJlc3BvbnNlU25hcHNob3Quc2V0KHRoaXMsIHZvaWQgMCk7XG4gICAgICAgIF9SZXNwb25zZVN0cmVhbV9maW5hbFJlc3BvbnNlLnNldCh0aGlzLCB2b2lkIDApO1xuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9SZXNwb25zZVN0cmVhbV9wYXJhbXMsIHBhcmFtcywgXCJmXCIpO1xuICAgIH1cbiAgICBzdGF0aWMgY3JlYXRlUmVzcG9uc2UoY2xpZW50LCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgcnVubmVyID0gbmV3IFJlc3BvbnNlU3RyZWFtKHBhcmFtcyk7XG4gICAgICAgIHJ1bm5lci5fcnVuKCgpID0+IHJ1bm5lci5fY3JlYXRlT3JSZXRyaWV2ZVJlc3BvbnNlKGNsaWVudCwgcGFyYW1zLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAuLi5vcHRpb25zPy5oZWFkZXJzLCAnWC1TdGFpbmxlc3MtSGVscGVyLU1ldGhvZCc6ICdzdHJlYW0nIH0sXG4gICAgICAgIH0pKTtcbiAgICAgICAgcmV0dXJuIHJ1bm5lcjtcbiAgICB9XG4gICAgYXN5bmMgX2NyZWF0ZU9yUmV0cmlldmVSZXNwb25zZShjbGllbnQsIHBhcmFtcywgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBzaWduYWwgPSBvcHRpb25zPy5zaWduYWw7XG4gICAgICAgIGlmIChzaWduYWwpIHtcbiAgICAgICAgICAgIGlmIChzaWduYWwuYWJvcnRlZClcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHRoaXMuY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICAgICAgfVxuICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9SZXNwb25zZVN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfUmVzcG9uc2VTdHJlYW1fYmVnaW5SZXF1ZXN0KS5jYWxsKHRoaXMpO1xuICAgICAgICBsZXQgc3RyZWFtO1xuICAgICAgICBsZXQgc3RhcnRpbmdfYWZ0ZXIgPSBudWxsO1xuICAgICAgICBpZiAoJ3Jlc3BvbnNlX2lkJyBpbiBwYXJhbXMpIHtcbiAgICAgICAgICAgIHN0cmVhbSA9IGF3YWl0IGNsaWVudC5yZXNwb25zZXMucmV0cmlldmUocGFyYW1zLnJlc3BvbnNlX2lkLCB7IHN0cmVhbTogdHJ1ZSB9LCB7IC4uLm9wdGlvbnMsIHNpZ25hbDogdGhpcy5jb250cm9sbGVyLnNpZ25hbCwgc3RyZWFtOiB0cnVlIH0pO1xuICAgICAgICAgICAgc3RhcnRpbmdfYWZ0ZXIgPSBwYXJhbXMuc3RhcnRpbmdfYWZ0ZXIgPz8gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHN0cmVhbSA9IGF3YWl0IGNsaWVudC5yZXNwb25zZXMuY3JlYXRlKHsgLi4ucGFyYW1zLCBzdHJlYW06IHRydWUgfSwgeyAuLi5vcHRpb25zLCBzaWduYWw6IHRoaXMuY29udHJvbGxlci5zaWduYWwgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fY29ubmVjdGVkKCk7XG4gICAgICAgIGZvciBhd2FpdCAoY29uc3QgZXZlbnQgb2Ygc3RyZWFtKSB7XG4gICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9SZXNwb25zZVN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfUmVzcG9uc2VTdHJlYW1fYWRkRXZlbnQpLmNhbGwodGhpcywgZXZlbnQsIHN0YXJ0aW5nX2FmdGVyKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RyZWFtLmNvbnRyb2xsZXIuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfUmVzcG9uc2VTdHJlYW1faW5zdGFuY2VzLCBcIm1cIiwgX1Jlc3BvbnNlU3RyZWFtX2VuZFJlcXVlc3QpLmNhbGwodGhpcyk7XG4gICAgfVxuICAgIFsoX1Jlc3BvbnNlU3RyZWFtX3BhcmFtcyA9IG5ldyBXZWFrTWFwKCksIF9SZXNwb25zZVN0cmVhbV9jdXJyZW50UmVzcG9uc2VTbmFwc2hvdCA9IG5ldyBXZWFrTWFwKCksIF9SZXNwb25zZVN0cmVhbV9maW5hbFJlc3BvbnNlID0gbmV3IFdlYWtNYXAoKSwgX1Jlc3BvbnNlU3RyZWFtX2luc3RhbmNlcyA9IG5ldyBXZWFrU2V0KCksIF9SZXNwb25zZVN0cmVhbV9iZWdpblJlcXVlc3QgPSBmdW5jdGlvbiBfUmVzcG9uc2VTdHJlYW1fYmVnaW5SZXF1ZXN0KCkge1xuICAgICAgICBpZiAodGhpcy5lbmRlZClcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfUmVzcG9uc2VTdHJlYW1fY3VycmVudFJlc3BvbnNlU25hcHNob3QsIHVuZGVmaW5lZCwgXCJmXCIpO1xuICAgIH0sIF9SZXNwb25zZVN0cmVhbV9hZGRFdmVudCA9IGZ1bmN0aW9uIF9SZXNwb25zZVN0cmVhbV9hZGRFdmVudChldmVudCwgc3RhcnRpbmdfYWZ0ZXIpIHtcbiAgICAgICAgaWYgKHRoaXMuZW5kZWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNvbnN0IG1heWJlRW1pdCA9IChuYW1lLCBldmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKHN0YXJ0aW5nX2FmdGVyID09IG51bGwgfHwgZXZlbnQuc2VxdWVuY2VfbnVtYmVyID4gc3RhcnRpbmdfYWZ0ZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0KG5hbWUsIGV2ZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KHRoaXMsIF9SZXNwb25zZVN0cmVhbV9pbnN0YW5jZXMsIFwibVwiLCBfUmVzcG9uc2VTdHJlYW1fYWNjdW11bGF0ZVJlc3BvbnNlKS5jYWxsKHRoaXMsIGV2ZW50KTtcbiAgICAgICAgbWF5YmVFbWl0KCdldmVudCcsIGV2ZW50KTtcbiAgICAgICAgc3dpdGNoIChldmVudC50eXBlKSB7XG4gICAgICAgICAgICBjYXNlICdyZXNwb25zZS5vdXRwdXRfdGV4dC5kZWx0YSc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSByZXNwb25zZS5vdXRwdXRbZXZlbnQub3V0cHV0X2luZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAoIW91dHB1dCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYG1pc3Npbmcgb3V0cHV0IGF0IGluZGV4ICR7ZXZlbnQub3V0cHV0X2luZGV4fWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAob3V0cHV0LnR5cGUgPT09ICdtZXNzYWdlJykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50ID0gb3V0cHV0LmNvbnRlbnRbZXZlbnQuY29udGVudF9pbmRleF07XG4gICAgICAgICAgICAgICAgICAgIGlmICghY29udGVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIGNvbnRlbnQgYXQgaW5kZXggJHtldmVudC5jb250ZW50X2luZGV4fWApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50LnR5cGUgIT09ICdvdXRwdXRfdGV4dCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgZXhwZWN0ZWQgY29udGVudCB0byBiZSAnb3V0cHV0X3RleHQnLCBnb3QgJHtjb250ZW50LnR5cGV9YCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbWF5YmVFbWl0KCdyZXNwb25zZS5vdXRwdXRfdGV4dC5kZWx0YScsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmV2ZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgc25hcHNob3Q6IGNvbnRlbnQudGV4dCxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAncmVzcG9uc2UuZnVuY3Rpb25fY2FsbF9hcmd1bWVudHMuZGVsdGEnOiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3V0cHV0ID0gcmVzcG9uc2Uub3V0cHV0W2V2ZW50Lm91dHB1dF9pbmRleF07XG4gICAgICAgICAgICAgICAgaWYgKCFvdXRwdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIG91dHB1dCBhdCBpbmRleCAke2V2ZW50Lm91dHB1dF9pbmRleH1gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG91dHB1dC50eXBlID09PSAnZnVuY3Rpb25fY2FsbCcpIHtcbiAgICAgICAgICAgICAgICAgICAgbWF5YmVFbWl0KCdyZXNwb25zZS5mdW5jdGlvbl9jYWxsX2FyZ3VtZW50cy5kZWx0YScsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmV2ZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgc25hcHNob3Q6IG91dHB1dC5hcmd1bWVudHMsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgbWF5YmVFbWl0KGV2ZW50LnR5cGUsIGV2ZW50KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH0sIF9SZXNwb25zZVN0cmVhbV9lbmRSZXF1ZXN0ID0gZnVuY3Rpb24gX1Jlc3BvbnNlU3RyZWFtX2VuZFJlcXVlc3QoKSB7XG4gICAgICAgIGlmICh0aGlzLmVuZGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYHN0cmVhbSBoYXMgZW5kZWQsIHRoaXMgc2hvdWxkbid0IGhhcHBlbmApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNuYXBzaG90ID0gX19jbGFzc1ByaXZhdGVGaWVsZEdldCh0aGlzLCBfUmVzcG9uc2VTdHJlYW1fY3VycmVudFJlc3BvbnNlU25hcHNob3QsIFwiZlwiKTtcbiAgICAgICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGByZXF1ZXN0IGVuZGVkIHdpdGhvdXQgc2VuZGluZyBhbnkgZXZlbnRzYCk7XG4gICAgICAgIH1cbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfUmVzcG9uc2VTdHJlYW1fY3VycmVudFJlc3BvbnNlU25hcHNob3QsIHVuZGVmaW5lZCwgXCJmXCIpO1xuICAgICAgICBjb25zdCBwYXJzZWRSZXNwb25zZSA9IGZpbmFsaXplUmVzcG9uc2Uoc25hcHNob3QsIF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX1Jlc3BvbnNlU3RyZWFtX3BhcmFtcywgXCJmXCIpKTtcbiAgICAgICAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCh0aGlzLCBfUmVzcG9uc2VTdHJlYW1fZmluYWxSZXNwb25zZSwgcGFyc2VkUmVzcG9uc2UsIFwiZlwiKTtcbiAgICAgICAgcmV0dXJuIHBhcnNlZFJlc3BvbnNlO1xuICAgIH0sIF9SZXNwb25zZVN0cmVhbV9hY2N1bXVsYXRlUmVzcG9uc2UgPSBmdW5jdGlvbiBfUmVzcG9uc2VTdHJlYW1fYWNjdW11bGF0ZVJlc3BvbnNlKGV2ZW50KSB7XG4gICAgICAgIGxldCBzbmFwc2hvdCA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX1Jlc3BvbnNlU3RyZWFtX2N1cnJlbnRSZXNwb25zZVNuYXBzaG90LCBcImZcIik7XG4gICAgICAgIGlmICghc25hcHNob3QpIHtcbiAgICAgICAgICAgIGlmIChldmVudC50eXBlICE9PSAncmVzcG9uc2UuY3JlYXRlZCcpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYFdoZW4gc25hcHNob3QgaGFzbid0IGJlZW4gc2V0IHlldCwgZXhwZWN0ZWQgJ3Jlc3BvbnNlLmNyZWF0ZWQnIGV2ZW50LCBnb3QgJHtldmVudC50eXBlfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc25hcHNob3QgPSBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9SZXNwb25zZVN0cmVhbV9jdXJyZW50UmVzcG9uc2VTbmFwc2hvdCwgZXZlbnQucmVzcG9uc2UsIFwiZlwiKTtcbiAgICAgICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGV2ZW50LnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ3Jlc3BvbnNlLm91dHB1dF9pdGVtLmFkZGVkJzoge1xuICAgICAgICAgICAgICAgIHNuYXBzaG90Lm91dHB1dC5wdXNoKGV2ZW50Lml0ZW0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAncmVzcG9uc2UuY29udGVudF9wYXJ0LmFkZGVkJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IHNuYXBzaG90Lm91dHB1dFtldmVudC5vdXRwdXRfaW5kZXhdO1xuICAgICAgICAgICAgICAgIGlmICghb3V0cHV0KSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgbWlzc2luZyBvdXRwdXQgYXQgaW5kZXggJHtldmVudC5vdXRwdXRfaW5kZXh9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChvdXRwdXQudHlwZSA9PT0gJ21lc3NhZ2UnKSB7XG4gICAgICAgICAgICAgICAgICAgIG91dHB1dC5jb250ZW50LnB1c2goZXZlbnQucGFydCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAncmVzcG9uc2Uub3V0cHV0X3RleHQuZGVsdGEnOiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3V0cHV0ID0gc25hcHNob3Qub3V0cHV0W2V2ZW50Lm91dHB1dF9pbmRleF07XG4gICAgICAgICAgICAgICAgaWYgKCFvdXRwdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE9wZW5BSUVycm9yKGBtaXNzaW5nIG91dHB1dCBhdCBpbmRleCAke2V2ZW50Lm91dHB1dF9pbmRleH1gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG91dHB1dC50eXBlID09PSAnbWVzc2FnZScpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29udGVudCA9IG91dHB1dC5jb250ZW50W2V2ZW50LmNvbnRlbnRfaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWNvbnRlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcihgbWlzc2luZyBjb250ZW50IGF0IGluZGV4ICR7ZXZlbnQuY29udGVudF9pbmRleH1gKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudC50eXBlICE9PSAnb3V0cHV0X3RleHQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYGV4cGVjdGVkIGNvbnRlbnQgdG8gYmUgJ291dHB1dF90ZXh0JywgZ290ICR7Y29udGVudC50eXBlfWApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQudGV4dCArPSBldmVudC5kZWx0YTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdyZXNwb25zZS5mdW5jdGlvbl9jYWxsX2FyZ3VtZW50cy5kZWx0YSc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBzbmFwc2hvdC5vdXRwdXRbZXZlbnQub3V0cHV0X2luZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAoIW91dHB1dCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgT3BlbkFJRXJyb3IoYG1pc3Npbmcgb3V0cHV0IGF0IGluZGV4ICR7ZXZlbnQub3V0cHV0X2luZGV4fWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAob3V0cHV0LnR5cGUgPT09ICdmdW5jdGlvbl9jYWxsJykge1xuICAgICAgICAgICAgICAgICAgICBvdXRwdXQuYXJndW1lbnRzICs9IGV2ZW50LmRlbHRhO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ3Jlc3BvbnNlLmNvbXBsZXRlZCc6IHtcbiAgICAgICAgICAgICAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHRoaXMsIF9SZXNwb25zZVN0cmVhbV9jdXJyZW50UmVzcG9uc2VTbmFwc2hvdCwgZXZlbnQucmVzcG9uc2UsIFwiZlwiKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc25hcHNob3Q7XG4gICAgfSwgU3ltYm9sLmFzeW5jSXRlcmF0b3IpXSgpIHtcbiAgICAgICAgY29uc3QgcHVzaFF1ZXVlID0gW107XG4gICAgICAgIGNvbnN0IHJlYWRRdWV1ZSA9IFtdO1xuICAgICAgICBsZXQgZG9uZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm9uKCdldmVudCcsIChldmVudCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gcmVhZFF1ZXVlLnNoaWZ0KCk7XG4gICAgICAgICAgICBpZiAocmVhZGVyKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlc29sdmUoZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcHVzaFF1ZXVlLnB1c2goZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5vbignZW5kJywgKCkgPT4ge1xuICAgICAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlYWRlciBvZiByZWFkUXVldWUpIHtcbiAgICAgICAgICAgICAgICByZWFkZXIucmVzb2x2ZSh1bmRlZmluZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm9uKCdhYm9ydCcsIChlcnIpID0+IHtcbiAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCByZWFkZXIgb2YgcmVhZFF1ZXVlKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlamVjdChlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCByZWFkZXIgb2YgcmVhZFF1ZXVlKSB7XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlamVjdChlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbmV4dDogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghcHVzaFF1ZXVlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiByZWFkUXVldWUucHVzaCh7IHJlc29sdmUsIHJlamVjdCB9KSkudGhlbigoZXZlbnQpID0+IChldmVudCA/IHsgdmFsdWU6IGV2ZW50LCBkb25lOiBmYWxzZSB9IDogeyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiB0cnVlIH0pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgZXZlbnQgPSBwdXNoUXVldWUuc2hpZnQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogZXZlbnQsIGRvbmU6IGZhbHNlIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmV0dXJuOiBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5hYm9ydCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGZpbmFsIFJlc3BvbnNlLCBvciByZWplY3RzXG4gICAgICogaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIFJFc3BvbnNlLlxuICAgICAqL1xuICAgIGFzeW5jIGZpbmFsUmVzcG9uc2UoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IF9fY2xhc3NQcml2YXRlRmllbGRHZXQodGhpcywgX1Jlc3BvbnNlU3RyZWFtX2ZpbmFsUmVzcG9uc2UsIFwiZlwiKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZSlcbiAgICAgICAgICAgIHRocm93IG5ldyBPcGVuQUlFcnJvcignc3RyZWFtIGVuZGVkIHdpdGhvdXQgcHJvZHVjaW5nIGEgQ2hhdENvbXBsZXRpb24nKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGZpbmFsaXplUmVzcG9uc2Uoc25hcHNob3QsIHBhcmFtcykge1xuICAgIHJldHVybiBtYXliZVBhcnNlUmVzcG9uc2Uoc25hcHNob3QsIHBhcmFtcyk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1SZXNwb25zZVN0cmVhbS5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IHBhcnNlUmVzcG9uc2UsIGFkZE91dHB1dFRleHQsIH0gZnJvbSBcIi4uLy4uL2xpYi9SZXNwb25zZXNQYXJzZXIubWpzXCI7XG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCAqIGFzIElucHV0SXRlbXNBUEkgZnJvbSBcIi4vaW5wdXQtaXRlbXMubWpzXCI7XG5pbXBvcnQgeyBJbnB1dEl0ZW1zIH0gZnJvbSBcIi4vaW5wdXQtaXRlbXMubWpzXCI7XG5pbXBvcnQgeyBSZXNwb25zZVN0cmVhbSB9IGZyb20gXCIuLi8uLi9saWIvcmVzcG9uc2VzL1Jlc3BvbnNlU3RyZWFtLm1qc1wiO1xuaW1wb3J0IHsgQ3Vyc29yUGFnZSB9IGZyb20gXCIuLi8uLi9wYWdpbmF0aW9uLm1qc1wiO1xuZXhwb3J0IGNsYXNzIFJlc3BvbnNlcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5pbnB1dEl0ZW1zID0gbmV3IElucHV0SXRlbXNBUEkuSW5wdXRJdGVtcyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbiAgICBjcmVhdGUoYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy9yZXNwb25zZXMnLCB7IGJvZHksIC4uLm9wdGlvbnMsIHN0cmVhbTogYm9keS5zdHJlYW0gPz8gZmFsc2UgfSkuX3RoZW5VbndyYXAoKHJzcCkgPT4ge1xuICAgICAgICAgICAgaWYgKCdvYmplY3QnIGluIHJzcCAmJiByc3Aub2JqZWN0ID09PSAncmVzcG9uc2UnKSB7XG4gICAgICAgICAgICAgICAgYWRkT3V0cHV0VGV4dChyc3ApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJzcDtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHJpZXZlKHJlc3BvbnNlSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXQoYC9yZXNwb25zZXMvJHtyZXNwb25zZUlkfWAsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIHN0cmVhbTogcXVlcnk/LnN0cmVhbSA/PyBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERlbGV0ZXMgYSBtb2RlbCByZXNwb25zZSB3aXRoIHRoZSBnaXZlbiBJRC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBhd2FpdCBjbGllbnQucmVzcG9uc2VzLmRlbChcbiAgICAgKiAgICdyZXNwXzY3N2VmYjUxMzlhODgxOTBiNTEyYmMzZmVmOGU1MzVkJyxcbiAgICAgKiApO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGRlbChyZXNwb25zZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZGVsZXRlKGAvcmVzcG9uc2VzLyR7cmVzcG9uc2VJZH1gLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyBBY2NlcHQ6ICcqLyonLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwYXJzZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucmVzcG9uc2VzXG4gICAgICAgICAgICAuY3JlYXRlKGJvZHksIG9wdGlvbnMpXG4gICAgICAgICAgICAuX3RoZW5VbndyYXAoKHJlc3BvbnNlKSA9PiBwYXJzZVJlc3BvbnNlKHJlc3BvbnNlLCBib2R5KSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBtb2RlbCByZXNwb25zZSBzdHJlYW1cbiAgICAgKi9cbiAgICBzdHJlYW0oYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gUmVzcG9uc2VTdHJlYW0uY3JlYXRlUmVzcG9uc2UodGhpcy5fY2xpZW50LCBib2R5LCBvcHRpb25zKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ2FuY2VscyBhIG1vZGVsIHJlc3BvbnNlIHdpdGggdGhlIGdpdmVuIElELiBPbmx5IHJlc3BvbnNlcyBjcmVhdGVkIHdpdGggdGhlXG4gICAgICogYGJhY2tncm91bmRgIHBhcmFtZXRlciBzZXQgdG8gYHRydWVgIGNhbiBiZSBjYW5jZWxsZWQuXG4gICAgICogW0xlYXJuIG1vcmVdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2d1aWRlcy9iYWNrZ3JvdW5kKS5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBhd2FpdCBjbGllbnQucmVzcG9uc2VzLmNhbmNlbChcbiAgICAgKiAgICdyZXNwXzY3N2VmYjUxMzlhODgxOTBiNTEyYmMzZmVmOGU1MzVkJyxcbiAgICAgKiApO1xuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGNhbmNlbChyZXNwb25zZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3Jlc3BvbnNlcy8ke3Jlc3BvbnNlSWR9L2NhbmNlbGAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7IEFjY2VwdDogJyovKicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFJlc3BvbnNlSXRlbXNQYWdlIGV4dGVuZHMgQ3Vyc29yUGFnZSB7XG59XG5SZXNwb25zZXMuSW5wdXRJdGVtcyA9IElucHV0SXRlbXM7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXNwb25zZXMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi9yZXNvdXJjZS5tanNcIjtcbmltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4uLy4uL2NvcmUubWpzXCI7XG5leHBvcnQgY2xhc3MgUGFydHMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgLyoqXG4gICAgICogQWRkcyBhXG4gICAgICogW1BhcnRdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2FwaS1yZWZlcmVuY2UvdXBsb2Fkcy9wYXJ0LW9iamVjdCkgdG8gYW5cbiAgICAgKiBbVXBsb2FkXShodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hcGktcmVmZXJlbmNlL3VwbG9hZHMvb2JqZWN0KSBvYmplY3QuXG4gICAgICogQSBQYXJ0IHJlcHJlc2VudHMgYSBjaHVuayBvZiBieXRlcyBmcm9tIHRoZSBmaWxlIHlvdSBhcmUgdHJ5aW5nIHRvIHVwbG9hZC5cbiAgICAgKlxuICAgICAqIEVhY2ggUGFydCBjYW4gYmUgYXQgbW9zdCA2NCBNQiwgYW5kIHlvdSBjYW4gYWRkIFBhcnRzIHVudGlsIHlvdSBoaXQgdGhlIFVwbG9hZFxuICAgICAqIG1heGltdW0gb2YgOCBHQi5cbiAgICAgKlxuICAgICAqIEl0IGlzIHBvc3NpYmxlIHRvIGFkZCBtdWx0aXBsZSBQYXJ0cyBpbiBwYXJhbGxlbC4gWW91IGNhbiBkZWNpZGUgdGhlIGludGVuZGVkXG4gICAgICogb3JkZXIgb2YgdGhlIFBhcnRzIHdoZW4geW91XG4gICAgICogW2NvbXBsZXRlIHRoZSBVcGxvYWRdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2FwaS1yZWZlcmVuY2UvdXBsb2Fkcy9jb21wbGV0ZSkuXG4gICAgICovXG4gICAgY3JlYXRlKHVwbG9hZElkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3VwbG9hZHMvJHt1cGxvYWRJZH0vcGFydHNgLCBDb3JlLm11bHRpcGFydEZvcm1SZXF1ZXN0T3B0aW9ucyh7IGJvZHksIC4uLm9wdGlvbnMgfSkpO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhcnRzLm1qcy5tYXAiLCIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vcmVzb3VyY2UubWpzXCI7XG5pbXBvcnQgKiBhcyBQYXJ0c0FQSSBmcm9tIFwiLi9wYXJ0cy5tanNcIjtcbmltcG9ydCB7IFBhcnRzIH0gZnJvbSBcIi4vcGFydHMubWpzXCI7XG5leHBvcnQgY2xhc3MgVXBsb2FkcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5wYXJ0cyA9IG5ldyBQYXJ0c0FQSS5QYXJ0cyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGFuIGludGVybWVkaWF0ZVxuICAgICAqIFtVcGxvYWRdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2FwaS1yZWZlcmVuY2UvdXBsb2Fkcy9vYmplY3QpIG9iamVjdFxuICAgICAqIHRoYXQgeW91IGNhbiBhZGRcbiAgICAgKiBbUGFydHNdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2FwaS1yZWZlcmVuY2UvdXBsb2Fkcy9wYXJ0LW9iamVjdCkgdG8uXG4gICAgICogQ3VycmVudGx5LCBhbiBVcGxvYWQgY2FuIGFjY2VwdCBhdCBtb3N0IDggR0IgaW4gdG90YWwgYW5kIGV4cGlyZXMgYWZ0ZXIgYW4gaG91clxuICAgICAqIGFmdGVyIHlvdSBjcmVhdGUgaXQuXG4gICAgICpcbiAgICAgKiBPbmNlIHlvdSBjb21wbGV0ZSB0aGUgVXBsb2FkLCB3ZSB3aWxsIGNyZWF0ZSBhXG4gICAgICogW0ZpbGVdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2FwaS1yZWZlcmVuY2UvZmlsZXMvb2JqZWN0KSBvYmplY3QgdGhhdFxuICAgICAqIGNvbnRhaW5zIGFsbCB0aGUgcGFydHMgeW91IHVwbG9hZGVkLiBUaGlzIEZpbGUgaXMgdXNhYmxlIGluIHRoZSByZXN0IG9mIG91clxuICAgICAqIHBsYXRmb3JtIGFzIGEgcmVndWxhciBGaWxlIG9iamVjdC5cbiAgICAgKlxuICAgICAqIEZvciBjZXJ0YWluIGBwdXJwb3NlYCB2YWx1ZXMsIHRoZSBjb3JyZWN0IGBtaW1lX3R5cGVgIG11c3QgYmUgc3BlY2lmaWVkLiBQbGVhc2VcbiAgICAgKiByZWZlciB0byBkb2N1bWVudGF0aW9uIGZvciB0aGVcbiAgICAgKiBbc3VwcG9ydGVkIE1JTUUgdHlwZXMgZm9yIHlvdXIgdXNlIGNhc2VdKGh0dHBzOi8vcGxhdGZvcm0ub3BlbmFpLmNvbS9kb2NzL2Fzc2lzdGFudHMvdG9vbHMvZmlsZS1zZWFyY2gjc3VwcG9ydGVkLWZpbGVzKS5cbiAgICAgKlxuICAgICAqIEZvciBndWlkYW5jZSBvbiB0aGUgcHJvcGVyIGZpbGVuYW1lIGV4dGVuc2lvbnMgZm9yIGVhY2ggcHVycG9zZSwgcGxlYXNlIGZvbGxvd1xuICAgICAqIHRoZSBkb2N1bWVudGF0aW9uIG9uXG4gICAgICogW2NyZWF0aW5nIGEgRmlsZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvYXBpLXJlZmVyZW5jZS9maWxlcy9jcmVhdGUpLlxuICAgICAqL1xuICAgIGNyZWF0ZShib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdCgnL3VwbG9hZHMnLCB7IGJvZHksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENhbmNlbHMgdGhlIFVwbG9hZC4gTm8gUGFydHMgbWF5IGJlIGFkZGVkIGFmdGVyIGFuIFVwbG9hZCBpcyBjYW5jZWxsZWQuXG4gICAgICovXG4gICAgY2FuY2VsKHVwbG9hZElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3VwbG9hZHMvJHt1cGxvYWRJZH0vY2FuY2VsYCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENvbXBsZXRlcyB0aGVcbiAgICAgKiBbVXBsb2FkXShodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hcGktcmVmZXJlbmNlL3VwbG9hZHMvb2JqZWN0KS5cbiAgICAgKlxuICAgICAqIFdpdGhpbiB0aGUgcmV0dXJuZWQgVXBsb2FkIG9iamVjdCwgdGhlcmUgaXMgYSBuZXN0ZWRcbiAgICAgKiBbRmlsZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvYXBpLXJlZmVyZW5jZS9maWxlcy9vYmplY3QpIG9iamVjdCB0aGF0XG4gICAgICogaXMgcmVhZHkgdG8gdXNlIGluIHRoZSByZXN0IG9mIHRoZSBwbGF0Zm9ybS5cbiAgICAgKlxuICAgICAqIFlvdSBjYW4gc3BlY2lmeSB0aGUgb3JkZXIgb2YgdGhlIFBhcnRzIGJ5IHBhc3NpbmcgaW4gYW4gb3JkZXJlZCBsaXN0IG9mIHRoZSBQYXJ0XG4gICAgICogSURzLlxuICAgICAqXG4gICAgICogVGhlIG51bWJlciBvZiBieXRlcyB1cGxvYWRlZCB1cG9uIGNvbXBsZXRpb24gbXVzdCBtYXRjaCB0aGUgbnVtYmVyIG9mIGJ5dGVzXG4gICAgICogaW5pdGlhbGx5IHNwZWNpZmllZCB3aGVuIGNyZWF0aW5nIHRoZSBVcGxvYWQgb2JqZWN0LiBObyBQYXJ0cyBtYXkgYmUgYWRkZWQgYWZ0ZXJcbiAgICAgKiBhbiBVcGxvYWQgaXMgY29tcGxldGVkLlxuICAgICAqL1xuICAgIGNvbXBsZXRlKHVwbG9hZElkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3VwbG9hZHMvJHt1cGxvYWRJZH0vY29tcGxldGVgLCB7IGJvZHksIC4uLm9wdGlvbnMgfSk7XG4gICAgfVxufVxuVXBsb2Fkcy5QYXJ0cyA9IFBhcnRzO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXBsb2Fkcy5tanMubWFwIiwiLyoqXG4gKiBMaWtlIGBQcm9taXNlLmFsbFNldHRsZWQoKWAgYnV0IHRocm93cyBhbiBlcnJvciBpZiBhbnkgcHJvbWlzZXMgYXJlIHJlamVjdGVkLlxuICovXG5leHBvcnQgY29uc3QgYWxsU2V0dGxlZFdpdGhUaHJvdyA9IGFzeW5jIChwcm9taXNlcykgPT4ge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQocHJvbWlzZXMpO1xuICAgIGNvbnN0IHJlamVjdGVkID0gcmVzdWx0cy5maWx0ZXIoKHJlc3VsdCkgPT4gcmVzdWx0LnN0YXR1cyA9PT0gJ3JlamVjdGVkJyk7XG4gICAgaWYgKHJlamVjdGVkLmxlbmd0aCkge1xuICAgICAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiByZWplY3RlZCkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihyZXN1bHQucmVhc29uKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7cmVqZWN0ZWQubGVuZ3RofSBwcm9taXNlKHMpIGZhaWxlZCAtIHNlZSB0aGUgYWJvdmUgZXJyb3JzYCk7XG4gICAgfVxuICAgIC8vIE5vdGU6IFRTIHdhcyBjb21wbGFpbmluZyBhYm91dCB1c2luZyBgLmZpbHRlcigpLm1hcCgpYCBoZXJlIGZvciBzb21lIHJlYXNvblxuICAgIGNvbnN0IHZhbHVlcyA9IFtdO1xuICAgIGZvciAoY29uc3QgcmVzdWx0IG9mIHJlc3VsdHMpIHtcbiAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgPT09ICdmdWxmaWxsZWQnKSB7XG4gICAgICAgICAgICB2YWx1ZXMucHVzaChyZXN1bHQudmFsdWUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZXM7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9VXRpbC5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0IHsgc2xlZXAsIGlzUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vLi4vY29yZS5tanNcIjtcbmltcG9ydCB7IEN1cnNvclBhZ2UsIFBhZ2UgfSBmcm9tIFwiLi4vLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBGaWxlcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgICAvKipcbiAgICAgKiBDcmVhdGUgYSB2ZWN0b3Igc3RvcmUgZmlsZSBieSBhdHRhY2hpbmcgYVxuICAgICAqIFtGaWxlXShodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vZG9jcy9hcGktcmVmZXJlbmNlL2ZpbGVzKSB0byBhXG4gICAgICogW3ZlY3RvciBzdG9yZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvYXBpLXJlZmVyZW5jZS92ZWN0b3Itc3RvcmVzL29iamVjdCkuXG4gICAgICovXG4gICAgY3JlYXRlKHZlY3RvclN0b3JlSWQsIGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KGAvdmVjdG9yX3N0b3Jlcy8ke3ZlY3RvclN0b3JlSWR9L2ZpbGVzYCwge1xuICAgICAgICAgICAgYm9keSxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0cmlldmVzIGEgdmVjdG9yIHN0b3JlIGZpbGUuXG4gICAgICovXG4gICAgcmV0cmlldmUodmVjdG9yU3RvcmVJZCwgZmlsZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0KGAvdmVjdG9yX3N0b3Jlcy8ke3ZlY3RvclN0b3JlSWR9L2ZpbGVzLyR7ZmlsZUlkfWAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogVXBkYXRlIGF0dHJpYnV0ZXMgb24gYSB2ZWN0b3Igc3RvcmUgZmlsZS5cbiAgICAgKi9cbiAgICB1cGRhdGUodmVjdG9yU3RvcmVJZCwgZmlsZUlkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3ZlY3Rvcl9zdG9yZXMvJHt2ZWN0b3JTdG9yZUlkfS9maWxlcy8ke2ZpbGVJZH1gLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBsaXN0KHZlY3RvclN0b3JlSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KHZlY3RvclN0b3JlSWQsIHt9LCBxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXRBUElMaXN0KGAvdmVjdG9yX3N0b3Jlcy8ke3ZlY3RvclN0b3JlSWR9L2ZpbGVzYCwgVmVjdG9yU3RvcmVGaWxlc1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYSB2ZWN0b3Igc3RvcmUgZmlsZS4gVGhpcyB3aWxsIHJlbW92ZSB0aGUgZmlsZSBmcm9tIHRoZSB2ZWN0b3Igc3RvcmUgYnV0XG4gICAgICogdGhlIGZpbGUgaXRzZWxmIHdpbGwgbm90IGJlIGRlbGV0ZWQuIFRvIGRlbGV0ZSB0aGUgZmlsZSwgdXNlIHRoZVxuICAgICAqIFtkZWxldGUgZmlsZV0oaHR0cHM6Ly9wbGF0Zm9ybS5vcGVuYWkuY29tL2RvY3MvYXBpLXJlZmVyZW5jZS9maWxlcy9kZWxldGUpXG4gICAgICogZW5kcG9pbnQuXG4gICAgICovXG4gICAgZGVsKHZlY3RvclN0b3JlSWQsIGZpbGVJZCwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmRlbGV0ZShgL3ZlY3Rvcl9zdG9yZXMvJHt2ZWN0b3JTdG9yZUlkfS9maWxlcy8ke2ZpbGVJZH1gLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEF0dGFjaCBhIGZpbGUgdG8gdGhlIGdpdmVuIHZlY3RvciBzdG9yZSBhbmQgd2FpdCBmb3IgaXQgdG8gYmUgcHJvY2Vzc2VkLlxuICAgICAqL1xuICAgIGFzeW5jIGNyZWF0ZUFuZFBvbGwodmVjdG9yU3RvcmVJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBmaWxlID0gYXdhaXQgdGhpcy5jcmVhdGUodmVjdG9yU3RvcmVJZCwgYm9keSwgb3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLnBvbGwodmVjdG9yU3RvcmVJZCwgZmlsZS5pZCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFdhaXQgZm9yIHRoZSB2ZWN0b3Igc3RvcmUgZmlsZSB0byBmaW5pc2ggcHJvY2Vzc2luZy5cbiAgICAgKlxuICAgICAqIE5vdGU6IHRoaXMgd2lsbCByZXR1cm4gZXZlbiBpZiB0aGUgZmlsZSBmYWlsZWQgdG8gcHJvY2VzcywgeW91IG5lZWQgdG8gY2hlY2tcbiAgICAgKiBmaWxlLmxhc3RfZXJyb3IgYW5kIGZpbGUuc3RhdHVzIHRvIGhhbmRsZSB0aGVzZSBjYXNlc1xuICAgICAqL1xuICAgIGFzeW5jIHBvbGwodmVjdG9yU3RvcmVJZCwgZmlsZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSB7IC4uLm9wdGlvbnM/LmhlYWRlcnMsICdYLVN0YWlubGVzcy1Qb2xsLUhlbHBlcic6ICd0cnVlJyB9O1xuICAgICAgICBpZiAob3B0aW9ucz8ucG9sbEludGVydmFsTXMpIHtcbiAgICAgICAgICAgIGhlYWRlcnNbJ1gtU3RhaW5sZXNzLUN1c3RvbS1Qb2xsLUludGVydmFsJ10gPSBvcHRpb25zLnBvbGxJbnRlcnZhbE1zLnRvU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVSZXNwb25zZSA9IGF3YWl0IHRoaXMucmV0cmlldmUodmVjdG9yU3RvcmVJZCwgZmlsZUlkLCB7XG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgfSkud2l0aFJlc3BvbnNlKCk7XG4gICAgICAgICAgICBjb25zdCBmaWxlID0gZmlsZVJlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICBzd2l0Y2ggKGZpbGUuc3RhdHVzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnaW5fcHJvZ3Jlc3MnOlxuICAgICAgICAgICAgICAgICAgICBsZXQgc2xlZXBJbnRlcnZhbCA9IDUwMDA7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHRpb25zPy5wb2xsSW50ZXJ2YWxNcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2xlZXBJbnRlcnZhbCA9IG9wdGlvbnMucG9sbEludGVydmFsTXM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBoZWFkZXJJbnRlcnZhbCA9IGZpbGVSZXNwb25zZS5yZXNwb25zZS5oZWFkZXJzLmdldCgnb3BlbmFpLXBvbGwtYWZ0ZXItbXMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWFkZXJJbnRlcnZhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGhlYWRlckludGVydmFsTXMgPSBwYXJzZUludChoZWFkZXJJbnRlcnZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc05hTihoZWFkZXJJbnRlcnZhbE1zKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzbGVlcEludGVydmFsID0gaGVhZGVySW50ZXJ2YWxNcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgc2xlZXAoc2xlZXBJbnRlcnZhbCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgJ2ZhaWxlZCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnY29tcGxldGVkJzpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZpbGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogVXBsb2FkIGEgZmlsZSB0byB0aGUgYGZpbGVzYCBBUEkgYW5kIHRoZW4gYXR0YWNoIGl0IHRvIHRoZSBnaXZlbiB2ZWN0b3Igc3RvcmUuXG4gICAgICpcbiAgICAgKiBOb3RlIHRoZSBmaWxlIHdpbGwgYmUgYXN5bmNocm9ub3VzbHkgcHJvY2Vzc2VkICh5b3UgY2FuIHVzZSB0aGUgYWx0ZXJuYXRpdmVcbiAgICAgKiBwb2xsaW5nIGhlbHBlciBtZXRob2QgdG8gd2FpdCBmb3IgcHJvY2Vzc2luZyB0byBjb21wbGV0ZSkuXG4gICAgICovXG4gICAgYXN5bmMgdXBsb2FkKHZlY3RvclN0b3JlSWQsIGZpbGUsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgZmlsZUluZm8gPSBhd2FpdCB0aGlzLl9jbGllbnQuZmlsZXMuY3JlYXRlKHsgZmlsZTogZmlsZSwgcHVycG9zZTogJ2Fzc2lzdGFudHMnIH0sIG9wdGlvbnMpO1xuICAgICAgICByZXR1cm4gdGhpcy5jcmVhdGUodmVjdG9yU3RvcmVJZCwgeyBmaWxlX2lkOiBmaWxlSW5mby5pZCB9LCBvcHRpb25zKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQWRkIGEgZmlsZSB0byBhIHZlY3RvciBzdG9yZSBhbmQgcG9sbCB1bnRpbCBwcm9jZXNzaW5nIGlzIGNvbXBsZXRlLlxuICAgICAqL1xuICAgIGFzeW5jIHVwbG9hZEFuZFBvbGwodmVjdG9yU3RvcmVJZCwgZmlsZSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBmaWxlSW5mbyA9IGF3YWl0IHRoaXMudXBsb2FkKHZlY3RvclN0b3JlSWQsIGZpbGUsIG9wdGlvbnMpO1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5wb2xsKHZlY3RvclN0b3JlSWQsIGZpbGVJbmZvLmlkLCBvcHRpb25zKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0cmlldmUgdGhlIHBhcnNlZCBjb250ZW50cyBvZiBhIHZlY3RvciBzdG9yZSBmaWxlLlxuICAgICAqL1xuICAgIGNvbnRlbnQodmVjdG9yU3RvcmVJZCwgZmlsZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0QVBJTGlzdChgL3ZlY3Rvcl9zdG9yZXMvJHt2ZWN0b3JTdG9yZUlkfS9maWxlcy8ke2ZpbGVJZH0vY29udGVudGAsIEZpbGVDb250ZW50UmVzcG9uc2VzUGFnZSwgeyAuLi5vcHRpb25zLCBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9IH0pO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBWZWN0b3JTdG9yZUZpbGVzUGFnZSBleHRlbmRzIEN1cnNvclBhZ2Uge1xufVxuLyoqXG4gKiBOb3RlOiBubyBwYWdpbmF0aW9uIGFjdHVhbGx5IG9jY3VycyB5ZXQsIHRoaXMgaXMgZm9yIGZvcndhcmRzLWNvbXBhdGliaWxpdHkuXG4gKi9cbmV4cG9ydCBjbGFzcyBGaWxlQ29udGVudFJlc3BvbnNlc1BhZ2UgZXh0ZW5kcyBQYWdlIHtcbn1cbkZpbGVzLlZlY3RvclN0b3JlRmlsZXNQYWdlID0gVmVjdG9yU3RvcmVGaWxlc1BhZ2U7XG5GaWxlcy5GaWxlQ29udGVudFJlc3BvbnNlc1BhZ2UgPSBGaWxlQ29udGVudFJlc3BvbnNlc1BhZ2U7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1maWxlcy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0IHsgaXNSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi8uLi9jb3JlLm1qc1wiO1xuaW1wb3J0IHsgc2xlZXAgfSBmcm9tIFwiLi4vLi4vY29yZS5tanNcIjtcbmltcG9ydCB7IGFsbFNldHRsZWRXaXRoVGhyb3cgfSBmcm9tIFwiLi4vLi4vbGliL1V0aWwubWpzXCI7XG5pbXBvcnQgeyBWZWN0b3JTdG9yZUZpbGVzUGFnZSB9IGZyb20gXCIuL2ZpbGVzLm1qc1wiO1xuZXhwb3J0IGNsYXNzIEZpbGVCYXRjaGVzIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZSBhIHZlY3RvciBzdG9yZSBmaWxlIGJhdGNoLlxuICAgICAqL1xuICAgIGNyZWF0ZSh2ZWN0b3JTdG9yZUlkLCBib2R5LCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQucG9zdChgL3ZlY3Rvcl9zdG9yZXMvJHt2ZWN0b3JTdG9yZUlkfS9maWxlX2JhdGNoZXNgLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZXMgYSB2ZWN0b3Igc3RvcmUgZmlsZSBiYXRjaC5cbiAgICAgKi9cbiAgICByZXRyaWV2ZSh2ZWN0b3JTdG9yZUlkLCBiYXRjaElkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0KGAvdmVjdG9yX3N0b3Jlcy8ke3ZlY3RvclN0b3JlSWR9L2ZpbGVfYmF0Y2hlcy8ke2JhdGNoSWR9YCwge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDYW5jZWwgYSB2ZWN0b3Igc3RvcmUgZmlsZSBiYXRjaC4gVGhpcyBhdHRlbXB0cyB0byBjYW5jZWwgdGhlIHByb2Nlc3Npbmcgb2ZcbiAgICAgKiBmaWxlcyBpbiB0aGlzIGJhdGNoIGFzIHNvb24gYXMgcG9zc2libGUuXG4gICAgICovXG4gICAgY2FuY2VsKHZlY3RvclN0b3JlSWQsIGJhdGNoSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KGAvdmVjdG9yX3N0b3Jlcy8ke3ZlY3RvclN0b3JlSWR9L2ZpbGVfYmF0Y2hlcy8ke2JhdGNoSWR9L2NhbmNlbGAsIHtcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICBoZWFkZXJzOiB7ICdPcGVuQUktQmV0YSc6ICdhc3Npc3RhbnRzPXYyJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ3JlYXRlIGEgdmVjdG9yIHN0b3JlIGJhdGNoIGFuZCBwb2xsIHVudGlsIGFsbCBmaWxlcyBoYXZlIGJlZW4gcHJvY2Vzc2VkLlxuICAgICAqL1xuICAgIGFzeW5jIGNyZWF0ZUFuZFBvbGwodmVjdG9yU3RvcmVJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBiYXRjaCA9IGF3YWl0IHRoaXMuY3JlYXRlKHZlY3RvclN0b3JlSWQsIGJvZHkpO1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5wb2xsKHZlY3RvclN0b3JlSWQsIGJhdGNoLmlkLCBvcHRpb25zKTtcbiAgICB9XG4gICAgbGlzdEZpbGVzKHZlY3RvclN0b3JlSWQsIGJhdGNoSWQsIHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0RmlsZXModmVjdG9yU3RvcmVJZCwgYmF0Y2hJZCwge30sIHF1ZXJ5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC92ZWN0b3Jfc3RvcmVzLyR7dmVjdG9yU3RvcmVJZH0vZmlsZV9iYXRjaGVzLyR7YmF0Y2hJZH0vZmlsZXNgLCBWZWN0b3JTdG9yZUZpbGVzUGFnZSwgeyBxdWVyeSwgLi4ub3B0aW9ucywgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogV2FpdCBmb3IgdGhlIGdpdmVuIGZpbGUgYmF0Y2ggdG8gYmUgcHJvY2Vzc2VkLlxuICAgICAqXG4gICAgICogTm90ZTogdGhpcyB3aWxsIHJldHVybiBldmVuIGlmIG9uZSBvZiB0aGUgZmlsZXMgZmFpbGVkIHRvIHByb2Nlc3MsIHlvdSBuZWVkIHRvXG4gICAgICogY2hlY2sgYmF0Y2guZmlsZV9jb3VudHMuZmFpbGVkX2NvdW50IHRvIGhhbmRsZSB0aGlzIGNhc2UuXG4gICAgICovXG4gICAgYXN5bmMgcG9sbCh2ZWN0b3JTdG9yZUlkLCBiYXRjaElkLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSB7IC4uLm9wdGlvbnM/LmhlYWRlcnMsICdYLVN0YWlubGVzcy1Qb2xsLUhlbHBlcic6ICd0cnVlJyB9O1xuICAgICAgICBpZiAob3B0aW9ucz8ucG9sbEludGVydmFsTXMpIHtcbiAgICAgICAgICAgIGhlYWRlcnNbJ1gtU3RhaW5sZXNzLUN1c3RvbS1Qb2xsLUludGVydmFsJ10gPSBvcHRpb25zLnBvbGxJbnRlcnZhbE1zLnRvU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogYmF0Y2gsIHJlc3BvbnNlIH0gPSBhd2FpdCB0aGlzLnJldHJpZXZlKHZlY3RvclN0b3JlSWQsIGJhdGNoSWQsIHtcbiAgICAgICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICB9KS53aXRoUmVzcG9uc2UoKTtcbiAgICAgICAgICAgIHN3aXRjaCAoYmF0Y2guc3RhdHVzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnaW5fcHJvZ3Jlc3MnOlxuICAgICAgICAgICAgICAgICAgICBsZXQgc2xlZXBJbnRlcnZhbCA9IDUwMDA7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHRpb25zPy5wb2xsSW50ZXJ2YWxNcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2xlZXBJbnRlcnZhbCA9IG9wdGlvbnMucG9sbEludGVydmFsTXM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBoZWFkZXJJbnRlcnZhbCA9IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdvcGVuYWktcG9sbC1hZnRlci1tcycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlYWRlckludGVydmFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaGVhZGVySW50ZXJ2YWxNcyA9IHBhcnNlSW50KGhlYWRlckludGVydmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKGhlYWRlckludGVydmFsTXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNsZWVwSW50ZXJ2YWwgPSBoZWFkZXJJbnRlcnZhbE1zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBzbGVlcChzbGVlcEludGVydmFsKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAnZmFpbGVkJzpcbiAgICAgICAgICAgICAgICBjYXNlICdjYW5jZWxsZWQnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ2NvbXBsZXRlZCc6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBiYXRjaDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBVcGxvYWRzIHRoZSBnaXZlbiBmaWxlcyBjb25jdXJyZW50bHkgYW5kIHRoZW4gY3JlYXRlcyBhIHZlY3RvciBzdG9yZSBmaWxlIGJhdGNoLlxuICAgICAqXG4gICAgICogVGhlIGNvbmN1cnJlbmN5IGxpbWl0IGlzIGNvbmZpZ3VyYWJsZSB1c2luZyB0aGUgYG1heENvbmN1cnJlbmN5YCBwYXJhbWV0ZXIuXG4gICAgICovXG4gICAgYXN5bmMgdXBsb2FkQW5kUG9sbCh2ZWN0b3JTdG9yZUlkLCB7IGZpbGVzLCBmaWxlSWRzID0gW10gfSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoZmlsZXMgPT0gbnVsbCB8fCBmaWxlcy5sZW5ndGggPT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBObyBcXGBmaWxlc1xcYCBwcm92aWRlZCB0byBwcm9jZXNzLiBJZiB5b3UndmUgYWxyZWFkeSB1cGxvYWRlZCBmaWxlcyB5b3Ugc2hvdWxkIHVzZSBcXGAuY3JlYXRlQW5kUG9sbCgpXFxgIGluc3RlYWRgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjb25maWd1cmVkQ29uY3VycmVuY3kgPSBvcHRpb25zPy5tYXhDb25jdXJyZW5jeSA/PyA1O1xuICAgICAgICAvLyBXZSBjYXAgdGhlIG51bWJlciBvZiB3b3JrZXJzIGF0IHRoZSBudW1iZXIgb2YgZmlsZXMgKHNvIHdlIGRvbid0IHN0YXJ0IGFueSB1bm5lY2Vzc2FyeSB3b3JrZXJzKVxuICAgICAgICBjb25zdCBjb25jdXJyZW5jeUxpbWl0ID0gTWF0aC5taW4oY29uZmlndXJlZENvbmN1cnJlbmN5LCBmaWxlcy5sZW5ndGgpO1xuICAgICAgICBjb25zdCBjbGllbnQgPSB0aGlzLl9jbGllbnQ7XG4gICAgICAgIGNvbnN0IGZpbGVJdGVyYXRvciA9IGZpbGVzLnZhbHVlcygpO1xuICAgICAgICBjb25zdCBhbGxGaWxlSWRzID0gWy4uLmZpbGVJZHNdO1xuICAgICAgICAvLyBUaGlzIGNvZGUgaXMgYmFzZWQgb24gdGhpcyBkZXNpZ24uIFRoZSBsaWJyYXJpZXMgZG9uJ3QgYWNjb21tb2RhdGUgb3VyIGVudmlyb25tZW50IGxpbWl0cy5cbiAgICAgICAgLy8gaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvNDA2Mzk0MzIvd2hhdC1pcy10aGUtYmVzdC13YXktdG8tbGltaXQtY29uY3VycmVuY3ktd2hlbi11c2luZy1lczZzLXByb21pc2UtYWxsXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NGaWxlcyhpdGVyYXRvcikge1xuICAgICAgICAgICAgZm9yIChsZXQgaXRlbSBvZiBpdGVyYXRvcikge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpbGVPYmogPSBhd2FpdCBjbGllbnQuZmlsZXMuY3JlYXRlKHsgZmlsZTogaXRlbSwgcHVycG9zZTogJ2Fzc2lzdGFudHMnIH0sIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgIGFsbEZpbGVJZHMucHVzaChmaWxlT2JqLmlkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBTdGFydCB3b3JrZXJzIHRvIHByb2Nlc3MgcmVzdWx0c1xuICAgICAgICBjb25zdCB3b3JrZXJzID0gQXJyYXkoY29uY3VycmVuY3lMaW1pdCkuZmlsbChmaWxlSXRlcmF0b3IpLm1hcChwcm9jZXNzRmlsZXMpO1xuICAgICAgICAvLyBXYWl0IGZvciBhbGwgcHJvY2Vzc2luZyB0byBjb21wbGV0ZS5cbiAgICAgICAgYXdhaXQgYWxsU2V0dGxlZFdpdGhUaHJvdyh3b3JrZXJzKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY3JlYXRlQW5kUG9sbCh2ZWN0b3JTdG9yZUlkLCB7XG4gICAgICAgICAgICBmaWxlX2lkczogYWxsRmlsZUlkcyxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0IHsgVmVjdG9yU3RvcmVGaWxlc1BhZ2UgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZpbGUtYmF0Y2hlcy5tanMubWFwIiwiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uL3Jlc291cmNlLm1qc1wiO1xuaW1wb3J0IHsgaXNSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi8uLi9jb3JlLm1qc1wiO1xuaW1wb3J0ICogYXMgRmlsZUJhdGNoZXNBUEkgZnJvbSBcIi4vZmlsZS1iYXRjaGVzLm1qc1wiO1xuaW1wb3J0IHsgRmlsZUJhdGNoZXMsIH0gZnJvbSBcIi4vZmlsZS1iYXRjaGVzLm1qc1wiO1xuaW1wb3J0ICogYXMgRmlsZXNBUEkgZnJvbSBcIi4vZmlsZXMubWpzXCI7XG5pbXBvcnQgeyBGaWxlQ29udGVudFJlc3BvbnNlc1BhZ2UsIEZpbGVzLCBWZWN0b3JTdG9yZUZpbGVzUGFnZSwgfSBmcm9tIFwiLi9maWxlcy5tanNcIjtcbmltcG9ydCB7IEN1cnNvclBhZ2UsIFBhZ2UgfSBmcm9tIFwiLi4vLi4vcGFnaW5hdGlvbi5tanNcIjtcbmV4cG9ydCBjbGFzcyBWZWN0b3JTdG9yZXMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuZmlsZXMgPSBuZXcgRmlsZXNBUEkuRmlsZXModGhpcy5fY2xpZW50KTtcbiAgICAgICAgdGhpcy5maWxlQmF0Y2hlcyA9IG5ldyBGaWxlQmF0Y2hlc0FQSS5GaWxlQmF0Y2hlcyh0aGlzLl9jbGllbnQpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGUgYSB2ZWN0b3Igc3RvcmUuXG4gICAgICovXG4gICAgY3JlYXRlKGJvZHksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvdmVjdG9yX3N0b3JlcycsIHtcbiAgICAgICAgICAgIGJvZHksXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHZlY3RvciBzdG9yZS5cbiAgICAgKi9cbiAgICByZXRyaWV2ZSh2ZWN0b3JTdG9yZUlkLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbGllbnQuZ2V0KGAvdmVjdG9yX3N0b3Jlcy8ke3ZlY3RvclN0b3JlSWR9YCwge1xuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBNb2RpZmllcyBhIHZlY3RvciBzdG9yZS5cbiAgICAgKi9cbiAgICB1cGRhdGUodmVjdG9yU3RvcmVJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoYC92ZWN0b3Jfc3RvcmVzLyR7dmVjdG9yU3RvcmVJZH1gLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBsaXN0KHF1ZXJ5ID0ge30sIG9wdGlvbnMpIHtcbiAgICAgICAgaWYgKGlzUmVxdWVzdE9wdGlvbnMocXVlcnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0KHt9LCBxdWVyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5nZXRBUElMaXN0KCcvdmVjdG9yX3N0b3JlcycsIFZlY3RvclN0b3Jlc1BhZ2UsIHtcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ09wZW5BSS1CZXRhJzogJ2Fzc2lzdGFudHM9djInLCAuLi5vcHRpb25zPy5oZWFkZXJzIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYSB2ZWN0b3Igc3RvcmUuXG4gICAgICovXG4gICAgZGVsKHZlY3RvclN0b3JlSWQsIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NsaWVudC5kZWxldGUoYC92ZWN0b3Jfc3RvcmVzLyR7dmVjdG9yU3RvcmVJZH1gLCB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFNlYXJjaCBhIHZlY3RvciBzdG9yZSBmb3IgcmVsZXZhbnQgY2h1bmtzIGJhc2VkIG9uIGEgcXVlcnkgYW5kIGZpbGUgYXR0cmlidXRlc1xuICAgICAqIGZpbHRlci5cbiAgICAgKi9cbiAgICBzZWFyY2godmVjdG9yU3RvcmVJZCwgYm9keSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2xpZW50LmdldEFQSUxpc3QoYC92ZWN0b3Jfc3RvcmVzLyR7dmVjdG9yU3RvcmVJZH0vc2VhcmNoYCwgVmVjdG9yU3RvcmVTZWFyY2hSZXNwb25zZXNQYWdlLCB7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgbWV0aG9kOiAncG9zdCcsXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgaGVhZGVyczogeyAnT3BlbkFJLUJldGEnOiAnYXNzaXN0YW50cz12MicsIC4uLm9wdGlvbnM/LmhlYWRlcnMgfSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFZlY3RvclN0b3Jlc1BhZ2UgZXh0ZW5kcyBDdXJzb3JQYWdlIHtcbn1cbi8qKlxuICogTm90ZTogbm8gcGFnaW5hdGlvbiBhY3R1YWxseSBvY2N1cnMgeWV0LCB0aGlzIGlzIGZvciBmb3J3YXJkcy1jb21wYXRpYmlsaXR5LlxuICovXG5leHBvcnQgY2xhc3MgVmVjdG9yU3RvcmVTZWFyY2hSZXNwb25zZXNQYWdlIGV4dGVuZHMgUGFnZSB7XG59XG5WZWN0b3JTdG9yZXMuVmVjdG9yU3RvcmVzUGFnZSA9IFZlY3RvclN0b3Jlc1BhZ2U7XG5WZWN0b3JTdG9yZXMuVmVjdG9yU3RvcmVTZWFyY2hSZXNwb25zZXNQYWdlID0gVmVjdG9yU3RvcmVTZWFyY2hSZXNwb25zZXNQYWdlO1xuVmVjdG9yU3RvcmVzLkZpbGVzID0gRmlsZXM7XG5WZWN0b3JTdG9yZXMuVmVjdG9yU3RvcmVGaWxlc1BhZ2UgPSBWZWN0b3JTdG9yZUZpbGVzUGFnZTtcblZlY3RvclN0b3Jlcy5GaWxlQ29udGVudFJlc3BvbnNlc1BhZ2UgPSBGaWxlQ29udGVudFJlc3BvbnNlc1BhZ2U7XG5WZWN0b3JTdG9yZXMuRmlsZUJhdGNoZXMgPSBGaWxlQmF0Y2hlcztcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXZlY3Rvci1zdG9yZXMubWpzLm1hcCIsIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG52YXIgX2E7XG5pbXBvcnQgKiBhcyBxcyBmcm9tIFwiLi9pbnRlcm5hbC9xcy9pbmRleC5tanNcIjtcbmltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4vY29yZS5tanNcIjtcbmltcG9ydCAqIGFzIEVycm9ycyBmcm9tIFwiLi9lcnJvci5tanNcIjtcbmltcG9ydCAqIGFzIFBhZ2luYXRpb24gZnJvbSBcIi4vcGFnaW5hdGlvbi5tanNcIjtcbmltcG9ydCAqIGFzIFVwbG9hZHMgZnJvbSBcIi4vdXBsb2Fkcy5tanNcIjtcbmltcG9ydCAqIGFzIEFQSSBmcm9tIFwiLi9yZXNvdXJjZXMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBCYXRjaGVzLCBCYXRjaGVzUGFnZSwgfSBmcm9tIFwiLi9yZXNvdXJjZXMvYmF0Y2hlcy5tanNcIjtcbmltcG9ydCB7IENvbXBsZXRpb25zLCB9IGZyb20gXCIuL3Jlc291cmNlcy9jb21wbGV0aW9ucy5tanNcIjtcbmltcG9ydCB7IEVtYmVkZGluZ3MsIH0gZnJvbSBcIi4vcmVzb3VyY2VzL2VtYmVkZGluZ3MubWpzXCI7XG5pbXBvcnQgeyBGaWxlT2JqZWN0c1BhZ2UsIEZpbGVzLCB9IGZyb20gXCIuL3Jlc291cmNlcy9maWxlcy5tanNcIjtcbmltcG9ydCB7IEltYWdlcywgfSBmcm9tIFwiLi9yZXNvdXJjZXMvaW1hZ2VzLm1qc1wiO1xuaW1wb3J0IHsgTW9kZWxzLCBNb2RlbHNQYWdlIH0gZnJvbSBcIi4vcmVzb3VyY2VzL21vZGVscy5tanNcIjtcbmltcG9ydCB7IE1vZGVyYXRpb25zLCB9IGZyb20gXCIuL3Jlc291cmNlcy9tb2RlcmF0aW9ucy5tanNcIjtcbmltcG9ydCB7IEF1ZGlvIH0gZnJvbSBcIi4vcmVzb3VyY2VzL2F1ZGlvL2F1ZGlvLm1qc1wiO1xuaW1wb3J0IHsgQmV0YSB9IGZyb20gXCIuL3Jlc291cmNlcy9iZXRhL2JldGEubWpzXCI7XG5pbXBvcnQgeyBDaGF0IH0gZnJvbSBcIi4vcmVzb3VyY2VzL2NoYXQvY2hhdC5tanNcIjtcbmltcG9ydCB7IENvbnRhaW5lckxpc3RSZXNwb25zZXNQYWdlLCBDb250YWluZXJzLCB9IGZyb20gXCIuL3Jlc291cmNlcy9jb250YWluZXJzL2NvbnRhaW5lcnMubWpzXCI7XG5pbXBvcnQgeyBFdmFsTGlzdFJlc3BvbnNlc1BhZ2UsIEV2YWxzLCB9IGZyb20gXCIuL3Jlc291cmNlcy9ldmFscy9ldmFscy5tanNcIjtcbmltcG9ydCB7IEZpbmVUdW5pbmcgfSBmcm9tIFwiLi9yZXNvdXJjZXMvZmluZS10dW5pbmcvZmluZS10dW5pbmcubWpzXCI7XG5pbXBvcnQgeyBHcmFkZXJzIH0gZnJvbSBcIi4vcmVzb3VyY2VzL2dyYWRlcnMvZ3JhZGVycy5tanNcIjtcbmltcG9ydCB7IFJlc3BvbnNlcyB9IGZyb20gXCIuL3Jlc291cmNlcy9yZXNwb25zZXMvcmVzcG9uc2VzLm1qc1wiO1xuaW1wb3J0IHsgVXBsb2FkcyBhcyBVcGxvYWRzQVBJVXBsb2FkcywgfSBmcm9tIFwiLi9yZXNvdXJjZXMvdXBsb2Fkcy91cGxvYWRzLm1qc1wiO1xuaW1wb3J0IHsgVmVjdG9yU3RvcmVTZWFyY2hSZXNwb25zZXNQYWdlLCBWZWN0b3JTdG9yZXMsIFZlY3RvclN0b3Jlc1BhZ2UsIH0gZnJvbSBcIi4vcmVzb3VyY2VzL3ZlY3Rvci1zdG9yZXMvdmVjdG9yLXN0b3Jlcy5tanNcIjtcbmltcG9ydCB7IENoYXRDb21wbGV0aW9uc1BhZ2UsIH0gZnJvbSBcIi4vcmVzb3VyY2VzL2NoYXQvY29tcGxldGlvbnMvY29tcGxldGlvbnMubWpzXCI7XG4vKipcbiAqIEFQSSBDbGllbnQgZm9yIGludGVyZmFjaW5nIHdpdGggdGhlIE9wZW5BSSBBUEkuXG4gKi9cbmV4cG9ydCBjbGFzcyBPcGVuQUkgZXh0ZW5kcyBDb3JlLkFQSUNsaWVudCB7XG4gICAgLyoqXG4gICAgICogQVBJIENsaWVudCBmb3IgaW50ZXJmYWNpbmcgd2l0aCB0aGUgT3BlbkFJIEFQSS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgdW5kZWZpbmVkfSBbb3B0cy5hcGlLZXk9cHJvY2Vzcy5lbnZbJ09QRU5BSV9BUElfS0VZJ10gPz8gdW5kZWZpbmVkXVxuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gW29wdHMub3JnYW5pemF0aW9uPXByb2Nlc3MuZW52WydPUEVOQUlfT1JHX0lEJ10gPz8gbnVsbF1cbiAgICAgKiBAcGFyYW0ge3N0cmluZyB8IG51bGwgfCB1bmRlZmluZWR9IFtvcHRzLnByb2plY3Q9cHJvY2Vzcy5lbnZbJ09QRU5BSV9QUk9KRUNUX0lEJ10gPz8gbnVsbF1cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdHMuYmFzZVVSTD1wcm9jZXNzLmVudlsnT1BFTkFJX0JBU0VfVVJMJ10gPz8gaHR0cHM6Ly9hcGkub3BlbmFpLmNvbS92MV0gLSBPdmVycmlkZSB0aGUgZGVmYXVsdCBiYXNlIFVSTCBmb3IgdGhlIEFQSS5cbiAgICAgKiBAcGFyYW0ge251bWJlcn0gW29wdHMudGltZW91dD0xMCBtaW51dGVzXSAtIFRoZSBtYXhpbXVtIGFtb3VudCBvZiB0aW1lIChpbiBtaWxsaXNlY29uZHMpIHRoZSBjbGllbnQgd2lsbCB3YWl0IGZvciBhIHJlc3BvbnNlIGJlZm9yZSB0aW1pbmcgb3V0LlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0cy5odHRwQWdlbnRdIC0gQW4gSFRUUCBhZ2VudCB1c2VkIHRvIG1hbmFnZSBIVFRQKHMpIGNvbm5lY3Rpb25zLlxuICAgICAqIEBwYXJhbSB7Q29yZS5GZXRjaH0gW29wdHMuZmV0Y2hdIC0gU3BlY2lmeSBhIGN1c3RvbSBgZmV0Y2hgIGZ1bmN0aW9uIGltcGxlbWVudGF0aW9uLlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0cy5tYXhSZXRyaWVzPTJdIC0gVGhlIG1heGltdW0gbnVtYmVyIG9mIHRpbWVzIHRoZSBjbGllbnQgd2lsbCByZXRyeSBhIHJlcXVlc3QuXG4gICAgICogQHBhcmFtIHtDb3JlLkhlYWRlcnN9IG9wdHMuZGVmYXVsdEhlYWRlcnMgLSBEZWZhdWx0IGhlYWRlcnMgdG8gaW5jbHVkZSB3aXRoIGV2ZXJ5IHJlcXVlc3QgdG8gdGhlIEFQSS5cbiAgICAgKiBAcGFyYW0ge0NvcmUuRGVmYXVsdFF1ZXJ5fSBvcHRzLmRlZmF1bHRRdWVyeSAtIERlZmF1bHQgcXVlcnkgcGFyYW1ldGVycyB0byBpbmNsdWRlIHdpdGggZXZlcnkgcmVxdWVzdCB0byB0aGUgQVBJLlxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gW29wdHMuZGFuZ2Vyb3VzbHlBbGxvd0Jyb3dzZXI9ZmFsc2VdIC0gQnkgZGVmYXVsdCwgY2xpZW50LXNpZGUgdXNlIG9mIHRoaXMgbGlicmFyeSBpcyBub3QgYWxsb3dlZCwgYXMgaXQgcmlza3MgZXhwb3NpbmcgeW91ciBzZWNyZXQgQVBJIGNyZWRlbnRpYWxzIHRvIGF0dGFja2Vycy5cbiAgICAgKi9cbiAgICBjb25zdHJ1Y3Rvcih7IGJhc2VVUkwgPSBDb3JlLnJlYWRFbnYoJ09QRU5BSV9CQVNFX1VSTCcpLCBhcGlLZXkgPSBDb3JlLnJlYWRFbnYoJ09QRU5BSV9BUElfS0VZJyksIG9yZ2FuaXphdGlvbiA9IENvcmUucmVhZEVudignT1BFTkFJX09SR19JRCcpID8/IG51bGwsIHByb2plY3QgPSBDb3JlLnJlYWRFbnYoJ09QRU5BSV9QUk9KRUNUX0lEJykgPz8gbnVsbCwgLi4ub3B0cyB9ID0ge30pIHtcbiAgICAgICAgaWYgKGFwaUtleSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3JzLk9wZW5BSUVycm9yKFwiVGhlIE9QRU5BSV9BUElfS0VZIGVudmlyb25tZW50IHZhcmlhYmxlIGlzIG1pc3Npbmcgb3IgZW1wdHk7IGVpdGhlciBwcm92aWRlIGl0LCBvciBpbnN0YW50aWF0ZSB0aGUgT3BlbkFJIGNsaWVudCB3aXRoIGFuIGFwaUtleSBvcHRpb24sIGxpa2UgbmV3IE9wZW5BSSh7IGFwaUtleTogJ015IEFQSSBLZXknIH0pLlwiKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgICAgYXBpS2V5LFxuICAgICAgICAgICAgb3JnYW5pemF0aW9uLFxuICAgICAgICAgICAgcHJvamVjdCxcbiAgICAgICAgICAgIC4uLm9wdHMsXG4gICAgICAgICAgICBiYXNlVVJMOiBiYXNlVVJMIHx8IGBodHRwczovL2FwaS5vcGVuYWkuY29tL3YxYCxcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKCFvcHRpb25zLmRhbmdlcm91c2x5QWxsb3dCcm93c2VyICYmIENvcmUuaXNSdW5uaW5nSW5Ccm93c2VyKCkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcnMuT3BlbkFJRXJyb3IoXCJJdCBsb29rcyBsaWtlIHlvdSdyZSBydW5uaW5nIGluIGEgYnJvd3Nlci1saWtlIGVudmlyb25tZW50LlxcblxcblRoaXMgaXMgZGlzYWJsZWQgYnkgZGVmYXVsdCwgYXMgaXQgcmlza3MgZXhwb3NpbmcgeW91ciBzZWNyZXQgQVBJIGNyZWRlbnRpYWxzIHRvIGF0dGFja2Vycy5cXG5JZiB5b3UgdW5kZXJzdGFuZCB0aGUgcmlza3MgYW5kIGhhdmUgYXBwcm9wcmlhdGUgbWl0aWdhdGlvbnMgaW4gcGxhY2UsXFxueW91IGNhbiBzZXQgdGhlIGBkYW5nZXJvdXNseUFsbG93QnJvd3NlcmAgb3B0aW9uIHRvIGB0cnVlYCwgZS5nLixcXG5cXG5uZXcgT3BlbkFJKHsgYXBpS2V5LCBkYW5nZXJvdXNseUFsbG93QnJvd3NlcjogdHJ1ZSB9KTtcXG5cXG5odHRwczovL2hlbHAub3BlbmFpLmNvbS9lbi9hcnRpY2xlcy81MTEyNTk1LWJlc3QtcHJhY3RpY2VzLWZvci1hcGkta2V5LXNhZmV0eVxcblwiKTtcbiAgICAgICAgfVxuICAgICAgICBzdXBlcih7XG4gICAgICAgICAgICBiYXNlVVJMOiBvcHRpb25zLmJhc2VVUkwsXG4gICAgICAgICAgICB0aW1lb3V0OiBvcHRpb25zLnRpbWVvdXQgPz8gNjAwMDAwIC8qIDEwIG1pbnV0ZXMgKi8sXG4gICAgICAgICAgICBodHRwQWdlbnQ6IG9wdGlvbnMuaHR0cEFnZW50LFxuICAgICAgICAgICAgbWF4UmV0cmllczogb3B0aW9ucy5tYXhSZXRyaWVzLFxuICAgICAgICAgICAgZmV0Y2g6IG9wdGlvbnMuZmV0Y2gsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBsZXRpb25zID0gbmV3IEFQSS5Db21wbGV0aW9ucyh0aGlzKTtcbiAgICAgICAgdGhpcy5jaGF0ID0gbmV3IEFQSS5DaGF0KHRoaXMpO1xuICAgICAgICB0aGlzLmVtYmVkZGluZ3MgPSBuZXcgQVBJLkVtYmVkZGluZ3ModGhpcyk7XG4gICAgICAgIHRoaXMuZmlsZXMgPSBuZXcgQVBJLkZpbGVzKHRoaXMpO1xuICAgICAgICB0aGlzLmltYWdlcyA9IG5ldyBBUEkuSW1hZ2VzKHRoaXMpO1xuICAgICAgICB0aGlzLmF1ZGlvID0gbmV3IEFQSS5BdWRpbyh0aGlzKTtcbiAgICAgICAgdGhpcy5tb2RlcmF0aW9ucyA9IG5ldyBBUEkuTW9kZXJhdGlvbnModGhpcyk7XG4gICAgICAgIHRoaXMubW9kZWxzID0gbmV3IEFQSS5Nb2RlbHModGhpcyk7XG4gICAgICAgIHRoaXMuZmluZVR1bmluZyA9IG5ldyBBUEkuRmluZVR1bmluZyh0aGlzKTtcbiAgICAgICAgdGhpcy5ncmFkZXJzID0gbmV3IEFQSS5HcmFkZXJzKHRoaXMpO1xuICAgICAgICB0aGlzLnZlY3RvclN0b3JlcyA9IG5ldyBBUEkuVmVjdG9yU3RvcmVzKHRoaXMpO1xuICAgICAgICB0aGlzLmJldGEgPSBuZXcgQVBJLkJldGEodGhpcyk7XG4gICAgICAgIHRoaXMuYmF0Y2hlcyA9IG5ldyBBUEkuQmF0Y2hlcyh0aGlzKTtcbiAgICAgICAgdGhpcy51cGxvYWRzID0gbmV3IEFQSS5VcGxvYWRzKHRoaXMpO1xuICAgICAgICB0aGlzLnJlc3BvbnNlcyA9IG5ldyBBUEkuUmVzcG9uc2VzKHRoaXMpO1xuICAgICAgICB0aGlzLmV2YWxzID0gbmV3IEFQSS5FdmFscyh0aGlzKTtcbiAgICAgICAgdGhpcy5jb250YWluZXJzID0gbmV3IEFQSS5Db250YWluZXJzKHRoaXMpO1xuICAgICAgICB0aGlzLl9vcHRpb25zID0gb3B0aW9ucztcbiAgICAgICAgdGhpcy5hcGlLZXkgPSBhcGlLZXk7XG4gICAgICAgIHRoaXMub3JnYW5pemF0aW9uID0gb3JnYW5pemF0aW9uO1xuICAgICAgICB0aGlzLnByb2plY3QgPSBwcm9qZWN0O1xuICAgIH1cbiAgICBkZWZhdWx0UXVlcnkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9vcHRpb25zLmRlZmF1bHRRdWVyeTtcbiAgICB9XG4gICAgZGVmYXVsdEhlYWRlcnMob3B0cykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3VwZXIuZGVmYXVsdEhlYWRlcnMob3B0cyksXG4gICAgICAgICAgICAnT3BlbkFJLU9yZ2FuaXphdGlvbic6IHRoaXMub3JnYW5pemF0aW9uLFxuICAgICAgICAgICAgJ09wZW5BSS1Qcm9qZWN0JzogdGhpcy5wcm9qZWN0LFxuICAgICAgICAgICAgLi4udGhpcy5fb3B0aW9ucy5kZWZhdWx0SGVhZGVycyxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgYXV0aEhlYWRlcnMob3B0cykge1xuICAgICAgICByZXR1cm4geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5hcGlLZXl9YCB9O1xuICAgIH1cbiAgICBzdHJpbmdpZnlRdWVyeShxdWVyeSkge1xuICAgICAgICByZXR1cm4gcXMuc3RyaW5naWZ5KHF1ZXJ5LCB7IGFycmF5Rm9ybWF0OiAnYnJhY2tldHMnIH0pO1xuICAgIH1cbn1cbl9hID0gT3BlbkFJO1xuT3BlbkFJLk9wZW5BSSA9IF9hO1xuT3BlbkFJLkRFRkFVTFRfVElNRU9VVCA9IDYwMDAwMDsgLy8gMTAgbWludXRlc1xuT3BlbkFJLk9wZW5BSUVycm9yID0gRXJyb3JzLk9wZW5BSUVycm9yO1xuT3BlbkFJLkFQSUVycm9yID0gRXJyb3JzLkFQSUVycm9yO1xuT3BlbkFJLkFQSUNvbm5lY3Rpb25FcnJvciA9IEVycm9ycy5BUElDb25uZWN0aW9uRXJyb3I7XG5PcGVuQUkuQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvciA9IEVycm9ycy5BUElDb25uZWN0aW9uVGltZW91dEVycm9yO1xuT3BlbkFJLkFQSVVzZXJBYm9ydEVycm9yID0gRXJyb3JzLkFQSVVzZXJBYm9ydEVycm9yO1xuT3BlbkFJLk5vdEZvdW5kRXJyb3IgPSBFcnJvcnMuTm90Rm91bmRFcnJvcjtcbk9wZW5BSS5Db25mbGljdEVycm9yID0gRXJyb3JzLkNvbmZsaWN0RXJyb3I7XG5PcGVuQUkuUmF0ZUxpbWl0RXJyb3IgPSBFcnJvcnMuUmF0ZUxpbWl0RXJyb3I7XG5PcGVuQUkuQmFkUmVxdWVzdEVycm9yID0gRXJyb3JzLkJhZFJlcXVlc3RFcnJvcjtcbk9wZW5BSS5BdXRoZW50aWNhdGlvbkVycm9yID0gRXJyb3JzLkF1dGhlbnRpY2F0aW9uRXJyb3I7XG5PcGVuQUkuSW50ZXJuYWxTZXJ2ZXJFcnJvciA9IEVycm9ycy5JbnRlcm5hbFNlcnZlckVycm9yO1xuT3BlbkFJLlBlcm1pc3Npb25EZW5pZWRFcnJvciA9IEVycm9ycy5QZXJtaXNzaW9uRGVuaWVkRXJyb3I7XG5PcGVuQUkuVW5wcm9jZXNzYWJsZUVudGl0eUVycm9yID0gRXJyb3JzLlVucHJvY2Vzc2FibGVFbnRpdHlFcnJvcjtcbk9wZW5BSS50b0ZpbGUgPSBVcGxvYWRzLnRvRmlsZTtcbk9wZW5BSS5maWxlRnJvbVBhdGggPSBVcGxvYWRzLmZpbGVGcm9tUGF0aDtcbk9wZW5BSS5Db21wbGV0aW9ucyA9IENvbXBsZXRpb25zO1xuT3BlbkFJLkNoYXQgPSBDaGF0O1xuT3BlbkFJLkNoYXRDb21wbGV0aW9uc1BhZ2UgPSBDaGF0Q29tcGxldGlvbnNQYWdlO1xuT3BlbkFJLkVtYmVkZGluZ3MgPSBFbWJlZGRpbmdzO1xuT3BlbkFJLkZpbGVzID0gRmlsZXM7XG5PcGVuQUkuRmlsZU9iamVjdHNQYWdlID0gRmlsZU9iamVjdHNQYWdlO1xuT3BlbkFJLkltYWdlcyA9IEltYWdlcztcbk9wZW5BSS5BdWRpbyA9IEF1ZGlvO1xuT3BlbkFJLk1vZGVyYXRpb25zID0gTW9kZXJhdGlvbnM7XG5PcGVuQUkuTW9kZWxzID0gTW9kZWxzO1xuT3BlbkFJLk1vZGVsc1BhZ2UgPSBNb2RlbHNQYWdlO1xuT3BlbkFJLkZpbmVUdW5pbmcgPSBGaW5lVHVuaW5nO1xuT3BlbkFJLkdyYWRlcnMgPSBHcmFkZXJzO1xuT3BlbkFJLlZlY3RvclN0b3JlcyA9IFZlY3RvclN0b3Jlcztcbk9wZW5BSS5WZWN0b3JTdG9yZXNQYWdlID0gVmVjdG9yU3RvcmVzUGFnZTtcbk9wZW5BSS5WZWN0b3JTdG9yZVNlYXJjaFJlc3BvbnNlc1BhZ2UgPSBWZWN0b3JTdG9yZVNlYXJjaFJlc3BvbnNlc1BhZ2U7XG5PcGVuQUkuQmV0YSA9IEJldGE7XG5PcGVuQUkuQmF0Y2hlcyA9IEJhdGNoZXM7XG5PcGVuQUkuQmF0Y2hlc1BhZ2UgPSBCYXRjaGVzUGFnZTtcbk9wZW5BSS5VcGxvYWRzID0gVXBsb2Fkc0FQSVVwbG9hZHM7XG5PcGVuQUkuUmVzcG9uc2VzID0gUmVzcG9uc2VzO1xuT3BlbkFJLkV2YWxzID0gRXZhbHM7XG5PcGVuQUkuRXZhbExpc3RSZXNwb25zZXNQYWdlID0gRXZhbExpc3RSZXNwb25zZXNQYWdlO1xuT3BlbkFJLkNvbnRhaW5lcnMgPSBDb250YWluZXJzO1xuT3BlbkFJLkNvbnRhaW5lckxpc3RSZXNwb25zZXNQYWdlID0gQ29udGFpbmVyTGlzdFJlc3BvbnNlc1BhZ2U7XG4vKiogQVBJIENsaWVudCBmb3IgaW50ZXJmYWNpbmcgd2l0aCB0aGUgQXp1cmUgT3BlbkFJIEFQSS4gKi9cbmV4cG9ydCBjbGFzcyBBenVyZU9wZW5BSSBleHRlbmRzIE9wZW5BSSB7XG4gICAgLyoqXG4gICAgICogQVBJIENsaWVudCBmb3IgaW50ZXJmYWNpbmcgd2l0aCB0aGUgQXp1cmUgT3BlbkFJIEFQSS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgdW5kZWZpbmVkfSBbb3B0cy5hcGlWZXJzaW9uPXByb2Nlc3MuZW52WydPUEVOQUlfQVBJX1ZFUlNJT04nXSA/PyB1bmRlZmluZWRdXG4gICAgICogQHBhcmFtIHtzdHJpbmcgfCB1bmRlZmluZWR9IFtvcHRzLmVuZHBvaW50PXByb2Nlc3MuZW52WydBWlVSRV9PUEVOQUlfRU5EUE9JTlQnXSA/PyB1bmRlZmluZWRdIC0gWW91ciBBenVyZSBlbmRwb2ludCwgaW5jbHVkaW5nIHRoZSByZXNvdXJjZSwgZS5nLiBgaHR0cHM6Ly9leGFtcGxlLXJlc291cmNlLmF6dXJlLm9wZW5haS5jb20vYFxuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgdW5kZWZpbmVkfSBbb3B0cy5hcGlLZXk9cHJvY2Vzcy5lbnZbJ0FaVVJFX09QRU5BSV9BUElfS0VZJ10gPz8gdW5kZWZpbmVkXVxuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgdW5kZWZpbmVkfSBvcHRzLmRlcGxveW1lbnQgLSBBIG1vZGVsIGRlcGxveW1lbnQsIGlmIGdpdmVuLCBzZXRzIHRoZSBiYXNlIGNsaWVudCBVUkwgdG8gaW5jbHVkZSBgL2RlcGxveW1lbnRzL3tkZXBsb3ltZW50fWAuXG4gICAgICogQHBhcmFtIHtzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0cy5vcmdhbml6YXRpb249cHJvY2Vzcy5lbnZbJ09QRU5BSV9PUkdfSUQnXSA/PyBudWxsXVxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0cy5iYXNlVVJMPXByb2Nlc3MuZW52WydPUEVOQUlfQkFTRV9VUkwnXV0gLSBTZXRzIHRoZSBiYXNlIFVSTCBmb3IgdGhlIEFQSSwgZS5nLiBgaHR0cHM6Ly9leGFtcGxlLXJlc291cmNlLmF6dXJlLm9wZW5haS5jb20vb3BlbmFpL2AuXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IFtvcHRzLnRpbWVvdXQ9MTAgbWludXRlc10gLSBUaGUgbWF4aW11bSBhbW91bnQgb2YgdGltZSAoaW4gbWlsbGlzZWNvbmRzKSB0aGUgY2xpZW50IHdpbGwgd2FpdCBmb3IgYSByZXNwb25zZSBiZWZvcmUgdGltaW5nIG91dC5cbiAgICAgKiBAcGFyYW0ge251bWJlcn0gW29wdHMuaHR0cEFnZW50XSAtIEFuIEhUVFAgYWdlbnQgdXNlZCB0byBtYW5hZ2UgSFRUUChzKSBjb25uZWN0aW9ucy5cbiAgICAgKiBAcGFyYW0ge0NvcmUuRmV0Y2h9IFtvcHRzLmZldGNoXSAtIFNwZWNpZnkgYSBjdXN0b20gYGZldGNoYCBmdW5jdGlvbiBpbXBsZW1lbnRhdGlvbi5cbiAgICAgKiBAcGFyYW0ge251bWJlcn0gW29wdHMubWF4UmV0cmllcz0yXSAtIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0aW1lcyB0aGUgY2xpZW50IHdpbGwgcmV0cnkgYSByZXF1ZXN0LlxuICAgICAqIEBwYXJhbSB7Q29yZS5IZWFkZXJzfSBvcHRzLmRlZmF1bHRIZWFkZXJzIC0gRGVmYXVsdCBoZWFkZXJzIHRvIGluY2x1ZGUgd2l0aCBldmVyeSByZXF1ZXN0IHRvIHRoZSBBUEkuXG4gICAgICogQHBhcmFtIHtDb3JlLkRlZmF1bHRRdWVyeX0gb3B0cy5kZWZhdWx0UXVlcnkgLSBEZWZhdWx0IHF1ZXJ5IHBhcmFtZXRlcnMgdG8gaW5jbHVkZSB3aXRoIGV2ZXJ5IHJlcXVlc3QgdG8gdGhlIEFQSS5cbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IFtvcHRzLmRhbmdlcm91c2x5QWxsb3dCcm93c2VyPWZhbHNlXSAtIEJ5IGRlZmF1bHQsIGNsaWVudC1zaWRlIHVzZSBvZiB0aGlzIGxpYnJhcnkgaXMgbm90IGFsbG93ZWQsIGFzIGl0IHJpc2tzIGV4cG9zaW5nIHlvdXIgc2VjcmV0IEFQSSBjcmVkZW50aWFscyB0byBhdHRhY2tlcnMuXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoeyBiYXNlVVJMID0gQ29yZS5yZWFkRW52KCdPUEVOQUlfQkFTRV9VUkwnKSwgYXBpS2V5ID0gQ29yZS5yZWFkRW52KCdBWlVSRV9PUEVOQUlfQVBJX0tFWScpLCBhcGlWZXJzaW9uID0gQ29yZS5yZWFkRW52KCdPUEVOQUlfQVBJX1ZFUlNJT04nKSwgZW5kcG9pbnQsIGRlcGxveW1lbnQsIGF6dXJlQURUb2tlblByb3ZpZGVyLCBkYW5nZXJvdXNseUFsbG93QnJvd3NlciwgLi4ub3B0cyB9ID0ge30pIHtcbiAgICAgICAgaWYgKCFhcGlWZXJzaW9uKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3JzLk9wZW5BSUVycm9yKFwiVGhlIE9QRU5BSV9BUElfVkVSU0lPTiBlbnZpcm9ubWVudCB2YXJpYWJsZSBpcyBtaXNzaW5nIG9yIGVtcHR5OyBlaXRoZXIgcHJvdmlkZSBpdCwgb3IgaW5zdGFudGlhdGUgdGhlIEF6dXJlT3BlbkFJIGNsaWVudCB3aXRoIGFuIGFwaVZlcnNpb24gb3B0aW9uLCBsaWtlIG5ldyBBenVyZU9wZW5BSSh7IGFwaVZlcnNpb246ICdNeSBBUEkgVmVyc2lvbicgfSkuXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgYXp1cmVBRFRva2VuUHJvdmlkZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGRhbmdlcm91c2x5QWxsb3dCcm93c2VyID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWF6dXJlQURUb2tlblByb3ZpZGVyICYmICFhcGlLZXkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcnMuT3BlbkFJRXJyb3IoJ01pc3NpbmcgY3JlZGVudGlhbHMuIFBsZWFzZSBwYXNzIG9uZSBvZiBgYXBpS2V5YCBhbmQgYGF6dXJlQURUb2tlblByb3ZpZGVyYCwgb3Igc2V0IHRoZSBgQVpVUkVfT1BFTkFJX0FQSV9LRVlgIGVudmlyb25tZW50IHZhcmlhYmxlLicpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhenVyZUFEVG9rZW5Qcm92aWRlciAmJiBhcGlLZXkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcnMuT3BlbkFJRXJyb3IoJ1RoZSBgYXBpS2V5YCBhbmQgYGF6dXJlQURUb2tlblByb3ZpZGVyYCBhcmd1bWVudHMgYXJlIG11dHVhbGx5IGV4Y2x1c2l2ZTsgb25seSBvbmUgY2FuIGJlIHBhc3NlZCBhdCBhIHRpbWUuJyk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZGVmaW5lIGEgc2VudGluZWwgdmFsdWUgdG8gYXZvaWQgYW55IHR5cGluZyBpc3N1ZXNcbiAgICAgICAgYXBpS2V5ID8/IChhcGlLZXkgPSBBUElfS0VZX1NFTlRJTkVMKTtcbiAgICAgICAgb3B0cy5kZWZhdWx0UXVlcnkgPSB7IC4uLm9wdHMuZGVmYXVsdFF1ZXJ5LCAnYXBpLXZlcnNpb24nOiBhcGlWZXJzaW9uIH07XG4gICAgICAgIGlmICghYmFzZVVSTCkge1xuICAgICAgICAgICAgaWYgKCFlbmRwb2ludCkge1xuICAgICAgICAgICAgICAgIGVuZHBvaW50ID0gcHJvY2Vzcy5lbnZbJ0FaVVJFX09QRU5BSV9FTkRQT0lOVCddO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFlbmRwb2ludCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcnMuT3BlbkFJRXJyb3IoJ011c3QgcHJvdmlkZSBvbmUgb2YgdGhlIGBiYXNlVVJMYCBvciBgZW5kcG9pbnRgIGFyZ3VtZW50cywgb3IgdGhlIGBBWlVSRV9PUEVOQUlfRU5EUE9JTlRgIGVudmlyb25tZW50IHZhcmlhYmxlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBiYXNlVVJMID0gYCR7ZW5kcG9pbnR9L29wZW5haWA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBpZiAoZW5kcG9pbnQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3JzLk9wZW5BSUVycm9yKCdiYXNlVVJMIGFuZCBlbmRwb2ludCBhcmUgbXV0dWFsbHkgZXhjbHVzaXZlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgc3VwZXIoe1xuICAgICAgICAgICAgYXBpS2V5LFxuICAgICAgICAgICAgYmFzZVVSTCxcbiAgICAgICAgICAgIC4uLm9wdHMsXG4gICAgICAgICAgICAuLi4oZGFuZ2Vyb3VzbHlBbGxvd0Jyb3dzZXIgIT09IHVuZGVmaW5lZCA/IHsgZGFuZ2Vyb3VzbHlBbGxvd0Jyb3dzZXIgfSA6IHt9KSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuYXBpVmVyc2lvbiA9ICcnO1xuICAgICAgICB0aGlzLl9henVyZUFEVG9rZW5Qcm92aWRlciA9IGF6dXJlQURUb2tlblByb3ZpZGVyO1xuICAgICAgICB0aGlzLmFwaVZlcnNpb24gPSBhcGlWZXJzaW9uO1xuICAgICAgICB0aGlzLmRlcGxveW1lbnROYW1lID0gZGVwbG95bWVudDtcbiAgICB9XG4gICAgYnVpbGRSZXF1ZXN0KG9wdGlvbnMsIHByb3BzID0ge30pIHtcbiAgICAgICAgaWYgKF9kZXBsb3ltZW50c19lbmRwb2ludHMuaGFzKG9wdGlvbnMucGF0aCkgJiYgb3B0aW9ucy5tZXRob2QgPT09ICdwb3N0JyAmJiBvcHRpb25zLmJvZHkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgaWYgKCFDb3JlLmlzT2JqKG9wdGlvbnMuYm9keSkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4cGVjdGVkIHJlcXVlc3QgYm9keSB0byBiZSBhbiBvYmplY3QnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IG1vZGVsID0gdGhpcy5kZXBsb3ltZW50TmFtZSB8fCBvcHRpb25zLmJvZHlbJ21vZGVsJ10gfHwgb3B0aW9ucy5fX21ldGFkYXRhPy5bJ21vZGVsJ107XG4gICAgICAgICAgICBpZiAobW9kZWwgIT09IHVuZGVmaW5lZCAmJiAhdGhpcy5iYXNlVVJMLmluY2x1ZGVzKCcvZGVwbG95bWVudHMnKSkge1xuICAgICAgICAgICAgICAgIG9wdGlvbnMucGF0aCA9IGAvZGVwbG95bWVudHMvJHttb2RlbH0ke29wdGlvbnMucGF0aH1gO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdXBlci5idWlsZFJlcXVlc3Qob3B0aW9ucywgcHJvcHMpO1xuICAgIH1cbiAgICBhc3luYyBfZ2V0QXp1cmVBRFRva2VuKCkge1xuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2F6dXJlQURUb2tlblByb3ZpZGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjb25zdCB0b2tlbiA9IGF3YWl0IHRoaXMuX2F6dXJlQURUb2tlblByb3ZpZGVyKCk7XG4gICAgICAgICAgICBpZiAoIXRva2VuIHx8IHR5cGVvZiB0b2tlbiAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3JzLk9wZW5BSUVycm9yKGBFeHBlY3RlZCAnYXp1cmVBRFRva2VuUHJvdmlkZXInIGFyZ3VtZW50IHRvIHJldHVybiBhIHN0cmluZyBidXQgaXQgcmV0dXJuZWQgJHt0b2tlbn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0b2tlbjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBhdXRoSGVhZGVycyhvcHRzKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgYXN5bmMgcHJlcGFyZU9wdGlvbnMob3B0cykge1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHVzZXIgc2hvdWxkIHByb3ZpZGUgYSBiZWFyZXIgdG9rZW4gcHJvdmlkZXIgaWYgdGhleSB3YW50XG4gICAgICAgICAqIHRvIHVzZSBBenVyZSBBRCBhdXRoZW50aWNhdGlvbi4gVGhlIHVzZXIgc2hvdWxkbid0IHNldCB0aGVcbiAgICAgICAgICogQXV0aG9yaXphdGlvbiBoZWFkZXIgbWFudWFsbHkgYmVjYXVzZSB0aGUgaGVhZGVyIGlzIG92ZXJ3cml0dGVuXG4gICAgICAgICAqIHdpdGggdGhlIEF6dXJlIEFEIHRva2VuIGlmIGEgYmVhcmVyIHRva2VuIHByb3ZpZGVyIGlzIHByb3ZpZGVkLlxuICAgICAgICAgKi9cbiAgICAgICAgaWYgKG9wdHMuaGVhZGVycz8uWydhcGkta2V5J10pIHtcbiAgICAgICAgICAgIHJldHVybiBzdXBlci5wcmVwYXJlT3B0aW9ucyhvcHRzKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0b2tlbiA9IGF3YWl0IHRoaXMuX2dldEF6dXJlQURUb2tlbigpO1xuICAgICAgICBvcHRzLmhlYWRlcnMgPz8gKG9wdHMuaGVhZGVycyA9IHt9KTtcbiAgICAgICAgaWYgKHRva2VuKSB7XG4gICAgICAgICAgICBvcHRzLmhlYWRlcnNbJ0F1dGhvcml6YXRpb24nXSA9IGBCZWFyZXIgJHt0b2tlbn1gO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMuYXBpS2V5ICE9PSBBUElfS0VZX1NFTlRJTkVMKSB7XG4gICAgICAgICAgICBvcHRzLmhlYWRlcnNbJ2FwaS1rZXknXSA9IHRoaXMuYXBpS2V5O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9ycy5PcGVuQUlFcnJvcignVW5hYmxlIHRvIGhhbmRsZSBhdXRoJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN1cGVyLnByZXBhcmVPcHRpb25zKG9wdHMpO1xuICAgIH1cbn1cbmNvbnN0IF9kZXBsb3ltZW50c19lbmRwb2ludHMgPSBuZXcgU2V0KFtcbiAgICAnL2NvbXBsZXRpb25zJyxcbiAgICAnL2NoYXQvY29tcGxldGlvbnMnLFxuICAgICcvZW1iZWRkaW5ncycsXG4gICAgJy9hdWRpby90cmFuc2NyaXB0aW9ucycsXG4gICAgJy9hdWRpby90cmFuc2xhdGlvbnMnLFxuICAgICcvYXVkaW8vc3BlZWNoJyxcbiAgICAnL2ltYWdlcy9nZW5lcmF0aW9ucycsXG4gICAgJy9pbWFnZXMvZWRpdHMnLFxuXSk7XG5jb25zdCBBUElfS0VZX1NFTlRJTkVMID0gJzxNaXNzaW5nIEtleT4nO1xuZXhwb3J0IHsgdG9GaWxlLCBmaWxlRnJvbVBhdGggfSBmcm9tIFwiLi91cGxvYWRzLm1qc1wiO1xuZXhwb3J0IHsgT3BlbkFJRXJyb3IsIEFQSUVycm9yLCBBUElDb25uZWN0aW9uRXJyb3IsIEFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IsIEFQSVVzZXJBYm9ydEVycm9yLCBOb3RGb3VuZEVycm9yLCBDb25mbGljdEVycm9yLCBSYXRlTGltaXRFcnJvciwgQmFkUmVxdWVzdEVycm9yLCBBdXRoZW50aWNhdGlvbkVycm9yLCBJbnRlcm5hbFNlcnZlckVycm9yLCBQZXJtaXNzaW9uRGVuaWVkRXJyb3IsIFVucHJvY2Vzc2FibGVFbnRpdHlFcnJvciwgfSBmcm9tIFwiLi9lcnJvci5tanNcIjtcbmV4cG9ydCBkZWZhdWx0IE9wZW5BSTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXAiLCJpbXBvcnQgdHlwZSB7IFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcyc7XHJcblxyXG5jb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcclxuICBhcGlLZXk6ICdzay1wcm9qLUZpZ1M4eTBlU0FETURVSmR1Tjg5cEtReDZlXzJQVFlwY2pablRmWXdjUUxCNVdtRHRURElfbXBWRmhJUGg5RnItMVlzTUl6aEFUM0JsYmtGSjhwd2lmREhiTDdKVGVCWkkxTjY1cEd3QkxBUURLMkUzbm5nWFRjUVMxRTNhRF9Ia2QxNTYtNEk3MWJkb3FkUXEtN00zRFRlZ0EnLFxyXG4gIG1vZGVsOiAnZ3B0LTMuNS10dXJibycsXHJcbiAgbGFuZ3VhZ2U6ICdlbicsXHJcbiAgaXNFbmFibGVkOiB0cnVlLFxyXG4gIHRvbmU6ICdiYWxhbmNlZCcsXHJcbn07XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoJ3NldHRpbmdzJyk7XHJcbiAgcmV0dXJuIHsgLi4uREVGQVVMVF9TRVRUSU5HUywgLi4ucmVzdWx0LnNldHRpbmdzIH07XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlU2V0dGluZ3Moc2V0dGluZ3M6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IHNldHRpbmdzIH0pO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNFeHRlbnNpb25FbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICByZXR1cm4gc2V0dGluZ3MuaXNFbmFibGVkO1xyXG59XHJcbiIsImltcG9ydCB7IGRlZmluZUJhY2tncm91bmQgfSBmcm9tICd3eHQvdXRpbHMvZGVmaW5lLWJhY2tncm91bmQnO1xyXG5pbXBvcnQgT3BlbkFJIGZyb20gJ29wZW5haSc7XHJcbmltcG9ydCB7IGdldFNldHRpbmdzIH0gZnJvbSAnQC9saWIvc3RvcmFnZSc7XHJcbmltcG9ydCB0eXBlIHsgQ2hhdENvbnRleHQsIFN1Z2dlc3Rpb24gfSBmcm9tICdAL2xpYi90eXBlcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVCYWNrZ3JvdW5kKHtcclxuICB0eXBlOiAnbW9kdWxlJyxcclxuICBcclxuICBtYWluKCkge1xyXG4gICAgY29uc29sZS5sb2coJ1doYXRzQXBwIEFJIEFzc2lzdGFudDogQmFja2dyb3VuZCBzY3JpcHQgbG9hZGVkJyk7XHJcblxyXG4gICAgLy8gTGlzdGVuIGZvciBtZXNzYWdlcyBmcm9tIGNvbnRlbnQgc2NyaXB0XHJcbiAgICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKGFzeW5jIChtZXNzYWdlOiBhbnksIF9zZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIpID0+IHtcclxuICAgICAgaWYgKG1lc3NhZ2UuYWN0aW9uID09PSAnZ2VuZXJhdGVTdWdnZXN0aW9ucycpIHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZ2VuZXJhdGVTdWdnZXN0aW9ucyhtZXNzYWdlLmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICBpZiAobWVzc2FnZS5hY3Rpb24gPT09ICdyZWdlbmVyYXRlJykge1xyXG4gICAgICAgIC8vIEdldCBsYXN0IGNvbnRleHQgZnJvbSBzdG9yYWdlIGFuZCByZWdlbmVyYXRlXHJcbiAgICAgICAgY29uc3QgbGFzdENvbnRleHQgPSBhd2FpdCBnZXRMYXN0Q29udGV4dCgpO1xyXG4gICAgICAgIGlmIChsYXN0Q29udGV4dCkge1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IGdlbmVyYXRlU3VnZ2VzdGlvbnMobGFzdENvbnRleHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4geyBzdWdnZXN0aW9uczogW10sIGVycm9yOiAnTm8gcHJldmlvdXMgY29udGV4dCBmb3VuZCcgfTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfSxcclxufSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZVN1Z2dlc3Rpb25zKGNvbnRleHQ6IENoYXRDb250ZXh0KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICAgIFxyXG4gICAgaWYgKCFzZXR0aW5ncy5hcGlLZXkpIHtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBlcnJvcjogJ0FQSSBrZXkgbm90IGNvbmZpZ3VyZWQuIFBsZWFzZSBhZGQgeW91ciBPcGVuQUkgQVBJIGtleSBpbiBzZXR0aW5ncy4nLFxyXG4gICAgICAgIHN1Z2dlc3Rpb25zOiBbXSxcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJKHtcclxuICAgICAgYXBpS2V5OiBzZXR0aW5ncy5hcGlLZXksXHJcbiAgICAgIGRhbmdlcm91c2x5QWxsb3dCcm93c2VyOiB0cnVlLCAvLyBGb3IgZXh0ZW5zaW9uIHVzYWdlXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBzeXN0ZW1Qcm9tcHQgPSBnZXRTeXN0ZW1Qcm9tcHQoc2V0dGluZ3MubGFuZ3VhZ2UpO1xyXG4gICAgY29uc3QgdXNlclByb21wdCA9IGZvcm1hdFVzZXJQcm9tcHQoY29udGV4dCk7XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBvcGVuYWkuY2hhdC5jb21wbGV0aW9ucy5jcmVhdGUoe1xyXG4gICAgICBtb2RlbDogc2V0dGluZ3MubW9kZWwsXHJcbiAgICAgIG1lc3NhZ2VzOiBbXHJcbiAgICAgICAgeyByb2xlOiAnc3lzdGVtJywgY29udGVudDogc3lzdGVtUHJvbXB0IH0sXHJcbiAgICAgICAgeyByb2xlOiAndXNlcicsIGNvbnRlbnQ6IHVzZXJQcm9tcHQgfSxcclxuICAgICAgXSxcclxuICAgICAgdGVtcGVyYXR1cmU6IDAuNyxcclxuICAgICAgbWF4X3Rva2VuczogNTAwLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgYWlSZXNwb25zZSA9IHJlc3BvbnNlLmNob2ljZXNbMF0/Lm1lc3NhZ2U/LmNvbnRlbnQgfHwgJyc7XHJcbiAgICBjb25zdCBzdWdnZXN0aW9ucyA9IHBhcnNlQUlSZXNwb25zZShhaVJlc3BvbnNlKTtcclxuXHJcbiAgICAvLyBTYXZlIGNvbnRleHQgZm9yIHJlZ2VuZXJhdGlvblxyXG4gICAgYXdhaXQgc2F2ZUxhc3RDb250ZXh0KGNvbnRleHQpO1xyXG5cclxuICAgIHJldHVybiB7IHN1Z2dlc3Rpb25zLCBlcnJvcjogbnVsbCB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ09wZW5BSSBBUEkgZXJyb3I6JywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZXJyb3I6IGZvcm1hdEVycm9yKGVycm9yKSxcclxuICAgICAgc3VnZ2VzdGlvbnM6IFtdLFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldFN5c3RlbVByb21wdChsYW5ndWFnZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICBjb25zdCBwcm9tcHRzID0ge1xyXG4gICAgZW46IFwiWW91IGFyZSBhIHByb2Zlc3Npb25hbCBjb21tdW5pY2F0aW9uIGFzc2lzdGFudCBmb3IgYSBmcmVlbGFuY2VyIGNvbW11bmljYXRpbmcgd2l0aCBjbGllbnRzIG9uIFdoYXRzQXBwLiBHZW5lcmF0ZSAzIGRpZmZlcmVudCByZXNwb25zZSBzdWdnZXN0aW9ucyB3aXRoIHRoZXNlIHRvbmVzOiAxKSBQUk9GRVNTSU9OQUwgKGZvcm1hbCBhbmQgYnVzaW5lc3MtbGlrZSksIDIpIEZSSUVORExZICh3YXJtIGFuZCBhcHByb2FjaGFibGUpLCAzKSBRVUlDSyAoYnJpZWYgYW5kIHRvLXRoZS1wb2ludCkuIEtlZXAgYWxsIHJlc3BvbnNlcyBjb25jaXNlICgyLTMgc2VudGVuY2VzIG1heCkuIEZvY3VzIG9uIGNsZWFyLCBoZWxwZnVsIGNvbW11bmljYXRpb24uXCIsXHJcbiAgICBcclxuICAgIHVyOiBcItii2b4g2KfbjNqpINmB2LHbjCDZhNin2YbYs9ixINqp25Ig2YTbjNuSINm+2LHZiNmB24zYtNmG2YQg2qnZhduM2YjZhtuM2qnbjNi02YYg2KfYs9iz2bnZhtm5INuB24zauiDYrNmIINmI2KfZudizINin24zZviDZvtixINqp2YTYp9im2YbZudizINiz25Ig2KjYp9iqINqp2LEg2LHbgdinINuB25LblCAzINmF2K7YqtmE2YEg2KzZiNin2KjYp9iqINiq24zYp9ixINqp2LHbjNq6OiAxKSBQUk9GRVNTSU9OQUwgKNix2LPZhduMINin2YjYsSDYqNiy2YbYsyDZhNin2KbZgiksIDIpIEZSSUVORExZICjYr9mI2LPYqtin2YbbgSDYp9mI2LEg2q/YsdmF2KzZiNi0KSwgMykgUVVJQ0sgKNmF2K7Yqti12LEg2KfZiNixINmI2KfYttitKduUINiz2Kgg2KzZiNin2KjYp9iqINmF2K7Yqti12LEg2LHaqdq+24zauiAoMi0zINis2YXZhNuSKduUXCIsXHJcbiAgICBcclxuICAgIG1peGVkOiBcIllvdSBhcmUgYSBwcm9mZXNzaW9uYWwgY29tbXVuaWNhdGlvbiBhc3Npc3RhbnQuIEdlbmVyYXRlIDMgcmVzcG9uc2Ugc3VnZ2VzdGlvbnMgaW4gYSBtaXggb2YgRW5nbGlzaCBhbmQgVXJkdSAoUm9tYW4gVXJkdSBpcyBhY2NlcHRhYmxlKS4gVG9uZXM6IDEpIFBST0ZFU1NJT05BTCAoZm9ybWFsKSwgMikgRlJJRU5ETFkgKHdhcm0pLCAzKSBRVUlDSyAoYnJpZWYpLiBLZWVwIHJlc3BvbnNlcyBjb25jaXNlICgyLTMgc2VudGVuY2VzKS5cIixcclxuICB9O1xyXG5cclxuICByZXR1cm4gcHJvbXB0c1tsYW5ndWFnZSBhcyBrZXlvZiB0eXBlb2YgcHJvbXB0c10gfHwgcHJvbXB0cy5lbjtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0VXNlclByb21wdChjb250ZXh0OiBDaGF0Q29udGV4dCk6IHN0cmluZyB7XHJcbiAgY29uc3QgY29udGV4dFN0ciA9IGNvbnRleHQucHJldmlvdXNNZXNzYWdlcy5sZW5ndGggPiAwXHJcbiAgICA/IGBQcmV2aW91cyBjb252ZXJzYXRpb246XFxuJHtjb250ZXh0LnByZXZpb3VzTWVzc2FnZXMuam9pbignXFxuJyl9XFxuXFxuYFxyXG4gICAgOiAnJztcclxuXHJcbiAgcmV0dXJuIGAke2NvbnRleHRTdHJ9Q2xpZW50ICgke2NvbnRleHQuc2VuZGVyTmFtZX0pIGp1c3Qgc2VudDogXCIke2NvbnRleHQuY3VycmVudE1lc3NhZ2V9XCJcclxuXHJcbkdlbmVyYXRlIDMgcmVzcG9uc2Ugb3B0aW9ucyBpbiB0aGlzIEVYQUNUIGZvcm1hdDpcclxuXHJcbjEuIFBST0ZFU1NJT05BTDpcclxuW1lvdXIgcHJvZmVzc2lvbmFsIHJlc3BvbnNlIGhlcmVdXHJcblxyXG4yLiBGUklFTkRMWTpcclxuW1lvdXIgZnJpZW5kbHkgcmVzcG9uc2UgaGVyZV1cclxuXHJcbjMuIFFVSUNLOlxyXG5bWW91ciBxdWljayByZXNwb25zZSBoZXJlXWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcnNlQUlSZXNwb25zZShyZXNwb25zZTogc3RyaW5nKTogU3VnZ2VzdGlvbltdIHtcclxuICBjb25zdCBzdWdnZXN0aW9uczogU3VnZ2VzdGlvbltdID0gW107XHJcbiAgXHJcbiAgLy8gUGFyc2UgcHJvZmVzc2lvbmFsIHN1Z2dlc3Rpb25cclxuICBjb25zdCBwcm9mZXNzaW9uYWxNYXRjaCA9IHJlc3BvbnNlLm1hdGNoKC8xXFwuXFxzKlBST0ZFU1NJT05BTDpcXHMqXFxuKFtcXHNcXFNdKj8pKD89XFxuMlxcLnwkKS9pKTtcclxuICBpZiAocHJvZmVzc2lvbmFsTWF0Y2gpIHtcclxuICAgIHN1Z2dlc3Rpb25zLnB1c2goe1xyXG4gICAgICBpZDogJzEnLFxyXG4gICAgICB0eXBlOiAncHJvZmVzc2lvbmFsJyxcclxuICAgICAgdGV4dDogcHJvZmVzc2lvbmFsTWF0Y2hbMV0udHJpbSgpLFxyXG4gICAgICBpY29uOiAn8J+OrycsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8vIFBhcnNlIGZyaWVuZGx5IHN1Z2dlc3Rpb25cclxuICBjb25zdCBmcmllbmRseU1hdGNoID0gcmVzcG9uc2UubWF0Y2goLzJcXC5cXHMqRlJJRU5ETFk6XFxzKlxcbihbXFxzXFxTXSo/KSg/PVxcbjNcXC58JCkvaSk7XHJcbiAgaWYgKGZyaWVuZGx5TWF0Y2gpIHtcclxuICAgIHN1Z2dlc3Rpb25zLnB1c2goe1xyXG4gICAgICBpZDogJzInLFxyXG4gICAgICB0eXBlOiAnZnJpZW5kbHknLFxyXG4gICAgICB0ZXh0OiBmcmllbmRseU1hdGNoWzFdLnRyaW0oKSxcclxuICAgICAgaWNvbjogJ/CfmIonLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyBQYXJzZSBxdWljayBzdWdnZXN0aW9uXHJcbiAgY29uc3QgcXVpY2tNYXRjaCA9IHJlc3BvbnNlLm1hdGNoKC8zXFwuXFxzKlFVSUNLOlxccypcXG4oW1xcc1xcU10qPykkL2kpO1xyXG4gIGlmIChxdWlja01hdGNoKSB7XHJcbiAgICBzdWdnZXN0aW9ucy5wdXNoKHtcclxuICAgICAgaWQ6ICczJyxcclxuICAgICAgdHlwZTogJ3F1aWNrJyxcclxuICAgICAgdGV4dDogcXVpY2tNYXRjaFsxXS50cmltKCksXHJcbiAgICAgIGljb246ICfimqEnLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyBGYWxsYmFjazogaWYgcGFyc2luZyBmYWlsZWQsIHRyeSB0byBleHRyYWN0IGFueSBudW1iZXJlZCBpdGVtc1xyXG4gIGlmIChzdWdnZXN0aW9ucy5sZW5ndGggPT09IDApIHtcclxuICAgIGNvbnN0IGxpbmVzID0gcmVzcG9uc2Uuc3BsaXQoJ1xcbicpLmZpbHRlcihsaW5lID0+IGxpbmUudHJpbSgpKTtcclxuICAgIGxldCBjdXJyZW50VHlwZTogJ3Byb2Zlc3Npb25hbCcgfCAnZnJpZW5kbHknIHwgJ3F1aWNrJyA9ICdwcm9mZXNzaW9uYWwnO1xyXG4gICAgbGV0IGN1cnJlbnRUZXh0ID0gJyc7XHJcblxyXG4gICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVzKSB7XHJcbiAgICAgIGlmIChsaW5lLm1hdGNoKC8xXFwufHByb2Zlc3Npb25hbC9pKSkge1xyXG4gICAgICAgIGlmIChjdXJyZW50VGV4dCkge1xyXG4gICAgICAgICAgc3VnZ2VzdGlvbnMucHVzaCh7XHJcbiAgICAgICAgICAgIGlkOiBTdHJpbmcoc3VnZ2VzdGlvbnMubGVuZ3RoICsgMSksXHJcbiAgICAgICAgICAgIHR5cGU6IGN1cnJlbnRUeXBlLFxyXG4gICAgICAgICAgICB0ZXh0OiBjdXJyZW50VGV4dC50cmltKCksXHJcbiAgICAgICAgICAgIGljb246IGN1cnJlbnRUeXBlID09PSAncHJvZmVzc2lvbmFsJyA/ICfwn46vJyA6IGN1cnJlbnRUeXBlID09PSAnZnJpZW5kbHknID8gJ/CfmIonIDogJ+KaoScsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY3VycmVudFR5cGUgPSAncHJvZmVzc2lvbmFsJztcclxuICAgICAgICBjdXJyZW50VGV4dCA9IGxpbmUucmVwbGFjZSgvMVxcLnxwcm9mZXNzaW9uYWw6L2dpLCAnJykudHJpbSgpO1xyXG4gICAgICB9IGVsc2UgaWYgKGxpbmUubWF0Y2goLzJcXC58ZnJpZW5kbHkvaSkpIHtcclxuICAgICAgICBpZiAoY3VycmVudFRleHQpIHtcclxuICAgICAgICAgIHN1Z2dlc3Rpb25zLnB1c2goe1xyXG4gICAgICAgICAgICBpZDogU3RyaW5nKHN1Z2dlc3Rpb25zLmxlbmd0aCArIDEpLFxyXG4gICAgICAgICAgICB0eXBlOiBjdXJyZW50VHlwZSxcclxuICAgICAgICAgICAgdGV4dDogY3VycmVudFRleHQudHJpbSgpLFxyXG4gICAgICAgICAgICBpY29uOiBjdXJyZW50VHlwZSA9PT0gJ3Byb2Zlc3Npb25hbCcgPyAn8J+OrycgOiBjdXJyZW50VHlwZSA9PT0gJ2ZyaWVuZGx5JyA/ICfwn5iKJyA6ICfimqEnLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGN1cnJlbnRUeXBlID0gJ2ZyaWVuZGx5JztcclxuICAgICAgICBjdXJyZW50VGV4dCA9IGxpbmUucmVwbGFjZSgvMlxcLnxmcmllbmRseTovZ2ksICcnKS50cmltKCk7XHJcbiAgICAgIH0gZWxzZSBpZiAobGluZS5tYXRjaCgvM1xcLnxxdWljay9pKSkge1xyXG4gICAgICAgIGlmIChjdXJyZW50VGV4dCkge1xyXG4gICAgICAgICAgc3VnZ2VzdGlvbnMucHVzaCh7XHJcbiAgICAgICAgICAgIGlkOiBTdHJpbmcoc3VnZ2VzdGlvbnMubGVuZ3RoICsgMSksXHJcbiAgICAgICAgICAgIHR5cGU6IGN1cnJlbnRUeXBlLFxyXG4gICAgICAgICAgICB0ZXh0OiBjdXJyZW50VGV4dC50cmltKCksXHJcbiAgICAgICAgICAgIGljb246IGN1cnJlbnRUeXBlID09PSAncHJvZmVzc2lvbmFsJyA/ICfwn46vJyA6IGN1cnJlbnRUeXBlID09PSAnZnJpZW5kbHknID8gJ/CfmIonIDogJ+KaoScsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY3VycmVudFR5cGUgPSAncXVpY2snO1xyXG4gICAgICAgIGN1cnJlbnRUZXh0ID0gbGluZS5yZXBsYWNlKC8zXFwufHF1aWNrOi9naSwgJycpLnRyaW0oKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjdXJyZW50VGV4dCArPSAnICcgKyBsaW5lLnRyaW0oKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlmIChjdXJyZW50VGV4dCAmJiBzdWdnZXN0aW9ucy5sZW5ndGggPCAzKSB7XHJcbiAgICAgIHN1Z2dlc3Rpb25zLnB1c2goe1xyXG4gICAgICAgIGlkOiBTdHJpbmcoc3VnZ2VzdGlvbnMubGVuZ3RoICsgMSksXHJcbiAgICAgICAgdHlwZTogY3VycmVudFR5cGUsXHJcbiAgICAgICAgdGV4dDogY3VycmVudFRleHQudHJpbSgpLFxyXG4gICAgICAgIGljb246IGN1cnJlbnRUeXBlID09PSAncHJvZmVzc2lvbmFsJyA/ICfwn46vJyA6IGN1cnJlbnRUeXBlID09PSAnZnJpZW5kbHknID8gJ/CfmIonIDogJ+KaoScsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHN1Z2dlc3Rpb25zO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRFcnJvcihlcnJvcjogYW55KTogc3RyaW5nIHtcclxuICBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDEpIHJldHVybiAnSW52YWxpZCBBUEkga2V5LiBQbGVhc2UgY2hlY2sgeW91ciBzZXR0aW5ncy4nO1xyXG4gIGlmIChlcnJvci5zdGF0dXMgPT09IDQyOSkgcmV0dXJuICdSYXRlIGxpbWl0IGV4Y2VlZGVkLiBQbGVhc2Ugd2FpdCBhIG1vbWVudC4nO1xyXG4gIGlmIChlcnJvci5zdGF0dXMgPT09IDUwMCkgcmV0dXJuICdPcGVuQUkgc2VydmljZSBlcnJvci4gUGxlYXNlIHRyeSBhZ2Fpbi4nO1xyXG4gIHJldHVybiAnRmFpbGVkIHRvIGdlbmVyYXRlIHN1Z2dlc3Rpb25zLiBQbGVhc2UgdHJ5IGFnYWluLic7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNhdmVMYXN0Q29udGV4dChjb250ZXh0OiBDaGF0Q29udGV4dCkge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBsYXN0Q29udGV4dDogY29udGV4dCB9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0TGFzdENvbnRleHQoKTogUHJvbWlzZTxDaGF0Q29udGV4dCB8IG51bGw+IHtcclxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdsYXN0Q29udGV4dCcpO1xyXG4gIHJldHVybiByZXN1bHQubGFzdENvbnRleHQgfHwgbnVsbDtcclxufVxyXG4iLCIvLyBzcmMvaW5kZXgudHNcbnZhciBfTWF0Y2hQYXR0ZXJuID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihtYXRjaFBhdHRlcm4pIHtcbiAgICBpZiAobWF0Y2hQYXR0ZXJuID09PSBcIjxhbGxfdXJscz5cIikge1xuICAgICAgdGhpcy5pc0FsbFVybHMgPSB0cnVlO1xuICAgICAgdGhpcy5wcm90b2NvbE1hdGNoZXMgPSBbLi4uX01hdGNoUGF0dGVybi5QUk9UT0NPTFNdO1xuICAgICAgdGhpcy5ob3N0bmFtZU1hdGNoID0gXCIqXCI7XG4gICAgICB0aGlzLnBhdGhuYW1lTWF0Y2ggPSBcIipcIjtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgZ3JvdXBzID0gLyguKik6XFwvXFwvKC4qPykoXFwvLiopLy5leGVjKG1hdGNoUGF0dGVybik7XG4gICAgICBpZiAoZ3JvdXBzID09IG51bGwpXG4gICAgICAgIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKG1hdGNoUGF0dGVybiwgXCJJbmNvcnJlY3QgZm9ybWF0XCIpO1xuICAgICAgY29uc3QgW18sIHByb3RvY29sLCBob3N0bmFtZSwgcGF0aG5hbWVdID0gZ3JvdXBzO1xuICAgICAgdmFsaWRhdGVQcm90b2NvbChtYXRjaFBhdHRlcm4sIHByb3RvY29sKTtcbiAgICAgIHZhbGlkYXRlSG9zdG5hbWUobWF0Y2hQYXR0ZXJuLCBob3N0bmFtZSk7XG4gICAgICB2YWxpZGF0ZVBhdGhuYW1lKG1hdGNoUGF0dGVybiwgcGF0aG5hbWUpO1xuICAgICAgdGhpcy5wcm90b2NvbE1hdGNoZXMgPSBwcm90b2NvbCA9PT0gXCIqXCIgPyBbXCJodHRwXCIsIFwiaHR0cHNcIl0gOiBbcHJvdG9jb2xdO1xuICAgICAgdGhpcy5ob3N0bmFtZU1hdGNoID0gaG9zdG5hbWU7XG4gICAgICB0aGlzLnBhdGhuYW1lTWF0Y2ggPSBwYXRobmFtZTtcbiAgICB9XG4gIH1cbiAgaW5jbHVkZXModXJsKSB7XG4gICAgaWYgKHRoaXMuaXNBbGxVcmxzKVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgdSA9IHR5cGVvZiB1cmwgPT09IFwic3RyaW5nXCIgPyBuZXcgVVJMKHVybCkgOiB1cmwgaW5zdGFuY2VvZiBMb2NhdGlvbiA/IG5ldyBVUkwodXJsLmhyZWYpIDogdXJsO1xuICAgIHJldHVybiAhIXRoaXMucHJvdG9jb2xNYXRjaGVzLmZpbmQoKHByb3RvY29sKSA9PiB7XG4gICAgICBpZiAocHJvdG9jb2wgPT09IFwiaHR0cFwiKVxuICAgICAgICByZXR1cm4gdGhpcy5pc0h0dHBNYXRjaCh1KTtcbiAgICAgIGlmIChwcm90b2NvbCA9PT0gXCJodHRwc1wiKVxuICAgICAgICByZXR1cm4gdGhpcy5pc0h0dHBzTWF0Y2godSk7XG4gICAgICBpZiAocHJvdG9jb2wgPT09IFwiZmlsZVwiKVxuICAgICAgICByZXR1cm4gdGhpcy5pc0ZpbGVNYXRjaCh1KTtcbiAgICAgIGlmIChwcm90b2NvbCA9PT0gXCJmdHBcIilcbiAgICAgICAgcmV0dXJuIHRoaXMuaXNGdHBNYXRjaCh1KTtcbiAgICAgIGlmIChwcm90b2NvbCA9PT0gXCJ1cm5cIilcbiAgICAgICAgcmV0dXJuIHRoaXMuaXNVcm5NYXRjaCh1KTtcbiAgICB9KTtcbiAgfVxuICBpc0h0dHBNYXRjaCh1cmwpIHtcbiAgICByZXR1cm4gdXJsLnByb3RvY29sID09PSBcImh0dHA6XCIgJiYgdGhpcy5pc0hvc3RQYXRoTWF0Y2godXJsKTtcbiAgfVxuICBpc0h0dHBzTWF0Y2godXJsKSB7XG4gICAgcmV0dXJuIHVybC5wcm90b2NvbCA9PT0gXCJodHRwczpcIiAmJiB0aGlzLmlzSG9zdFBhdGhNYXRjaCh1cmwpO1xuICB9XG4gIGlzSG9zdFBhdGhNYXRjaCh1cmwpIHtcbiAgICBpZiAoIXRoaXMuaG9zdG5hbWVNYXRjaCB8fCAhdGhpcy5wYXRobmFtZU1hdGNoKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGhvc3RuYW1lTWF0Y2hSZWdleHMgPSBbXG4gICAgICB0aGlzLmNvbnZlcnRQYXR0ZXJuVG9SZWdleCh0aGlzLmhvc3RuYW1lTWF0Y2gpLFxuICAgICAgdGhpcy5jb252ZXJ0UGF0dGVyblRvUmVnZXgodGhpcy5ob3N0bmFtZU1hdGNoLnJlcGxhY2UoL15cXCpcXC4vLCBcIlwiKSlcbiAgICBdO1xuICAgIGNvbnN0IHBhdGhuYW1lTWF0Y2hSZWdleCA9IHRoaXMuY29udmVydFBhdHRlcm5Ub1JlZ2V4KHRoaXMucGF0aG5hbWVNYXRjaCk7XG4gICAgcmV0dXJuICEhaG9zdG5hbWVNYXRjaFJlZ2V4cy5maW5kKChyZWdleCkgPT4gcmVnZXgudGVzdCh1cmwuaG9zdG5hbWUpKSAmJiBwYXRobmFtZU1hdGNoUmVnZXgudGVzdCh1cmwucGF0aG5hbWUpO1xuICB9XG4gIGlzRmlsZU1hdGNoKHVybCkge1xuICAgIHRocm93IEVycm9yKFwiTm90IGltcGxlbWVudGVkOiBmaWxlOi8vIHBhdHRlcm4gbWF0Y2hpbmcuIE9wZW4gYSBQUiB0byBhZGQgc3VwcG9ydFwiKTtcbiAgfVxuICBpc0Z0cE1hdGNoKHVybCkge1xuICAgIHRocm93IEVycm9yKFwiTm90IGltcGxlbWVudGVkOiBmdHA6Ly8gcGF0dGVybiBtYXRjaGluZy4gT3BlbiBhIFBSIHRvIGFkZCBzdXBwb3J0XCIpO1xuICB9XG4gIGlzVXJuTWF0Y2godXJsKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWQ6IHVybjovLyBwYXR0ZXJuIG1hdGNoaW5nLiBPcGVuIGEgUFIgdG8gYWRkIHN1cHBvcnRcIik7XG4gIH1cbiAgY29udmVydFBhdHRlcm5Ub1JlZ2V4KHBhdHRlcm4pIHtcbiAgICBjb25zdCBlc2NhcGVkID0gdGhpcy5lc2NhcGVGb3JSZWdleChwYXR0ZXJuKTtcbiAgICBjb25zdCBzdGFyc1JlcGxhY2VkID0gZXNjYXBlZC5yZXBsYWNlKC9cXFxcXFwqL2csIFwiLipcIik7XG4gICAgcmV0dXJuIFJlZ0V4cChgXiR7c3RhcnNSZXBsYWNlZH0kYCk7XG4gIH1cbiAgZXNjYXBlRm9yUmVnZXgoc3RyaW5nKSB7XG4gICAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKC9bLiorP14ke30oKXxbXFxdXFxcXF0vZywgXCJcXFxcJCZcIik7XG4gIH1cbn07XG52YXIgTWF0Y2hQYXR0ZXJuID0gX01hdGNoUGF0dGVybjtcbk1hdGNoUGF0dGVybi5QUk9UT0NPTFMgPSBbXCJodHRwXCIsIFwiaHR0cHNcIiwgXCJmaWxlXCIsIFwiZnRwXCIsIFwidXJuXCJdO1xudmFyIEludmFsaWRNYXRjaFBhdHRlcm4gPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IobWF0Y2hQYXR0ZXJuLCByZWFzb24pIHtcbiAgICBzdXBlcihgSW52YWxpZCBtYXRjaCBwYXR0ZXJuIFwiJHttYXRjaFBhdHRlcm59XCI6ICR7cmVhc29ufWApO1xuICB9XG59O1xuZnVuY3Rpb24gdmFsaWRhdGVQcm90b2NvbChtYXRjaFBhdHRlcm4sIHByb3RvY29sKSB7XG4gIGlmICghTWF0Y2hQYXR0ZXJuLlBST1RPQ09MUy5pbmNsdWRlcyhwcm90b2NvbCkgJiYgcHJvdG9jb2wgIT09IFwiKlwiKVxuICAgIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKFxuICAgICAgbWF0Y2hQYXR0ZXJuLFxuICAgICAgYCR7cHJvdG9jb2x9IG5vdCBhIHZhbGlkIHByb3RvY29sICgke01hdGNoUGF0dGVybi5QUk9UT0NPTFMuam9pbihcIiwgXCIpfSlgXG4gICAgKTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlSG9zdG5hbWUobWF0Y2hQYXR0ZXJuLCBob3N0bmFtZSkge1xuICBpZiAoaG9zdG5hbWUuaW5jbHVkZXMoXCI6XCIpKVxuICAgIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKG1hdGNoUGF0dGVybiwgYEhvc3RuYW1lIGNhbm5vdCBpbmNsdWRlIGEgcG9ydGApO1xuICBpZiAoaG9zdG5hbWUuaW5jbHVkZXMoXCIqXCIpICYmIGhvc3RuYW1lLmxlbmd0aCA+IDEgJiYgIWhvc3RuYW1lLnN0YXJ0c1dpdGgoXCIqLlwiKSlcbiAgICB0aHJvdyBuZXcgSW52YWxpZE1hdGNoUGF0dGVybihcbiAgICAgIG1hdGNoUGF0dGVybixcbiAgICAgIGBJZiB1c2luZyBhIHdpbGRjYXJkICgqKSwgaXQgbXVzdCBnbyBhdCB0aGUgc3RhcnQgb2YgdGhlIGhvc3RuYW1lYFxuICAgICk7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZVBhdGhuYW1lKG1hdGNoUGF0dGVybiwgcGF0aG5hbWUpIHtcbiAgcmV0dXJuO1xufVxuZXhwb3J0IHtcbiAgSW52YWxpZE1hdGNoUGF0dGVybixcbiAgTWF0Y2hQYXR0ZXJuXG59O1xuIl0sIm5hbWVzIjpbImJyb3dzZXIiLCJfYnJvd3NlciIsImlzX2FycmF5Iiwic3RyIiwiZmV0Y2giLCJGb3JtRGF0YSIsIkZpbGUiLCJSZWFkYWJsZVN0cmVhbSIsInNoaW1zLmtpbmQiLCJzaGltcy5zZXRTaGltcyIsImF1dG8uZ2V0UnVudGltZSIsIl9fY2xhc3NQcml2YXRlRmllbGRTZXQiLCJraW5kIiwiX19jbGFzc1ByaXZhdGVGaWVsZEdldCIsInJlc3VsdCIsInBhcnNlUmVzcG9uc2UiLCJvcHRzIiwiUGFnZSIsInNoaW1zS2luZCIsInJldHJ5TWVzc2FnZSIsImluaXQiLCJtb2RpZmllZEFyZyIsIk1lc3NhZ2VzQVBJLk1lc3NhZ2VzIiwiQ29tcGxldGlvbnMiLCJNZXNzYWdlcyIsIkNvbXBsZXRpb25zQVBJLkNvbXBsZXRpb25zIiwiQ2hhdCIsIkNvcmUubXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zIiwiVHJhbnNjcmlwdGlvbnNBUEkuVHJhbnNjcmlwdGlvbnMiLCJUcmFuc2xhdGlvbnNBUEkuVHJhbnNsYXRpb25zIiwiU3BlZWNoQVBJLlNwZWVjaCIsIl9FdmVudFN0cmVhbV9oYW5kbGVFcnJvciIsImNodW5rIiwiQ29yZS5pc09iaiIsIl9Bc3Npc3RhbnRTdHJlYW1fYWRkRXZlbnQiLCJfQXNzaXN0YW50U3RyZWFtX2VuZFJlcXVlc3QiLCJfQXNzaXN0YW50U3RyZWFtX2hhbmRsZU1lc3NhZ2UiLCJfQXNzaXN0YW50U3RyZWFtX2hhbmRsZVJ1blN0ZXAiLCJfQXNzaXN0YW50U3RyZWFtX2hhbmRsZUV2ZW50IiwiX0Fzc2lzdGFudFN0cmVhbV9hY2N1bXVsYXRlUnVuU3RlcCIsIl9Bc3Npc3RhbnRTdHJlYW1fYWNjdW11bGF0ZU1lc3NhZ2UiLCJfQXNzaXN0YW50U3RyZWFtX2FjY3VtdWxhdGVDb250ZW50IiwiX0Fzc2lzdGFudFN0cmVhbV9oYW5kbGVSdW4iLCJpc0F1dG9QYXJzYWJsZVRvb2wiLCJoYXNBdXRvUGFyc2VhYmxlSW5wdXQiLCJwYXJzZVRvb2xDYWxsIiwiaW5wdXRUb29sIiwiY29udGVudCIsIm5hbWUiLCJfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbENvbnRlbnQiLCJfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbE1lc3NhZ2UiLCJfQWJzdHJhY3RDaGF0Q29tcGxldGlvblJ1bm5lcl9nZXRGaW5hbEZ1bmN0aW9uQ2FsbCIsIl9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX2dldEZpbmFsRnVuY3Rpb25DYWxsUmVzdWx0IiwiX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfY2FsY3VsYXRlVG90YWxVc2FnZSIsIl9BYnN0cmFjdENoYXRDb21wbGV0aW9uUnVubmVyX3ZhbGlkYXRlUGFyYW1zIiwiX0Fic3RyYWN0Q2hhdENvbXBsZXRpb25SdW5uZXJfc3RyaW5naWZ5RnVuY3Rpb25DYWxsUmVzdWx0IiwiZXNjYXBlIiwiZSIsIl9DaGF0Q29tcGxldGlvblN0cmVhbV9iZWdpblJlcXVlc3QiLCJfQ2hhdENvbXBsZXRpb25TdHJlYW1fZ2V0Q2hvaWNlRXZlbnRTdGF0ZSIsIl9DaGF0Q29tcGxldGlvblN0cmVhbV9hZGRDaHVuayIsIl9DaGF0Q29tcGxldGlvblN0cmVhbV9lbWl0VG9vbENhbGxEb25lRXZlbnQiLCJfQ2hhdENvbXBsZXRpb25TdHJlYW1fZW1pdENvbnRlbnREb25lRXZlbnRzIiwiX0NoYXRDb21wbGV0aW9uU3RyZWFtX2VuZFJlcXVlc3QiLCJfQ2hhdENvbXBsZXRpb25TdHJlYW1fZ2V0QXV0b1BhcnNlYWJsZVJlc3BvbnNlRm9ybWF0IiwiX0NoYXRDb21wbGV0aW9uU3RyZWFtX2FjY3VtdWxhdGVDaGF0Q29tcGxldGlvbiIsIl9hIiwicmVmdXNhbCIsInJlc3QiLCJpbmRleCIsImlkIiwiU2Vzc2lvbnNBUEkuU2Vzc2lvbnMiLCJUcmFuc2NyaXB0aW9uU2Vzc2lvbnNBUEkuVHJhbnNjcmlwdGlvblNlc3Npb25zIiwiU3RlcHNBUEkuU3RlcHMiLCJSdW5zIiwiUnVuc0FQSS5SdW5zIiwiUmVhbHRpbWVBUEkuUmVhbHRpbWUiLCJDaGF0QVBJLkNoYXQiLCJBc3Npc3RhbnRzQVBJLkFzc2lzdGFudHMiLCJUaHJlYWRzQVBJLlRocmVhZHMiLCJDb250ZW50QVBJLkNvbnRlbnQiLCJGaWxlcyIsIkZpbGVzQVBJLkZpbGVzIiwiQ29yZS5kZWJ1ZyIsInJlc3BvbnNlIiwiQ29yZS50b0Zsb2F0MzJBcnJheSIsIk91dHB1dEl0ZW1zQVBJLk91dHB1dEl0ZW1zIiwiR3JhZGVyc0FQSS5HcmFkZXJzIiwiR3JhZGVycyIsIlBlcm1pc3Npb25zQVBJLlBlcm1pc3Npb25zIiwiQ2hlY2twb2ludHMiLCJDaGVja3BvaW50c0FQSS5DaGVja3BvaW50cyIsIk1ldGhvZHNBUEkuTWV0aG9kcyIsIkpvYnNBUEkuSm9icyIsIkFscGhhQVBJLkFscGhhIiwiR3JhZGVyTW9kZWxzQVBJLkdyYWRlck1vZGVscyIsIm91dHB1dCIsIl9SZXNwb25zZVN0cmVhbV9iZWdpblJlcXVlc3QiLCJfUmVzcG9uc2VTdHJlYW1fYWRkRXZlbnQiLCJldmVudCIsIl9SZXNwb25zZVN0cmVhbV9lbmRSZXF1ZXN0IiwiX1Jlc3BvbnNlU3RyZWFtX2FjY3VtdWxhdGVSZXNwb25zZSIsIklucHV0SXRlbXNBUEkuSW5wdXRJdGVtcyIsIlBhcnRzQVBJLlBhcnRzIiwiRmlsZUJhdGNoZXNBUEkuRmlsZUJhdGNoZXMiLCJDb3JlLkFQSUNsaWVudCIsIkNvcmUucmVhZEVudiIsIkVycm9ycy5PcGVuQUlFcnJvciIsIkNvcmUuaXNSdW5uaW5nSW5Ccm93c2VyIiwiQVBJLkNvbXBsZXRpb25zIiwiQVBJLkNoYXQiLCJBUEkuRW1iZWRkaW5ncyIsIkFQSS5GaWxlcyIsIkFQSS5JbWFnZXMiLCJBUEkuQXVkaW8iLCJBUEkuTW9kZXJhdGlvbnMiLCJBUEkuTW9kZWxzIiwiQVBJLkZpbmVUdW5pbmciLCJBUEkuR3JhZGVycyIsIkFQSS5WZWN0b3JTdG9yZXMiLCJBUEkuQmV0YSIsIkFQSS5CYXRjaGVzIiwiQVBJLlVwbG9hZHMiLCJBUEkuUmVzcG9uc2VzIiwiQVBJLkV2YWxzIiwiQVBJLkNvbnRhaW5lcnMiLCJxcy5zdHJpbmdpZnkiLCJFcnJvcnMuQVBJRXJyb3IiLCJFcnJvcnMuQVBJQ29ubmVjdGlvbkVycm9yIiwiRXJyb3JzLkFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IiLCJFcnJvcnMuQVBJVXNlckFib3J0RXJyb3IiLCJFcnJvcnMuTm90Rm91bmRFcnJvciIsIkVycm9ycy5Db25mbGljdEVycm9yIiwiRXJyb3JzLlJhdGVMaW1pdEVycm9yIiwiRXJyb3JzLkJhZFJlcXVlc3RFcnJvciIsIkVycm9ycy5BdXRoZW50aWNhdGlvbkVycm9yIiwiRXJyb3JzLkludGVybmFsU2VydmVyRXJyb3IiLCJFcnJvcnMuUGVybWlzc2lvbkRlbmllZEVycm9yIiwiRXJyb3JzLlVucHJvY2Vzc2FibGVFbnRpdHlFcnJvciIsIlVwbG9hZHMudG9GaWxlIiwiVXBsb2Fkcy5maWxlRnJvbVBhdGgiLCJVcGxvYWRzQVBJVXBsb2FkcyJdLCJtYXBwaW5ncyI6IkFBQ08sTUFBTUEsWUFBVSxXQUFXLFNBQVMsU0FBUyxLQUNoRCxXQUFXLFVBQ1gsV0FBVztBQ0ZSLE1BQU0sVUFBVUM7QUNEaEIsU0FBUyxpQkFBaUIsS0FBSztBQUNwQyxNQUFJLE9BQU8sUUFBUSxPQUFPLFFBQVEsV0FBWSxRQUFPLEVBQUUsTUFBTSxJQUFHO0FBQ2hFLFNBQU87QUFDVDtBQ0hPLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sYUFBYTtBQUFBLEVBQ3RCLFNBQVMsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxFQUFFLFFBQVEsUUFBUSxHQUFHO0FBQUEsRUFDN0MsU0FBUyxDQUFDLE1BQU0sT0FBTyxDQUFDO0FBQzVCO0FBQ08sTUFBTSxVQUFVO0FDSHZCLE1BQU1DLGFBQVcsTUFBTTtBQUN2QixNQUFNLGFBQWEsTUFBTTtBQUNyQixRQUFNLFFBQVEsQ0FBQTtBQUNkLFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxFQUFFLEdBQUc7QUFDMUIsVUFBTSxLQUFLLFFBQVEsSUFBSSxLQUFLLE1BQU0sTUFBTSxFQUFFLFNBQVMsRUFBRSxHQUFHLFlBQVcsQ0FBRTtBQUFBLEVBQ3pFO0FBQ0EsU0FBTztBQUNYLEdBQUM7QUF1R0QsTUFBTSxRQUFRO0FBQ1AsTUFBTSxTQUFTLENBQUNDLE1BQUssaUJBQWlCLFNBQVMsT0FBTyxXQUFXO0FBR3BFLE1BQUlBLEtBQUksV0FBVyxHQUFHO0FBQ2xCLFdBQU9BO0FBQUEsRUFDWDtBQUNBLE1BQUksU0FBU0E7QUFDYixNQUFJLE9BQU9BLFNBQVEsVUFBVTtBQUN6QixhQUFTLE9BQU8sVUFBVSxTQUFTLEtBQUtBLElBQUc7QUFBQSxFQUMvQyxXQUNTLE9BQU9BLFNBQVEsVUFBVTtBQUM5QixhQUFTLE9BQU9BLElBQUc7QUFBQSxFQUN2QjtBQUNBLE1BQUksWUFBWSxjQUFjO0FBQzFCLFdBQU8sT0FBTyxNQUFNLEVBQUUsUUFBUSxtQkFBbUIsU0FBVSxJQUFJO0FBQzNELGFBQU8sV0FBVyxTQUFTLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQUEsSUFDbEQsQ0FBQztBQUFBLEVBQ0w7QUFDQSxNQUFJLE1BQU07QUFDVixXQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLLE9BQU87QUFDM0MsVUFBTSxVQUFVLE9BQU8sVUFBVSxRQUFRLE9BQU8sTUFBTSxHQUFHLElBQUksS0FBSyxJQUFJO0FBQ3RFLFVBQU0sTUFBTSxDQUFBO0FBQ1osYUFBUyxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsRUFBRSxHQUFHO0FBQ3JDLFVBQUksSUFBSSxRQUFRLFdBQVcsQ0FBQztBQUM1QixVQUFJLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNMLEtBQUssTUFBUSxLQUFLO0FBQUEsTUFDbEIsS0FBSyxNQUFRLEtBQUs7QUFBQSxNQUNsQixLQUFLLE1BQVEsS0FBSztBQUFBLE1BQ2xCLFdBQVcsWUFBWSxNQUFNLE1BQVEsTUFBTSxLQUM5QztBQUNFLFlBQUksSUFBSSxNQUFNLElBQUksUUFBUSxPQUFPLENBQUM7QUFDbEM7QUFBQSxNQUNKO0FBQ0EsVUFBSSxJQUFJLEtBQU07QUFDVixZQUFJLElBQUksTUFBTSxJQUFJLFVBQVUsQ0FBQztBQUM3QjtBQUFBLE1BQ0o7QUFDQSxVQUFJLElBQUksTUFBTztBQUNYLFlBQUksSUFBSSxNQUFNLElBQUksVUFBVSxNQUFRLEtBQUssQ0FBRSxJQUFJLFVBQVUsTUFBUSxJQUFJLEVBQUs7QUFDMUU7QUFBQSxNQUNKO0FBQ0EsVUFBSSxJQUFJLFNBQVUsS0FBSyxPQUFRO0FBQzNCLFlBQUksSUFBSSxNQUFNLElBQ1YsVUFBVSxNQUFRLEtBQUssRUFBRyxJQUFJLFVBQVUsTUFBUyxLQUFLLElBQUssRUFBSyxJQUFJLFVBQVUsTUFBUSxJQUFJLEVBQUs7QUFDbkc7QUFBQSxNQUNKO0FBQ0EsV0FBSztBQUNMLFVBQUksVUFBYSxJQUFJLFNBQVUsS0FBTyxRQUFRLFdBQVcsQ0FBQyxJQUFJO0FBQzlELFVBQUksSUFBSSxNQUFNLElBQ1YsVUFBVSxNQUFRLEtBQUssRUFBRyxJQUN0QixVQUFVLE1BQVMsS0FBSyxLQUFNLEVBQUssSUFDbkMsVUFBVSxNQUFTLEtBQUssSUFBSyxFQUFLLElBQ2xDLFVBQVUsTUFBUSxJQUFJLEVBQUs7QUFBQSxJQUN2QztBQUNBLFdBQU8sSUFBSSxLQUFLLEVBQUU7QUFBQSxFQUN0QjtBQUNBLFNBQU87QUFDWDtBQXdCTyxTQUFTLFVBQVUsS0FBSztBQUMzQixNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsVUFBVTtBQUNqQyxXQUFPO0FBQUEsRUFDWDtBQUNBLFNBQU8sQ0FBQyxFQUFFLElBQUksZUFBZSxJQUFJLFlBQVksWUFBWSxJQUFJLFlBQVksU0FBUyxHQUFHO0FBQ3pGO0FBSU8sU0FBUyxVQUFVLEtBQUssSUFBSTtBQUMvQixNQUFJRCxXQUFTLEdBQUcsR0FBRztBQUNmLFVBQU0sU0FBUyxDQUFBO0FBQ2YsYUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSyxHQUFHO0FBQ3BDLGFBQU8sS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUMxQjtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsU0FBTyxHQUFHLEdBQUc7QUFDakI7QUNyTkEsTUFBTSxNQUFNLE9BQU8sVUFBVTtBQUM3QixNQUFNLDBCQUEwQjtBQUFBLEVBQzVCLFNBQVMsUUFBUTtBQUNiLFdBQU8sT0FBTyxNQUFNLElBQUk7QUFBQSxFQUM1QjtBQUFBLEVBQ0EsT0FBTztBQUFBLEVBQ1AsUUFBUSxRQUFRLEtBQUs7QUFDakIsV0FBTyxPQUFPLE1BQU0sSUFBSSxNQUFNLE1BQU07QUFBQSxFQUN4QztBQUFBLEVBQ0EsT0FBTyxRQUFRO0FBQ1gsV0FBTyxPQUFPLE1BQU07QUFBQSxFQUN4QjtBQUNKO0FBQ0EsTUFBTSxXQUFXLE1BQU07QUFDdkIsTUFBTSxPQUFPLE1BQU0sVUFBVTtBQUM3QixNQUFNLGdCQUFnQixTQUFVLEtBQUssZ0JBQWdCO0FBQ2pELE9BQUssTUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJLGlCQUFpQixDQUFDLGNBQWMsQ0FBQztBQUNoRjtBQUNBLE1BQU0sU0FBUyxLQUFLLFVBQVU7QUFDOUIsTUFBTSxXQUFXO0FBQUEsRUFDYixnQkFBZ0I7QUFBQSxFQUNoQixXQUFXO0FBQUEsRUFDWCxrQkFBa0I7QUFBQSxFQUNsQixhQUFhO0FBQUEsRUFDYixTQUFTO0FBQUEsRUFDVCxpQkFBaUI7QUFBQSxFQUNqQixXQUFXO0FBQUEsRUFDWCxRQUFRO0FBQUEsRUFDUixpQkFBaUI7QUFBQSxFQUNqQixTQUFTO0FBQUEsRUFDVCxrQkFBa0I7QUFBQSxFQUNsQixRQUFRO0FBQUEsRUFDUixXQUFXLFdBQVcsY0FBYztBQUFBO0FBQUEsRUFFcEMsU0FBUztBQUFBLEVBQ1QsY0FBYyxNQUFNO0FBQ2hCLFdBQU8sT0FBTyxLQUFLLElBQUk7QUFBQSxFQUMzQjtBQUFBLEVBQ0EsV0FBVztBQUFBLEVBQ1gsb0JBQW9CO0FBQ3hCO0FBQ0EsU0FBUyx5QkFBeUIsR0FBRztBQUNqQyxTQUFRLE9BQU8sTUFBTSxZQUNqQixPQUFPLE1BQU0sWUFDYixPQUFPLE1BQU0sYUFDYixPQUFPLE1BQU0sWUFDYixPQUFPLE1BQU07QUFDckI7QUFDQSxNQUFNLFdBQVcsQ0FBQTtBQUNqQixTQUFTLGdCQUFnQixRQUFRLFFBQVEscUJBQXFCLGdCQUFnQixrQkFBa0Isb0JBQW9CLFdBQVcsaUJBQWlCLFNBQVMsUUFBUSxNQUFNLFdBQVcsZUFBZSxRQUFRLFdBQVcsa0JBQWtCLFNBQVMsYUFBYTtBQUN4UCxNQUFJLE1BQU07QUFDVixNQUFJLFNBQVM7QUFDYixNQUFJLE9BQU87QUFDWCxNQUFJLFlBQVk7QUFDaEIsVUFBUSxTQUFTLE9BQU8sSUFBSSxRQUFRLE9BQU8sVUFBa0IsQ0FBQyxXQUFXO0FBRXJFLFVBQU0sTUFBTSxPQUFPLElBQUksTUFBTTtBQUM3QixZQUFRO0FBQ1IsUUFBSSxPQUFPLFFBQVEsYUFBYTtBQUM1QixVQUFJLFFBQVEsTUFBTTtBQUNkLGNBQU0sSUFBSSxXQUFXLHFCQUFxQjtBQUFBLE1BQzlDLE9BQ0s7QUFDRCxvQkFBWTtBQUFBLE1BQ2hCO0FBQUEsSUFDSjtBQUNBLFFBQUksT0FBTyxPQUFPLElBQUksUUFBUSxNQUFNLGFBQWE7QUFDN0MsYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0EsTUFBSSxPQUFPLFdBQVcsWUFBWTtBQUM5QixVQUFNLE9BQU8sUUFBUSxHQUFHO0FBQUEsRUFDNUIsV0FDUyxlQUFlLE1BQU07QUFDMUIsVUFBTSxnQkFBZ0IsR0FBRztBQUFBLEVBQzdCLFdBQ1Msd0JBQXdCLFdBQVcsU0FBUyxHQUFHLEdBQUc7QUFDdkQsVUFBTSxVQUFVLEtBQUssU0FBVSxPQUFPO0FBQ2xDLFVBQUksaUJBQWlCLE1BQU07QUFDdkIsZUFBTyxnQkFBZ0IsS0FBSztBQUFBLE1BQ2hDO0FBQ0EsYUFBTztBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFDQSxNQUFJLFFBQVEsTUFBTTtBQUNkLFFBQUksb0JBQW9CO0FBQ3BCLGFBQU8sV0FBVyxDQUFDO0FBQUE7QUFBQSxRQUVmLFFBQVEsUUFBUSxTQUFTLFNBQVMsU0FBUyxPQUFPLE1BQU07QUFBQSxVQUN0RDtBQUFBLElBQ1Y7QUFDQSxVQUFNO0FBQUEsRUFDVjtBQUNBLE1BQUkseUJBQXlCLEdBQUcsS0FBSyxVQUFVLEdBQUcsR0FBRztBQUNqRCxRQUFJLFNBQVM7QUFDVCxZQUFNLFlBQVksbUJBQW1CLFNBRS9CLFFBQVEsUUFBUSxTQUFTLFNBQVMsU0FBUyxPQUFPLE1BQU07QUFDOUQsYUFBTztBQUFBLFFBQ0gsWUFBWSxTQUFTLElBQ2pCO0FBQUEsUUFFQSxZQUFZLFFBQVEsS0FBSyxTQUFTLFNBQVMsU0FBUyxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQ3hGO0FBQUEsSUFDUTtBQUNBLFdBQU8sQ0FBQyxZQUFZLE1BQU0sSUFBSSxNQUFNLFlBQVksT0FBTyxHQUFHLENBQUMsQ0FBQztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxTQUFTLENBQUE7QUFDZixNQUFJLE9BQU8sUUFBUSxhQUFhO0FBQzVCLFdBQU87QUFBQSxFQUNYO0FBQ0EsTUFBSTtBQUNKLE1BQUksd0JBQXdCLFdBQVcsU0FBUyxHQUFHLEdBQUc7QUFFbEQsUUFBSSxvQkFBb0IsU0FBUztBQUU3QixZQUFNLFVBQVUsS0FBSyxPQUFPO0FBQUEsSUFDaEM7QUFDQSxlQUFXLENBQUMsRUFBRSxPQUFPLElBQUksU0FBUyxJQUFJLElBQUksS0FBSyxHQUFHLEtBQUssT0FBTyxPQUFjLENBQUU7QUFBQSxFQUNsRixXQUNTLFNBQVMsTUFBTSxHQUFHO0FBQ3ZCLGVBQVc7QUFBQSxFQUNmLE9BQ0s7QUFDRCxVQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUc7QUFDNUIsZUFBVyxPQUFPLEtBQUssS0FBSyxJQUFJLElBQUk7QUFBQSxFQUN4QztBQUNBLFFBQU0saUJBQWlCLGtCQUFrQixPQUFPLE1BQU0sRUFBRSxRQUFRLE9BQU8sS0FBSyxJQUFJLE9BQU8sTUFBTTtBQUM3RixRQUFNLGtCQUFrQixrQkFBa0IsU0FBUyxHQUFHLEtBQUssSUFBSSxXQUFXLElBQUksaUJBQWlCLE9BQU87QUFDdEcsTUFBSSxvQkFBb0IsU0FBUyxHQUFHLEtBQUssSUFBSSxXQUFXLEdBQUc7QUFDdkQsV0FBTyxrQkFBa0I7QUFBQSxFQUM3QjtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEVBQUUsR0FBRztBQUN0QyxVQUFNLE1BQU0sU0FBUyxDQUFDO0FBQ3RCLFVBQU07QUFBQTtBQUFBLE1BRU4sT0FBTyxRQUFRLFlBQVksT0FBTyxJQUFJLFVBQVUsY0FBYyxJQUFJLFFBQVEsSUFBSSxHQUFHO0FBQUE7QUFDakYsUUFBSSxhQUFhLFVBQVUsTUFBTTtBQUM3QjtBQUFBLElBQ0o7QUFFQSxVQUFNLGNBQWMsYUFBYSxrQkFBa0IsSUFBSSxRQUFRLE9BQU8sS0FBSyxJQUFJO0FBQy9FLFVBQU0sYUFBYSxTQUFTLEdBQUcsSUFDM0IsT0FBTyx3QkFBd0IsYUFDM0Isb0JBQW9CLGlCQUFpQixXQUFXLElBQzlDLGtCQUNKLG1CQUFtQixZQUFZLE1BQU0sY0FBYyxNQUFNLGNBQWM7QUFDN0UsZ0JBQVksSUFBSSxRQUFRLElBQUk7QUFDNUIsVUFBTSxtQkFBbUIsb0JBQUksUUFBTztBQUNwQyxxQkFBaUIsSUFBSSxVQUFVLFdBQVc7QUFDMUMsa0JBQWMsUUFBUTtBQUFBLE1BQWdCO0FBQUEsTUFBTztBQUFBLE1BQVk7QUFBQSxNQUFxQjtBQUFBLE1BQWdCO0FBQUEsTUFBa0I7QUFBQSxNQUFvQjtBQUFBLE1BQVc7QUFBQTtBQUFBLE1BRS9JLHdCQUF3QixXQUFXLG9CQUFvQixTQUFTLEdBQUcsSUFBSSxPQUFPO0FBQUEsTUFBUztBQUFBLE1BQVE7QUFBQSxNQUFNO0FBQUEsTUFBVztBQUFBLE1BQWU7QUFBQSxNQUFRO0FBQUEsTUFBVztBQUFBLE1BQWtCO0FBQUEsTUFBUztBQUFBLElBQWdCLENBQUM7QUFBQSxFQUNsTTtBQUNBLFNBQU87QUFDWDtBQUNBLFNBQVMsNEJBQTRCLE9BQU8sVUFBVTtBQUNsRCxNQUFJLE9BQU8sS0FBSyxxQkFBcUIsZUFBZSxPQUFPLEtBQUsscUJBQXFCLFdBQVc7QUFDNUYsVUFBTSxJQUFJLFVBQVUsd0VBQXdFO0FBQUEsRUFDaEc7QUFDQSxNQUFJLE9BQU8sS0FBSyxvQkFBb0IsZUFBZSxPQUFPLEtBQUssb0JBQW9CLFdBQVc7QUFDMUYsVUFBTSxJQUFJLFVBQVUsdUVBQXVFO0FBQUEsRUFDL0Y7QUFDQSxNQUFJLEtBQUssWUFBWSxRQUFRLE9BQU8sS0FBSyxZQUFZLGVBQWUsT0FBTyxLQUFLLFlBQVksWUFBWTtBQUNwRyxVQUFNLElBQUksVUFBVSwrQkFBK0I7QUFBQSxFQUN2RDtBQUNBLFFBQU0sVUFBVSxLQUFLLFdBQVcsU0FBUztBQUN6QyxNQUFJLE9BQU8sS0FBSyxZQUFZLGVBQWUsS0FBSyxZQUFZLFdBQVcsS0FBSyxZQUFZLGNBQWM7QUFDbEcsVUFBTSxJQUFJLFVBQVUsbUVBQW1FO0FBQUEsRUFDM0Y7QUFDQSxNQUFJLFNBQVM7QUFDYixNQUFJLE9BQU8sS0FBSyxXQUFXLGFBQWE7QUFDcEMsUUFBSSxDQUFDLElBQUksS0FBSyxZQUFZLEtBQUssTUFBTSxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxVQUFVLGlDQUFpQztBQUFBLElBQ3pEO0FBQ0EsYUFBUyxLQUFLO0FBQUEsRUFDbEI7QUFDQSxRQUFNLFlBQVksV0FBVyxNQUFNO0FBQ25DLE1BQUksU0FBUyxTQUFTO0FBQ3RCLE1BQUksT0FBTyxLQUFLLFdBQVcsY0FBYyxTQUFTLEtBQUssTUFBTSxHQUFHO0FBQzVELGFBQVMsS0FBSztBQUFBLEVBQ2xCO0FBQ0EsTUFBSTtBQUNKLE1BQUksS0FBSyxlQUFlLEtBQUssZUFBZSx5QkFBeUI7QUFDakUsa0JBQWMsS0FBSztBQUFBLEVBQ3ZCLFdBQ1MsYUFBYSxNQUFNO0FBQ3hCLGtCQUFjLEtBQUssVUFBVSxZQUFZO0FBQUEsRUFDN0MsT0FDSztBQUNELGtCQUFjLFNBQVM7QUFBQSxFQUMzQjtBQUNBLE1BQUksb0JBQW9CLFFBQVEsT0FBTyxLQUFLLG1CQUFtQixXQUFXO0FBQ3RFLFVBQU0sSUFBSSxVQUFVLCtDQUErQztBQUFBLEVBQ3ZFO0FBQ0EsUUFBTSxZQUFZLE9BQU8sS0FBSyxjQUFjLGNBQ3hDLENBQUMsQ0FBQyxLQUFLLG9CQUFvQixPQUN2QixPQUNFLFNBQVMsWUFDYixDQUFDLENBQUMsS0FBSztBQUNiLFNBQU87QUFBQSxJQUNILGdCQUFnQixPQUFPLEtBQUssbUJBQW1CLFlBQVksS0FBSyxpQkFBaUIsU0FBUztBQUFBO0FBQUEsSUFFMUY7QUFBQSxJQUNBLGtCQUFrQixPQUFPLEtBQUsscUJBQXFCLFlBQVksQ0FBQyxDQUFDLEtBQUssbUJBQW1CLFNBQVM7QUFBQSxJQUNsRztBQUFBLElBQ0E7QUFBQSxJQUNBLGlCQUFpQixPQUFPLEtBQUssb0JBQW9CLFlBQVksS0FBSyxrQkFBa0IsU0FBUztBQUFBLElBQzdGLGdCQUFnQixDQUFDLENBQUMsS0FBSztBQUFBLElBQ3ZCLFdBQVcsT0FBTyxLQUFLLGNBQWMsY0FBYyxTQUFTLFlBQVksS0FBSztBQUFBLElBQzdFLFFBQVEsT0FBTyxLQUFLLFdBQVcsWUFBWSxLQUFLLFNBQVMsU0FBUztBQUFBLElBQ2xFLGlCQUFpQixPQUFPLEtBQUssb0JBQW9CLFlBQVksS0FBSyxrQkFBa0IsU0FBUztBQUFBLElBQzdGLFNBQVMsT0FBTyxLQUFLLFlBQVksYUFBYSxLQUFLLFVBQVUsU0FBUztBQUFBLElBQ3RFLGtCQUFrQixPQUFPLEtBQUsscUJBQXFCLFlBQVksS0FBSyxtQkFBbUIsU0FBUztBQUFBLElBQ2hHO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsT0FBTyxLQUFLLGtCQUFrQixhQUFhLEtBQUssZ0JBQWdCLFNBQVM7QUFBQSxJQUN4RixXQUFXLE9BQU8sS0FBSyxjQUFjLFlBQVksS0FBSyxZQUFZLFNBQVM7QUFBQTtBQUFBLElBRTNFLE1BQU0sT0FBTyxLQUFLLFNBQVMsYUFBYSxLQUFLLE9BQU87QUFBQSxJQUNwRCxvQkFBb0IsT0FBTyxLQUFLLHVCQUF1QixZQUFZLEtBQUsscUJBQXFCLFNBQVM7QUFBQSxFQUM5RztBQUNBO0FBQ08sU0FBUyxVQUFVLFFBQVEsT0FBTyxJQUFJO0FBQ3pDLE1BQUksTUFBTTtBQUNWLFFBQU0sVUFBVSw0QkFBNEIsSUFBSTtBQUNoRCxNQUFJO0FBQ0osTUFBSTtBQUNKLE1BQUksT0FBTyxRQUFRLFdBQVcsWUFBWTtBQUN0QyxhQUFTLFFBQVE7QUFDakIsVUFBTSxPQUFPLElBQUksR0FBRztBQUFBLEVBQ3hCLFdBQ1MsU0FBUyxRQUFRLE1BQU0sR0FBRztBQUMvQixhQUFTLFFBQVE7QUFDakIsZUFBVztBQUFBLEVBQ2Y7QUFDQSxRQUFNLE9BQU8sQ0FBQTtBQUNiLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxNQUFNO0FBQ3pDLFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSxzQkFBc0Isd0JBQXdCLFFBQVEsV0FBVztBQUN2RSxRQUFNLGlCQUFpQix3QkFBd0IsV0FBVyxRQUFRO0FBQ2xFLE1BQUksQ0FBQyxVQUFVO0FBQ1gsZUFBVyxPQUFPLEtBQUssR0FBRztBQUFBLEVBQzlCO0FBQ0EsTUFBSSxRQUFRLE1BQU07QUFDZCxhQUFTLEtBQUssUUFBUSxJQUFJO0FBQUEsRUFDOUI7QUFDQSxRQUFNLGNBQWMsb0JBQUksUUFBTztBQUMvQixXQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxFQUFFLEdBQUc7QUFDdEMsVUFBTSxNQUFNLFNBQVMsQ0FBQztBQUN0QixRQUFJLFFBQVEsYUFBYSxJQUFJLEdBQUcsTUFBTSxNQUFNO0FBQ3hDO0FBQUEsSUFDSjtBQUNBLGtCQUFjLE1BQU07QUFBQSxNQUFnQixJQUFJLEdBQUc7QUFBQSxNQUFHO0FBQUE7QUFBQSxNQUU5QztBQUFBLE1BQXFCO0FBQUEsTUFBZ0IsUUFBUTtBQUFBLE1BQWtCLFFBQVE7QUFBQSxNQUFvQixRQUFRO0FBQUEsTUFBVyxRQUFRO0FBQUEsTUFBaUIsUUFBUSxTQUFTLFFBQVEsVUFBVTtBQUFBLE1BQU0sUUFBUTtBQUFBLE1BQVEsUUFBUTtBQUFBLE1BQU0sUUFBUTtBQUFBLE1BQVcsUUFBUTtBQUFBLE1BQWUsUUFBUTtBQUFBLE1BQVEsUUFBUTtBQUFBLE1BQVcsUUFBUTtBQUFBLE1BQWtCLFFBQVE7QUFBQSxNQUFTO0FBQUEsSUFBVyxDQUFDO0FBQUEsRUFDdFY7QUFDQSxRQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsU0FBUztBQUMxQyxNQUFJLFNBQVMsUUFBUSxtQkFBbUIsT0FBTyxNQUFNO0FBQ3JELE1BQUksUUFBUSxpQkFBaUI7QUFDekIsUUFBSSxRQUFRLFlBQVksY0FBYztBQUVsQyxnQkFBVTtBQUFBLElBQ2QsT0FDSztBQUVELGdCQUFVO0FBQUEsSUFDZDtBQUFBLEVBQ0o7QUFDQSxTQUFPLE9BQU8sU0FBUyxJQUFJLFNBQVMsU0FBUztBQUNqRDtBQ2xSTyxNQUFNLFVBQVU7QUNBaEIsSUFBSSxPQUFPO0FBQ1gsSUFBSSxPQUFPO0FBQ1gsSUFBSUUsVUFBUTtBQUlaLElBQUlDLGFBQVc7QUFFZixJQUFJQyxTQUFPO0FBQ1gsSUFBSUMsbUJBQWlCO0FBQ3JCLElBQUksNkJBQTZCO0FBQ2pDLElBQUksa0JBQWtCO0FBQ3RCLElBQUksZUFBZTtBQUNuQixJQUFJLGlCQUFpQjtBQUNyQixTQUFTLFNBQVMsT0FBTyxVQUFVLEVBQUUsTUFBTSxNQUFLLEdBQUk7QUFDdkQsTUFBSSxNQUFNO0FBQ04sVUFBTSxJQUFJLE1BQU0sbUNBQW1DLE1BQU0sSUFBSSxnREFBZ0Q7QUFBQSxFQUNqSDtBQUNBLE1BQUksTUFBTTtBQUNOLFVBQU0sSUFBSSxNQUFNLGdDQUFnQyxNQUFNLElBQUksb0NBQW9DLElBQUksS0FBSztBQUFBLEVBQzNHO0FBQ0EsU0FBTyxRQUFRO0FBQ2YsU0FBTyxNQUFNO0FBQ2JILFlBQVEsTUFBTTtBQUlkQyxlQUFXLE1BQU07QUFFakJDLFdBQU8sTUFBTTtBQUNiQyxxQkFBaUIsTUFBTTtBQUN2QiwrQkFBNkIsTUFBTTtBQUNuQyxvQkFBa0IsTUFBTTtBQUN4QixpQkFBZSxNQUFNO0FBQ3JCLG1CQUFpQixNQUFNO0FBQzNCO0FDaENPLE1BQU0sY0FBYztBQUFBLEVBQ3ZCLFlBQVksTUFBTTtBQUNkLFNBQUssT0FBTztBQUFBLEVBQ2hCO0FBQUEsRUFDQSxLQUFLLE9BQU8sV0FBVyxJQUFJO0FBQ3ZCLFdBQU87QUFBQSxFQUNYO0FBQ0o7QUNUTyxTQUFTLFdBQVcsRUFBRSxpQkFBZ0IsSUFBSyxJQUFJO0FBQ2xELFFBQU0saUJBQWlCLG1CQUNuQixrQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUlOLE1BQUksUUFBUSxVQUFVLFdBQVc7QUFDakMsTUFBSTtBQUVBLGFBQVM7QUFFVCxlQUFXO0FBRVgsZ0JBQVk7QUFFWixlQUFXO0FBQUEsRUFDZixTQUNPLE9BQU87QUFDVixVQUFNLElBQUksTUFBTSxpRUFBaUUsTUFBTSxPQUFPLEtBQUssY0FBYyxFQUFFO0FBQUEsRUFDdkg7QUFDQSxTQUFPO0FBQUEsSUFDSCxNQUFNO0FBQUEsSUFDTixPQUFPO0FBQUEsSUFDUCxTQUFTO0FBQUEsSUFDVCxVQUFVO0FBQUEsSUFDVixTQUFTO0FBQUEsSUFDVDtBQUFBO0FBQUEsTUFFQSxPQUFPLGFBQWEsY0FBYyxXQUFZLE1BQU0sU0FBUztBQUFBO0FBQUEsUUFFekQsY0FBYztBQUNWLGdCQUFNLElBQUksTUFBTSxxRkFBcUYsY0FBYyxFQUFFO0FBQUEsUUFDekg7QUFBQSxNQUNaO0FBQUE7QUFBQSxJQUNRLE1BQU0sT0FBTyxTQUFTLGNBQWMsT0FBUSxNQUFNLEtBQUs7QUFBQSxNQUNuRCxjQUFjO0FBQ1YsY0FBTSxJQUFJLE1BQU0saUZBQWlGLGNBQWMsRUFBRTtBQUFBLE1BQ3JIO0FBQUEsSUFDWjtBQUFBLElBQ1E7QUFBQTtBQUFBLE1BRUEsT0FBTyxTQUFTLGNBQWMsT0FBUSxNQUFNLEtBQUs7QUFBQTtBQUFBLFFBRTdDLGNBQWM7QUFDVixnQkFBTSxJQUFJLE1BQU0saUZBQWlGLGNBQWMsRUFBRTtBQUFBLFFBQ3JIO0FBQUEsTUFDWjtBQUFBO0FBQUEsSUFDUTtBQUFBO0FBQUEsTUFFQSxPQUFPLG1CQUFtQixjQUFjLGlCQUFrQixNQUFNLGVBQWU7QUFBQTtBQUFBLFFBRTNFLGNBQWM7QUFDVixnQkFBTSxJQUFJLE1BQU0sdUZBQXVGLGNBQWMsRUFBRTtBQUFBLFFBQzNIO0FBQUEsTUFDWjtBQUFBO0FBQUEsSUFDUSw0QkFBNEIsT0FFNUIsTUFBTSxVQUFVO0FBQUEsTUFDWixHQUFHO0FBQUEsTUFDSCxNQUFNLElBQUksY0FBYyxJQUFJO0FBQUEsSUFDeEM7QUFBQSxJQUNRLGlCQUFpQixDQUFDLFFBQVE7QUFBQSxJQUMxQixjQUFjLE1BQU07QUFDaEIsWUFBTSxJQUFJLE1BQU0sZ0pBQWdKO0FBQUEsSUFDcEs7QUFBQSxJQUNBLGdCQUFnQixDQUFDLFVBQVU7QUFBQSxFQUNuQztBQUNBO0FDaEVPLE1BQU0sT0FBTyxNQUFNO0FBQ3hCLE1BQUksQ0FBQ0MsS0FBWUMsVUFBZUMsV0FBZSxHQUFJLEVBQUUsTUFBTSxNQUFNO0FBQ25FO0FBR0EsS0FBSTtBQ1JHLE1BQU0sb0JBQW9CLE1BQU07QUFDdkM7QUFDTyxNQUFNLGlCQUFpQixZQUFZO0FBQUEsRUFDdEMsWUFBWSxRQUFRLE9BQU8sU0FBUyxTQUFTO0FBQ3pDLFVBQU0sR0FBRyxTQUFTLFlBQVksUUFBUSxPQUFPLE9BQU8sQ0FBQyxFQUFFO0FBQ3ZELFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssYUFBYSxVQUFVLGNBQWM7QUFDMUMsU0FBSyxRQUFRO0FBQ2IsVUFBTSxPQUFPO0FBQ2IsU0FBSyxPQUFPLE9BQU8sTUFBTTtBQUN6QixTQUFLLFFBQVEsT0FBTyxPQUFPO0FBQzNCLFNBQUssT0FBTyxPQUFPLE1BQU07QUFBQSxFQUM3QjtBQUFBLEVBQ0EsT0FBTyxZQUFZLFFBQVEsT0FBTyxTQUFTO0FBQ3ZDLFVBQU0sTUFBTSxPQUFPLFVBQ2YsT0FBTyxNQUFNLFlBQVksV0FDckIsTUFBTSxVQUNKLEtBQUssVUFBVSxNQUFNLE9BQU8sSUFDaEMsUUFBUSxLQUFLLFVBQVUsS0FBSyxJQUN4QjtBQUNWLFFBQUksVUFBVSxLQUFLO0FBQ2YsYUFBTyxHQUFHLE1BQU0sSUFBSSxHQUFHO0FBQUEsSUFDM0I7QUFDQSxRQUFJLFFBQVE7QUFDUixhQUFPLEdBQUcsTUFBTTtBQUFBLElBQ3BCO0FBQ0EsUUFBSSxLQUFLO0FBQ0wsYUFBTztBQUFBLElBQ1g7QUFDQSxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsT0FBTyxTQUFTLFFBQVEsZUFBZSxTQUFTLFNBQVM7QUFDckQsUUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTO0FBQ3JCLGFBQU8sSUFBSSxtQkFBbUIsRUFBRSxTQUFTLE9BQU8sWUFBWSxhQUFhLEdBQUc7QUFBQSxJQUNoRjtBQUNBLFVBQU0sUUFBUSxnQkFBZ0IsT0FBTztBQUNyQyxRQUFJLFdBQVcsS0FBSztBQUNoQixhQUFPLElBQUksZ0JBQWdCLFFBQVEsT0FBTyxTQUFTLE9BQU87QUFBQSxJQUM5RDtBQUNBLFFBQUksV0FBVyxLQUFLO0FBQ2hCLGFBQU8sSUFBSSxvQkFBb0IsUUFBUSxPQUFPLFNBQVMsT0FBTztBQUFBLElBQ2xFO0FBQ0EsUUFBSSxXQUFXLEtBQUs7QUFDaEIsYUFBTyxJQUFJLHNCQUFzQixRQUFRLE9BQU8sU0FBUyxPQUFPO0FBQUEsSUFDcEU7QUFDQSxRQUFJLFdBQVcsS0FBSztBQUNoQixhQUFPLElBQUksY0FBYyxRQUFRLE9BQU8sU0FBUyxPQUFPO0FBQUEsSUFDNUQ7QUFDQSxRQUFJLFdBQVcsS0FBSztBQUNoQixhQUFPLElBQUksY0FBYyxRQUFRLE9BQU8sU0FBUyxPQUFPO0FBQUEsSUFDNUQ7QUFDQSxRQUFJLFdBQVcsS0FBSztBQUNoQixhQUFPLElBQUkseUJBQXlCLFFBQVEsT0FBTyxTQUFTLE9BQU87QUFBQSxJQUN2RTtBQUNBLFFBQUksV0FBVyxLQUFLO0FBQ2hCLGFBQU8sSUFBSSxlQUFlLFFBQVEsT0FBTyxTQUFTLE9BQU87QUFBQSxJQUM3RDtBQUNBLFFBQUksVUFBVSxLQUFLO0FBQ2YsYUFBTyxJQUFJLG9CQUFvQixRQUFRLE9BQU8sU0FBUyxPQUFPO0FBQUEsSUFDbEU7QUFDQSxXQUFPLElBQUksU0FBUyxRQUFRLE9BQU8sU0FBUyxPQUFPO0FBQUEsRUFDdkQ7QUFDSjtBQUNPLE1BQU0sMEJBQTBCLFNBQVM7QUFBQSxFQUM1QyxZQUFZLEVBQUUsUUFBTyxJQUFLLElBQUk7QUFDMUIsVUFBTSxRQUFXLFFBQVcsV0FBVyx3QkFBd0IsTUFBUztBQUFBLEVBQzVFO0FBQ0o7QUFDTyxNQUFNLDJCQUEyQixTQUFTO0FBQUEsRUFDN0MsWUFBWSxFQUFFLFNBQVMsU0FBUztBQUM1QixVQUFNLFFBQVcsUUFBVyxXQUFXLHFCQUFxQixNQUFTO0FBR3JFLFFBQUk7QUFDQSxXQUFLLFFBQVE7QUFBQSxFQUNyQjtBQUNKO0FBQ08sTUFBTSxrQ0FBa0MsbUJBQW1CO0FBQUEsRUFDOUQsWUFBWSxFQUFFLFFBQU8sSUFBSyxJQUFJO0FBQzFCLFVBQU0sRUFBRSxTQUFTLFdBQVcscUJBQW9CLENBQUU7QUFBQSxFQUN0RDtBQUNKO0FBQ08sTUFBTSx3QkFBd0IsU0FBUztBQUM5QztBQUNPLE1BQU0sNEJBQTRCLFNBQVM7QUFDbEQ7QUFDTyxNQUFNLDhCQUE4QixTQUFTO0FBQ3BEO0FBQ08sTUFBTSxzQkFBc0IsU0FBUztBQUM1QztBQUNPLE1BQU0sc0JBQXNCLFNBQVM7QUFDNUM7QUFDTyxNQUFNLGlDQUFpQyxTQUFTO0FBQ3ZEO0FBQ08sTUFBTSx1QkFBdUIsU0FBUztBQUM3QztBQUNPLE1BQU0sNEJBQTRCLFNBQVM7QUFDbEQ7QUFDTyxNQUFNLGdDQUFnQyxZQUFZO0FBQUEsRUFDckQsY0FBYztBQUNWLFVBQU0sa0VBQWtFO0FBQUEsRUFDNUU7QUFDSjtBQUNPLE1BQU0sdUNBQXVDLFlBQVk7QUFBQSxFQUM1RCxjQUFjO0FBQ1YsVUFBTSxvRkFBb0Y7QUFBQSxFQUM5RjtBQUNKO0FDOUdBLElBQUlDLDJCQUFrRSxTQUFVLFVBQVUsT0FBTyxPQUFPQyxPQUFNLEdBQUc7QUFDN0csTUFBSUEsVUFBUyxJQUFLLE9BQU0sSUFBSSxVQUFVLGdDQUFnQztBQUN0RSxNQUFJQSxVQUFTLE9BQU8sQ0FBQyxFQUFHLE9BQU0sSUFBSSxVQUFVLCtDQUErQztBQUMzRixNQUFJLE9BQU8sVUFBVSxhQUFhLGFBQWEsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksUUFBUSxFQUFHLE9BQU0sSUFBSSxVQUFVLHlFQUF5RTtBQUNoTCxTQUFRQSxVQUFTLE1BQU0sRUFBRSxLQUFLLFVBQVUsS0FBSyxJQUFJLElBQUksRUFBRSxRQUFRLFFBQVEsTUFBTSxJQUFJLFVBQVUsS0FBSyxHQUFJO0FBQ3hHO0FBQ0EsSUFBSUMsMkJBQWtFLFNBQVUsVUFBVSxPQUFPRCxPQUFNLEdBQUc7QUFDdEcsTUFBSUEsVUFBUyxPQUFPLENBQUMsRUFBRyxPQUFNLElBQUksVUFBVSwrQ0FBK0M7QUFDM0YsTUFBSSxPQUFPLFVBQVUsYUFBYSxhQUFhLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRyxPQUFNLElBQUksVUFBVSwwRUFBMEU7QUFDakwsU0FBT0EsVUFBUyxNQUFNLElBQUlBLFVBQVMsTUFBTSxFQUFFLEtBQUssUUFBUSxJQUFJLElBQUksRUFBRSxRQUFRLE1BQU0sSUFBSSxRQUFRO0FBQ2hHO0FBQ0EsSUFBSTtBQVFHLE1BQU0sWUFBWTtBQUFBLEVBQ3JCLGNBQWM7QUFDVixxQ0FBaUMsSUFBSSxNQUFNLE1BQU07QUFDakQsU0FBSyxTQUFTLElBQUksV0FBVTtBQUM1QkQsNkJBQXVCLE1BQU0sa0NBQWtDLE1BQU0sR0FBRztBQUFBLEVBQzVFO0FBQUEsRUFDQSxPQUFPLE9BQU87QUFDVixRQUFJLFNBQVMsTUFBTTtBQUNmLGFBQU8sQ0FBQTtBQUFBLElBQ1g7QUFDQSxVQUFNLGNBQWMsaUJBQWlCLGNBQWMsSUFBSSxXQUFXLEtBQUssSUFDakUsT0FBTyxVQUFVLFdBQVcsSUFBSSxZQUFXLEVBQUcsT0FBTyxLQUFLLElBQ3REO0FBQ1YsUUFBSSxVQUFVLElBQUksV0FBVyxLQUFLLE9BQU8sU0FBUyxZQUFZLE1BQU07QUFDcEUsWUFBUSxJQUFJLEtBQUssTUFBTTtBQUN2QixZQUFRLElBQUksYUFBYSxLQUFLLE9BQU8sTUFBTTtBQUMzQyxTQUFLLFNBQVM7QUFDZCxVQUFNLFFBQVEsQ0FBQTtBQUNkLFFBQUk7QUFDSixZQUFRLGVBQWUsaUJBQWlCLEtBQUssUUFBUUUseUJBQXVCLE1BQU0sa0NBQWtDLEdBQUcsQ0FBQyxNQUFNLE1BQU07QUFDaEksVUFBSSxhQUFhLFlBQVlBLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLEtBQUssTUFBTTtBQUV0R0YsaUNBQXVCLE1BQU0sa0NBQWtDLGFBQWEsT0FBTyxHQUFHO0FBQ3RGO0FBQUEsTUFDSjtBQUVBLFVBQUlFLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLEtBQUssU0FDdEUsYUFBYSxVQUFVQSx5QkFBdUIsTUFBTSxrQ0FBa0MsR0FBRyxJQUFJLEtBQUssYUFBYSxXQUFXO0FBQzNILGNBQU0sS0FBSyxLQUFLLFdBQVcsS0FBSyxPQUFPLE1BQU0sR0FBR0EseUJBQXVCLE1BQU0sa0NBQWtDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN6SCxhQUFLLFNBQVMsS0FBSyxPQUFPLE1BQU1BLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLENBQUM7QUFDbkdGLGlDQUF1QixNQUFNLGtDQUFrQyxNQUFNLEdBQUc7QUFDeEU7QUFBQSxNQUNKO0FBQ0EsWUFBTSxXQUFXRSx5QkFBdUIsTUFBTSxrQ0FBa0MsR0FBRyxNQUFNLE9BQU8sYUFBYSxZQUFZLElBQUksYUFBYTtBQUMxSSxZQUFNLE9BQU8sS0FBSyxXQUFXLEtBQUssT0FBTyxNQUFNLEdBQUcsUUFBUSxDQUFDO0FBQzNELFlBQU0sS0FBSyxJQUFJO0FBQ2YsV0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLGFBQWEsS0FBSztBQUNsREYsK0JBQXVCLE1BQU0sa0NBQWtDLE1BQU0sR0FBRztBQUFBLElBQzVFO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLFdBQVcsT0FBTztBQUNkLFFBQUksU0FBUztBQUNULGFBQU87QUFDWCxRQUFJLE9BQU8sVUFBVTtBQUNqQixhQUFPO0FBRVgsUUFBSSxPQUFPLFdBQVcsYUFBYTtBQUMvQixVQUFJLGlCQUFpQixRQUFRO0FBQ3pCLGVBQU8sTUFBTSxTQUFRO0FBQUEsTUFDekI7QUFDQSxVQUFJLGlCQUFpQixZQUFZO0FBQzdCLGVBQU8sT0FBTyxLQUFLLEtBQUssRUFBRSxTQUFRO0FBQUEsTUFDdEM7QUFDQSxZQUFNLElBQUksWUFBWSx3Q0FBd0MsTUFBTSxZQUFZLElBQUksbUlBQW1JO0FBQUEsSUFDM047QUFFQSxRQUFJLE9BQU8sZ0JBQWdCLGFBQWE7QUFDcEMsVUFBSSxpQkFBaUIsY0FBYyxpQkFBaUIsYUFBYTtBQUM3RCxhQUFLLGdCQUFnQixLQUFLLGNBQWMsSUFBSSxZQUFZLE1BQU07QUFDOUQsZUFBTyxLQUFLLFlBQVksT0FBTyxLQUFLO0FBQUEsTUFDeEM7QUFDQSxZQUFNLElBQUksWUFBWSxvREFBb0QsTUFBTSxZQUFZLElBQUksZ0RBQWdEO0FBQUEsSUFDcEo7QUFDQSxVQUFNLElBQUksWUFBWSxnR0FBZ0c7QUFBQSxFQUMxSDtBQUFBLEVBQ0EsUUFBUTtBQUNKLFFBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUTtBQUNyQixhQUFPLENBQUE7QUFBQSxJQUNYO0FBQ0EsV0FBTyxLQUFLLE9BQU8sSUFBSTtBQUFBLEVBQzNCO0FBQ0o7QUFDQSxtQ0FBbUMsb0JBQUksUUFBTztBQUU5QyxZQUFZLGdCQUFnQixvQkFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUM7QUFDaEQsWUFBWSxpQkFBaUI7QUFVN0IsU0FBUyxpQkFBaUIsUUFBUSxZQUFZO0FBQzFDLFFBQU0sVUFBVTtBQUNoQixRQUFNLFdBQVc7QUFDakIsV0FBUyxJQUFJLGNBQWMsR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0FBQ2xELFFBQUksT0FBTyxDQUFDLE1BQU0sU0FBUztBQUN2QixhQUFPLEVBQUUsV0FBVyxHQUFHLE9BQU8sSUFBSSxHQUFHLFVBQVUsTUFBSztBQUFBLElBQ3hEO0FBQ0EsUUFBSSxPQUFPLENBQUMsTUFBTSxVQUFVO0FBQ3hCLGFBQU8sRUFBRSxXQUFXLEdBQUcsT0FBTyxJQUFJLEdBQUcsVUFBVSxLQUFJO0FBQUEsSUFDdkQ7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNYO0FBQ08sU0FBUyx1QkFBdUIsUUFBUTtBQUkzQyxRQUFNLFVBQVU7QUFDaEIsUUFBTSxXQUFXO0FBQ2pCLFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxTQUFTLEdBQUcsS0FBSztBQUN4QyxRQUFJLE9BQU8sQ0FBQyxNQUFNLFdBQVcsT0FBTyxJQUFJLENBQUMsTUFBTSxTQUFTO0FBRXBELGFBQU8sSUFBSTtBQUFBLElBQ2Y7QUFDQSxRQUFJLE9BQU8sQ0FBQyxNQUFNLFlBQVksT0FBTyxJQUFJLENBQUMsTUFBTSxVQUFVO0FBRXRELGFBQU8sSUFBSTtBQUFBLElBQ2Y7QUFDQSxRQUFJLE9BQU8sQ0FBQyxNQUFNLFlBQ2QsT0FBTyxJQUFJLENBQUMsTUFBTSxXQUNsQixJQUFJLElBQUksT0FBTyxVQUNmLE9BQU8sSUFBSSxDQUFDLE1BQU0sWUFDbEIsT0FBTyxJQUFJLENBQUMsTUFBTSxTQUFTO0FBRTNCLGFBQU8sSUFBSTtBQUFBLElBQ2Y7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNYO0FDeklPLFNBQVMsOEJBQThCLFFBQVE7QUFDbEQsTUFBSSxPQUFPLE9BQU8sYUFBYTtBQUMzQixXQUFPO0FBQ1gsUUFBTSxTQUFTLE9BQU8sVUFBUztBQUMvQixTQUFPO0FBQUEsSUFDSCxNQUFNLE9BQU87QUFDVCxVQUFJO0FBQ0EsY0FBTUcsVUFBUyxNQUFNLE9BQU8sS0FBSTtBQUNoQyxZQUFJQSxTQUFRO0FBQ1IsaUJBQU8sWUFBVztBQUN0QixlQUFPQTtBQUFBLE1BQ1gsU0FDTyxHQUFHO0FBQ04sZUFBTyxZQUFXO0FBQ2xCLGNBQU07QUFBQSxNQUNWO0FBQUEsSUFDSjtBQUFBLElBQ0EsTUFBTSxTQUFTO0FBQ1gsWUFBTSxnQkFBZ0IsT0FBTyxPQUFNO0FBQ25DLGFBQU8sWUFBVztBQUNsQixZQUFNO0FBQ04sYUFBTyxFQUFFLE1BQU0sTUFBTSxPQUFPLE9BQVM7QUFBQSxJQUN6QztBQUFBLElBQ0EsQ0FBQyxPQUFPLGFBQWEsSUFBSTtBQUNyQixhQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ1I7QUFDQTtBQzNCTyxNQUFNLE9BQU87QUFBQSxFQUNoQixZQUFZLFVBQVUsWUFBWTtBQUM5QixTQUFLLFdBQVc7QUFDaEIsU0FBSyxhQUFhO0FBQUEsRUFDdEI7QUFBQSxFQUNBLE9BQU8sZ0JBQWdCLFVBQVUsWUFBWTtBQUN6QyxRQUFJLFdBQVc7QUFDZixvQkFBZ0IsV0FBVztBQUN2QixVQUFJLFVBQVU7QUFDVixjQUFNLElBQUksTUFBTSwwRUFBMEU7QUFBQSxNQUM5RjtBQUNBLGlCQUFXO0FBQ1gsVUFBSSxPQUFPO0FBQ1gsVUFBSTtBQUNBLHlCQUFpQixPQUFPLGlCQUFpQixVQUFVLFVBQVUsR0FBRztBQUM1RCxjQUFJO0FBQ0E7QUFDSixjQUFJLElBQUksS0FBSyxXQUFXLFFBQVEsR0FBRztBQUMvQixtQkFBTztBQUNQO0FBQUEsVUFDSjtBQUNBLGNBQUksSUFBSSxVQUFVLFFBQ2QsSUFBSSxNQUFNLFdBQVcsV0FBVyxLQUNoQyxJQUFJLE1BQU0sV0FBVyxhQUFhLEdBQUc7QUFDckMsZ0JBQUk7QUFDSixnQkFBSTtBQUNBLHFCQUFPLEtBQUssTUFBTSxJQUFJLElBQUk7QUFBQSxZQUM5QixTQUNPLEdBQUc7QUFDTixzQkFBUSxNQUFNLHNDQUFzQyxJQUFJLElBQUk7QUFDNUQsc0JBQVEsTUFBTSxlQUFlLElBQUksR0FBRztBQUNwQyxvQkFBTTtBQUFBLFlBQ1Y7QUFDQSxnQkFBSSxRQUFRLEtBQUssT0FBTztBQUNwQixvQkFBTSxJQUFJLFNBQVMsUUFBVyxLQUFLLE9BQU8sUUFBVyxzQkFBc0IsU0FBUyxPQUFPLENBQUM7QUFBQSxZQUNoRztBQUNBLGtCQUFNO0FBQUEsVUFDVixPQUNLO0FBQ0QsZ0JBQUk7QUFDSixnQkFBSTtBQUNBLHFCQUFPLEtBQUssTUFBTSxJQUFJLElBQUk7QUFBQSxZQUM5QixTQUNPLEdBQUc7QUFDTixzQkFBUSxNQUFNLHNDQUFzQyxJQUFJLElBQUk7QUFDNUQsc0JBQVEsTUFBTSxlQUFlLElBQUksR0FBRztBQUNwQyxvQkFBTTtBQUFBLFlBQ1Y7QUFFQSxnQkFBSSxJQUFJLFNBQVMsU0FBUztBQUN0QixvQkFBTSxJQUFJLFNBQVMsUUFBVyxLQUFLLE9BQU8sS0FBSyxTQUFTLE1BQVM7QUFBQSxZQUNyRTtBQUNBLGtCQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU8sS0FBVTtBQUFBLFVBQ3hDO0FBQUEsUUFDSjtBQUNBLGVBQU87QUFBQSxNQUNYLFNBQ08sR0FBRztBQUVOLFlBQUksYUFBYSxTQUFTLEVBQUUsU0FBUztBQUNqQztBQUNKLGNBQU07QUFBQSxNQUNWLFVBQ1o7QUFFZ0IsWUFBSSxDQUFDO0FBQ0QscUJBQVcsTUFBSztBQUFBLE1BQ3hCO0FBQUEsSUFDSjtBQUNBLFdBQU8sSUFBSSxPQUFPLFVBQVUsVUFBVTtBQUFBLEVBQzFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLE9BQU8sbUJBQW1CLGdCQUFnQixZQUFZO0FBQ2xELFFBQUksV0FBVztBQUNmLG9CQUFnQixZQUFZO0FBQ3hCLFlBQU0sY0FBYyxJQUFJLFlBQVc7QUFDbkMsWUFBTSxPQUFPLDhCQUE4QixjQUFjO0FBQ3pELHVCQUFpQixTQUFTLE1BQU07QUFDNUIsbUJBQVcsUUFBUSxZQUFZLE9BQU8sS0FBSyxHQUFHO0FBQzFDLGdCQUFNO0FBQUEsUUFDVjtBQUFBLE1BQ0o7QUFDQSxpQkFBVyxRQUFRLFlBQVksU0FBUztBQUNwQyxjQUFNO0FBQUEsTUFDVjtBQUFBLElBQ0o7QUFDQSxvQkFBZ0IsV0FBVztBQUN2QixVQUFJLFVBQVU7QUFDVixjQUFNLElBQUksTUFBTSwwRUFBMEU7QUFBQSxNQUM5RjtBQUNBLGlCQUFXO0FBQ1gsVUFBSSxPQUFPO0FBQ1gsVUFBSTtBQUNBLHlCQUFpQixRQUFRLGFBQWE7QUFDbEMsY0FBSTtBQUNBO0FBQ0osY0FBSTtBQUNBLGtCQUFNLEtBQUssTUFBTSxJQUFJO0FBQUEsUUFDN0I7QUFDQSxlQUFPO0FBQUEsTUFDWCxTQUNPLEdBQUc7QUFFTixZQUFJLGFBQWEsU0FBUyxFQUFFLFNBQVM7QUFDakM7QUFDSixjQUFNO0FBQUEsTUFDVixVQUNaO0FBRWdCLFlBQUksQ0FBQztBQUNELHFCQUFXLE1BQUs7QUFBQSxNQUN4QjtBQUFBLElBQ0o7QUFDQSxXQUFPLElBQUksT0FBTyxVQUFVLFVBQVU7QUFBQSxFQUMxQztBQUFBLEVBQ0EsQ0FBQyxPQUFPLGFBQWEsSUFBSTtBQUNyQixXQUFPLEtBQUssU0FBUTtBQUFBLEVBQ3hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLE1BQU07QUFDRixVQUFNLE9BQU8sQ0FBQTtBQUNiLFVBQU0sUUFBUSxDQUFBO0FBQ2QsVUFBTSxXQUFXLEtBQUssU0FBUTtBQUM5QixVQUFNLGNBQWMsQ0FBQyxVQUFVO0FBQzNCLGFBQU87QUFBQSxRQUNILE1BQU0sTUFBTTtBQUNSLGNBQUksTUFBTSxXQUFXLEdBQUc7QUFDcEIsa0JBQU1BLFVBQVMsU0FBUyxLQUFJO0FBQzVCLGlCQUFLLEtBQUtBLE9BQU07QUFDaEIsa0JBQU0sS0FBS0EsT0FBTTtBQUFBLFVBQ3JCO0FBQ0EsaUJBQU8sTUFBTSxNQUFLO0FBQUEsUUFDdEI7QUFBQSxNQUNoQjtBQUFBLElBQ1E7QUFDQSxXQUFPO0FBQUEsTUFDSCxJQUFJLE9BQU8sTUFBTSxZQUFZLElBQUksR0FBRyxLQUFLLFVBQVU7QUFBQSxNQUNuRCxJQUFJLE9BQU8sTUFBTSxZQUFZLEtBQUssR0FBRyxLQUFLLFVBQVU7QUFBQSxJQUNoRTtBQUFBLEVBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxtQkFBbUI7QUFDZixVQUFNLE9BQU87QUFDYixRQUFJO0FBQ0osVUFBTSxVQUFVLElBQUksWUFBVztBQUMvQixXQUFPLElBQUlQLGlCQUFlO0FBQUEsTUFDdEIsTUFBTSxRQUFRO0FBQ1YsZUFBTyxLQUFLLE9BQU8sYUFBYSxFQUFDO0FBQUEsTUFDckM7QUFBQSxNQUNBLE1BQU0sS0FBSyxNQUFNO0FBQ2IsWUFBSTtBQUNBLGdCQUFNLEVBQUUsT0FBTyxLQUFJLElBQUssTUFBTSxLQUFLLEtBQUk7QUFDdkMsY0FBSTtBQUNBLG1CQUFPLEtBQUssTUFBSztBQUNyQixnQkFBTSxRQUFRLFFBQVEsT0FBTyxLQUFLLFVBQVUsS0FBSyxJQUFJLElBQUk7QUFDekQsZUFBSyxRQUFRLEtBQUs7QUFBQSxRQUN0QixTQUNPLEtBQUs7QUFDUixlQUFLLE1BQU0sR0FBRztBQUFBLFFBQ2xCO0FBQUEsTUFDSjtBQUFBLE1BQ0EsTUFBTSxTQUFTO0FBQ1gsY0FBTSxLQUFLLFNBQU07QUFBQSxNQUNyQjtBQUFBLElBQ1osQ0FBUztBQUFBLEVBQ0w7QUFDSjtBQUNPLGdCQUFnQixpQkFBaUIsVUFBVSxZQUFZO0FBQzFELE1BQUksQ0FBQyxTQUFTLE1BQU07QUFDaEIsZUFBVyxNQUFLO0FBQ2hCLFVBQU0sSUFBSSxZQUFZLG1EQUFtRDtBQUFBLEVBQzdFO0FBQ0EsUUFBTSxhQUFhLElBQUksV0FBVTtBQUNqQyxRQUFNLGNBQWMsSUFBSSxZQUFXO0FBQ25DLFFBQU0sT0FBTyw4QkFBOEIsU0FBUyxJQUFJO0FBQ3hELG1CQUFpQixZQUFZLGNBQWMsSUFBSSxHQUFHO0FBQzlDLGVBQVcsUUFBUSxZQUFZLE9BQU8sUUFBUSxHQUFHO0FBQzdDLFlBQU0sTUFBTSxXQUFXLE9BQU8sSUFBSTtBQUNsQyxVQUFJO0FBQ0EsY0FBTTtBQUFBLElBQ2Q7QUFBQSxFQUNKO0FBQ0EsYUFBVyxRQUFRLFlBQVksU0FBUztBQUNwQyxVQUFNLE1BQU0sV0FBVyxPQUFPLElBQUk7QUFDbEMsUUFBSTtBQUNBLFlBQU07QUFBQSxFQUNkO0FBQ0o7QUFLQSxnQkFBZ0IsY0FBYyxVQUFVO0FBQ3BDLE1BQUksT0FBTyxJQUFJLFdBQVU7QUFDekIsbUJBQWlCLFNBQVMsVUFBVTtBQUNoQyxRQUFJLFNBQVMsTUFBTTtBQUNmO0FBQUEsSUFDSjtBQUNBLFVBQU0sY0FBYyxpQkFBaUIsY0FBYyxJQUFJLFdBQVcsS0FBSyxJQUNqRSxPQUFPLFVBQVUsV0FBVyxJQUFJLFlBQVcsRUFBRyxPQUFPLEtBQUssSUFDdEQ7QUFDVixRQUFJLFVBQVUsSUFBSSxXQUFXLEtBQUssU0FBUyxZQUFZLE1BQU07QUFDN0QsWUFBUSxJQUFJLElBQUk7QUFDaEIsWUFBUSxJQUFJLGFBQWEsS0FBSyxNQUFNO0FBQ3BDLFdBQU87QUFDUCxRQUFJO0FBQ0osWUFBUSxlQUFlLHVCQUF1QixJQUFJLE9BQU8sSUFBSTtBQUN6RCxZQUFNLEtBQUssTUFBTSxHQUFHLFlBQVk7QUFDaEMsYUFBTyxLQUFLLE1BQU0sWUFBWTtBQUFBLElBQ2xDO0FBQUEsRUFDSjtBQUNBLE1BQUksS0FBSyxTQUFTLEdBQUc7QUFDakIsVUFBTTtBQUFBLEVBQ1Y7QUFDSjtBQUNBLE1BQU0sV0FBVztBQUFBLEVBQ2IsY0FBYztBQUNWLFNBQUssUUFBUTtBQUNiLFNBQUssT0FBTyxDQUFBO0FBQ1osU0FBSyxTQUFTLENBQUE7QUFBQSxFQUNsQjtBQUFBLEVBQ0EsT0FBTyxNQUFNO0FBQ1QsUUFBSSxLQUFLLFNBQVMsSUFBSSxHQUFHO0FBQ3JCLGFBQU8sS0FBSyxVQUFVLEdBQUcsS0FBSyxTQUFTLENBQUM7QUFBQSxJQUM1QztBQUNBLFFBQUksQ0FBQyxNQUFNO0FBRVAsVUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLEtBQUssS0FBSztBQUMxQixlQUFPO0FBQ1gsWUFBTSxNQUFNO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLE1BQU0sS0FBSyxLQUFLLEtBQUssSUFBSTtBQUFBLFFBQ3pCLEtBQUssS0FBSztBQUFBLE1BQzFCO0FBQ1ksV0FBSyxRQUFRO0FBQ2IsV0FBSyxPQUFPLENBQUE7QUFDWixXQUFLLFNBQVMsQ0FBQTtBQUNkLGFBQU87QUFBQSxJQUNYO0FBQ0EsU0FBSyxPQUFPLEtBQUssSUFBSTtBQUNyQixRQUFJLEtBQUssV0FBVyxHQUFHLEdBQUc7QUFDdEIsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssSUFBSSxVQUFVLE1BQU0sR0FBRztBQUMvQyxRQUFJLE1BQU0sV0FBVyxHQUFHLEdBQUc7QUFDdkIsY0FBUSxNQUFNLFVBQVUsQ0FBQztBQUFBLElBQzdCO0FBQ0EsUUFBSSxjQUFjLFNBQVM7QUFDdkIsV0FBSyxRQUFRO0FBQUEsSUFDakIsV0FDUyxjQUFjLFFBQVE7QUFDM0IsV0FBSyxLQUFLLEtBQUssS0FBSztBQUFBLElBQ3hCO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDSjtBQUNBLFNBQVMsVUFBVUosTUFBSyxXQUFXO0FBQy9CLFFBQU0sUUFBUUEsS0FBSSxRQUFRLFNBQVM7QUFDbkMsTUFBSSxVQUFVLElBQUk7QUFDZCxXQUFPLENBQUNBLEtBQUksVUFBVSxHQUFHLEtBQUssR0FBRyxXQUFXQSxLQUFJLFVBQVUsUUFBUSxVQUFVLE1BQU0sQ0FBQztBQUFBLEVBQ3ZGO0FBQ0EsU0FBTyxDQUFDQSxNQUFLLElBQUksRUFBRTtBQUN2QjtBQ3BSTyxNQUFNLGlCQUFpQixDQUFDLFVBQVUsU0FBUyxRQUM5QyxPQUFPLFVBQVUsWUFDakIsT0FBTyxNQUFNLFFBQVEsWUFDckIsT0FBTyxNQUFNLFNBQVM7QUFDbkIsTUFBTSxhQUFhLENBQUMsVUFBVSxTQUFTLFFBQzFDLE9BQU8sVUFBVSxZQUNqQixPQUFPLE1BQU0sU0FBUyxZQUN0QixPQUFPLE1BQU0saUJBQWlCLFlBQzlCLFdBQVcsS0FBSztBQUtiLE1BQU0sYUFBYSxDQUFDLFVBQVUsU0FBUyxRQUMxQyxPQUFPLFVBQVUsWUFDakIsT0FBTyxNQUFNLFNBQVMsWUFDdEIsT0FBTyxNQUFNLFNBQVMsWUFDdEIsT0FBTyxNQUFNLFNBQVMsY0FDdEIsT0FBTyxNQUFNLFVBQVUsY0FDdkIsT0FBTyxNQUFNLGdCQUFnQjtBQUMxQixNQUFNLGVBQWUsQ0FBQyxVQUFVO0FBQ25DLFNBQU8sV0FBVyxLQUFLLEtBQUssZUFBZSxLQUFLLEtBQUssZUFBZSxLQUFLO0FBQzdFO0FBVU8sZUFBZSxPQUFPLE9BQU8sTUFBTSxTQUFTO0FBRS9DLFVBQVEsTUFBTTtBQUVkLE1BQUksV0FBVyxLQUFLLEdBQUc7QUFDbkIsV0FBTztBQUFBLEVBQ1g7QUFDQSxNQUFJLGVBQWUsS0FBSyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSTtBQUM3QixhQUFTLE9BQU8sSUFBSSxJQUFJLE1BQU0sR0FBRyxFQUFFLFNBQVMsTUFBTSxPQUFPLEVBQUUsSUFBRyxLQUFNO0FBSXBFLFVBQU0sT0FBTyxXQUFXLElBQUksSUFBSSxDQUFFLE1BQU0sS0FBSyxZQUFXLEtBQU8sQ0FBQyxJQUFJO0FBQ3BFLFdBQU8sSUFBSUcsT0FBSyxNQUFNLE1BQU0sT0FBTztBQUFBLEVBQ3ZDO0FBQ0EsUUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0FBQ2pDLFdBQVMsT0FBTyxRQUFRLEtBQUssS0FBSztBQUNsQyxNQUFJLENBQUMsU0FBUyxNQUFNO0FBQ2hCLFVBQU0sT0FBTyxLQUFLLENBQUMsR0FBRztBQUN0QixRQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzFCLGdCQUFVLEVBQUUsR0FBRyxTQUFTLEtBQUk7QUFBQSxJQUNoQztBQUFBLEVBQ0o7QUFDQSxTQUFPLElBQUlBLE9BQUssTUFBTSxNQUFNLE9BQU87QUFDdkM7QUFDQSxlQUFlLFNBQVMsT0FBTztBQUMzQixNQUFJLFFBQVEsQ0FBQTtBQUNaLE1BQUksT0FBTyxVQUFVLFlBQ2pCLFlBQVksT0FBTyxLQUFLO0FBQUEsRUFDeEIsaUJBQWlCLGFBQWE7QUFDOUIsVUFBTSxLQUFLLEtBQUs7QUFBQSxFQUNwQixXQUNTLFdBQVcsS0FBSyxHQUFHO0FBQ3hCLFVBQU0sS0FBSyxNQUFNLE1BQU0sWUFBVyxDQUFFO0FBQUEsRUFDeEMsV0FDUyx3QkFBd0IsS0FBSyxHQUNwQztBQUNFLHFCQUFpQixTQUFTLE9BQU87QUFDN0IsWUFBTSxLQUFLLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0osT0FDSztBQUNELFVBQU0sSUFBSSxNQUFNLHlCQUF5QixPQUFPLEtBQUssa0JBQWtCLE9BQU8sYUFDeEUsSUFBSSxZQUFZLGNBQWMsS0FBSyxDQUFDLEVBQUU7QUFBQSxFQUNoRDtBQUNBLFNBQU87QUFDWDtBQUNBLFNBQVMsY0FBYyxPQUFPO0FBQzFCLFFBQU0sUUFBUSxPQUFPLG9CQUFvQixLQUFLO0FBQzlDLFNBQU8sSUFBSSxNQUFNLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFDcEQ7QUFDQSxTQUFTLFFBQVEsT0FBTztBQUNwQixTQUFRLHlCQUF5QixNQUFNLElBQUksS0FDdkMseUJBQXlCLE1BQU0sUUFBUTtBQUFBLEVBRXZDLHlCQUF5QixNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sRUFBRSxJQUFHO0FBQ2hFO0FBQ0EsTUFBTSwyQkFBMkIsQ0FBQyxNQUFNO0FBQ3BDLE1BQUksT0FBTyxNQUFNO0FBQ2IsV0FBTztBQUNYLE1BQUksT0FBTyxXQUFXLGVBQWUsYUFBYTtBQUM5QyxXQUFPLE9BQU8sQ0FBQztBQUNuQixTQUFPO0FBQ1g7QUFDQSxNQUFNLDBCQUEwQixDQUFDLFVBQVUsU0FBUyxRQUFRLE9BQU8sVUFBVSxZQUFZLE9BQU8sTUFBTSxPQUFPLGFBQWEsTUFBTTtBQUN6SCxNQUFNLGtCQUFrQixDQUFDLFNBQVMsUUFBUSxPQUFPLFNBQVMsWUFBWSxLQUFLLFFBQVEsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQVdoSCxNQUFNLDhCQUE4QixPQUFPLFNBQVM7QUFDdkQsUUFBTSxPQUFPLE1BQU0sV0FBVyxLQUFLLElBQUk7QUFDdkMsU0FBTywyQkFBMkIsTUFBTSxJQUFJO0FBQ2hEO0FBQ08sTUFBTSxhQUFhLE9BQU8sU0FBUztBQUN0QyxRQUFNLE9BQU8sSUFBSUQsV0FBUTtBQUN6QixRQUFNLFFBQVEsSUFBSSxPQUFPLFFBQVEsUUFBUSxDQUFBLENBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTSxhQUFhLE1BQU0sS0FBSyxLQUFLLENBQUMsQ0FBQztBQUNsRyxTQUFPO0FBQ1g7QUFjQSxNQUFNLGVBQWUsT0FBTyxNQUFNLEtBQUssVUFBVTtBQUM3QyxNQUFJLFVBQVU7QUFDVjtBQUNKLE1BQUksU0FBUyxNQUFNO0FBQ2YsVUFBTSxJQUFJLFVBQVUsc0JBQXNCLEdBQUcsNkRBQTZEO0FBQUEsRUFDOUc7QUFFQSxNQUFJLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxXQUFXO0FBQ3RGLFNBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxDQUFDO0FBQUEsRUFDbEMsV0FDUyxhQUFhLEtBQUssR0FBRztBQUMxQixVQUFNLE9BQU8sTUFBTSxPQUFPLEtBQUs7QUFDL0IsU0FBSyxPQUFPLEtBQUssSUFBSTtBQUFBLEVBQ3pCLFdBQ1MsTUFBTSxRQUFRLEtBQUssR0FBRztBQUMzQixVQUFNLFFBQVEsSUFBSSxNQUFNLElBQUksQ0FBQyxVQUFVLGFBQWEsTUFBTSxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFBQSxFQUNqRixXQUNTLE9BQU8sVUFBVSxVQUFVO0FBQ2hDLFVBQU0sUUFBUSxJQUFJLE9BQU8sUUFBUSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLE1BQU0sYUFBYSxNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQztBQUFBLEVBQzlHLE9BQ0s7QUFDRCxVQUFNLElBQUksVUFBVSx3R0FBd0csS0FBSyxVQUFVO0FBQUEsRUFDL0k7QUFDSjs7QUM1SkEsSUFBSU0sMkJBQWtFLFNBQVUsVUFBVSxPQUFPLE9BQU9DLE9BQU0sR0FBRztBQUc3RyxNQUFJLE9BQU8sVUFBVSxhQUFhLGFBQWEsU0FBUyxPQUFLLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRyxPQUFNLElBQUksVUFBVSx5RUFBeUU7QUFDaEwsU0FBdUUsTUFBTSxJQUFJLFVBQVUsS0FBSyxHQUFJO0FBQ3hHO0FBQ0EsSUFBSUMsMkJBQWtFLFNBQVUsVUFBVSxPQUFPRCxPQUFNLEdBQUc7QUFFdEcsTUFBSSxPQUFPLFVBQVUsYUFBYSxhQUFhLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRyxPQUFNLElBQUksVUFBVSwwRUFBMEU7QUFDakwsU0FBT0EsVUFBUyxNQUFNLElBQUlBLFVBQVMsTUFBTSxFQUFFLEtBQUssUUFBUSxJQUFJLElBQUksRUFBRSxRQUFRLE1BQU0sSUFBSSxRQUFRO0FBQ2hHO0FBQ0EsSUFBSTtBQU1KLEtBQUE7QUFHQSxlQUFlLHFCQUFxQixPQUFPO0FBQ3ZDLFFBQU0sRUFBRSxhQUFhO0FBQ3JCLE1BQUksTUFBTSxRQUFRLFFBQVE7QUFDdEIsVUFBTSxZQUFZLFNBQVMsUUFBUSxTQUFTLEtBQUssU0FBUyxTQUFTLFNBQVMsSUFBSTtBQUdoRixRQUFJLE1BQU0sUUFBUSxlQUFlO0FBQzdCLGFBQU8sTUFBTSxRQUFRLGNBQWMsZ0JBQWdCLFVBQVUsTUFBTSxVQUFVO0FBQUEsSUFDakY7QUFDQSxXQUFPLE9BQU8sZ0JBQWdCLFVBQVUsTUFBTSxVQUFVO0FBQUEsRUFDNUQ7QUFFQSxNQUFJLFNBQVMsV0FBVyxLQUFLO0FBQ3pCLFdBQU87QUFBQSxFQUNYO0FBQ0EsTUFBSSxNQUFNLFFBQVEsa0JBQWtCO0FBQ2hDLFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSxjQUFjLFNBQVMsUUFBUSxJQUFJLGNBQWM7QUFDdkQsUUFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFHLEtBQUE7QUFDOUMsUUFBTSxTQUFTLFdBQVcsU0FBUyxrQkFBa0IsS0FBSyxXQUFXLFNBQVMsT0FBTztBQUNyRixNQUFJLFFBQVE7QUFDUixVQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUE7QUFDNUIsVUFBTSxZQUFZLFNBQVMsUUFBUSxTQUFTLEtBQUssU0FBUyxTQUFTLElBQUk7QUFDdkUsV0FBTyxjQUFjLE1BQU0sUUFBUTtBQUFBLEVBQ3ZDO0FBQ0EsUUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFBO0FBQzVCLFFBQU0sWUFBWSxTQUFTLFFBQVEsU0FBUyxLQUFLLFNBQVMsU0FBUyxJQUFJO0FBRXZFLFNBQU87QUFDWDtBQUNBLFNBQVMsY0FBYyxPQUFPLFVBQVU7QUFDcEMsTUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFlBQVksTUFBTSxRQUFRLEtBQUssR0FBRztBQUM3RCxXQUFPO0FBQUEsRUFDWDtBQUNBLFNBQU8sT0FBTyxlQUFlLE9BQU8sZUFBZTtBQUFBLElBQy9DLE9BQU8sU0FBUyxRQUFRLElBQUksY0FBYztBQUFBLElBQzFDLFlBQVk7QUFBQSxFQUFBLENBQ2Y7QUFDTDtBQUtPLE1BQU0sbUJBQW1CLFFBQVE7QUFBQSxFQUNwQyxZQUFZLGlCQUFpQkcsaUJBQWdCLHNCQUFzQjtBQUMvRCxVQUFNLENBQUMsWUFBWTtBQUlmLGNBQVEsSUFBSTtBQUFBLElBQ2hCLENBQUM7QUFDRCxTQUFLLGtCQUFrQjtBQUN2QixTQUFLLGdCQUFnQkE7QUFBQSxFQUN6QjtBQUFBLEVBQ0EsWUFBWSxXQUFXO0FBQ25CLFdBQU8sSUFBSSxXQUFXLEtBQUssaUJBQWlCLE9BQU8sVUFBVSxjQUFjLFVBQVUsTUFBTSxLQUFLLGNBQWMsS0FBSyxHQUFHLEtBQUssR0FBRyxNQUFNLFFBQVEsQ0FBQztBQUFBLEVBQ2pKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWNBLGFBQWE7QUFDVCxXQUFPLEtBQUssZ0JBQWdCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUTtBQUFBLEVBQ3REO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkEsTUFBTSxlQUFlO0FBQ2pCLFVBQU0sQ0FBQyxNQUFNLFFBQVEsSUFBSSxNQUFNLFFBQVEsSUFBSSxDQUFDLEtBQUssTUFBQSxHQUFTLEtBQUssV0FBQSxDQUFZLENBQUM7QUFDNUUsV0FBTyxFQUFFLE1BQU0sVUFBVSxZQUFZLFNBQVMsUUFBUSxJQUFJLGNBQWMsRUFBQTtBQUFBLEVBQzVFO0FBQUEsRUFDQSxRQUFRO0FBQ0osUUFBSSxDQUFDLEtBQUssZUFBZTtBQUNyQixXQUFLLGdCQUFnQixLQUFLLGdCQUFnQixLQUFLLEtBQUssYUFBYTtBQUFBLElBQ3JFO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDaEI7QUFBQSxFQUNBLEtBQUssYUFBYSxZQUFZO0FBQzFCLFdBQU8sS0FBSyxNQUFBLEVBQVEsS0FBSyxhQUFhLFVBQVU7QUFBQSxFQUNwRDtBQUFBLEVBQ0EsTUFBTSxZQUFZO0FBQ2QsV0FBTyxLQUFLLFFBQVEsTUFBTSxVQUFVO0FBQUEsRUFDeEM7QUFBQSxFQUNBLFFBQVEsV0FBVztBQUNmLFdBQU8sS0FBSyxRQUFRLFFBQVEsU0FBUztBQUFBLEVBQ3pDO0FBQ0o7QUFDTyxNQUFNLFVBQVU7QUFBQSxFQUNuQixZQUFZO0FBQUEsSUFBRTtBQUFBLElBQVMsYUFBYTtBQUFBLElBQUcsVUFBVTtBQUFBO0FBQUEsSUFDakQ7QUFBQSxJQUFXLE9BQU87QUFBQSxFQUFBLEdBQW9CO0FBQ2xDLFNBQUssVUFBVTtBQUNmLFNBQUssYUFBYSx3QkFBd0IsY0FBYyxVQUFVO0FBQ2xFLFNBQUssVUFBVSx3QkFBd0IsV0FBVyxPQUFPO0FBQ3pELFNBQUssWUFBWTtBQUNqQixTQUFLLFFBQVEsbUJBQW1CWDtBQUFBQSxFQUNwQztBQUFBLEVBQ0EsWUFBWSxNQUFNO0FBQ2QsV0FBTyxDQUFBO0FBQUEsRUFDWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLGVBQWUsTUFBTTtBQUNqQixXQUFPO0FBQUEsTUFDSCxRQUFRO0FBQUEsTUFDUixnQkFBZ0I7QUFBQSxNQUNoQixjQUFjLEtBQUssYUFBQTtBQUFBLE1BQ25CLEdBQUcsbUJBQUE7QUFBQSxNQUNILEdBQUcsS0FBSyxZQUFZLElBQUk7QUFBQSxJQUFBO0FBQUEsRUFFaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGdCQUFnQixTQUFTLGVBQWU7QUFBQSxFQUFFO0FBQUEsRUFDMUMsd0JBQXdCO0FBQ3BCLFdBQU8sd0JBQXdCLE9BQU87QUFBQSxFQUMxQztBQUFBLEVBQ0EsSUFBSSxNQUFNLE1BQU07QUFDWixXQUFPLEtBQUssY0FBYyxPQUFPLE1BQU0sSUFBSTtBQUFBLEVBQy9DO0FBQUEsRUFDQSxLQUFLLE1BQU0sTUFBTTtBQUNiLFdBQU8sS0FBSyxjQUFjLFFBQVEsTUFBTSxJQUFJO0FBQUEsRUFDaEQ7QUFBQSxFQUNBLE1BQU0sTUFBTSxNQUFNO0FBQ2QsV0FBTyxLQUFLLGNBQWMsU0FBUyxNQUFNLElBQUk7QUFBQSxFQUNqRDtBQUFBLEVBQ0EsSUFBSSxNQUFNLE1BQU07QUFDWixXQUFPLEtBQUssY0FBYyxPQUFPLE1BQU0sSUFBSTtBQUFBLEVBQy9DO0FBQUEsRUFDQSxPQUFPLE1BQU0sTUFBTTtBQUNmLFdBQU8sS0FBSyxjQUFjLFVBQVUsTUFBTSxJQUFJO0FBQUEsRUFDbEQ7QUFBQSxFQUNBLGNBQWMsUUFBUSxNQUFNLE1BQU07QUFDOUIsV0FBTyxLQUFLLFFBQVEsUUFBUSxRQUFRLElBQUksRUFBRSxLQUFLLE9BQU9ZLFVBQVM7QUFDM0QsWUFBTSxPQUFPQSxTQUFRLFdBQVdBLE9BQU0sSUFBSSxJQUFJLElBQUksU0FBUyxNQUFNQSxNQUFLLEtBQUssWUFBQSxDQUFhLElBQ2xGQSxPQUFNLGdCQUFnQixXQUFXQSxNQUFLLE9BQ2xDQSxPQUFNLGdCQUFnQixjQUFjLElBQUksU0FBU0EsTUFBSyxJQUFJLElBQ3REQSxTQUFRLFlBQVksT0FBT0EsT0FBTSxJQUFJLElBQUksSUFBSSxTQUFTQSxNQUFLLEtBQUssTUFBTSxJQUNsRUEsT0FBTTtBQUN4QixhQUFPLEVBQUUsUUFBUSxNQUFNLEdBQUdBLE9BQU0sS0FBQTtBQUFBLElBQ3BDLENBQUMsQ0FBQztBQUFBLEVBQ047QUFBQSxFQUNBLFdBQVcsTUFBTUMsT0FBTSxNQUFNO0FBQ3pCLFdBQU8sS0FBSyxlQUFlQSxPQUFNLEVBQUUsUUFBUSxPQUFPLE1BQU0sR0FBRyxNQUFNO0FBQUEsRUFDckU7QUFBQSxFQUNBLHVCQUF1QixNQUFNO0FBQ3pCLFFBQUksT0FBTyxTQUFTLFVBQVU7QUFDMUIsVUFBSSxPQUFPLFdBQVcsYUFBYTtBQUMvQixlQUFPLE9BQU8sV0FBVyxNQUFNLE1BQU0sRUFBRSxTQUFBO0FBQUEsTUFDM0M7QUFDQSxVQUFJLE9BQU8sZ0JBQWdCLGFBQWE7QUFDcEMsY0FBTSxVQUFVLElBQUksWUFBQTtBQUNwQixjQUFNLFVBQVUsUUFBUSxPQUFPLElBQUk7QUFDbkMsZUFBTyxRQUFRLE9BQU8sU0FBQTtBQUFBLE1BQzFCO0FBQUEsSUFDSixXQUNTLFlBQVksT0FBTyxJQUFJLEdBQUc7QUFDL0IsYUFBTyxLQUFLLFdBQVcsU0FBQTtBQUFBLElBQzNCO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLGFBQWEsY0FBYyxFQUFFLGFBQWEsRUFBQSxJQUFNLENBQUEsR0FBSTtBQUNoRCxVQUFNLFVBQVUsRUFBRSxHQUFHLGFBQUE7QUFDckIsVUFBTSxFQUFFLFFBQVEsTUFBTSxPQUFPLFVBQW1CLENBQUEsTUFBTztBQUN2RCxVQUFNLE9BQU8sWUFBWSxPQUFPLFFBQVEsSUFBSSxLQUFNLFFBQVEsbUJBQW1CLE9BQU8sUUFBUSxTQUFTLFdBQ2pHLFFBQVEsT0FDTixnQkFBZ0IsUUFBUSxJQUFJLElBQUksUUFBUSxLQUFLLE9BQ3pDLFFBQVEsT0FBTyxLQUFLLFVBQVUsUUFBUSxNQUFNLE1BQU0sQ0FBQyxJQUMvQztBQUNkLFVBQU0sZ0JBQWdCLEtBQUssdUJBQXVCLElBQUk7QUFDdEQsVUFBTSxNQUFNLEtBQUssU0FBUyxNQUFNLEtBQUs7QUFDckMsUUFBSSxhQUFhO0FBQ2IsOEJBQXdCLFdBQVcsUUFBUSxPQUFPO0FBQ3RELFlBQVEsVUFBVSxRQUFRLFdBQVcsS0FBSztBQUMxQyxVQUFNLFlBQVksUUFBUSxhQUFhLEtBQUssYUFBYSxnQkFBZ0IsR0FBRztBQUM1RSxVQUFNLGtCQUFrQixRQUFRLFVBQVU7QUFDMUMsUUFBSSxPQUFPLFdBQVcsU0FBUyxZQUFZLFlBQ3ZDLG1CQUFtQixVQUFVLFFBQVEsV0FBVyxJQUFJO0FBS3BELGdCQUFVLFFBQVEsVUFBVTtBQUFBLElBQ2hDO0FBQ0EsUUFBSSxLQUFLLHFCQUFxQixXQUFXLE9BQU87QUFDNUMsVUFBSSxDQUFDLGFBQWE7QUFDZCxxQkFBYSxpQkFBaUIsS0FBSyxzQkFBQTtBQUN2QyxjQUFRLEtBQUssaUJBQWlCLElBQUksYUFBYTtBQUFBLElBQ25EO0FBQ0EsVUFBTSxhQUFhLEtBQUssYUFBYSxFQUFFLFNBQVMsU0FBUyxlQUFlLFlBQVk7QUFDcEYsVUFBTSxNQUFNO0FBQUEsTUFDUjtBQUFBLE1BQ0EsR0FBSSxRQUFRLEVBQUUsS0FBQTtBQUFBLE1BQ2QsU0FBUztBQUFBLE1BQ1QsR0FBSSxhQUFhLEVBQUUsT0FBTyxVQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzFCLFFBQVEsUUFBUSxVQUFVO0FBQUEsSUFBQTtBQUU5QixXQUFPLEVBQUUsS0FBSyxLQUFLLFNBQVMsUUFBUSxRQUFBO0FBQUEsRUFDeEM7QUFBQSxFQUNBLGFBQWEsRUFBRSxTQUFTLFNBQVMsZUFBZSxjQUFlO0FBQzNELFVBQU0sYUFBYSxDQUFBO0FBQ25CLFFBQUksZUFBZTtBQUNmLGlCQUFXLGdCQUFnQixJQUFJO0FBQUEsSUFDbkM7QUFDQSxVQUFNLGlCQUFpQixLQUFLLGVBQWUsT0FBTztBQUNsRCxvQkFBZ0IsWUFBWSxjQUFjO0FBQzFDLG9CQUFnQixZQUFZLE9BQU87QUFFbkMsUUFBSSxnQkFBZ0IsUUFBUSxJQUFJLEtBQUtDLFNBQWMsUUFBUTtBQUN2RCxhQUFPLFdBQVcsY0FBYztBQUFBLElBQ3BDO0FBSUEsUUFBSSxVQUFVLGdCQUFnQix5QkFBeUIsTUFBTSxVQUN6RCxVQUFVLFNBQVMseUJBQXlCLE1BQU0sUUFBVztBQUM3RCxpQkFBVyx5QkFBeUIsSUFBSSxPQUFPLFVBQVU7QUFBQSxJQUM3RDtBQUNBLFFBQUksVUFBVSxnQkFBZ0IscUJBQXFCLE1BQU0sVUFDckQsVUFBVSxTQUFTLHFCQUFxQixNQUFNLFVBQzlDLFFBQVEsU0FBUztBQUNqQixpQkFBVyxxQkFBcUIsSUFBSSxPQUFPLEtBQUssTUFBTSxRQUFRLFVBQVUsR0FBSSxDQUFDO0FBQUEsSUFDakY7QUFDQSxTQUFLLGdCQUFnQixZQUFZLE9BQU87QUFDeEMsV0FBTztBQUFBLEVBQ1g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLE1BQU0sZUFBZSxTQUFTO0FBQUEsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT2hDLE1BQU0sZUFBZSxTQUFTLEVBQUUsS0FBSyxXQUFXO0FBQUEsRUFBRTtBQUFBLEVBQ2xELGFBQWEsU0FBUztBQUNsQixXQUFRLENBQUMsVUFBVSxDQUFBLElBQ2IsT0FBTyxZQUFZLFVBQ2pCLE9BQU8sWUFBWSxNQUFNLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxJQUNqRSxFQUFFLEdBQUcsUUFBQTtBQUFBLEVBQ25CO0FBQUEsRUFDQSxnQkFBZ0IsUUFBUSxPQUFPLFNBQVMsU0FBUztBQUM3QyxXQUFPLFNBQVMsU0FBUyxRQUFRLE9BQU8sU0FBUyxPQUFPO0FBQUEsRUFDNUQ7QUFBQSxFQUNBLFFBQVEsU0FBUyxtQkFBbUIsTUFBTTtBQUN0QyxXQUFPLElBQUksV0FBVyxLQUFLLFlBQVksU0FBUyxnQkFBZ0IsQ0FBQztBQUFBLEVBQ3JFO0FBQUEsRUFDQSxNQUFNLFlBQVksY0FBYyxrQkFBa0I7QUFDOUMsVUFBTSxVQUFVLE1BQU07QUFDdEIsVUFBTSxhQUFhLFFBQVEsY0FBYyxLQUFLO0FBQzlDLFFBQUksb0JBQW9CLE1BQU07QUFDMUIseUJBQW1CO0FBQUEsSUFDdkI7QUFDQSxVQUFNLEtBQUssZUFBZSxPQUFPO0FBQ2pDLFVBQU0sRUFBRSxLQUFLLEtBQUssUUFBQSxJQUFZLEtBQUssYUFBYSxTQUFTLEVBQUUsWUFBWSxhQUFhLGlCQUFBLENBQWtCO0FBQ3RHLFVBQU0sS0FBSyxlQUFlLEtBQUssRUFBRSxLQUFLLFNBQVM7QUFDL0MsVUFBTSxXQUFXLEtBQUssU0FBUyxJQUFJLE9BQU87QUFDMUMsUUFBSSxRQUFRLFFBQVEsU0FBUztBQUN6QixZQUFNLElBQUksa0JBQUE7QUFBQSxJQUNkO0FBQ0EsVUFBTSxhQUFhLElBQUksZ0JBQUE7QUFDdkIsVUFBTSxXQUFXLE1BQU0sS0FBSyxpQkFBaUIsS0FBSyxLQUFLLFNBQVMsVUFBVSxFQUFFLE1BQU0sV0FBVztBQUM3RixRQUFJLG9CQUFvQixPQUFPO0FBQzNCLFVBQUksUUFBUSxRQUFRLFNBQVM7QUFDekIsY0FBTSxJQUFJLGtCQUFBO0FBQUEsTUFDZDtBQUNBLFVBQUksa0JBQWtCO0FBQ2xCLGVBQU8sS0FBSyxhQUFhLFNBQVMsZ0JBQWdCO0FBQUEsTUFDdEQ7QUFDQSxVQUFJLFNBQVMsU0FBUyxjQUFjO0FBQ2hDLGNBQU0sSUFBSSwwQkFBQTtBQUFBLE1BQ2Q7QUFDQSxZQUFNLElBQUksbUJBQW1CLEVBQUUsT0FBTyxVQUFVO0FBQUEsSUFDcEQ7QUFDQSxVQUFNLGtCQUFrQixzQkFBc0IsU0FBUyxPQUFPO0FBQzlELFFBQUksQ0FBQyxTQUFTLElBQUk7QUFDZCxVQUFJLG9CQUFvQixLQUFLLFlBQVksUUFBUSxHQUFHO0FBQ2hELGNBQU1DLGdCQUFlLGFBQWEsZ0JBQWdCO0FBQ2xELGNBQU0sb0JBQW9CQSxhQUFZLEtBQUssU0FBUyxRQUFRLEtBQUssZUFBZTtBQUNoRixlQUFPLEtBQUssYUFBYSxTQUFTLGtCQUFrQixlQUFlO0FBQUEsTUFDdkU7QUFDQSxZQUFNLFVBQVUsTUFBTSxTQUFTLE9BQU8sTUFBTSxDQUFDLE1BQU0sWUFBWSxDQUFDLEVBQUUsT0FBTztBQUN6RSxZQUFNLFVBQVUsU0FBUyxPQUFPO0FBQ2hDLFlBQU0sYUFBYSxVQUFVLFNBQVk7QUFDekMsWUFBTSxlQUFlLG1CQUFtQixrQ0FBa0M7QUFDMUUsWUFBTSxvQkFBb0IsWUFBWSxLQUFLLFNBQVMsUUFBUSxLQUFLLGlCQUFpQixVQUFVO0FBQzVGLFlBQU0sTUFBTSxLQUFLLGdCQUFnQixTQUFTLFFBQVEsU0FBUyxZQUFZLGVBQWU7QUFDdEYsWUFBTTtBQUFBLElBQ1Y7QUFDQSxXQUFPLEVBQUUsVUFBVSxTQUFTLFdBQUE7QUFBQSxFQUNoQztBQUFBLEVBQ0EsZUFBZUYsT0FBTSxTQUFTO0FBQzFCLFVBQU0sVUFBVSxLQUFLLFlBQVksU0FBUyxJQUFJO0FBQzlDLFdBQU8sSUFBSSxZQUFZLE1BQU0sU0FBU0EsS0FBSTtBQUFBLEVBQzlDO0FBQUEsRUFDQSxTQUFTLE1BQU0sT0FBTztBQUNsQixVQUFNLE1BQU0sY0FBYyxJQUFJLElBQzFCLElBQUksSUFBSSxJQUFJLElBQ1YsSUFBSSxJQUFJLEtBQUssV0FBVyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQUssS0FBSyxXQUFXLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUs7QUFDeEcsVUFBTSxlQUFlLEtBQUssYUFBQTtBQUMxQixRQUFJLENBQUMsV0FBVyxZQUFZLEdBQUc7QUFDM0IsY0FBUSxFQUFFLEdBQUcsY0FBYyxHQUFHLE1BQUE7QUFBQSxJQUNsQztBQUNBLFFBQUksT0FBTyxVQUFVLFlBQVksU0FBUyxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDN0QsVUFBSSxTQUFTLEtBQUssZUFBZSxLQUFLO0FBQUEsSUFDMUM7QUFDQSxXQUFPLElBQUksU0FBQTtBQUFBLEVBQ2Y7QUFBQSxFQUNBLGVBQWUsT0FBTztBQUNsQixXQUFPLE9BQU8sUUFBUSxLQUFLLEVBQ3RCLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSyxNQUFNLE9BQU8sVUFBVSxXQUFXLEVBQ25ELElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxNQUFNO0FBQ3ZCLFVBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFdBQVc7QUFDdEYsZUFBTyxHQUFHLG1CQUFtQixHQUFHLENBQUMsSUFBSSxtQkFBbUIsS0FBSyxDQUFDO0FBQUEsTUFDbEU7QUFDQSxVQUFJLFVBQVUsTUFBTTtBQUNoQixlQUFPLEdBQUcsbUJBQW1CLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQ0EsWUFBTSxJQUFJLFlBQVkseUJBQXlCLE9BQU8sS0FBSyxtUUFBbVE7QUFBQSxJQUNsVSxDQUFDLEVBQ0ksS0FBSyxHQUFHO0FBQUEsRUFDakI7QUFBQSxFQUNBLE1BQU0saUJBQWlCLEtBQUtHLE9BQU0sSUFBSSxZQUFZO0FBQzlDLFVBQU0sRUFBRSxRQUFRLEdBQUcsUUFBQSxJQUFZQSxTQUFRLENBQUE7QUFDdkMsUUFBSTtBQUNBLGFBQU8saUJBQWlCLFNBQVMsTUFBTSxXQUFXLE9BQU87QUFDN0QsVUFBTSxVQUFVLFdBQVcsTUFBTSxXQUFXLE1BQUEsR0FBUyxFQUFFO0FBQ3ZELFVBQU0sZUFBZTtBQUFBLE1BQ2pCLFFBQVEsV0FBVztBQUFBLE1BQ25CLEdBQUc7QUFBQSxJQUFBO0FBRVAsUUFBSSxhQUFhLFFBQVE7QUFHckIsbUJBQWEsU0FBUyxhQUFhLE9BQU8sWUFBQTtBQUFBLElBQzlDO0FBQ0E7QUFBQTtBQUFBLE1BRUEsS0FBSyxNQUFNLEtBQUssUUFBVyxLQUFLLFlBQVksRUFBRSxRQUFRLE1BQU07QUFDeEQscUJBQWEsT0FBTztBQUFBLE1BQ3hCLENBQUM7QUFBQTtBQUFBLEVBQ0w7QUFBQSxFQUNBLFlBQVksVUFBVTtBQUVsQixVQUFNLG9CQUFvQixTQUFTLFFBQVEsSUFBSSxnQkFBZ0I7QUFFL0QsUUFBSSxzQkFBc0I7QUFDdEIsYUFBTztBQUNYLFFBQUksc0JBQXNCO0FBQ3RCLGFBQU87QUFFWCxRQUFJLFNBQVMsV0FBVztBQUNwQixhQUFPO0FBRVgsUUFBSSxTQUFTLFdBQVc7QUFDcEIsYUFBTztBQUVYLFFBQUksU0FBUyxXQUFXO0FBQ3BCLGFBQU87QUFFWCxRQUFJLFNBQVMsVUFBVTtBQUNuQixhQUFPO0FBQ1gsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLE1BQU0sYUFBYSxTQUFTLGtCQUFrQixpQkFBaUI7QUFDM0QsUUFBSTtBQUVKLFVBQU0seUJBQXlCLGtCQUFrQixnQkFBZ0I7QUFDakUsUUFBSSx3QkFBd0I7QUFDeEIsWUFBTSxZQUFZLFdBQVcsc0JBQXNCO0FBQ25ELFVBQUksQ0FBQyxPQUFPLE1BQU0sU0FBUyxHQUFHO0FBQzFCLHdCQUFnQjtBQUFBLE1BQ3BCO0FBQUEsSUFDSjtBQUVBLFVBQU0sbUJBQW1CLGtCQUFrQixhQUFhO0FBQ3hELFFBQUksb0JBQW9CLENBQUMsZUFBZTtBQUNwQyxZQUFNLGlCQUFpQixXQUFXLGdCQUFnQjtBQUNsRCxVQUFJLENBQUMsT0FBTyxNQUFNLGNBQWMsR0FBRztBQUMvQix3QkFBZ0IsaUJBQWlCO0FBQUEsTUFDckMsT0FDSztBQUNELHdCQUFnQixLQUFLLE1BQU0sZ0JBQWdCLElBQUksS0FBSyxJQUFBO0FBQUEsTUFDeEQ7QUFBQSxJQUNKO0FBR0EsUUFBSSxFQUFFLGlCQUFpQixLQUFLLGlCQUFpQixnQkFBZ0IsS0FBSyxNQUFPO0FBQ3JFLFlBQU0sYUFBYSxRQUFRLGNBQWMsS0FBSztBQUM5QyxzQkFBZ0IsS0FBSyxtQ0FBbUMsa0JBQWtCLFVBQVU7QUFBQSxJQUN4RjtBQUNBLFVBQU0sTUFBTSxhQUFhO0FBQ3pCLFdBQU8sS0FBSyxZQUFZLFNBQVMsbUJBQW1CLENBQUM7QUFBQSxFQUN6RDtBQUFBLEVBQ0EsbUNBQW1DLGtCQUFrQixZQUFZO0FBQzdELFVBQU0sb0JBQW9CO0FBQzFCLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sYUFBYSxhQUFhO0FBRWhDLFVBQU0sZUFBZSxLQUFLLElBQUksb0JBQW9CLEtBQUssSUFBSSxHQUFHLFVBQVUsR0FBRyxhQUFhO0FBRXhGLFVBQU0sU0FBUyxJQUFJLEtBQUssT0FBQSxJQUFXO0FBQ25DLFdBQU8sZUFBZSxTQUFTO0FBQUEsRUFDbkM7QUFBQSxFQUNBLGVBQWU7QUFDWCxXQUFPLEdBQUcsS0FBSyxZQUFZLElBQUksT0FBTyxPQUFPO0FBQUEsRUFDakQ7QUFDSjtBQUNPLE1BQU0sYUFBYTtBQUFBLEVBQ3RCLFlBQVksUUFBUSxVQUFVLE1BQU0sU0FBUztBQUN6Qyx5QkFBcUIsSUFBSSxNQUFNLE1BQU07QUFDckNULDZCQUF1QixNQUFNLHNCQUFzQixNQUFXO0FBQzlELFNBQUssVUFBVTtBQUNmLFNBQUssV0FBVztBQUNoQixTQUFLLE9BQU87QUFBQSxFQUNoQjtBQUFBLEVBQ0EsY0FBYztBQUNWLFVBQU0sUUFBUSxLQUFLLGtCQUFBO0FBQ25CLFFBQUksQ0FBQyxNQUFNO0FBQ1AsYUFBTztBQUNYLFdBQU8sS0FBSyxrQkFBa0I7QUFBQSxFQUNsQztBQUFBLEVBQ0EsTUFBTSxjQUFjO0FBQ2hCLFVBQU0sV0FBVyxLQUFLLGFBQUE7QUFDdEIsUUFBSSxDQUFDLFVBQVU7QUFDWCxZQUFNLElBQUksWUFBWSx1RkFBdUY7QUFBQSxJQUNqSDtBQUNBLFVBQU0sY0FBYyxFQUFFLEdBQUcsS0FBSyxRQUFBO0FBQzlCLFFBQUksWUFBWSxZQUFZLE9BQU8sWUFBWSxVQUFVLFVBQVU7QUFDL0Qsa0JBQVksUUFBUSxFQUFFLEdBQUcsWUFBWSxPQUFPLEdBQUcsU0FBUyxPQUFBO0FBQUEsSUFDNUQsV0FDUyxTQUFTLFVBQVU7QUFDeEIsWUFBTSxTQUFTLENBQUMsR0FBRyxPQUFPLFFBQVEsWUFBWSxTQUFTLENBQUEsQ0FBRSxHQUFHLEdBQUcsU0FBUyxJQUFJLGFBQWEsU0FBUztBQUNsRyxpQkFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLFFBQVE7QUFDL0IsaUJBQVMsSUFBSSxhQUFhLElBQUksS0FBSyxLQUFLO0FBQUEsTUFDNUM7QUFDQSxrQkFBWSxRQUFRO0FBQ3BCLGtCQUFZLE9BQU8sU0FBUyxJQUFJLFNBQUE7QUFBQSxJQUNwQztBQUNBLFdBQU8sTUFBTUUseUJBQXVCLE1BQU0sc0JBQXNCLEdBQUcsRUFBRSxlQUFlLEtBQUssYUFBYSxXQUFXO0FBQUEsRUFDckg7QUFBQSxFQUNBLE9BQU8sWUFBWTtBQUVmLFFBQUksT0FBTztBQUNYLFVBQU07QUFDTixXQUFPLEtBQUssZUFBZTtBQUN2QixhQUFPLE1BQU0sS0FBSyxZQUFBO0FBQ2xCLFlBQU07QUFBQSxJQUNWO0FBQUEsRUFDSjtBQUFBLEVBQ0EsU0FBUyx1QkFBdUIsb0JBQUksV0FBVyxPQUFPLGtCQUFrQjtBQUNwRSxxQkFBaUIsUUFBUSxLQUFLLGFBQWE7QUFDdkMsaUJBQVcsUUFBUSxLQUFLLHFCQUFxQjtBQUN6QyxjQUFNO0FBQUEsTUFDVjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0o7QUFVTyxNQUFNLG9CQUFvQixXQUFXO0FBQUEsRUFDeEMsWUFBWSxRQUFRLFNBQVNJLE9BQU07QUFDL0IsVUFBTSxTQUFTLE9BQU8sVUFBVSxJQUFJQSxNQUFLLFFBQVEsTUFBTSxVQUFVLE1BQU0scUJBQXFCLEtBQUssR0FBRyxNQUFNLE9BQU8sQ0FBQztBQUFBLEVBQ3RIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBLFFBQVEsT0FBTyxhQUFhLElBQUk7QUFDNUIsVUFBTSxPQUFPLE1BQU07QUFDbkIscUJBQWlCLFFBQVEsTUFBTTtBQUMzQixZQUFNO0FBQUEsSUFDVjtBQUFBLEVBQ0o7QUFDSjtBQUNPLE1BQU0sd0JBQXdCLENBQUMsWUFBWTtBQUM5QyxTQUFPLElBQUksTUFBTSxPQUFPO0FBQUE7QUFBQSxJQUV4QixRQUFRLFFBQUE7QUFBQSxFQUFRLEdBQUk7QUFBQSxJQUNoQixJQUFJLFFBQVEsTUFBTTtBQUNkLFlBQU0sTUFBTSxLQUFLLFNBQUE7QUFDakIsYUFBTyxPQUFPLElBQUksWUFBQSxDQUFhLEtBQUssT0FBTyxHQUFHO0FBQUEsSUFDbEQ7QUFBQSxFQUFBLENBQ0g7QUFDTDtBQUlBLE1BQU0scUJBQXFCO0FBQUEsRUFDdkIsUUFBUTtBQUFBLEVBQ1IsTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsWUFBWTtBQUFBLEVBQ1osUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsV0FBVztBQUFBLEVBQ1gsUUFBUTtBQUFBLEVBQ1IsZ0JBQWdCO0FBQUEsRUFDaEIsWUFBWTtBQUFBLEVBQ1osaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQUEsRUFDbEIsZUFBZTtBQUNuQjtBQUNPLE1BQU0sbUJBQW1CLENBQUMsUUFBUTtBQUNyQyxTQUFRLE9BQU8sUUFBUSxZQUNuQixRQUFRLFFBQ1IsQ0FBQyxXQUFXLEdBQUcsS0FDZixPQUFPLEtBQUssR0FBRyxFQUFFLE1BQU0sQ0FBQyxNQUFNLE9BQU8sb0JBQW9CLENBQUMsQ0FBQztBQUNuRTtBQUNBLE1BQU0sd0JBQXdCLE1BQU07QUFDaEMsTUFBSSxPQUFPLFNBQVMsZUFBZSxLQUFLLFNBQVMsTUFBTTtBQUNuRCxXQUFPO0FBQUEsTUFDSCxvQkFBb0I7QUFBQSxNQUNwQiwrQkFBK0I7QUFBQSxNQUMvQixrQkFBa0Isa0JBQWtCLEtBQUssTUFBTSxFQUFFO0FBQUEsTUFDakQsb0JBQW9CLGNBQWMsS0FBSyxNQUFNLElBQUk7QUFBQSxNQUNqRCx1QkFBdUI7QUFBQSxNQUN2QiwrQkFBK0IsT0FBTyxLQUFLLFlBQVksV0FBVyxLQUFLLFVBQVUsS0FBSyxTQUFTLFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFL0c7QUFDQSxNQUFJLE9BQU8sZ0JBQWdCLGFBQWE7QUFDcEMsV0FBTztBQUFBLE1BQ0gsb0JBQW9CO0FBQUEsTUFDcEIsK0JBQStCO0FBQUEsTUFDL0Isa0JBQWtCO0FBQUEsTUFDbEIsb0JBQW9CLFNBQVMsV0FBVztBQUFBLE1BQ3hDLHVCQUF1QjtBQUFBLE1BQ3ZCLCtCQUErQixRQUFRO0FBQUEsSUFBQTtBQUFBLEVBRS9DO0FBRUEsTUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLE9BQU8sWUFBWSxjQUFjLFVBQVUsQ0FBQyxNQUFNLG9CQUFvQjtBQUNyRyxXQUFPO0FBQUEsTUFDSCxvQkFBb0I7QUFBQSxNQUNwQiwrQkFBK0I7QUFBQSxNQUMvQixrQkFBa0Isa0JBQWtCLFFBQVEsUUFBUTtBQUFBLE1BQ3BELG9CQUFvQixjQUFjLFFBQVEsSUFBSTtBQUFBLE1BQzlDLHVCQUF1QjtBQUFBLE1BQ3ZCLCtCQUErQixRQUFRO0FBQUEsSUFBQTtBQUFBLEVBRS9DO0FBQ0EsUUFBTSxjQUFjLGVBQUE7QUFDcEIsTUFBSSxhQUFhO0FBQ2IsV0FBTztBQUFBLE1BQ0gsb0JBQW9CO0FBQUEsTUFDcEIsK0JBQStCO0FBQUEsTUFDL0Isa0JBQWtCO0FBQUEsTUFDbEIsb0JBQW9CO0FBQUEsTUFDcEIsdUJBQXVCLFdBQVcsWUFBWSxPQUFPO0FBQUEsTUFDckQsK0JBQStCLFlBQVk7QUFBQSxJQUFBO0FBQUEsRUFFbkQ7QUFFQSxTQUFPO0FBQUEsSUFDSCxvQkFBb0I7QUFBQSxJQUNwQiwrQkFBK0I7QUFBQSxJQUMvQixrQkFBa0I7QUFBQSxJQUNsQixvQkFBb0I7QUFBQSxJQUNwQix1QkFBdUI7QUFBQSxJQUN2QiwrQkFBK0I7QUFBQSxFQUFBO0FBRXZDO0FBRUEsU0FBUyxpQkFBaUI7QUFDdEIsTUFBSSxPQUFPLGNBQWMsZUFBZSxDQUFDLFdBQVc7QUFDaEQsV0FBTztBQUFBLEVBQ1g7QUFFQSxRQUFNLGtCQUFrQjtBQUFBLElBQ3BCLEVBQUUsS0FBSyxRQUFRLFNBQVMsdUNBQUE7QUFBQSxJQUN4QixFQUFFLEtBQUssTUFBTSxTQUFTLHVDQUFBO0FBQUEsSUFDdEIsRUFBRSxLQUFLLE1BQU0sU0FBUyw2Q0FBQTtBQUFBLElBQ3RCLEVBQUUsS0FBSyxVQUFVLFNBQVMseUNBQUE7QUFBQSxJQUMxQixFQUFFLEtBQUssV0FBVyxTQUFTLDBDQUFBO0FBQUEsSUFDM0IsRUFBRSxLQUFLLFVBQVUsU0FBUyxvRUFBQTtBQUFBLEVBQW9FO0FBR2xHLGFBQVcsRUFBRSxLQUFLLFFBQUEsS0FBYSxpQkFBaUI7QUFDNUMsVUFBTSxRQUFRLFFBQVEsS0FBSyxVQUFVLFNBQVM7QUFDOUMsUUFBSSxPQUFPO0FBQ1AsWUFBTSxRQUFRLE1BQU0sQ0FBQyxLQUFLO0FBQzFCLFlBQU0sUUFBUSxNQUFNLENBQUMsS0FBSztBQUMxQixZQUFNLFFBQVEsTUFBTSxDQUFDLEtBQUs7QUFDMUIsYUFBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEdBQUE7QUFBQSxJQUM5RDtBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQ1g7QUFDQSxNQUFNLGdCQUFnQixDQUFDLFNBQVM7QUFLNUIsTUFBSSxTQUFTO0FBQ1QsV0FBTztBQUNYLE1BQUksU0FBUyxZQUFZLFNBQVM7QUFDOUIsV0FBTztBQUNYLE1BQUksU0FBUztBQUNULFdBQU87QUFDWCxNQUFJLFNBQVMsYUFBYSxTQUFTO0FBQy9CLFdBQU87QUFDWCxNQUFJO0FBQ0EsV0FBTyxTQUFTLElBQUk7QUFDeEIsU0FBTztBQUNYO0FBQ0EsTUFBTSxvQkFBb0IsQ0FBQyxhQUFhO0FBTXBDLGFBQVcsU0FBUyxZQUFBO0FBS3BCLE1BQUksU0FBUyxTQUFTLEtBQUs7QUFDdkIsV0FBTztBQUNYLE1BQUksYUFBYTtBQUNiLFdBQU87QUFDWCxNQUFJLGFBQWE7QUFDYixXQUFPO0FBQ1gsTUFBSSxhQUFhO0FBQ2IsV0FBTztBQUNYLE1BQUksYUFBYTtBQUNiLFdBQU87QUFDWCxNQUFJLGFBQWE7QUFDYixXQUFPO0FBQ1gsTUFBSSxhQUFhO0FBQ2IsV0FBTztBQUNYLE1BQUk7QUFDQSxXQUFPLFNBQVMsUUFBUTtBQUM1QixTQUFPO0FBQ1g7QUFDQSxJQUFJO0FBQ0osTUFBTSxxQkFBcUIsTUFBTTtBQUM3QixTQUFRLHFCQUFxQixtQkFBbUI7QUFDcEQ7QUFDTyxNQUFNLFdBQVcsQ0FBQyxTQUFTO0FBQzlCLE1BQUk7QUFDQSxXQUFPLEtBQUssTUFBTSxJQUFJO0FBQUEsRUFDMUIsU0FDTyxLQUFLO0FBQ1IsV0FBTztBQUFBLEVBQ1g7QUFDSjtBQUVBLE1BQU0seUJBQXlCO0FBQy9CLE1BQU0sZ0JBQWdCLENBQUMsUUFBUTtBQUMzQixTQUFPLHVCQUF1QixLQUFLLEdBQUc7QUFDMUM7QUFDTyxNQUFNLFFBQVEsQ0FBQyxPQUFPLElBQUksUUFBUSxDQUFDLFlBQVksV0FBVyxTQUFTLEVBQUUsQ0FBQztBQUM3RSxNQUFNLDBCQUEwQixDQUFDLE1BQU0sTUFBTTtBQUN6QyxNQUFJLE9BQU8sTUFBTSxZQUFZLENBQUMsT0FBTyxVQUFVLENBQUMsR0FBRztBQUMvQyxVQUFNLElBQUksWUFBWSxHQUFHLElBQUkscUJBQXFCO0FBQUEsRUFDdEQ7QUFDQSxNQUFJLElBQUksR0FBRztBQUNQLFVBQU0sSUFBSSxZQUFZLEdBQUcsSUFBSSw2QkFBNkI7QUFBQSxFQUM5RDtBQUNBLFNBQU87QUFDWDtBQUNPLE1BQU0sY0FBYyxDQUFDLFFBQVE7QUFDaEMsTUFBSSxlQUFlO0FBQ2YsV0FBTztBQUNYLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxNQUFNO0FBQ3pDLFFBQUk7QUFDQSxhQUFPLElBQUksTUFBTSxLQUFLLFVBQVUsR0FBRyxDQUFDO0FBQUEsSUFDeEMsUUFDTTtBQUFBLElBQUU7QUFBQSxFQUNaO0FBQ0EsU0FBTyxJQUFJLE1BQU0sR0FBRztBQUN4QjtBQWFPLE1BQU0sVUFBVSxDQUFDLFFBQVE7QUFDNUIsTUFBSSxPQUFPLFlBQVksYUFBYTtBQUNoQyxXQUFPLDZCQUFjLEdBQUcsR0FBRyxLQUFBLEtBQVU7QUFBQSxFQUN6QztBQUNBLE1BQUksT0FBTyxTQUFTLGFBQWE7QUFDN0IsV0FBTyxLQUFLLEtBQUssTUFBTSxHQUFHLEdBQUcsS0FBQTtBQUFBLEVBQ2pDO0FBQ0EsU0FBTztBQUNYO0FBeUNPLFNBQVMsV0FBVyxLQUFLO0FBQzVCLE1BQUksQ0FBQztBQUNELFdBQU87QUFDWCxhQUFXLE1BQU07QUFDYixXQUFPO0FBQ1gsU0FBTztBQUNYO0FBRU8sU0FBUyxPQUFPLEtBQUssS0FBSztBQUM3QixTQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssS0FBSyxHQUFHO0FBQ3hEO0FBT0EsU0FBUyxnQkFBZ0IsZUFBZSxZQUFZO0FBQ2hELGFBQVcsS0FBSyxZQUFZO0FBQ3hCLFFBQUksQ0FBQyxPQUFPLFlBQVksQ0FBQztBQUNyQjtBQUNKLFVBQU0sV0FBVyxFQUFFLFlBQUE7QUFDbkIsUUFBSSxDQUFDO0FBQ0Q7QUFDSixVQUFNLE1BQU0sV0FBVyxDQUFDO0FBQ3hCLFFBQUksUUFBUSxNQUFNO0FBQ2QsYUFBTyxjQUFjLFFBQVE7QUFBQSxJQUNqQyxXQUNTLFFBQVEsUUFBVztBQUN4QixvQkFBYyxRQUFRLElBQUk7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFDSjtBQUNBLE1BQU0sb0JBQW9CLG9CQUFJLElBQUksQ0FBQyxpQkFBaUIsU0FBUyxDQUFDO0FBQ3ZELFNBQVMsTUFBTSxXQUFXLE1BQU07QUFDbkMsTUFBSSxPQUFPLFlBQVksZUFBZSw2QkFBZSxPQUFPLE1BQU0sUUFBUTtBQUN0RSxVQUFNLGVBQWUsS0FBSyxJQUFJLENBQUMsUUFBUTtBQUNuQyxVQUFJLENBQUMsS0FBSztBQUNOLGVBQU87QUFBQSxNQUNYO0FBRUEsVUFBSSxJQUFJLFNBQVMsR0FBRztBQUVoQixjQUFNSSxlQUFjLEVBQUUsR0FBRyxLQUFLLFNBQVMsRUFBRSxHQUFHLElBQUksU0FBUyxJQUFFO0FBQzNELG1CQUFXLFVBQVUsSUFBSSxTQUFTLEdBQUc7QUFDakMsY0FBSSxrQkFBa0IsSUFBSSxPQUFPLFlBQUEsQ0FBYSxHQUFHO0FBQzdDQSx5QkFBWSxTQUFTLEVBQUUsTUFBTSxJQUFJO0FBQUEsVUFDckM7QUFBQSxRQUNKO0FBQ0EsZUFBT0E7QUFBQUEsTUFDWDtBQUNBLFVBQUksY0FBYztBQUVsQixpQkFBVyxVQUFVLEtBQUs7QUFDdEIsWUFBSSxrQkFBa0IsSUFBSSxPQUFPLFlBQUEsQ0FBYSxHQUFHO0FBRTdDLDBCQUFnQixjQUFjLEVBQUUsR0FBRztBQUNuQyxzQkFBWSxNQUFNLElBQUk7QUFBQSxRQUMxQjtBQUFBLE1BQ0o7QUFDQSxhQUFPLGVBQWU7QUFBQSxJQUMxQixDQUFDO0FBQ0QsWUFBUSxJQUFJLGdCQUFnQixNQUFNLElBQUksR0FBRyxZQUFZO0FBQUEsRUFDekQ7QUFDSjtBQUlBLE1BQU0sUUFBUSxNQUFNO0FBQ2hCLFNBQU8sdUNBQXVDLFFBQVEsU0FBUyxDQUFDLE1BQU07QUFDbEUsVUFBTSxJQUFLLEtBQUssT0FBQSxJQUFXLEtBQU07QUFDakMsVUFBTSxJQUFJLE1BQU0sTUFBTSxJQUFLLElBQUksSUFBTztBQUN0QyxXQUFPLEVBQUUsU0FBUyxFQUFFO0FBQUEsRUFDeEIsQ0FBQztBQUNMO0FBQ08sTUFBTSxxQkFBcUIsTUFBTTtBQUNwQztBQUFBO0FBQUEsSUFFQSxPQUFPLFdBQVc7QUFBQSxJQUVkLE9BQU8sT0FBTyxhQUFhO0FBQUEsSUFFM0IsT0FBTyxjQUFjO0FBQUE7QUFDN0I7QUFDTyxNQUFNLG9CQUFvQixDQUFDLFlBQVk7QUFDMUMsU0FBTyxPQUFPLFNBQVMsUUFBUTtBQUNuQztBQVFPLE1BQU0sWUFBWSxDQUFDLFNBQVMsV0FBVztBQUMxQyxRQUFNLG1CQUFtQixPQUFPLFlBQUE7QUFDaEMsTUFBSSxrQkFBa0IsT0FBTyxHQUFHO0FBRTVCLFVBQU0sa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGdCQUMvQixPQUFPLFVBQVUsQ0FBQyxFQUFFLFFBQVEsZ0JBQWdCLENBQUMsSUFBSSxJQUFJLE9BQU8sS0FBSyxHQUFHLGFBQWE7QUFDckYsZUFBVyxPQUFPLENBQUMsUUFBUSxrQkFBa0IsT0FBTyxZQUFBLEdBQWUsZUFBZSxHQUFHO0FBQ2pGLFlBQU0sUUFBUSxRQUFRLElBQUksR0FBRztBQUM3QixVQUFJLE9BQU87QUFDUCxlQUFPO0FBQUEsTUFDWDtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0EsYUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDaEQsUUFBSSxJQUFJLFlBQUEsTUFBa0Isa0JBQWtCO0FBQ3hDLFVBQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN0QixZQUFJLE1BQU0sVUFBVTtBQUNoQixpQkFBTyxNQUFNLENBQUM7QUFDbEIsZ0JBQVEsS0FBSyxZQUFZLE1BQU0sTUFBTSxvQkFBb0IsTUFBTSxpQ0FBaUM7QUFDaEcsZUFBTyxNQUFNLENBQUM7QUFBQSxNQUNsQjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUNBLFNBQU87QUFDWDtBQW9CTyxNQUFNLGlCQUFpQixDQUFDLGNBQWM7QUFDekMsTUFBSSxPQUFPLFdBQVcsYUFBYTtBQUUvQixVQUFNLE1BQU0sT0FBTyxLQUFLLFdBQVcsUUFBUTtBQUMzQyxXQUFPLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxRQUFRLElBQUksWUFBWSxJQUFJLFNBQVMsYUFBYSxpQkFBaUIsQ0FBQztBQUFBLEVBQy9HLE9BQ0s7QUFFRCxVQUFNLFlBQVksS0FBSyxTQUFTO0FBQ2hDLFVBQU0sTUFBTSxVQUFVO0FBQ3RCLFVBQU0sUUFBUSxJQUFJLFdBQVcsR0FBRztBQUNoQyxhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztBQUMxQixZQUFNLENBQUMsSUFBSSxVQUFVLFdBQVcsQ0FBQztBQUFBLElBQ3JDO0FBQ0EsV0FBTyxNQUFNLEtBQUssSUFBSSxhQUFhLE1BQU0sTUFBTSxDQUFDO0FBQUEsRUFDcEQ7QUFDSjtBQUNPLFNBQVMsTUFBTSxLQUFLO0FBQ3ZCLFNBQU8sT0FBTyxRQUFRLE9BQU8sUUFBUSxZQUFZLENBQUMsTUFBTSxRQUFRLEdBQUc7QUFDdkU7QUN0N0JPLE1BQU0sYUFBYSxhQUFhO0FBQUEsRUFDbkMsWUFBWSxRQUFRLFVBQVUsTUFBTSxTQUFTO0FBQ3pDLFVBQU0sUUFBUSxVQUFVLE1BQU0sT0FBTztBQUNyQyxTQUFLLE9BQU8sS0FBSyxRQUFRLENBQUE7QUFDekIsU0FBSyxTQUFTLEtBQUs7QUFBQSxFQUN2QjtBQUFBLEVBQ0Esb0JBQW9CO0FBQ2hCLFdBQU8sS0FBSyxRQUFRLENBQUE7QUFBQSxFQUN4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLGlCQUFpQjtBQUNiLFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxlQUFlO0FBQ1gsV0FBTztBQUFBLEVBQ1g7QUFDSjtBQUNPLE1BQU0sbUJBQW1CLGFBQWE7QUFBQSxFQUN6QyxZQUFZLFFBQVEsVUFBVSxNQUFNLFNBQVM7QUFDekMsVUFBTSxRQUFRLFVBQVUsTUFBTSxPQUFPO0FBQ3JDLFNBQUssT0FBTyxLQUFLLFFBQVEsQ0FBQTtBQUN6QixTQUFLLFdBQVcsS0FBSyxZQUFZO0FBQUEsRUFDckM7QUFBQSxFQUNBLG9CQUFvQjtBQUNoQixXQUFPLEtBQUssUUFBUSxDQUFBO0FBQUEsRUFDeEI7QUFBQSxFQUNBLGNBQWM7QUFDVixRQUFJLEtBQUssYUFBYSxPQUFPO0FBQ3pCLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTyxNQUFNLFlBQVc7QUFBQSxFQUM1QjtBQUFBO0FBQUEsRUFFQSxpQkFBaUI7QUFDYixVQUFNLE9BQU8sS0FBSyxhQUFZO0FBQzlCLFFBQUksQ0FBQztBQUNELGFBQU87QUFDWCxRQUFJLFlBQVk7QUFDWixhQUFPLEtBQUs7QUFDaEIsVUFBTSxTQUFTLE9BQU8sWUFBWSxLQUFLLElBQUksWUFBWTtBQUN2RCxRQUFJLENBQUMsT0FBTyxLQUFLLE1BQU0sRUFBRTtBQUNyQixhQUFPO0FBQ1gsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLGVBQWU7QUFDWCxVQUFNLE9BQU8sS0FBSyxrQkFBaUI7QUFDbkMsUUFBSSxDQUFDLEtBQUssUUFBUTtBQUNkLGFBQU87QUFBQSxJQUNYO0FBQ0EsVUFBTSxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUMsR0FBRztBQUNsQyxRQUFJLENBQUMsSUFBSTtBQUNMLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLEdBQUUsRUFBRTtBQUFBLEVBQ2xDO0FBQ0o7QUMvRE8sTUFBTSxZQUFZO0FBQUEsRUFDckIsWUFBWSxRQUFRO0FBQ2hCLFNBQUssVUFBVTtBQUFBLEVBQ25CO0FBQ0o7aUJDRE8sTUFBTSxpQkFBaUIsWUFBWTtBQUFBLEVBQ3RDLEtBQUssY0FBYyxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ3BDLFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssS0FBSyxjQUFjLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDNUM7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLHFCQUFxQixZQUFZLGFBQWEsaUNBQWlDLEVBQUUsT0FBTyxHQUFHLFFBQU8sQ0FBRTtBQUFBLEVBQ3ZJO0FBQ0o7b0JDTE8sTUFBTSxvQkFBb0IsWUFBWTtBQUFBLEVBQ3pDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLFdBQVcsSUFBSUMsV0FBcUIsS0FBSyxPQUFPO0FBQUEsRUFDekQ7QUFBQSxFQUNBLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUsscUJBQXFCLEVBQUUsTUFBTSxHQUFHLFNBQVMsUUFBUSxLQUFLLFVBQVUsTUFBSyxDQUFFO0FBQUEsRUFDcEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsU0FBUyxjQUFjLFNBQVM7QUFDNUIsV0FBTyxLQUFLLFFBQVEsSUFBSSxxQkFBcUIsWUFBWSxJQUFJLE9BQU87QUFBQSxFQUN4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjQSxPQUFPLGNBQWMsTUFBTSxTQUFTO0FBQ2hDLFdBQU8sS0FBSyxRQUFRLEtBQUsscUJBQXFCLFlBQVksSUFBSSxFQUFFLE1BQU0sR0FBRyxTQUFTO0FBQUEsRUFDdEY7QUFBQSxFQUNBLEtBQUssUUFBUSxDQUFBLEdBQUksU0FBUztBQUN0QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUM5QjtBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcscUJBQXFCLHFCQUFxQixFQUFFLE9BQU8sR0FBRyxTQUFTO0FBQUEsRUFDbEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsSUFBSSxjQUFjLFNBQVM7QUFDdkIsV0FBTyxLQUFLLFFBQVEsT0FBTyxxQkFBcUIsWUFBWSxJQUFJLE9BQU87QUFBQSxFQUMzRTtBQUNKO0FBQ08sTUFBTSw0QkFBNEIsV0FBVztBQUNwRDtBQUNPLE1BQU0sd0NBQXdDLFdBQVc7QUFDaEU7QUFDQUMsY0FBWSxzQkFBc0I7QUFDbENBLGNBQVksV0FBV0M7YUNoRWhCLE1BQU0sYUFBYSxZQUFZO0FBQUEsRUFDbEMsY0FBYztBQUNWLFVBQU0sR0FBRyxTQUFTO0FBQ2xCLFNBQUssY0FBYyxJQUFJQyxjQUEyQixLQUFLLE9BQU87QUFBQSxFQUNsRTtBQUNKO0FBQ0FDLE9BQUssY0FBY0g7QUFDbkJHLE9BQUssc0JBQXNCO0FDVHBCLE1BQU0sZUFBZSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQnBDLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUssaUJBQWlCO0FBQUEsTUFDdEM7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxRQUFRLDRCQUE0QixHQUFHLFNBQVMsUUFBTztBQUFBLE1BQ2xFLGtCQUFrQjtBQUFBLElBQzlCLENBQVM7QUFBQSxFQUNMO0FBQ0o7QUN2Qk8sTUFBTSx1QkFBdUIsWUFBWTtBQUFBLEVBQzVDLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUsseUJBQXlCQyw0QkFBaUM7QUFBQSxNQUMvRTtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsUUFBUSxLQUFLLFVBQVU7QUFBQSxNQUN2QixZQUFZLEVBQUUsT0FBTyxLQUFLLE1BQUs7QUFBQSxJQUMzQyxDQUFTLENBQUM7QUFBQSxFQUNOO0FBQ0o7QUNUTyxNQUFNLHFCQUFxQixZQUFZO0FBQUEsRUFDMUMsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxLQUFLLFFBQVEsS0FBSyx1QkFBdUJBLDRCQUFpQyxFQUFFLE1BQU0sR0FBRyxTQUFTLFlBQVksRUFBRSxPQUFPLEtBQUssTUFBSyxFQUFFLENBQUUsQ0FBQztBQUFBLEVBQzdJO0FBQ0o7QUNDTyxNQUFNLGNBQWMsWUFBWTtBQUFBLEVBQ25DLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLGlCQUFpQixJQUFJQyxlQUFpQyxLQUFLLE9BQU87QUFDdkUsU0FBSyxlQUFlLElBQUlDLGFBQTZCLEtBQUssT0FBTztBQUNqRSxTQUFLLFNBQVMsSUFBSUMsT0FBaUIsS0FBSyxPQUFPO0FBQUEsRUFDbkQ7QUFDSjtBQUNBLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sZUFBZTtBQUNyQixNQUFNLFNBQVM7QUNkUixNQUFNLGdCQUFnQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJckMsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxLQUFLLFFBQVEsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLFNBQVM7QUFBQSxFQUM3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsU0FBUyxTQUFTLFNBQVM7QUFDdkIsV0FBTyxLQUFLLFFBQVEsSUFBSSxZQUFZLE9BQU8sSUFBSSxPQUFPO0FBQUEsRUFDMUQ7QUFBQSxFQUNBLEtBQUssUUFBUSxDQUFBLEdBQUksU0FBUztBQUN0QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUM5QjtBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcsWUFBWSxhQUFhLEVBQUUsT0FBTyxHQUFHLFNBQVM7QUFBQSxFQUNqRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE9BQU8sU0FBUyxTQUFTO0FBQ3JCLFdBQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxPQUFPLFdBQVcsT0FBTztBQUFBLEVBQ2xFO0FBQ0o7QUFDTyxNQUFNLG9CQUFvQixXQUFXO0FBQzVDO0FBQ0EsUUFBUSxjQUFjO0FDbEN0QixJQUFJbkIsMkJBQWtFLFNBQVUsVUFBVSxPQUFPLE9BQU9DLE9BQU0sR0FBRztBQUM3RyxNQUFJQSxVQUFTLElBQUssT0FBTSxJQUFJLFVBQVUsZ0NBQWdDO0FBQ3RFLE1BQUlBLFVBQVMsT0FBTyxDQUFDLEVBQUcsT0FBTSxJQUFJLFVBQVUsK0NBQStDO0FBQzNGLE1BQUksT0FBTyxVQUFVLGFBQWEsYUFBYSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxRQUFRLEVBQUcsT0FBTSxJQUFJLFVBQVUseUVBQXlFO0FBQ2hMLFNBQVFBLFVBQVMsTUFBTSxFQUFFLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSSxFQUFFLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVSxLQUFLLEdBQUk7QUFDeEc7QUFDQSxJQUFJQywyQkFBa0UsU0FBVSxVQUFVLE9BQU9ELE9BQU0sR0FBRztBQUN0RyxNQUFJQSxVQUFTLE9BQU8sQ0FBQyxFQUFHLE9BQU0sSUFBSSxVQUFVLCtDQUErQztBQUMzRixNQUFJLE9BQU8sVUFBVSxhQUFhLGFBQWEsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksUUFBUSxFQUFHLE9BQU0sSUFBSSxVQUFVLDBFQUEwRTtBQUNqTCxTQUFPQSxVQUFTLE1BQU0sSUFBSUEsVUFBUyxNQUFNLEVBQUUsS0FBSyxRQUFRLElBQUksSUFBSSxFQUFFLFFBQVEsTUFBTSxJQUFJLFFBQVE7QUFDaEc7QUFDQSxJQUFJLHdCQUF3QiwrQkFBK0Isc0NBQXNDLHFDQUFxQyx5QkFBeUIsZ0NBQWdDLCtCQUErQix3QkFBd0Isb0JBQW9CLHNCQUFzQixzQkFBc0IscUNBQXFDO0FBRXBWLE1BQU0sWUFBWTtBQUFBLEVBQ3JCLGNBQWM7QUFDViwyQkFBdUIsSUFBSSxJQUFJO0FBQy9CLFNBQUssYUFBYSxJQUFJLGdCQUFlO0FBQ3JDLGtDQUE4QixJQUFJLE1BQU0sTUFBTTtBQUM5Qyx5Q0FBcUMsSUFBSSxNQUFNLE1BQU07QUFBQSxJQUFFLENBQUM7QUFDeEQsd0NBQW9DLElBQUksTUFBTSxNQUFNO0FBQUEsSUFBRSxDQUFDO0FBQ3ZELDRCQUF3QixJQUFJLE1BQU0sTUFBTTtBQUN4QyxtQ0FBK0IsSUFBSSxNQUFNLE1BQU07QUFBQSxJQUFFLENBQUM7QUFDbEQsa0NBQThCLElBQUksTUFBTSxNQUFNO0FBQUEsSUFBRSxDQUFDO0FBQ2pELDJCQUF1QixJQUFJLE1BQU0sRUFBRTtBQUNuQyx1QkFBbUIsSUFBSSxNQUFNLEtBQUs7QUFDbEMseUJBQXFCLElBQUksTUFBTSxLQUFLO0FBQ3BDLHlCQUFxQixJQUFJLE1BQU0sS0FBSztBQUNwQyx3Q0FBb0MsSUFBSSxNQUFNLEtBQUs7QUFDbkRELDZCQUF1QixNQUFNLCtCQUErQixJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDekZBLCtCQUF1QixNQUFNLHNDQUFzQyxTQUFTLEdBQUc7QUFDL0VBLCtCQUF1QixNQUFNLHFDQUFxQyxRQUFRLEdBQUc7QUFBQSxJQUNqRixDQUFDLEdBQUcsR0FBRztBQUNQQSw2QkFBdUIsTUFBTSx5QkFBeUIsSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQ25GQSwrQkFBdUIsTUFBTSxnQ0FBZ0MsU0FBUyxHQUFHO0FBQ3pFQSwrQkFBdUIsTUFBTSwrQkFBK0IsUUFBUSxHQUFHO0FBQUEsSUFDM0UsQ0FBQyxHQUFHLEdBQUc7QUFLUEUsNkJBQXVCLE1BQU0sK0JBQStCLEdBQUcsRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFFLENBQUM7QUFDaEZBLDZCQUF1QixNQUFNLHlCQUF5QixHQUFHLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBRSxDQUFDO0FBQUEsRUFDOUU7QUFBQSxFQUNBLEtBQUssVUFBVTtBQUdYLGVBQVcsTUFBTTtBQUNiLGVBQVEsRUFBRyxLQUFLLE1BQU07QUFDbEIsYUFBSyxXQUFVO0FBQ2YsYUFBSyxNQUFNLEtBQUs7QUFBQSxNQUNwQixHQUFHQSx5QkFBdUIsTUFBTSx3QkFBd0IsS0FBSyx3QkFBd0IsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLElBQ3JHLEdBQUcsQ0FBQztBQUFBLEVBQ1I7QUFBQSxFQUNBLGFBQWE7QUFDVCxRQUFJLEtBQUs7QUFDTDtBQUNKQSw2QkFBdUIsTUFBTSxzQ0FBc0MsR0FBRyxFQUFFLEtBQUssSUFBSTtBQUNqRixTQUFLLE1BQU0sU0FBUztBQUFBLEVBQ3hCO0FBQUEsRUFDQSxJQUFJLFFBQVE7QUFDUixXQUFPQSx5QkFBdUIsTUFBTSxvQkFBb0IsR0FBRztBQUFBLEVBQy9EO0FBQUEsRUFDQSxJQUFJLFVBQVU7QUFDVixXQUFPQSx5QkFBdUIsTUFBTSxzQkFBc0IsR0FBRztBQUFBLEVBQ2pFO0FBQUEsRUFDQSxJQUFJLFVBQVU7QUFDVixXQUFPQSx5QkFBdUIsTUFBTSxzQkFBc0IsR0FBRztBQUFBLEVBQ2pFO0FBQUEsRUFDQSxRQUFRO0FBQ0osU0FBSyxXQUFXLE1BQUs7QUFBQSxFQUN6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxHQUFHLE9BQU8sVUFBVTtBQUNoQixVQUFNLFlBQVlBLHlCQUF1QixNQUFNLHdCQUF3QixHQUFHLEVBQUUsS0FBSyxNQUFNQSx5QkFBdUIsTUFBTSx3QkFBd0IsR0FBRyxFQUFFLEtBQUssSUFBSSxDQUFBO0FBQzFKLGNBQVUsS0FBSyxFQUFFLFVBQVU7QUFDM0IsV0FBTztBQUFBLEVBQ1g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsSUFBSSxPQUFPLFVBQVU7QUFDakIsVUFBTSxZQUFZQSx5QkFBdUIsTUFBTSx3QkFBd0IsR0FBRyxFQUFFLEtBQUs7QUFDakYsUUFBSSxDQUFDO0FBQ0QsYUFBTztBQUNYLFVBQU0sUUFBUSxVQUFVLFVBQVUsQ0FBQyxNQUFNLEVBQUUsYUFBYSxRQUFRO0FBQ2hFLFFBQUksU0FBUztBQUNULGdCQUFVLE9BQU8sT0FBTyxDQUFDO0FBQzdCLFdBQU87QUFBQSxFQUNYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsS0FBSyxPQUFPLFVBQVU7QUFDbEIsVUFBTSxZQUFZQSx5QkFBdUIsTUFBTSx3QkFBd0IsR0FBRyxFQUFFLEtBQUssTUFBTUEseUJBQXVCLE1BQU0sd0JBQXdCLEdBQUcsRUFBRSxLQUFLLElBQUksQ0FBQTtBQUMxSixjQUFVLEtBQUssRUFBRSxVQUFVLE1BQU0sS0FBSSxDQUFFO0FBQ3ZDLFdBQU87QUFBQSxFQUNYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUEsUUFBUSxPQUFPO0FBQ1gsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDcENGLCtCQUF1QixNQUFNLHFDQUFxQyxNQUFNLEdBQUc7QUFDM0UsVUFBSSxVQUFVO0FBQ1YsYUFBSyxLQUFLLFNBQVMsTUFBTTtBQUM3QixXQUFLLEtBQUssT0FBTyxPQUFPO0FBQUEsSUFDNUIsQ0FBQztBQUFBLEVBQ0w7QUFBQSxFQUNBLE1BQU0sT0FBTztBQUNUQSw2QkFBdUIsTUFBTSxxQ0FBcUMsTUFBTSxHQUFHO0FBQzNFLFVBQU1FLHlCQUF1QixNQUFNLHlCQUF5QixHQUFHO0FBQUEsRUFDbkU7QUFBQSxFQUNBLE1BQU0sVUFBVSxNQUFNO0FBRWxCLFFBQUlBLHlCQUF1QixNQUFNLG9CQUFvQixHQUFHLEdBQUc7QUFDdkQ7QUFBQSxJQUNKO0FBQ0EsUUFBSSxVQUFVLE9BQU87QUFDakJGLCtCQUF1QixNQUFNLG9CQUFvQixNQUFNLEdBQUc7QUFDMURFLCtCQUF1QixNQUFNLGdDQUFnQyxHQUFHLEVBQUUsS0FBSyxJQUFJO0FBQUEsSUFDL0U7QUFDQSxVQUFNLFlBQVlBLHlCQUF1QixNQUFNLHdCQUF3QixHQUFHLEVBQUUsS0FBSztBQUNqRixRQUFJLFdBQVc7QUFDWEEsK0JBQXVCLE1BQU0sd0JBQXdCLEdBQUcsRUFBRSxLQUFLLElBQUksVUFBVSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSTtBQUNsRyxnQkFBVSxRQUFRLENBQUMsRUFBRSxTQUFRLE1BQU8sU0FBUyxHQUFHLElBQUksQ0FBQztBQUFBLElBQ3pEO0FBQ0EsUUFBSSxVQUFVLFNBQVM7QUFDbkIsWUFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixVQUFJLENBQUNBLHlCQUF1QixNQUFNLHFDQUFxQyxHQUFHLEtBQUssQ0FBQyxXQUFXLFFBQVE7QUFDL0YsZ0JBQVEsT0FBTyxLQUFLO0FBQUEsTUFDeEI7QUFDQUEsK0JBQXVCLE1BQU0scUNBQXFDLEdBQUcsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUN2RkEsK0JBQXVCLE1BQU0sK0JBQStCLEdBQUcsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUNqRixXQUFLLE1BQU0sS0FBSztBQUNoQjtBQUFBLElBQ0o7QUFDQSxRQUFJLFVBQVUsU0FBUztBQUVuQixZQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLFVBQUksQ0FBQ0EseUJBQXVCLE1BQU0scUNBQXFDLEdBQUcsS0FBSyxDQUFDLFdBQVcsUUFBUTtBQU8vRixnQkFBUSxPQUFPLEtBQUs7QUFBQSxNQUN4QjtBQUNBQSwrQkFBdUIsTUFBTSxxQ0FBcUMsR0FBRyxFQUFFLEtBQUssTUFBTSxLQUFLO0FBQ3ZGQSwrQkFBdUIsTUFBTSwrQkFBK0IsR0FBRyxFQUFFLEtBQUssTUFBTSxLQUFLO0FBQ2pGLFdBQUssTUFBTSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBQUEsRUFDQSxhQUFhO0FBQUEsRUFBRTtBQUNuQjtBQUNBLGdDQUFnQyxvQkFBSSxRQUFPLEdBQUksdUNBQXVDLG9CQUFJLFFBQU8sR0FBSSxzQ0FBc0Msb0JBQUksV0FBVywwQkFBMEIsb0JBQUksUUFBTyxHQUFJLGlDQUFpQyxvQkFBSSxRQUFPLEdBQUksZ0NBQWdDLG9CQUFJLFFBQU8sR0FBSSx5QkFBeUIsb0JBQUksUUFBTyxHQUFJLHFCQUFxQixvQkFBSSxXQUFXLHVCQUF1QixvQkFBSSxRQUFPLEdBQUksdUJBQXVCLG9CQUFJLFFBQU8sR0FBSSxzQ0FBc0Msb0JBQUksUUFBTyxHQUFJLHlCQUF5QixvQkFBSSxRQUFPLEdBQUksMkJBQTJCLFNBQVNrQiwwQkFBeUIsT0FBTztBQUN2bEJwQiwyQkFBdUIsTUFBTSxzQkFBc0IsTUFBTSxHQUFHO0FBQzVELE1BQUksaUJBQWlCLFNBQVMsTUFBTSxTQUFTLGNBQWM7QUFDdkQsWUFBUSxJQUFJLGtCQUFpQjtBQUFBLEVBQ2pDO0FBQ0EsTUFBSSxpQkFBaUIsbUJBQW1CO0FBQ3BDQSw2QkFBdUIsTUFBTSxzQkFBc0IsTUFBTSxHQUFHO0FBQzVELFdBQU8sS0FBSyxNQUFNLFNBQVMsS0FBSztBQUFBLEVBQ3BDO0FBQ0EsTUFBSSxpQkFBaUIsYUFBYTtBQUM5QixXQUFPLEtBQUssTUFBTSxTQUFTLEtBQUs7QUFBQSxFQUNwQztBQUNBLE1BQUksaUJBQWlCLE9BQU87QUFDeEIsVUFBTSxjQUFjLElBQUksWUFBWSxNQUFNLE9BQU87QUFFakQsZ0JBQVksUUFBUTtBQUNwQixXQUFPLEtBQUssTUFBTSxTQUFTLFdBQVc7QUFBQSxFQUMxQztBQUNBLFNBQU8sS0FBSyxNQUFNLFNBQVMsSUFBSSxZQUFZLE9BQU8sS0FBSyxDQUFDLENBQUM7QUFDN0Q7QUNsTUEsSUFBSUUsMkJBQWtFLFNBQVUsVUFBVSxPQUFPRCxPQUFNLEdBQUc7QUFDdEcsTUFBSUEsVUFBUyxPQUFPLENBQUMsRUFBRyxPQUFNLElBQUksVUFBVSwrQ0FBK0M7QUFDM0YsTUFBSSxPQUFPLFVBQVUsYUFBYSxhQUFhLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRyxPQUFNLElBQUksVUFBVSwwRUFBMEU7QUFDakwsU0FBT0EsVUFBUyxNQUFNLElBQUlBLFVBQVMsTUFBTSxFQUFFLEtBQUssUUFBUSxJQUFJLElBQUksRUFBRSxRQUFRLE1BQU0sSUFBSSxRQUFRO0FBQ2hHO0FBQ0EsSUFBSUQsMkJBQWtFLFNBQVUsVUFBVSxPQUFPLE9BQU9DLE9BQU0sR0FBRztBQUM3RyxNQUFJQSxVQUFTLElBQUssT0FBTSxJQUFJLFVBQVUsZ0NBQWdDO0FBQ3RFLE1BQUlBLFVBQVMsT0FBTyxDQUFDLEVBQUcsT0FBTSxJQUFJLFVBQVUsK0NBQStDO0FBQzNGLE1BQUksT0FBTyxVQUFVLGFBQWEsYUFBYSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxRQUFRLEVBQUcsT0FBTSxJQUFJLFVBQVUseUVBQXlFO0FBQ2hMLFNBQVFBLFVBQVMsTUFBTSxFQUFFLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSSxFQUFFLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVSxLQUFLLEdBQUk7QUFDeEc7QUFDQSxJQUFJLDRCQUE0Qix5QkFBeUIsbUNBQW1DLG1DQUFtQyxrQ0FBa0MsMkJBQTJCLHNDQUFzQyxpQ0FBaUMsdUNBQXVDLGtDQUFrQywrQkFBK0IscUNBQXFDLHlDQUF5QywyQkFBMkIsNkJBQTZCLGdDQUFnQyxnQ0FBZ0MsOEJBQThCLG9DQUFvQyxvQ0FBb0Msb0NBQW9DO0FBS3ByQixNQUFNLHdCQUF3QixZQUFZO0FBQUEsRUFDN0MsY0FBYztBQUNWLFVBQU0sR0FBRyxTQUFTO0FBQ2xCLCtCQUEyQixJQUFJLElBQUk7QUFFbkMsNEJBQXdCLElBQUksTUFBTSxFQUFFO0FBR3BDLHNDQUFrQyxJQUFJLE1BQU0sRUFBRTtBQUM5QyxzQ0FBa0MsSUFBSSxNQUFNLEVBQUU7QUFDOUMscUNBQWlDLElBQUksTUFBTSxNQUFNO0FBQ2pELDhCQUEwQixJQUFJLE1BQU0sTUFBTTtBQUMxQyx5Q0FBcUMsSUFBSSxNQUFNLE1BQU07QUFDckQsb0NBQWdDLElBQUksTUFBTSxNQUFNO0FBQ2hELDBDQUFzQyxJQUFJLE1BQU0sTUFBTTtBQUN0RCxxQ0FBaUMsSUFBSSxNQUFNLE1BQU07QUFFakQsa0NBQThCLElBQUksTUFBTSxNQUFNO0FBQzlDLHdDQUFvQyxJQUFJLE1BQU0sTUFBTTtBQUNwRCw0Q0FBd0MsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUM1RDtBQUFBLEVBQ0EsRUFBRSwwQkFBMEIsb0JBQUksV0FBVyxvQ0FBb0Msb0JBQUksUUFBTyxHQUFJLG9DQUFvQyxvQkFBSSxRQUFPLEdBQUksbUNBQW1DLG9CQUFJLFFBQU8sR0FBSSw0QkFBNEIsb0JBQUksUUFBTyxHQUFJLHVDQUF1QyxvQkFBSSxXQUFXLGtDQUFrQyxvQkFBSSxRQUFPLEdBQUksd0NBQXdDLG9CQUFJLFFBQU8sR0FBSSxtQ0FBbUMsb0JBQUksUUFBTyxHQUFJLGdDQUFnQyxvQkFBSSxRQUFPLEdBQUksc0NBQXNDLG9CQUFJLFdBQVcsMENBQTBDLG9CQUFJLFdBQVcsNkJBQTZCLG9CQUFJLFFBQU8sR0FBSSxPQUFPLGtCQUFrQjtBQUM1cEIsVUFBTSxZQUFZLENBQUE7QUFDbEIsVUFBTSxZQUFZLENBQUE7QUFDbEIsUUFBSSxPQUFPO0FBRVgsU0FBSyxHQUFHLFNBQVMsQ0FBQyxVQUFVO0FBQ3hCLFlBQU0sU0FBUyxVQUFVLE1BQUs7QUFDOUIsVUFBSSxRQUFRO0FBQ1IsZUFBTyxRQUFRLEtBQUs7QUFBQSxNQUN4QixPQUNLO0FBQ0Qsa0JBQVUsS0FBSyxLQUFLO0FBQUEsTUFDeEI7QUFBQSxJQUNKLENBQUM7QUFDRCxTQUFLLEdBQUcsT0FBTyxNQUFNO0FBQ2pCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDNUIsZUFBTyxRQUFRLE1BQVM7QUFBQSxNQUM1QjtBQUNBLGdCQUFVLFNBQVM7QUFBQSxJQUN2QixDQUFDO0FBQ0QsU0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFRO0FBQ3RCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDNUIsZUFBTyxPQUFPLEdBQUc7QUFBQSxNQUNyQjtBQUNBLGdCQUFVLFNBQVM7QUFBQSxJQUN2QixDQUFDO0FBQ0QsU0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFRO0FBQ3RCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDNUIsZUFBTyxPQUFPLEdBQUc7QUFBQSxNQUNyQjtBQUNBLGdCQUFVLFNBQVM7QUFBQSxJQUN2QixDQUFDO0FBQ0QsV0FBTztBQUFBLE1BQ0gsTUFBTSxZQUFZO0FBQ2QsWUFBSSxDQUFDLFVBQVUsUUFBUTtBQUNuQixjQUFJLE1BQU07QUFDTixtQkFBTyxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUk7QUFBQSxVQUN6QztBQUNBLGlCQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVyxVQUFVLEtBQUssRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFLEtBQUssQ0FBQ29CLFdBQVdBLFNBQVEsRUFBRSxPQUFPQSxRQUFPLE1BQU0sTUFBSyxJQUFLLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSSxDQUFHO0FBQUEsUUFDM0s7QUFDQSxjQUFNLFFBQVEsVUFBVSxNQUFLO0FBQzdCLGVBQU8sRUFBRSxPQUFPLE9BQU8sTUFBTSxNQUFLO0FBQUEsTUFDdEM7QUFBQSxNQUNBLFFBQVEsWUFBWTtBQUNoQixhQUFLLE1BQUs7QUFDVixlQUFPLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSTtBQUFBLE1BQ3pDO0FBQUEsSUFDWjtBQUFBLEVBQ0k7QUFBQSxFQUNBLE9BQU8sbUJBQW1CLFFBQVE7QUFDOUIsVUFBTSxTQUFTLElBQUksZ0JBQWU7QUFDbEMsV0FBTyxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsTUFBTSxDQUFDO0FBQ3BELFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxNQUFNLG9CQUFvQixnQkFBZ0IsU0FBUztBQUMvQyxVQUFNLFNBQVMsU0FBUztBQUN4QixRQUFJLFFBQVE7QUFDUixVQUFJLE9BQU87QUFDUCxhQUFLLFdBQVcsTUFBSztBQUN6QixhQUFPLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxXQUFXLE9BQU87QUFBQSxJQUNsRTtBQUNBLFNBQUssV0FBVTtBQUNmLFVBQU0sU0FBUyxPQUFPLG1CQUFtQixnQkFBZ0IsS0FBSyxVQUFVO0FBQ3hFLHFCQUFpQixTQUFTLFFBQVE7QUFDOUJuQiwrQkFBdUIsTUFBTSw0QkFBNEIsS0FBSyx5QkFBeUIsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUFBLElBQzdHO0FBQ0EsUUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTO0FBQ25DLFlBQU0sSUFBSSxrQkFBaUI7QUFBQSxJQUMvQjtBQUNBLFdBQU8sS0FBSyxRQUFRQSx5QkFBdUIsTUFBTSw0QkFBNEIsS0FBSywyQkFBMkIsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLEVBQzdIO0FBQUEsRUFDQSxtQkFBbUI7QUFDZixVQUFNLFNBQVMsSUFBSSxPQUFPLEtBQUssT0FBTyxhQUFhLEVBQUUsS0FBSyxJQUFJLEdBQUcsS0FBSyxVQUFVO0FBQ2hGLFdBQU8sT0FBTyxpQkFBZ0I7QUFBQSxFQUNsQztBQUFBLEVBQ0EsT0FBTywwQkFBMEIsVUFBVSxPQUFPLE1BQU0sUUFBUSxTQUFTO0FBQ3JFLFVBQU0sU0FBUyxJQUFJLGdCQUFlO0FBQ2xDLFdBQU8sS0FBSyxNQUFNLE9BQU8sd0JBQXdCLFVBQVUsT0FBTyxNQUFNLFFBQVE7QUFBQSxNQUM1RSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsNkJBQTZCLFNBQVE7QUFBQSxJQUNqRixDQUFTLENBQUM7QUFDRixXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsTUFBTSwyQkFBMkIsS0FBSyxVQUFVLE9BQU8sUUFBUSxTQUFTO0FBQ3BFLFVBQU0sU0FBUyxTQUFTO0FBQ3hCLFFBQUksUUFBUTtBQUNSLFVBQUksT0FBTztBQUNQLGFBQUssV0FBVyxNQUFLO0FBQ3pCLGFBQU8saUJBQWlCLFNBQVMsTUFBTSxLQUFLLFdBQVcsT0FBTztBQUFBLElBQ2xFO0FBQ0EsVUFBTSxPQUFPLEVBQUUsR0FBRyxRQUFRLFFBQVEsS0FBSTtBQUN0QyxVQUFNLFNBQVMsTUFBTSxJQUFJLGtCQUFrQixVQUFVLE9BQU8sTUFBTTtBQUFBLE1BQzlELEdBQUc7QUFBQSxNQUNILFFBQVEsS0FBSyxXQUFXO0FBQUEsSUFDcEMsQ0FBUztBQUNELFNBQUssV0FBVTtBQUNmLHFCQUFpQixTQUFTLFFBQVE7QUFDOUJBLCtCQUF1QixNQUFNLDRCQUE0QixLQUFLLHlCQUF5QixFQUFFLEtBQUssTUFBTSxLQUFLO0FBQUEsSUFDN0c7QUFDQSxRQUFJLE9BQU8sV0FBVyxRQUFRLFNBQVM7QUFDbkMsWUFBTSxJQUFJLGtCQUFpQjtBQUFBLElBQy9CO0FBQ0EsV0FBTyxLQUFLLFFBQVFBLHlCQUF1QixNQUFNLDRCQUE0QixLQUFLLDJCQUEyQixFQUFFLEtBQUssSUFBSSxDQUFDO0FBQUEsRUFDN0g7QUFBQSxFQUNBLE9BQU8sNEJBQTRCLFFBQVEsUUFBUSxTQUFTO0FBQ3hELFVBQU0sU0FBUyxJQUFJLGdCQUFlO0FBQ2xDLFdBQU8sS0FBSyxNQUFNLE9BQU8sdUJBQXVCLFFBQVEsUUFBUTtBQUFBLE1BQzVELEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxHQUFHLFNBQVMsU0FBUyw2QkFBNkIsU0FBUTtBQUFBLElBQ2pGLENBQVMsQ0FBQztBQUNGLFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxPQUFPLHNCQUFzQixVQUFVLE1BQU0sUUFBUSxTQUFTO0FBQzFELFVBQU0sU0FBUyxJQUFJLGdCQUFlO0FBQ2xDLFdBQU8sS0FBSyxNQUFNLE9BQU8sb0JBQW9CLFVBQVUsTUFBTSxRQUFRO0FBQUEsTUFDakUsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLEdBQUcsU0FBUyxTQUFTLDZCQUE2QixTQUFRO0FBQUEsSUFDakYsQ0FBUyxDQUFDO0FBQ0YsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLGVBQWU7QUFDWCxXQUFPQSx5QkFBdUIsTUFBTSwrQkFBK0IsR0FBRztBQUFBLEVBQzFFO0FBQUEsRUFDQSxhQUFhO0FBQ1QsV0FBT0EseUJBQXVCLE1BQU0scUNBQXFDLEdBQUc7QUFBQSxFQUNoRjtBQUFBLEVBQ0EseUJBQXlCO0FBQ3JCLFdBQU9BLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHO0FBQUEsRUFDN0U7QUFBQSxFQUNBLHlCQUF5QjtBQUNyQixXQUFPQSx5QkFBdUIsTUFBTSx5Q0FBeUMsR0FBRztBQUFBLEVBQ3BGO0FBQUEsRUFDQSxNQUFNLGdCQUFnQjtBQUNsQixVQUFNLEtBQUssS0FBSTtBQUNmLFdBQU8sT0FBTyxPQUFPQSx5QkFBdUIsTUFBTSxtQ0FBbUMsR0FBRyxDQUFDO0FBQUEsRUFDN0Y7QUFBQSxFQUNBLE1BQU0sZ0JBQWdCO0FBQ2xCLFVBQU0sS0FBSyxLQUFJO0FBQ2YsV0FBTyxPQUFPLE9BQU9BLHlCQUF1QixNQUFNLG1DQUFtQyxHQUFHLENBQUM7QUFBQSxFQUM3RjtBQUFBLEVBQ0EsTUFBTSxXQUFXO0FBQ2IsVUFBTSxLQUFLLEtBQUk7QUFDZixRQUFJLENBQUNBLHlCQUF1QixNQUFNLDJCQUEyQixHQUFHO0FBQzVELFlBQU0sTUFBTSw2QkFBNkI7QUFDN0MsV0FBT0EseUJBQXVCLE1BQU0sMkJBQTJCLEdBQUc7QUFBQSxFQUN0RTtBQUFBLEVBQ0EsTUFBTSw2QkFBNkIsUUFBUSxRQUFRLFNBQVM7QUFDeEQsVUFBTSxTQUFTLFNBQVM7QUFDeEIsUUFBSSxRQUFRO0FBQ1IsVUFBSSxPQUFPO0FBQ1AsYUFBSyxXQUFXLE1BQUs7QUFDekIsYUFBTyxpQkFBaUIsU0FBUyxNQUFNLEtBQUssV0FBVyxPQUFPO0FBQUEsSUFDbEU7QUFDQSxVQUFNLE9BQU8sRUFBRSxHQUFHLFFBQVEsUUFBUSxLQUFJO0FBQ3RDLFVBQU0sU0FBUyxNQUFNLE9BQU8sYUFBYSxNQUFNLEVBQUUsR0FBRyxTQUFTLFFBQVEsS0FBSyxXQUFXLE9BQU0sQ0FBRTtBQUM3RixTQUFLLFdBQVU7QUFDZixxQkFBaUIsU0FBUyxRQUFRO0FBQzlCQSwrQkFBdUIsTUFBTSw0QkFBNEIsS0FBSyx5QkFBeUIsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUFBLElBQzdHO0FBQ0EsUUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTO0FBQ25DLFlBQU0sSUFBSSxrQkFBaUI7QUFBQSxJQUMvQjtBQUNBLFdBQU8sS0FBSyxRQUFRQSx5QkFBdUIsTUFBTSw0QkFBNEIsS0FBSywyQkFBMkIsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLEVBQzdIO0FBQUEsRUFDQSxNQUFNLHVCQUF1QixLQUFLLFVBQVUsUUFBUSxTQUFTO0FBQ3pELFVBQU0sU0FBUyxTQUFTO0FBQ3hCLFFBQUksUUFBUTtBQUNSLFVBQUksT0FBTztBQUNQLGFBQUssV0FBVyxNQUFLO0FBQ3pCLGFBQU8saUJBQWlCLFNBQVMsTUFBTSxLQUFLLFdBQVcsT0FBTztBQUFBLElBQ2xFO0FBQ0EsVUFBTSxPQUFPLEVBQUUsR0FBRyxRQUFRLFFBQVEsS0FBSTtBQUN0QyxVQUFNLFNBQVMsTUFBTSxJQUFJLE9BQU8sVUFBVSxNQUFNLEVBQUUsR0FBRyxTQUFTLFFBQVEsS0FBSyxXQUFXLE9BQU0sQ0FBRTtBQUM5RixTQUFLLFdBQVU7QUFDZixxQkFBaUIsU0FBUyxRQUFRO0FBQzlCQSwrQkFBdUIsTUFBTSw0QkFBNEIsS0FBSyx5QkFBeUIsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUFBLElBQzdHO0FBQ0EsUUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTO0FBQ25DLFlBQU0sSUFBSSxrQkFBaUI7QUFBQSxJQUMvQjtBQUNBLFdBQU8sS0FBSyxRQUFRQSx5QkFBdUIsTUFBTSw0QkFBNEIsS0FBSywyQkFBMkIsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLEVBQzdIO0FBQUEsRUFDQSxPQUFPLGdCQUFnQixLQUFLLE9BQU87QUFDL0IsZUFBVyxDQUFDLEtBQUssVUFBVSxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDbkQsVUFBSSxDQUFDLElBQUksZUFBZSxHQUFHLEdBQUc7QUFDMUIsWUFBSSxHQUFHLElBQUk7QUFDWDtBQUFBLE1BQ0o7QUFDQSxVQUFJLFdBQVcsSUFBSSxHQUFHO0FBQ3RCLFVBQUksYUFBYSxRQUFRLGFBQWEsUUFBVztBQUM3QyxZQUFJLEdBQUcsSUFBSTtBQUNYO0FBQUEsTUFDSjtBQUVBLFVBQUksUUFBUSxXQUFXLFFBQVEsUUFBUTtBQUNuQyxZQUFJLEdBQUcsSUFBSTtBQUNYO0FBQUEsTUFDSjtBQUVBLFVBQUksT0FBTyxhQUFhLFlBQVksT0FBTyxlQUFlLFVBQVU7QUFDaEUsb0JBQVk7QUFBQSxNQUNoQixXQUNTLE9BQU8sYUFBYSxZQUFZLE9BQU8sZUFBZSxVQUFVO0FBQ3JFLG9CQUFZO0FBQUEsTUFDaEIsV0FDU29CLE1BQVcsUUFBUSxLQUFLQSxNQUFXLFVBQVUsR0FBRztBQUNyRCxtQkFBVyxLQUFLLGdCQUFnQixVQUFVLFVBQVU7QUFBQSxNQUN4RCxXQUNTLE1BQU0sUUFBUSxRQUFRLEtBQUssTUFBTSxRQUFRLFVBQVUsR0FBRztBQUMzRCxZQUFJLFNBQVMsTUFBTSxDQUFDLE1BQU0sT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFFBQVEsR0FBRztBQUN2RSxtQkFBUyxLQUFLLEdBQUcsVUFBVTtBQUMzQjtBQUFBLFFBQ0o7QUFDQSxtQkFBVyxjQUFjLFlBQVk7QUFDakMsY0FBSSxDQUFDQSxNQUFXLFVBQVUsR0FBRztBQUN6QixrQkFBTSxJQUFJLE1BQU0sdURBQXVELFVBQVUsRUFBRTtBQUFBLFVBQ3ZGO0FBQ0EsZ0JBQU0sUUFBUSxXQUFXLE9BQU87QUFDaEMsY0FBSSxTQUFTLE1BQU07QUFDZixvQkFBUSxNQUFNLFVBQVU7QUFDeEIsa0JBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUFBLFVBQzVFO0FBQ0EsY0FBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixrQkFBTSxJQUFJLE1BQU0sd0VBQXdFLEtBQUssRUFBRTtBQUFBLFVBQ25HO0FBQ0EsZ0JBQU0sV0FBVyxTQUFTLEtBQUs7QUFDL0IsY0FBSSxZQUFZLE1BQU07QUFDbEIscUJBQVMsS0FBSyxVQUFVO0FBQUEsVUFDNUIsT0FDSztBQUNELHFCQUFTLEtBQUssSUFBSSxLQUFLLGdCQUFnQixVQUFVLFVBQVU7QUFBQSxVQUMvRDtBQUFBLFFBQ0o7QUFDQTtBQUFBLE1BQ0osT0FDSztBQUNELGNBQU0sTUFBTSwwQkFBMEIsR0FBRyxpQkFBaUIsVUFBVSxlQUFlLFFBQVEsRUFBRTtBQUFBLE1BQ2pHO0FBQ0EsVUFBSSxHQUFHLElBQUk7QUFBQSxJQUNmO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLFFBQVEsS0FBSztBQUNULFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxNQUFNLHVCQUF1QixRQUFRLFFBQVEsU0FBUztBQUNsRCxXQUFPLE1BQU0sS0FBSyw2QkFBNkIsUUFBUSxRQUFRLE9BQU87QUFBQSxFQUMxRTtBQUFBLEVBQ0EsTUFBTSxvQkFBb0IsVUFBVSxNQUFNLFFBQVEsU0FBUztBQUN2RCxXQUFPLE1BQU0sS0FBSyx1QkFBdUIsTUFBTSxVQUFVLFFBQVEsT0FBTztBQUFBLEVBQzVFO0FBQUEsRUFDQSxNQUFNLHdCQUF3QixVQUFVLE9BQU8sTUFBTSxRQUFRLFNBQVM7QUFDbEUsV0FBTyxNQUFNLEtBQUssMkJBQTJCLE1BQU0sVUFBVSxPQUFPLFFBQVEsT0FBTztBQUFBLEVBQ3ZGO0FBQ0o7QUFDQSw0QkFBNEIsU0FBU0MsMkJBQTBCLE9BQU87QUFDbEUsTUFBSSxLQUFLO0FBQ0w7QUFDSnZCLDJCQUF1QixNQUFNLCtCQUErQixPQUFPLEdBQUc7QUFDdEVFLDJCQUF1QixNQUFNLDRCQUE0QixLQUFLLDRCQUE0QixFQUFFLEtBQUssTUFBTSxLQUFLO0FBQzVHLFVBQVEsTUFBTSxPQUFLO0FBQUEsSUFDZixLQUFLO0FBRUQ7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDREEsK0JBQXVCLE1BQU0sNEJBQTRCLEtBQUssMEJBQTBCLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDMUc7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDREEsK0JBQXVCLE1BQU0sNEJBQTRCLEtBQUssOEJBQThCLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDOUc7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDREEsK0JBQXVCLE1BQU0sNEJBQTRCLEtBQUssOEJBQThCLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDOUc7QUFBQSxJQUNKLEtBQUs7QUFFRCxZQUFNLElBQUksTUFBTSxxRkFBcUY7QUFBQSxFQUdqSDtBQUNBLEdBQUcsOEJBQThCLFNBQVNzQiwrQkFBOEI7QUFDcEUsTUFBSSxLQUFLLE9BQU87QUFDWixVQUFNLElBQUksWUFBWSx5Q0FBeUM7QUFBQSxFQUNuRTtBQUNBLE1BQUksQ0FBQ3RCLHlCQUF1QixNQUFNLDJCQUEyQixHQUFHO0FBQzVELFVBQU0sTUFBTSxpQ0FBaUM7QUFDakQsU0FBT0EseUJBQXVCLE1BQU0sMkJBQTJCLEdBQUc7QUFDdEUsR0FBRyxpQ0FBaUMsU0FBU3VCLGdDQUErQixPQUFPO0FBQy9FLFFBQU0sQ0FBQyxvQkFBb0IsVUFBVSxJQUFJdkIseUJBQXVCLE1BQU0sNEJBQTRCLEtBQUssa0NBQWtDLEVBQUUsS0FBSyxNQUFNLE9BQU9BLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLENBQUM7QUFDaE9GLDJCQUF1QixNQUFNLGtDQUFrQyxvQkFBb0IsR0FBRztBQUN0RkUsMkJBQXVCLE1BQU0sbUNBQW1DLEdBQUcsRUFBRSxtQkFBbUIsRUFBRSxJQUFJO0FBQzlGLGFBQVcsV0FBVyxZQUFZO0FBQzlCLFVBQU0sa0JBQWtCLG1CQUFtQixRQUFRLFFBQVEsS0FBSztBQUNoRSxRQUFJLGlCQUFpQixRQUFRLFFBQVE7QUFDakMsV0FBSyxNQUFNLGVBQWUsZ0JBQWdCLElBQUk7QUFBQSxJQUNsRDtBQUFBLEVBQ0o7QUFDQSxVQUFRLE1BQU0sT0FBSztBQUFBLElBQ2YsS0FBSztBQUNELFdBQUssTUFBTSxrQkFBa0IsTUFBTSxJQUFJO0FBQ3ZDO0FBQUEsSUFDSixLQUFLO0FBQ0Q7QUFBQSxJQUNKLEtBQUs7QUFDRCxXQUFLLE1BQU0sZ0JBQWdCLE1BQU0sS0FBSyxPQUFPLGtCQUFrQjtBQUMvRCxVQUFJLE1BQU0sS0FBSyxNQUFNLFNBQVM7QUFDMUIsbUJBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxTQUFTO0FBRTVDLGNBQUksUUFBUSxRQUFRLFVBQVUsUUFBUSxNQUFNO0FBQ3hDLGdCQUFJLFlBQVksUUFBUTtBQUN4QixnQkFBSSxXQUFXLG1CQUFtQixRQUFRLFFBQVEsS0FBSztBQUN2RCxnQkFBSSxZQUFZLFNBQVMsUUFBUSxRQUFRO0FBQ3JDLG1CQUFLLE1BQU0sYUFBYSxXQUFXLFNBQVMsSUFBSTtBQUFBLFlBQ3BELE9BQ0s7QUFDRCxvQkFBTSxNQUFNLHFFQUFxRTtBQUFBLFlBQ3JGO0FBQUEsVUFDSjtBQUNBLGNBQUksUUFBUSxTQUFTQSx5QkFBdUIsTUFBTSxzQ0FBc0MsR0FBRyxHQUFHO0FBRTFGLGdCQUFJQSx5QkFBdUIsTUFBTSxpQ0FBaUMsR0FBRyxHQUFHO0FBQ3BFLHNCQUFRQSx5QkFBdUIsTUFBTSxpQ0FBaUMsR0FBRyxFQUFFLE1BQUk7QUFBQSxnQkFDM0UsS0FBSztBQUNELHVCQUFLLE1BQU0sWUFBWUEseUJBQXVCLE1BQU0saUNBQWlDLEdBQUcsRUFBRSxNQUFNQSx5QkFBdUIsTUFBTSxrQ0FBa0MsR0FBRyxDQUFDO0FBQ25LO0FBQUEsZ0JBQ0osS0FBSztBQUNELHVCQUFLLE1BQU0saUJBQWlCQSx5QkFBdUIsTUFBTSxpQ0FBaUMsR0FBRyxFQUFFLFlBQVlBLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLENBQUM7QUFDOUs7QUFBQSxjQUNwQztBQUFBLFlBQ3dCO0FBQ0FGLHFDQUF1QixNQUFNLHNDQUFzQyxRQUFRLE9BQU8sR0FBRztBQUFBLFVBQ3pGO0FBQ0FBLG1DQUF1QixNQUFNLGlDQUFpQyxtQkFBbUIsUUFBUSxRQUFRLEtBQUssR0FBRyxHQUFHO0FBQUEsUUFDaEg7QUFBQSxNQUNKO0FBQ0E7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFFRCxVQUFJRSx5QkFBdUIsTUFBTSxzQ0FBc0MsR0FBRyxNQUFNLFFBQVc7QUFDdkYsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLFFBQVFBLHlCQUF1QixNQUFNLHNDQUFzQyxHQUFHLENBQUM7QUFDakgsWUFBSSxnQkFBZ0I7QUFDaEIsa0JBQVEsZUFBZSxNQUFJO0FBQUEsWUFDdkIsS0FBSztBQUNELG1CQUFLLE1BQU0saUJBQWlCLGVBQWUsWUFBWUEseUJBQXVCLE1BQU0sa0NBQWtDLEdBQUcsQ0FBQztBQUMxSDtBQUFBLFlBQ0osS0FBSztBQUNELG1CQUFLLE1BQU0sWUFBWSxlQUFlLE1BQU1BLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLENBQUM7QUFDL0c7QUFBQSxVQUM1QjtBQUFBLFFBQ2dCO0FBQUEsTUFDSjtBQUNBLFVBQUlBLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLEdBQUc7QUFDckUsYUFBSyxNQUFNLGVBQWUsTUFBTSxJQUFJO0FBQUEsTUFDeEM7QUFDQUYsK0JBQXVCLE1BQU0sa0NBQWtDLFFBQVcsR0FBRztBQUFBLEVBQ3pGO0FBQ0EsR0FBRyxpQ0FBaUMsU0FBUzBCLGdDQUErQixPQUFPO0FBQy9FLFFBQU0scUJBQXFCeEIseUJBQXVCLE1BQU0sNEJBQTRCLEtBQUssa0NBQWtDLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDN0lGLDJCQUF1QixNQUFNLHlDQUF5QyxvQkFBb0IsR0FBRztBQUM3RixVQUFRLE1BQU0sT0FBSztBQUFBLElBQ2YsS0FBSztBQUNELFdBQUssTUFBTSxrQkFBa0IsTUFBTSxJQUFJO0FBQ3ZDO0FBQUEsSUFDSixLQUFLO0FBQ0QsWUFBTSxRQUFRLE1BQU0sS0FBSztBQUN6QixVQUFJLE1BQU0sZ0JBQ04sTUFBTSxhQUFhLFFBQVEsZ0JBQzNCLE1BQU0sYUFBYSxjQUNuQixtQkFBbUIsYUFBYSxRQUFRLGNBQWM7QUFDdEQsbUJBQVcsWUFBWSxNQUFNLGFBQWEsWUFBWTtBQUNsRCxjQUFJLFNBQVMsU0FBU0UseUJBQXVCLE1BQU0sdUNBQXVDLEdBQUcsR0FBRztBQUM1RixpQkFBSyxNQUFNLGlCQUFpQixVQUFVLG1CQUFtQixhQUFhLFdBQVcsU0FBUyxLQUFLLENBQUM7QUFBQSxVQUNwRyxPQUNLO0FBQ0QsZ0JBQUlBLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLEdBQUc7QUFDckUsbUJBQUssTUFBTSxnQkFBZ0JBLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLENBQUM7QUFBQSxZQUNsRztBQUNBRixxQ0FBdUIsTUFBTSx1Q0FBdUMsU0FBUyxPQUFPLEdBQUc7QUFDdkZBLHFDQUF1QixNQUFNLGtDQUFrQyxtQkFBbUIsYUFBYSxXQUFXLFNBQVMsS0FBSyxHQUFHLEdBQUc7QUFDOUgsZ0JBQUlFLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHO0FBQ2xFLG1CQUFLLE1BQU0sbUJBQW1CQSx5QkFBdUIsTUFBTSxrQ0FBa0MsR0FBRyxDQUFDO0FBQUEsVUFDekc7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUNBLFdBQUssTUFBTSxnQkFBZ0IsTUFBTSxLQUFLLE9BQU8sa0JBQWtCO0FBQy9EO0FBQUEsSUFDSixLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0RGLCtCQUF1QixNQUFNLHlDQUF5QyxRQUFXLEdBQUc7QUFDcEYsWUFBTSxVQUFVLE1BQU0sS0FBSztBQUMzQixVQUFJLFFBQVEsUUFBUSxjQUFjO0FBQzlCLFlBQUlFLHlCQUF1QixNQUFNLGtDQUFrQyxHQUFHLEdBQUc7QUFDckUsZUFBSyxNQUFNLGdCQUFnQkEseUJBQXVCLE1BQU0sa0NBQWtDLEdBQUcsQ0FBQztBQUM5RkYsbUNBQXVCLE1BQU0sa0NBQWtDLFFBQVcsR0FBRztBQUFBLFFBQ2pGO0FBQUEsTUFDSjtBQUNBLFdBQUssTUFBTSxlQUFlLE1BQU0sTUFBTSxrQkFBa0I7QUFDeEQ7QUFBQSxFQUdaO0FBQ0EsR0FBRywrQkFBK0IsU0FBUzJCLDhCQUE2QixPQUFPO0FBQzNFekIsMkJBQXVCLE1BQU0seUJBQXlCLEdBQUcsRUFBRSxLQUFLLEtBQUs7QUFDckUsT0FBSyxNQUFNLFNBQVMsS0FBSztBQUM3QixHQUFHLHFDQUFxQyxTQUFTMEIsb0NBQW1DLE9BQU87QUFDdkYsVUFBUSxNQUFNLE9BQUs7QUFBQSxJQUNmLEtBQUs7QUFDRDFCLCtCQUF1QixNQUFNLG1DQUFtQyxHQUFHLEVBQUUsTUFBTSxLQUFLLEVBQUUsSUFBSSxNQUFNO0FBQzVGLGFBQU8sTUFBTTtBQUFBLElBQ2pCLEtBQUs7QUFDRCxVQUFJLFdBQVdBLHlCQUF1QixNQUFNLG1DQUFtQyxHQUFHLEVBQUUsTUFBTSxLQUFLLEVBQUU7QUFDakcsVUFBSSxDQUFDLFVBQVU7QUFDWCxjQUFNLE1BQU0sdURBQXVEO0FBQUEsTUFDdkU7QUFDQSxVQUFJLE9BQU8sTUFBTTtBQUNqQixVQUFJLEtBQUssT0FBTztBQUNaLGNBQU0sY0FBYyxnQkFBZ0IsZ0JBQWdCLFVBQVUsS0FBSyxLQUFLO0FBQ3hFQSxpQ0FBdUIsTUFBTSxtQ0FBbUMsR0FBRyxFQUFFLE1BQU0sS0FBSyxFQUFFLElBQUk7QUFBQSxNQUMxRjtBQUNBLGFBQU9BLHlCQUF1QixNQUFNLG1DQUFtQyxHQUFHLEVBQUUsTUFBTSxLQUFLLEVBQUU7QUFBQSxJQUM3RixLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0RBLCtCQUF1QixNQUFNLG1DQUFtQyxHQUFHLEVBQUUsTUFBTSxLQUFLLEVBQUUsSUFBSSxNQUFNO0FBQzVGO0FBQUEsRUFDWjtBQUNJLE1BQUlBLHlCQUF1QixNQUFNLG1DQUFtQyxHQUFHLEVBQUUsTUFBTSxLQUFLLEVBQUU7QUFDbEYsV0FBT0EseUJBQXVCLE1BQU0sbUNBQW1DLEdBQUcsRUFBRSxNQUFNLEtBQUssRUFBRTtBQUM3RixRQUFNLElBQUksTUFBTSx1QkFBdUI7QUFDM0MsR0FBRyxxQ0FBcUMsU0FBUzJCLG9DQUFtQyxPQUFPLFVBQVU7QUFDakcsTUFBSSxhQUFhLENBQUE7QUFDakIsVUFBUSxNQUFNLE9BQUs7QUFBQSxJQUNmLEtBQUs7QUFFRCxhQUFPLENBQUMsTUFBTSxNQUFNLFVBQVU7QUFBQSxJQUNsQyxLQUFLO0FBQ0QsVUFBSSxDQUFDLFVBQVU7QUFDWCxjQUFNLE1BQU0sd0ZBQXdGO0FBQUEsTUFDeEc7QUFDQSxVQUFJLE9BQU8sTUFBTTtBQUVqQixVQUFJLEtBQUssTUFBTSxTQUFTO0FBQ3BCLG1CQUFXLGtCQUFrQixLQUFLLE1BQU0sU0FBUztBQUM3QyxjQUFJLGVBQWUsU0FBUyxTQUFTLFNBQVM7QUFDMUMsZ0JBQUksaUJBQWlCLFNBQVMsUUFBUSxlQUFlLEtBQUs7QUFDMUQscUJBQVMsUUFBUSxlQUFlLEtBQUssSUFBSTNCLHlCQUF1QixNQUFNLDRCQUE0QixLQUFLLGtDQUFrQyxFQUFFLEtBQUssTUFBTSxnQkFBZ0IsY0FBYztBQUFBLFVBQ3hMLE9BQ0s7QUFDRCxxQkFBUyxRQUFRLGVBQWUsS0FBSyxJQUFJO0FBRXpDLHVCQUFXLEtBQUssY0FBYztBQUFBLFVBQ2xDO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFDQSxhQUFPLENBQUMsVUFBVSxVQUFVO0FBQUEsSUFDaEMsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUVELFVBQUksVUFBVTtBQUNWLGVBQU8sQ0FBQyxVQUFVLFVBQVU7QUFBQSxNQUNoQyxPQUNLO0FBQ0QsY0FBTSxNQUFNLHlEQUF5RDtBQUFBLE1BQ3pFO0FBQUEsRUFDWjtBQUNJLFFBQU0sTUFBTSx5Q0FBeUM7QUFDekQsR0FBRyxxQ0FBcUMsU0FBUzRCLG9DQUFtQyxnQkFBZ0IsZ0JBQWdCO0FBQ2hILFNBQU8sZ0JBQWdCLGdCQUFnQixnQkFBZ0IsY0FBYztBQUN6RSxHQUFHLDZCQUE2QixTQUFTQyw0QkFBMkIsT0FBTztBQUN2RS9CLDJCQUF1QixNQUFNLHFDQUFxQyxNQUFNLE1BQU0sR0FBRztBQUNqRixVQUFRLE1BQU0sT0FBSztBQUFBLElBQ2YsS0FBSztBQUNEO0FBQUEsSUFDSixLQUFLO0FBQ0Q7QUFBQSxJQUNKLEtBQUs7QUFDRDtBQUFBLElBQ0osS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNEQSwrQkFBdUIsTUFBTSwyQkFBMkIsTUFBTSxNQUFNLEdBQUc7QUFDdkUsVUFBSUUseUJBQXVCLE1BQU0sa0NBQWtDLEdBQUcsR0FBRztBQUNyRSxhQUFLLE1BQU0sZ0JBQWdCQSx5QkFBdUIsTUFBTSxrQ0FBa0MsR0FBRyxDQUFDO0FBQzlGRixpQ0FBdUIsTUFBTSxrQ0FBa0MsUUFBVyxHQUFHO0FBQUEsTUFDakY7QUFDQTtBQUFBLEVBR1o7QUFDQTtBQ3RpQk8sTUFBTSxtQkFBbUIsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXeEMsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxLQUFLLFFBQVEsS0FBSyxlQUFlO0FBQUEsTUFDcEM7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBLFNBQVMsYUFBYSxTQUFTO0FBQzNCLFdBQU8sS0FBSyxRQUFRLElBQUksZUFBZSxXQUFXLElBQUk7QUFBQSxNQUNsRCxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXQSxPQUFPLGFBQWEsTUFBTSxTQUFTO0FBQy9CLFdBQU8sS0FBSyxRQUFRLEtBQUssZUFBZSxXQUFXLElBQUk7QUFBQSxNQUNuRDtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDMUUsQ0FBUztBQUFBLEVBQ0w7QUFBQSxFQUNBLEtBQUssUUFBUSxDQUFBLEdBQUksU0FBUztBQUN0QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUM5QjtBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcsZUFBZSxnQkFBZ0I7QUFBQSxNQUMxRDtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDMUUsQ0FBUztBQUFBLEVBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsSUFBSSxhQUFhLFNBQVM7QUFDdEIsV0FBTyxLQUFLLFFBQVEsT0FBTyxlQUFlLFdBQVcsSUFBSTtBQUFBLE1BQ3JELEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQ0o7QUFDTyxNQUFNLHVCQUF1QixXQUFXO0FBQy9DO0FBQ0EsV0FBVyxpQkFBaUI7QUNyRnJCLFNBQVMsNEJBQTRCLElBQUk7QUFDNUMsU0FBTyxPQUFPLEdBQUcsVUFBVTtBQUMvQjtBQ0ZPLE1BQU0scUJBQXFCLENBQUMsWUFBWTtBQUMzQyxTQUFPLFNBQVMsU0FBUztBQUM3QjtBQUNPLE1BQU0sb0JBQW9CLENBQUMsWUFBWTtBQUMxQyxTQUFPLFNBQVMsU0FBUztBQUM3QjtBQUNPLE1BQU0sZ0JBQWdCLENBQUMsWUFBWTtBQUN0QyxTQUFPLFNBQVMsU0FBUztBQUM3QjtBQ3FCTyxTQUFTLDZCQUE2QixpQkFBaUI7QUFDMUQsU0FBTyxrQkFBa0IsUUFBUSxNQUFNO0FBQzNDO0FBbUJPLFNBQVNnQyxxQkFBbUIsTUFBTTtBQUNyQyxTQUFPLE9BQU8sUUFBUSxNQUFNO0FBQ2hDO0FBQ08sU0FBUyx5QkFBeUIsWUFBWSxRQUFRO0FBQ3pELE1BQUksQ0FBQyxVQUFVLENBQUNDLHdCQUFzQixNQUFNLEdBQUc7QUFDM0MsV0FBTztBQUFBLE1BQ0gsR0FBRztBQUFBLE1BQ0gsU0FBUyxXQUFXLFFBQVEsSUFBSSxDQUFDLFlBQVk7QUFBQSxRQUN6QyxHQUFHO0FBQUEsUUFDSCxTQUFTO0FBQUEsVUFDTCxHQUFHLE9BQU87QUFBQSxVQUNWLFFBQVE7QUFBQSxVQUNSLEdBQUksT0FBTyxRQUFRLGFBQ2Y7QUFBQSxZQUNJLFlBQVksT0FBTyxRQUFRO0FBQUEsVUFDdkQsSUFDMEI7QUFBQSxRQUMxQjtBQUFBLE1BQ0EsRUFBYztBQUFBLElBQ2Q7QUFBQSxFQUNJO0FBQ0EsU0FBTyxvQkFBb0IsWUFBWSxNQUFNO0FBQ2pEO0FBQ08sU0FBUyxvQkFBb0IsWUFBWSxRQUFRO0FBQ3BELFFBQU0sVUFBVSxXQUFXLFFBQVEsSUFBSSxDQUFDLFdBQVc7QUFDL0MsUUFBSSxPQUFPLGtCQUFrQixVQUFVO0FBQ25DLFlBQU0sSUFBSSx3QkFBdUI7QUFBQSxJQUNyQztBQUNBLFFBQUksT0FBTyxrQkFBa0Isa0JBQWtCO0FBQzNDLFlBQU0sSUFBSSwrQkFBOEI7QUFBQSxJQUM1QztBQUNBLFdBQU87QUFBQSxNQUNILEdBQUc7QUFBQSxNQUNILFNBQVM7QUFBQSxRQUNMLEdBQUcsT0FBTztBQUFBLFFBQ1YsR0FBSSxPQUFPLFFBQVEsYUFDZjtBQUFBLFVBQ0ksWUFBWSxPQUFPLFFBQVEsWUFBWSxJQUFJLENBQUMsYUFBYUMsZ0JBQWMsUUFBUSxRQUFRLENBQUMsS0FBSztBQUFBLFFBQ3JILElBQ3NCO0FBQUEsUUFDTixRQUFRLE9BQU8sUUFBUSxXQUFXLENBQUMsT0FBTyxRQUFRLFVBQzlDLG9CQUFvQixRQUFRLE9BQU8sUUFBUSxPQUFPLElBQ2hEO0FBQUEsTUFDdEI7QUFBQSxJQUNBO0FBQUEsRUFDSSxDQUFDO0FBQ0QsU0FBTyxFQUFFLEdBQUcsWUFBWSxRQUFPO0FBQ25DO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxTQUFTO0FBQzFDLE1BQUksT0FBTyxpQkFBaUIsU0FBUyxlQUFlO0FBQ2hELFdBQU87QUFBQSxFQUNYO0FBQ0EsTUFBSSxPQUFPLGlCQUFpQixTQUFTLGVBQWU7QUFDaEQsUUFBSSxlQUFlLE9BQU8saUJBQWlCO0FBQ3ZDLFlBQU0sa0JBQWtCLE9BQU87QUFDL0IsYUFBTyxnQkFBZ0IsVUFBVSxPQUFPO0FBQUEsSUFDNUM7QUFDQSxXQUFPLEtBQUssTUFBTSxPQUFPO0FBQUEsRUFDN0I7QUFDQSxTQUFPO0FBQ1g7QUFDQSxTQUFTQSxnQkFBYyxRQUFRLFVBQVU7QUFDckMsUUFBTSxZQUFZLE9BQU8sT0FBTyxLQUFLLENBQUNDLGVBQWNBLFdBQVUsVUFBVSxTQUFTLFNBQVMsU0FBUyxJQUFJO0FBQ3ZHLFNBQU87QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILFVBQVU7QUFBQSxNQUNOLEdBQUcsU0FBUztBQUFBLE1BQ1osa0JBQWtCSCxxQkFBbUIsU0FBUyxJQUFJLFVBQVUsVUFBVSxTQUFTLFNBQVMsU0FBUyxJQUMzRixXQUFXLFNBQVMsU0FBUyxLQUFLLE1BQU0sU0FBUyxTQUFTLFNBQVMsSUFDL0Q7QUFBQSxJQUN0QjtBQUFBLEVBQ0E7QUFDQTtBQUNPLFNBQVMsb0JBQW9CLFFBQVEsVUFBVTtBQUNsRCxNQUFJLENBQUMsUUFBUTtBQUNULFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSxZQUFZLE9BQU8sT0FBTyxLQUFLLENBQUNHLGVBQWNBLFdBQVUsVUFBVSxTQUFTLFNBQVMsU0FBUyxJQUFJO0FBQ3ZHLFNBQU9ILHFCQUFtQixTQUFTLEtBQUssV0FBVyxTQUFTLFVBQVU7QUFDMUU7QUFDTyxTQUFTQyx3QkFBc0IsUUFBUTtBQUMxQyxNQUFJLDZCQUE2QixPQUFPLGVBQWUsR0FBRztBQUN0RCxXQUFPO0FBQUEsRUFDWDtBQUNBLFNBQVEsT0FBTyxPQUFPLEtBQUssQ0FBQyxNQUFNRCxxQkFBbUIsQ0FBQyxLQUFNLEVBQUUsU0FBUyxjQUFjLEVBQUUsU0FBUyxXQUFXLElBQUssS0FBSztBQUN6SDtBQUNPLFNBQVMsbUJBQW1CLE9BQU87QUFDdEMsYUFBVyxRQUFRLFNBQVMsSUFBSTtBQUM1QixRQUFJLEtBQUssU0FBUyxZQUFZO0FBQzFCLFlBQU0sSUFBSSxZQUFZLDJFQUEyRSxLQUFLLElBQUksSUFBSTtBQUFBLElBQ2xIO0FBQ0EsUUFBSSxLQUFLLFNBQVMsV0FBVyxNQUFNO0FBQy9CLFlBQU0sSUFBSSxZQUFZLFNBQVMsS0FBSyxTQUFTLElBQUksNEZBQTRGO0FBQUEsSUFDako7QUFBQSxFQUNKO0FBQ0o7QUNqSkEsSUFBSTlCLDJCQUFrRSxTQUFVLFVBQVUsT0FBT0QsT0FBTSxHQUFHO0FBQ3RHLE1BQUlBLFVBQVMsT0FBTyxDQUFDLEVBQUcsT0FBTSxJQUFJLFVBQVUsK0NBQStDO0FBQzNGLE1BQUksT0FBTyxVQUFVLGFBQWEsYUFBYSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxRQUFRLEVBQUcsT0FBTSxJQUFJLFVBQVUsMEVBQTBFO0FBQ2pMLFNBQU9BLFVBQVMsTUFBTSxJQUFJQSxVQUFTLE1BQU0sRUFBRSxLQUFLLFFBQVEsSUFBSSxJQUFJLEVBQUUsUUFBUSxNQUFNLElBQUksUUFBUTtBQUNoRztBQUNBLElBQUkseUNBQXlDLCtDQUErQywrQ0FBK0Msb0RBQW9ELDBEQUEwRCxtREFBbUQsOENBQThDO0FBTTFWLE1BQU0sK0JBQStCO0FBQzlCLE1BQU0scUNBQXFDLFlBQVk7QUFBQSxFQUMxRCxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsNENBQXdDLElBQUksSUFBSTtBQUNoRCxTQUFLLG1CQUFtQixDQUFBO0FBQ3hCLFNBQUssV0FBVyxDQUFBO0FBQUEsRUFDcEI7QUFBQSxFQUNBLG1CQUFtQixnQkFBZ0I7QUFDL0IsU0FBSyxpQkFBaUIsS0FBSyxjQUFjO0FBQ3pDLFNBQUssTUFBTSxrQkFBa0IsY0FBYztBQUMzQyxVQUFNLFVBQVUsZUFBZSxRQUFRLENBQUMsR0FBRztBQUMzQyxRQUFJO0FBQ0EsV0FBSyxZQUFZLE9BQU87QUFDNUIsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLFlBQVksU0FBUyxPQUFPLE1BQU07QUFDOUIsUUFBSSxFQUFFLGFBQWE7QUFDZixjQUFRLFVBQVU7QUFDdEIsU0FBSyxTQUFTLEtBQUssT0FBTztBQUMxQixRQUFJLE1BQU07QUFDTixXQUFLLE1BQU0sV0FBVyxPQUFPO0FBQzdCLFdBQUssa0JBQWtCLE9BQU8sS0FBSyxjQUFjLE9BQU8sTUFBTSxRQUFRLFNBQVM7QUFFM0UsYUFBSyxNQUFNLHNCQUFzQixRQUFRLE9BQU87QUFBQSxNQUNwRCxXQUNTLG1CQUFtQixPQUFPLEtBQUssUUFBUSxlQUFlO0FBQzNELGFBQUssTUFBTSxnQkFBZ0IsUUFBUSxhQUFhO0FBQUEsTUFDcEQsV0FDUyxtQkFBbUIsT0FBTyxLQUFLLFFBQVEsWUFBWTtBQUN4RCxtQkFBVyxhQUFhLFFBQVEsWUFBWTtBQUN4QyxjQUFJLFVBQVUsU0FBUyxZQUFZO0FBQy9CLGlCQUFLLE1BQU0sZ0JBQWdCLFVBQVUsUUFBUTtBQUFBLFVBQ2pEO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxNQUFNLHNCQUFzQjtBQUN4QixVQUFNLEtBQUssS0FBSTtBQUNmLFVBQU0sYUFBYSxLQUFLLGlCQUFpQixLQUFLLGlCQUFpQixTQUFTLENBQUM7QUFDekUsUUFBSSxDQUFDO0FBQ0QsWUFBTSxJQUFJLFlBQVksaURBQWlEO0FBQzNFLFdBQU87QUFBQSxFQUNYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLE1BQU0sZUFBZTtBQUNqQixVQUFNLEtBQUssS0FBSTtBQUNmLFdBQU9DLHlCQUF1QixNQUFNLHlDQUF5QyxLQUFLLDZDQUE2QyxFQUFFLEtBQUssSUFBSTtBQUFBLEVBQzlJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLE1BQU0sZUFBZTtBQUNqQixVQUFNLEtBQUssS0FBSTtBQUNmLFdBQU9BLHlCQUF1QixNQUFNLHlDQUF5QyxLQUFLLDZDQUE2QyxFQUFFLEtBQUssSUFBSTtBQUFBLEVBQzlJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLE1BQU0sb0JBQW9CO0FBQ3RCLFVBQU0sS0FBSyxLQUFJO0FBQ2YsV0FBT0EseUJBQXVCLE1BQU0seUNBQXlDLEtBQUssa0RBQWtELEVBQUUsS0FBSyxJQUFJO0FBQUEsRUFDbko7QUFBQSxFQUNBLE1BQU0sMEJBQTBCO0FBQzVCLFVBQU0sS0FBSyxLQUFJO0FBQ2YsV0FBT0EseUJBQXVCLE1BQU0seUNBQXlDLEtBQUssd0RBQXdELEVBQUUsS0FBSyxJQUFJO0FBQUEsRUFDeko7QUFBQSxFQUNBLE1BQU0sYUFBYTtBQUNmLFVBQU0sS0FBSyxLQUFJO0FBQ2YsV0FBT0EseUJBQXVCLE1BQU0seUNBQXlDLEtBQUssaURBQWlELEVBQUUsS0FBSyxJQUFJO0FBQUEsRUFDbEo7QUFBQSxFQUNBLHFCQUFxQjtBQUNqQixXQUFPLENBQUMsR0FBRyxLQUFLLGdCQUFnQjtBQUFBLEVBQ3BDO0FBQUEsRUFDQSxhQUFhO0FBQ1QsVUFBTSxhQUFhLEtBQUssaUJBQWlCLEtBQUssaUJBQWlCLFNBQVMsQ0FBQztBQUN6RSxRQUFJO0FBQ0EsV0FBSyxNQUFNLHVCQUF1QixVQUFVO0FBQ2hELFVBQU0sZUFBZUEseUJBQXVCLE1BQU0seUNBQXlDLEtBQUssNkNBQTZDLEVBQUUsS0FBSyxJQUFJO0FBQ3hKLFFBQUk7QUFDQSxXQUFLLE1BQU0sZ0JBQWdCLFlBQVk7QUFDM0MsVUFBTSxlQUFlQSx5QkFBdUIsTUFBTSx5Q0FBeUMsS0FBSyw2Q0FBNkMsRUFBRSxLQUFLLElBQUk7QUFDeEosUUFBSTtBQUNBLFdBQUssTUFBTSxnQkFBZ0IsWUFBWTtBQUMzQyxVQUFNLG9CQUFvQkEseUJBQXVCLE1BQU0seUNBQXlDLEtBQUssa0RBQWtELEVBQUUsS0FBSyxJQUFJO0FBQ2xLLFFBQUk7QUFDQSxXQUFLLE1BQU0scUJBQXFCLGlCQUFpQjtBQUNyRCxVQUFNLDBCQUEwQkEseUJBQXVCLE1BQU0seUNBQXlDLEtBQUssd0RBQXdELEVBQUUsS0FBSyxJQUFJO0FBQzlLLFFBQUksMkJBQTJCO0FBQzNCLFdBQUssTUFBTSwyQkFBMkIsdUJBQXVCO0FBQ2pFLFFBQUksS0FBSyxpQkFBaUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEdBQUc7QUFDNUMsV0FBSyxNQUFNLGNBQWNBLHlCQUF1QixNQUFNLHlDQUF5QyxLQUFLLGlEQUFpRCxFQUFFLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDcks7QUFBQSxFQUNKO0FBQUEsRUFDQSxNQUFNLHNCQUFzQixRQUFRLFFBQVEsU0FBUztBQUNqRCxVQUFNLFNBQVMsU0FBUztBQUN4QixRQUFJLFFBQVE7QUFDUixVQUFJLE9BQU87QUFDUCxhQUFLLFdBQVcsTUFBSztBQUN6QixhQUFPLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxXQUFXLE9BQU87QUFBQSxJQUNsRTtBQUNBQSw2QkFBdUIsTUFBTSx5Q0FBeUMsS0FBSyw0Q0FBNEMsRUFBRSxLQUFLLE1BQU0sTUFBTTtBQUMxSSxVQUFNLGlCQUFpQixNQUFNLE9BQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxHQUFHLFFBQVEsUUFBUSxNQUFLLEdBQUksRUFBRSxHQUFHLFNBQVMsUUFBUSxLQUFLLFdBQVcsUUFBUTtBQUN4SSxTQUFLLFdBQVU7QUFDZixXQUFPLEtBQUssbUJBQW1CLG9CQUFvQixnQkFBZ0IsTUFBTSxDQUFDO0FBQUEsRUFDOUU7QUFBQSxFQUNBLE1BQU0sbUJBQW1CLFFBQVEsUUFBUSxTQUFTO0FBQzlDLGVBQVcsV0FBVyxPQUFPLFVBQVU7QUFDbkMsV0FBSyxZQUFZLFNBQVMsS0FBSztBQUFBLElBQ25DO0FBQ0EsV0FBTyxNQUFNLEtBQUssc0JBQXNCLFFBQVEsUUFBUSxPQUFPO0FBQUEsRUFDbkU7QUFBQSxFQUNBLE1BQU0sY0FBYyxRQUFRLFFBQVEsU0FBUztBQUN6QyxVQUFNLE9BQU87QUFDYixVQUFNLEVBQUUsZ0JBQWdCLFFBQVEsUUFBUSxHQUFHLFdBQVUsSUFBSztBQUMxRCxVQUFNLHVCQUF1QixPQUFPLGtCQUFrQixZQUFZLGVBQWU7QUFDakYsVUFBTSxFQUFFLHFCQUFxQiw2QkFBNEIsSUFBSyxXQUFXLENBQUE7QUFDekUsVUFBTSxrQkFBa0IsQ0FBQTtBQUN4QixlQUFXLEtBQUssT0FBTyxXQUFXO0FBQzlCLHNCQUFnQixFQUFFLFFBQVEsRUFBRSxTQUFTLElBQUksSUFBSTtBQUFBLElBQ2pEO0FBQ0EsVUFBTSxZQUFZLE9BQU8sVUFBVSxJQUFJLENBQUMsT0FBTztBQUFBLE1BQzNDLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUztBQUFBLE1BQzNCLFlBQVksRUFBRTtBQUFBLE1BQ2QsYUFBYSxFQUFFO0FBQUEsSUFDM0IsRUFBVTtBQUNGLGVBQVcsV0FBVyxPQUFPLFVBQVU7QUFDbkMsV0FBSyxZQUFZLFNBQVMsS0FBSztBQUFBLElBQ25DO0FBQ0EsYUFBUyxJQUFJLEdBQUcsSUFBSSxvQkFBb0IsRUFBRSxHQUFHO0FBQ3pDLFlBQU0saUJBQWlCLE1BQU0sS0FBSyxzQkFBc0IsUUFBUTtBQUFBLFFBQzVELEdBQUc7QUFBQSxRQUNIO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxDQUFDLEdBQUcsS0FBSyxRQUFRO0FBQUEsTUFDM0MsR0FBZSxPQUFPO0FBQ1YsWUFBTSxVQUFVLGVBQWUsUUFBUSxDQUFDLEdBQUc7QUFDM0MsVUFBSSxDQUFDLFNBQVM7QUFDVixjQUFNLElBQUksWUFBWSw0Q0FBNEM7QUFBQSxNQUN0RTtBQUNBLFVBQUksQ0FBQyxRQUFRO0FBQ1Q7QUFDSixZQUFNLEVBQUUsTUFBTSxXQUFXLEtBQUksSUFBSyxRQUFRO0FBQzFDLFlBQU0sS0FBSyxnQkFBZ0IsSUFBSTtBQUMvQixVQUFJLENBQUMsSUFBSTtBQUNMLGNBQU1rQyxXQUFVLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLDRCQUE0QixVQUNyRixJQUFJLENBQUMsTUFBTSxLQUFLLFVBQVUsRUFBRSxJQUFJLENBQUMsRUFDakMsS0FBSyxJQUFJLENBQUM7QUFDZixhQUFLLFlBQVksRUFBRSxNQUFNLE1BQU0sU0FBQUEsU0FBTyxDQUFFO0FBQ3hDO0FBQUEsTUFDSixXQUNTLHdCQUF3Qix5QkFBeUIsTUFBTTtBQUM1RCxjQUFNQSxXQUFVLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLEtBQUssS0FBSyxVQUFVLG9CQUFvQixDQUFDO0FBQ3ZHLGFBQUssWUFBWSxFQUFFLE1BQU0sTUFBTSxTQUFBQSxTQUFPLENBQUU7QUFDeEM7QUFBQSxNQUNKO0FBQ0EsVUFBSTtBQUNKLFVBQUk7QUFDQSxpQkFBUyw0QkFBNEIsRUFBRSxJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSTtBQUFBLE1BQ3RFLFNBQ08sT0FBTztBQUNWLGFBQUssWUFBWTtBQUFBLFVBQ2I7QUFBQSxVQUNBO0FBQUEsVUFDQSxTQUFTLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxPQUFPLEtBQUs7QUFBQSxRQUNsRixDQUFpQjtBQUNEO0FBQUEsTUFDSjtBQUVBLFlBQU0sYUFBYSxNQUFNLEdBQUcsU0FBUyxRQUFRLElBQUk7QUFDakQsWUFBTSxVQUFVbEMseUJBQXVCLE1BQU0seUNBQXlDLEtBQUsseURBQXlELEVBQUUsS0FBSyxNQUFNLFVBQVU7QUFDM0ssV0FBSyxZQUFZLEVBQUUsTUFBTSxNQUFNLFFBQU8sQ0FBRTtBQUN4QyxVQUFJO0FBQ0E7QUFBQSxJQUNSO0FBQUEsRUFDSjtBQUFBLEVBQ0EsTUFBTSxVQUFVLFFBQVEsUUFBUSxTQUFTO0FBQ3JDLFVBQU0sT0FBTztBQUNiLFVBQU0sRUFBRSxjQUFjLFFBQVEsUUFBUSxHQUFHLFdBQVUsSUFBSztBQUN4RCxVQUFNLHVCQUF1QixPQUFPLGdCQUFnQixZQUFZLGFBQWEsVUFBVTtBQUN2RixVQUFNLEVBQUUscUJBQXFCLDZCQUE0QixJQUFLLFdBQVcsQ0FBQTtBQUV6RSxVQUFNLGFBQWEsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTO0FBQzFDLFVBQUk4QixxQkFBbUIsSUFBSSxHQUFHO0FBQzFCLFlBQUksQ0FBQyxLQUFLLFdBQVc7QUFDakIsZ0JBQU0sSUFBSSxZQUFZLHVFQUF1RTtBQUFBLFFBQ2pHO0FBQ0EsZUFBTztBQUFBLFVBQ0gsTUFBTTtBQUFBLFVBQ04sVUFBVTtBQUFBLFlBQ04sVUFBVSxLQUFLO0FBQUEsWUFDZixNQUFNLEtBQUssU0FBUztBQUFBLFlBQ3BCLGFBQWEsS0FBSyxTQUFTLGVBQWU7QUFBQSxZQUMxQyxZQUFZLEtBQUssU0FBUztBQUFBLFlBQzFCLE9BQU8sS0FBSztBQUFBLFlBQ1osUUFBUTtBQUFBLFVBQ2hDO0FBQUEsUUFDQTtBQUFBLE1BQ1k7QUFDQSxhQUFPO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsQ0FBQTtBQUN4QixlQUFXLEtBQUssWUFBWTtBQUN4QixVQUFJLEVBQUUsU0FBUyxZQUFZO0FBQ3ZCLHdCQUFnQixFQUFFLFNBQVMsUUFBUSxFQUFFLFNBQVMsU0FBUyxJQUFJLElBQUksRUFBRTtBQUFBLE1BQ3JFO0FBQUEsSUFDSjtBQUNBLFVBQU0sUUFBUSxXQUFXLFNBQ3JCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLGFBQzdCO0FBQUEsTUFDSSxNQUFNO0FBQUEsTUFDTixVQUFVO0FBQUEsUUFDTixNQUFNLEVBQUUsU0FBUyxRQUFRLEVBQUUsU0FBUyxTQUFTO0FBQUEsUUFDN0MsWUFBWSxFQUFFLFNBQVM7QUFBQSxRQUN2QixhQUFhLEVBQUUsU0FBUztBQUFBLFFBQ3hCLFFBQVEsRUFBRSxTQUFTO0FBQUEsTUFDM0M7QUFBQSxJQUNBLElBQ2tCLENBQUMsSUFDTDtBQUNOLGVBQVcsV0FBVyxPQUFPLFVBQVU7QUFDbkMsV0FBSyxZQUFZLFNBQVMsS0FBSztBQUFBLElBQ25DO0FBQ0EsYUFBUyxJQUFJLEdBQUcsSUFBSSxvQkFBb0IsRUFBRSxHQUFHO0FBQ3pDLFlBQU0saUJBQWlCLE1BQU0sS0FBSyxzQkFBc0IsUUFBUTtBQUFBLFFBQzVELEdBQUc7QUFBQSxRQUNIO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxDQUFDLEdBQUcsS0FBSyxRQUFRO0FBQUEsTUFDM0MsR0FBZSxPQUFPO0FBQ1YsWUFBTSxVQUFVLGVBQWUsUUFBUSxDQUFDLEdBQUc7QUFDM0MsVUFBSSxDQUFDLFNBQVM7QUFDVixjQUFNLElBQUksWUFBWSw0Q0FBNEM7QUFBQSxNQUN0RTtBQUNBLFVBQUksQ0FBQyxRQUFRLFlBQVksUUFBUTtBQUM3QjtBQUFBLE1BQ0o7QUFDQSxpQkFBVyxhQUFhLFFBQVEsWUFBWTtBQUN4QyxZQUFJLFVBQVUsU0FBUztBQUNuQjtBQUNKLGNBQU0sZUFBZSxVQUFVO0FBQy9CLGNBQU0sRUFBRSxNQUFNLFdBQVcsS0FBSSxJQUFLLFVBQVU7QUFDNUMsY0FBTSxLQUFLLGdCQUFnQixJQUFJO0FBQy9CLFlBQUksQ0FBQyxJQUFJO0FBQ0wsZ0JBQU1JLFdBQVUsc0JBQXNCLEtBQUssVUFBVSxJQUFJLENBQUMsNEJBQTRCLE9BQU8sS0FBSyxlQUFlLEVBQzVHLElBQUksQ0FBQ0MsVUFBUyxLQUFLLFVBQVVBLEtBQUksQ0FBQyxFQUNsQyxLQUFLLElBQUksQ0FBQztBQUNmLGVBQUssWUFBWSxFQUFFLE1BQU0sY0FBYyxTQUFBRCxTQUFPLENBQUU7QUFDaEQ7QUFBQSxRQUNKLFdBQ1Msd0JBQXdCLHlCQUF5QixNQUFNO0FBQzVELGdCQUFNQSxXQUFVLHNCQUFzQixLQUFLLFVBQVUsSUFBSSxDQUFDLEtBQUssS0FBSyxVQUFVLG9CQUFvQixDQUFDO0FBQ25HLGVBQUssWUFBWSxFQUFFLE1BQU0sY0FBYyxTQUFBQSxTQUFPLENBQUU7QUFDaEQ7QUFBQSxRQUNKO0FBQ0EsWUFBSTtBQUNKLFlBQUk7QUFDQSxtQkFBUyw0QkFBNEIsRUFBRSxJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSTtBQUFBLFFBQ3RFLFNBQ08sT0FBTztBQUNWLGdCQUFNQSxXQUFVLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxPQUFPLEtBQUs7QUFDckUsZUFBSyxZQUFZLEVBQUUsTUFBTSxjQUFjLFNBQUFBLFNBQU8sQ0FBRTtBQUNoRDtBQUFBLFFBQ0o7QUFFQSxjQUFNLGFBQWEsTUFBTSxHQUFHLFNBQVMsUUFBUSxJQUFJO0FBQ2pELGNBQU0sVUFBVWxDLHlCQUF1QixNQUFNLHlDQUF5QyxLQUFLLHlEQUF5RCxFQUFFLEtBQUssTUFBTSxVQUFVO0FBQzNLLGFBQUssWUFBWSxFQUFFLE1BQU0sY0FBYyxRQUFPLENBQUU7QUFDaEQsWUFBSSxzQkFBc0I7QUFDdEI7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFDQTtBQUFBLEVBQ0o7QUFDSjtBQUNBLDBDQUEwQyxvQkFBSSxRQUFPLEdBQUksZ0RBQWdELFNBQVNvQyxpREFBZ0Q7QUFDOUosU0FBT3BDLHlCQUF1QixNQUFNLHlDQUF5QyxLQUFLLDZDQUE2QyxFQUFFLEtBQUssSUFBSSxFQUFFLFdBQVc7QUFDM0osR0FBRyxnREFBZ0QsU0FBU3FDLGlEQUFnRDtBQUN4RyxNQUFJLElBQUksS0FBSyxTQUFTO0FBQ3RCLFNBQU8sTUFBTSxHQUFHO0FBQ1osVUFBTSxVQUFVLEtBQUssU0FBUyxDQUFDO0FBQy9CLFFBQUksbUJBQW1CLE9BQU8sR0FBRztBQUM3QixZQUFNLEVBQUUsZUFBZSxHQUFHLEtBQUksSUFBSztBQUVuQyxZQUFNLE1BQU07QUFBQSxRQUNSLEdBQUc7QUFBQSxRQUNILFNBQVMsUUFBUSxXQUFXO0FBQUEsUUFDNUIsU0FBUyxRQUFRLFdBQVc7QUFBQSxNQUM1QztBQUNZLFVBQUksZUFBZTtBQUNmLFlBQUksZ0JBQWdCO0FBQUEsTUFDeEI7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0o7QUFDQSxRQUFNLElBQUksWUFBWSw0RUFBNEU7QUFDdEcsR0FBRyxxREFBcUQsU0FBU0Msc0RBQXFEO0FBQ2xILFdBQVMsSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0FBQ2hELFVBQU0sVUFBVSxLQUFLLFNBQVMsQ0FBQztBQUMvQixRQUFJLG1CQUFtQixPQUFPLEtBQUssU0FBUyxlQUFlO0FBQ3ZELGFBQU8sUUFBUTtBQUFBLElBQ25CO0FBQ0EsUUFBSSxtQkFBbUIsT0FBTyxLQUFLLFNBQVMsWUFBWSxRQUFRO0FBQzVELGFBQU8sUUFBUSxXQUFXLEdBQUcsRUFBRSxHQUFHO0FBQUEsSUFDdEM7QUFBQSxFQUNKO0FBQ0E7QUFDSixHQUFHLDJEQUEyRCxTQUFTQyw0REFBMkQ7QUFDOUgsV0FBUyxJQUFJLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDaEQsVUFBTSxVQUFVLEtBQUssU0FBUyxDQUFDO0FBQy9CLFFBQUksa0JBQWtCLE9BQU8sS0FBSyxRQUFRLFdBQVcsTUFBTTtBQUN2RCxhQUFPLFFBQVE7QUFBQSxJQUNuQjtBQUNBLFFBQUksY0FBYyxPQUFPLEtBQ3JCLFFBQVEsV0FBVyxRQUNuQixPQUFPLFFBQVEsWUFBWSxZQUMzQixLQUFLLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLGVBQ2pDLEVBQUUsWUFBWSxLQUFLLENBQUMsTUFBTSxFQUFFLFNBQVMsY0FBYyxFQUFFLE9BQU8sUUFBUSxZQUFZLENBQUMsR0FBRztBQUN4RixhQUFPLFFBQVE7QUFBQSxJQUNuQjtBQUFBLEVBQ0o7QUFDQTtBQUNKLEdBQUcsb0RBQW9ELFNBQVNDLHFEQUFvRDtBQUNoSCxRQUFNLFFBQVE7QUFBQSxJQUNWLG1CQUFtQjtBQUFBLElBQ25CLGVBQWU7QUFBQSxJQUNmLGNBQWM7QUFBQSxFQUN0QjtBQUNJLGFBQVcsRUFBRSxXQUFXLEtBQUssa0JBQWtCO0FBQzNDLFFBQUksT0FBTztBQUNQLFlBQU0scUJBQXFCLE1BQU07QUFDakMsWUFBTSxpQkFBaUIsTUFBTTtBQUM3QixZQUFNLGdCQUFnQixNQUFNO0FBQUEsSUFDaEM7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNYLEdBQUcsK0NBQStDLFNBQVNDLDhDQUE2QyxRQUFRO0FBQzVHLE1BQUksT0FBTyxLQUFLLFFBQVEsT0FBTyxJQUFJLEdBQUc7QUFDbEMsVUFBTSxJQUFJLFlBQVksOEhBQThIO0FBQUEsRUFDeEo7QUFDSixHQUFHLDREQUE0RCxTQUFTQywyREFBMEQsWUFBWTtBQUMxSSxTQUFRLE9BQU8sZUFBZSxXQUFXLGFBQ25DLGVBQWUsU0FBWSxjQUN2QixLQUFLLFVBQVUsVUFBVTtBQUN2QztBQzVXTyxNQUFNLDZCQUE2Qiw2QkFBNkI7QUFBQTtBQUFBLEVBRW5FLE9BQU8sYUFBYSxRQUFRLFFBQVEsU0FBUztBQUN6QyxVQUFNLFNBQVMsSUFBSSxxQkFBb0I7QUFDdkMsVUFBTSxPQUFPO0FBQUEsTUFDVCxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsNkJBQTZCLGVBQWM7QUFBQSxJQUN2RjtBQUNRLFdBQU8sS0FBSyxNQUFNLE9BQU8sY0FBYyxRQUFRLFFBQVEsSUFBSSxDQUFDO0FBQzVELFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxPQUFPLFNBQVMsUUFBUSxRQUFRLFNBQVM7QUFDckMsVUFBTSxTQUFTLElBQUkscUJBQW9CO0FBQ3ZDLFVBQU0sT0FBTztBQUFBLE1BQ1QsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLEdBQUcsU0FBUyxTQUFTLDZCQUE2QixXQUFVO0FBQUEsSUFDbkY7QUFDUSxXQUFPLEtBQUssTUFBTSxPQUFPLFVBQVUsUUFBUSxRQUFRLElBQUksQ0FBQztBQUN4RCxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsWUFBWSxTQUFTLE9BQU8sTUFBTTtBQUM5QixVQUFNLFlBQVksU0FBUyxJQUFJO0FBQy9CLFFBQUksbUJBQW1CLE9BQU8sS0FBSyxRQUFRLFNBQVM7QUFDaEQsV0FBSyxNQUFNLFdBQVcsUUFBUSxPQUFPO0FBQUEsSUFDekM7QUFBQSxFQUNKO0FBQ0o7QUM1QkEsTUFBTSxNQUFNO0FBQ1osTUFBTSxNQUFNO0FBQ1osTUFBTSxNQUFNO0FBQ1osTUFBTSxNQUFNO0FBQ1osTUFBTSxPQUFPO0FBQ2IsTUFBTSxPQUFPO0FBQ2IsTUFBTSxNQUFNO0FBQ1osTUFBTSxXQUFXO0FBQ2pCLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sTUFBTSxXQUFXO0FBQ3ZCLE1BQU0sVUFBVSxPQUFPLE9BQU8sTUFBTTtBQUNwQyxNQUFNLE9BQU8sTUFBTSxNQUFNO0FBQ3pCLE1BQU0sYUFBYSxNQUFNO0FBQ3pCLE1BQU0sTUFBTSxPQUFPO0FBQ25CLE1BQU0sUUFBUTtBQUFBLEVBQ1Y7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0o7QUFFQSxNQUFNLG9CQUFvQixNQUFNO0FBQ2hDO0FBQ0EsTUFBTSxzQkFBc0IsTUFBTTtBQUNsQztBQVNBLFNBQVMsVUFBVSxZQUFZLGVBQWUsTUFBTSxLQUFLO0FBQ3JELE1BQUksT0FBTyxlQUFlLFVBQVU7QUFDaEMsVUFBTSxJQUFJLFVBQVUsc0JBQXNCLE9BQU8sVUFBVSxFQUFFO0FBQUEsRUFDakU7QUFDQSxNQUFJLENBQUMsV0FBVyxRQUFRO0FBQ3BCLFVBQU0sSUFBSSxNQUFNLEdBQUcsVUFBVSxXQUFXO0FBQUEsRUFDNUM7QUFDQSxTQUFPLFdBQVcsV0FBVyxLQUFJLEdBQUksWUFBWTtBQUNyRDtBQUNBLE1BQU0sYUFBYSxDQUFDLFlBQVksVUFBVTtBQUN0QyxRQUFNLFNBQVMsV0FBVztBQUMxQixNQUFJLFFBQVE7QUFDWixRQUFNLGtCQUFrQixDQUFDLFFBQVE7QUFDN0IsVUFBTSxJQUFJLFlBQVksR0FBRyxHQUFHLGdCQUFnQixLQUFLLEVBQUU7QUFBQSxFQUN2RDtBQUNBLFFBQU0sc0JBQXNCLENBQUMsUUFBUTtBQUNqQyxVQUFNLElBQUksY0FBYyxHQUFHLEdBQUcsZ0JBQWdCLEtBQUssRUFBRTtBQUFBLEVBQ3pEO0FBQ0EsUUFBTSxXQUFXLE1BQU07QUFDbkIsY0FBUztBQUNULFFBQUksU0FBUztBQUNULHNCQUFnQix5QkFBeUI7QUFDN0MsUUFBSSxXQUFXLEtBQUssTUFBTTtBQUN0QixhQUFPLFNBQVE7QUFDbkIsUUFBSSxXQUFXLEtBQUssTUFBTTtBQUN0QixhQUFPLFNBQVE7QUFDbkIsUUFBSSxXQUFXLEtBQUssTUFBTTtBQUN0QixhQUFPLFNBQVE7QUFDbkIsUUFBSSxXQUFXLFVBQVUsT0FBTyxRQUFRLENBQUMsTUFBTSxVQUMxQyxNQUFNLE9BQU8sU0FBUyxTQUFTLFFBQVEsS0FBSyxPQUFPLFdBQVcsV0FBVyxVQUFVLEtBQUssQ0FBQyxHQUFJO0FBQzlGLGVBQVM7QUFDVCxhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksV0FBVyxVQUFVLE9BQU8sUUFBUSxDQUFDLE1BQU0sVUFDMUMsTUFBTSxPQUFPLFNBQVMsU0FBUyxRQUFRLEtBQUssT0FBTyxXQUFXLFdBQVcsVUFBVSxLQUFLLENBQUMsR0FBSTtBQUM5RixlQUFTO0FBQ1QsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLFdBQVcsVUFBVSxPQUFPLFFBQVEsQ0FBQyxNQUFNLFdBQzFDLE1BQU0sT0FBTyxTQUFTLFNBQVMsUUFBUSxLQUFLLFFBQVEsV0FBVyxXQUFXLFVBQVUsS0FBSyxDQUFDLEdBQUk7QUFDL0YsZUFBUztBQUNULGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSSxXQUFXLFVBQVUsT0FBTyxRQUFRLENBQUMsTUFBTSxjQUMxQyxNQUFNLFdBQVcsU0FBUyxTQUFTLFFBQVEsS0FBSyxXQUFXLFdBQVcsV0FBVyxVQUFVLEtBQUssQ0FBQyxHQUFJO0FBQ3RHLGVBQVM7QUFDVCxhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksV0FBVyxVQUFVLE9BQU8sUUFBUSxDQUFDLE1BQU0sZUFDMUMsTUFBTSxpQkFBaUIsU0FDcEIsSUFBSSxTQUFTLFNBQ2IsU0FBUyxRQUFRLEtBQ2pCLFlBQVksV0FBVyxXQUFXLFVBQVUsS0FBSyxDQUFDLEdBQUk7QUFDMUQsZUFBUztBQUNULGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSSxXQUFXLFVBQVUsT0FBTyxRQUFRLENBQUMsTUFBTSxTQUMxQyxNQUFNLE1BQU0sU0FBUyxTQUFTLFFBQVEsS0FBSyxNQUFNLFdBQVcsV0FBVyxVQUFVLEtBQUssQ0FBQyxHQUFJO0FBQzVGLGVBQVM7QUFDVCxhQUFPO0FBQUEsSUFDWDtBQUNBLFdBQU8sU0FBUTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxXQUFXLE1BQU07QUFDbkIsVUFBTSxRQUFRO0FBQ2QsUUFBSUMsVUFBUztBQUNiO0FBQ0EsV0FBTyxRQUFRLFdBQVcsV0FBVyxLQUFLLE1BQU0sT0FBUUEsV0FBVSxXQUFXLFFBQVEsQ0FBQyxNQUFNLE9BQVE7QUFDaEcsTUFBQUEsVUFBUyxXQUFXLEtBQUssTUFBTSxPQUFPLENBQUNBLFVBQVM7QUFDaEQ7QUFBQSxJQUNKO0FBQ0EsUUFBSSxXQUFXLE9BQU8sS0FBSyxLQUFLLEtBQUs7QUFDakMsVUFBSTtBQUNBLGVBQU8sS0FBSyxNQUFNLFdBQVcsVUFBVSxPQUFPLEVBQUUsUUFBUSxPQUFPQSxPQUFNLENBQUMsQ0FBQztBQUFBLE1BQzNFLFNBQ08sR0FBRztBQUNOLDRCQUFvQixPQUFPLENBQUMsQ0FBQztBQUFBLE1BQ2pDO0FBQUEsSUFDSixXQUNTLE1BQU0sTUFBTSxPQUFPO0FBQ3hCLFVBQUk7QUFDQSxlQUFPLEtBQUssTUFBTSxXQUFXLFVBQVUsT0FBTyxRQUFRLE9BQU9BLE9BQU0sQ0FBQyxJQUFJLEdBQUc7QUFBQSxNQUMvRSxTQUNPLEdBQUc7QUFFTixlQUFPLEtBQUssTUFBTSxXQUFXLFVBQVUsT0FBTyxXQUFXLFlBQVksSUFBSSxDQUFDLElBQUksR0FBRztBQUFBLE1BQ3JGO0FBQUEsSUFDSjtBQUNBLG9CQUFnQiw2QkFBNkI7QUFBQSxFQUNqRDtBQUNBLFFBQU0sV0FBVyxNQUFNO0FBQ25CO0FBQ0EsY0FBUztBQUNULFVBQU0sTUFBTSxDQUFBO0FBQ1osUUFBSTtBQUNBLGFBQU8sV0FBVyxLQUFLLE1BQU0sS0FBSztBQUM5QixrQkFBUztBQUNULFlBQUksU0FBUyxVQUFVLE1BQU0sTUFBTTtBQUMvQixpQkFBTztBQUNYLGNBQU0sTUFBTSxTQUFRO0FBQ3BCLGtCQUFTO0FBQ1Q7QUFDQSxZQUFJO0FBQ0EsZ0JBQU0sUUFBUSxTQUFRO0FBQ3RCLGlCQUFPLGVBQWUsS0FBSyxLQUFLLEVBQUUsT0FBTyxVQUFVLE1BQU0sWUFBWSxNQUFNLGNBQWMsS0FBSSxDQUFFO0FBQUEsUUFDbkcsU0FDTyxHQUFHO0FBQ04sY0FBSSxNQUFNLE1BQU07QUFDWixtQkFBTztBQUFBO0FBRVAsa0JBQU07QUFBQSxRQUNkO0FBQ0Esa0JBQVM7QUFDVCxZQUFJLFdBQVcsS0FBSyxNQUFNO0FBQ3RCO0FBQUEsTUFDUjtBQUFBLElBQ0osU0FDTyxHQUFHO0FBQ04sVUFBSSxNQUFNLE1BQU07QUFDWixlQUFPO0FBQUE7QUFFUCx3QkFBZ0IsK0JBQStCO0FBQUEsSUFDdkQ7QUFDQTtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSxXQUFXLE1BQU07QUFDbkI7QUFDQSxVQUFNLE1BQU0sQ0FBQTtBQUNaLFFBQUk7QUFDQSxhQUFPLFdBQVcsS0FBSyxNQUFNLEtBQUs7QUFDOUIsWUFBSSxLQUFLLFVBQVU7QUFDbkIsa0JBQVM7QUFDVCxZQUFJLFdBQVcsS0FBSyxNQUFNLEtBQUs7QUFDM0I7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBLElBQ0osU0FDTyxHQUFHO0FBQ04sVUFBSSxNQUFNLE1BQU0sT0FBTztBQUNuQixlQUFPO0FBQUEsTUFDWDtBQUNBLHNCQUFnQiw4QkFBOEI7QUFBQSxJQUNsRDtBQUNBO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNLFdBQVcsTUFBTTtBQUNuQixRQUFJLFVBQVUsR0FBRztBQUNiLFVBQUksZUFBZSxPQUFPLE1BQU0sTUFBTTtBQUNsQyx3QkFBZ0Isc0JBQXNCO0FBQzFDLFVBQUk7QUFDQSxlQUFPLEtBQUssTUFBTSxVQUFVO0FBQUEsTUFDaEMsU0FDTyxHQUFHO0FBQ04sWUFBSSxNQUFNLE1BQU0sT0FBTztBQUNuQixjQUFJO0FBQ0EsZ0JBQUksUUFBUSxXQUFXLFdBQVcsU0FBUyxDQUFDO0FBQ3hDLHFCQUFPLEtBQUssTUFBTSxXQUFXLFVBQVUsR0FBRyxXQUFXLFlBQVksR0FBRyxDQUFDLENBQUM7QUFDMUUsbUJBQU8sS0FBSyxNQUFNLFdBQVcsVUFBVSxHQUFHLFdBQVcsWUFBWSxHQUFHLENBQUMsQ0FBQztBQUFBLFVBQzFFLFNBQ09DLElBQUc7QUFBQSxVQUFFO0FBQUEsUUFDaEI7QUFDQSw0QkFBb0IsT0FBTyxDQUFDLENBQUM7QUFBQSxNQUNqQztBQUFBLElBQ0o7QUFDQSxVQUFNLFFBQVE7QUFDZCxRQUFJLFdBQVcsS0FBSyxNQUFNO0FBQ3RCO0FBQ0osV0FBTyxXQUFXLEtBQUssS0FBSyxDQUFDLE1BQU0sU0FBUyxXQUFXLEtBQUssQ0FBQztBQUN6RDtBQUNKLFFBQUksU0FBUyxVQUFVLEVBQUUsTUFBTSxNQUFNO0FBQ2pDLHNCQUFnQiw2QkFBNkI7QUFDakQsUUFBSTtBQUNBLGFBQU8sS0FBSyxNQUFNLFdBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQztBQUFBLElBQ3hELFNBQ08sR0FBRztBQUNOLFVBQUksV0FBVyxVQUFVLE9BQU8sS0FBSyxNQUFNLE9BQU8sTUFBTSxNQUFNO0FBQzFELHdCQUFnQixzQkFBc0I7QUFDMUMsVUFBSTtBQUNBLGVBQU8sS0FBSyxNQUFNLFdBQVcsVUFBVSxPQUFPLFdBQVcsWUFBWSxHQUFHLENBQUMsQ0FBQztBQUFBLE1BQzlFLFNBQ09BLElBQUc7QUFDTiw0QkFBb0IsT0FBT0EsRUFBQyxDQUFDO0FBQUEsTUFDakM7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUNBLFFBQU0sWUFBWSxNQUFNO0FBQ3BCLFdBQU8sUUFBUSxVQUFVLFNBQVUsU0FBUyxXQUFXLEtBQUssQ0FBQyxHQUFHO0FBQzVEO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFDQSxTQUFPLFNBQVE7QUFDbkI7QUFFQSxNQUFNLGVBQWUsQ0FBQyxVQUFVLFVBQVUsT0FBTyxNQUFNLE1BQU0sTUFBTSxHQUFHO0FDOU90RSxJQUFJOUMsMkJBQWtFLFNBQVUsVUFBVSxPQUFPLE9BQU9DLE9BQU0sR0FBRztBQUM3RyxNQUFJQSxVQUFTLElBQUssT0FBTSxJQUFJLFVBQVUsZ0NBQWdDO0FBQ3RFLE1BQUlBLFVBQVMsT0FBTyxDQUFDLEVBQUcsT0FBTSxJQUFJLFVBQVUsK0NBQStDO0FBQzNGLE1BQUksT0FBTyxVQUFVLGFBQWEsYUFBYSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxRQUFRLEVBQUcsT0FBTSxJQUFJLFVBQVUseUVBQXlFO0FBQ2hMLFNBQVFBLFVBQVMsTUFBTSxFQUFFLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSSxFQUFFLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVSxLQUFLLEdBQUk7QUFDeEc7QUFDQSxJQUFJQywyQkFBa0UsU0FBVSxVQUFVLE9BQU9ELE9BQU0sR0FBRztBQUN0RyxNQUFJQSxVQUFTLE9BQU8sQ0FBQyxFQUFHLE9BQU0sSUFBSSxVQUFVLCtDQUErQztBQUMzRixNQUFJLE9BQU8sVUFBVSxhQUFhLGFBQWEsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksUUFBUSxFQUFHLE9BQU0sSUFBSSxVQUFVLDBFQUEwRTtBQUNqTCxTQUFPQSxVQUFTLE1BQU0sSUFBSUEsVUFBUyxNQUFNLEVBQUUsS0FBSyxRQUFRLElBQUksSUFBSSxFQUFFLFFBQVEsTUFBTSxJQUFJLFFBQVE7QUFDaEc7QUFDQSxJQUFJLGlDQUFpQyw4QkFBOEIseUNBQXlDLHFEQUFxRCxvQ0FBb0MsMkNBQTJDLGdDQUFnQyw2Q0FBNkMsNkNBQTZDLGtDQUFrQyxzREFBc0Q7QUFNM2IsTUFBTSw2QkFBNkIsNkJBQTZCO0FBQUEsRUFDbkUsWUFBWSxRQUFRO0FBQ2hCLFVBQUs7QUFDTCxvQ0FBZ0MsSUFBSSxJQUFJO0FBQ3hDLGlDQUE2QixJQUFJLE1BQU0sTUFBTTtBQUM3Qyw0Q0FBd0MsSUFBSSxNQUFNLE1BQU07QUFDeEQsd0RBQW9ELElBQUksTUFBTSxNQUFNO0FBQ3BFRCw2QkFBdUIsTUFBTSw4QkFBOEIsUUFBUSxHQUFHO0FBQ3RFQSw2QkFBdUIsTUFBTSx5Q0FBeUMsQ0FBQSxHQUFJLEdBQUc7QUFBQSxFQUNqRjtBQUFBLEVBQ0EsSUFBSSxnQ0FBZ0M7QUFDaEMsV0FBT0UseUJBQXVCLE1BQU0scURBQXFELEdBQUc7QUFBQSxFQUNoRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxPQUFPLG1CQUFtQixRQUFRO0FBQzlCLFVBQU0sU0FBUyxJQUFJLHFCQUFxQixJQUFJO0FBQzVDLFdBQU8sS0FBSyxNQUFNLE9BQU8sb0JBQW9CLE1BQU0sQ0FBQztBQUNwRCxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsT0FBTyxxQkFBcUIsUUFBUSxRQUFRLFNBQVM7QUFDakQsVUFBTSxTQUFTLElBQUkscUJBQXFCLE1BQU07QUFDOUMsV0FBTyxLQUFLLE1BQU0sT0FBTyxtQkFBbUIsUUFBUSxFQUFFLEdBQUcsUUFBUSxRQUFRLEtBQUksR0FBSSxFQUFFLEdBQUcsU0FBUyxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsNkJBQTZCLFNBQVEsRUFBRSxDQUFFLENBQUM7QUFDekssV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLE1BQU0sc0JBQXNCLFFBQVEsUUFBUSxTQUFTO0FBQ2pELFVBQU07QUFDTixVQUFNLFNBQVMsU0FBUztBQUN4QixRQUFJLFFBQVE7QUFDUixVQUFJLE9BQU87QUFDUCxhQUFLLFdBQVcsTUFBSztBQUN6QixhQUFPLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxXQUFXLE9BQU87QUFBQSxJQUNsRTtBQUNBQSw2QkFBdUIsTUFBTSxpQ0FBaUMsS0FBSyxrQ0FBa0MsRUFBRSxLQUFLLElBQUk7QUFDaEgsVUFBTSxTQUFTLE1BQU0sT0FBTyxLQUFLLFlBQVksT0FBTyxFQUFFLEdBQUcsUUFBUSxRQUFRLEtBQUksR0FBSSxFQUFFLEdBQUcsU0FBUyxRQUFRLEtBQUssV0FBVyxRQUFRO0FBQy9ILFNBQUssV0FBVTtBQUNmLHFCQUFpQixTQUFTLFFBQVE7QUFDOUJBLCtCQUF1QixNQUFNLGlDQUFpQyxLQUFLLDhCQUE4QixFQUFFLEtBQUssTUFBTSxLQUFLO0FBQUEsSUFDdkg7QUFDQSxRQUFJLE9BQU8sV0FBVyxRQUFRLFNBQVM7QUFDbkMsWUFBTSxJQUFJLGtCQUFpQjtBQUFBLElBQy9CO0FBQ0EsV0FBTyxLQUFLLG1CQUFtQkEseUJBQXVCLE1BQU0saUNBQWlDLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxFQUNsSjtBQUFBLEVBQ0EsTUFBTSxvQkFBb0IsZ0JBQWdCLFNBQVM7QUFDL0MsVUFBTSxTQUFTLFNBQVM7QUFDeEIsUUFBSSxRQUFRO0FBQ1IsVUFBSSxPQUFPO0FBQ1AsYUFBSyxXQUFXLE1BQUs7QUFDekIsYUFBTyxpQkFBaUIsU0FBUyxNQUFNLEtBQUssV0FBVyxPQUFPO0FBQUEsSUFDbEU7QUFDQUEsNkJBQXVCLE1BQU0saUNBQWlDLEtBQUssa0NBQWtDLEVBQUUsS0FBSyxJQUFJO0FBQ2hILFNBQUssV0FBVTtBQUNmLFVBQU0sU0FBUyxPQUFPLG1CQUFtQixnQkFBZ0IsS0FBSyxVQUFVO0FBQ3hFLFFBQUk7QUFDSixxQkFBaUIsU0FBUyxRQUFRO0FBQzlCLFVBQUksVUFBVSxXQUFXLE1BQU0sSUFBSTtBQUUvQixhQUFLLG1CQUFtQkEseUJBQXVCLE1BQU0saUNBQWlDLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxNQUMzSTtBQUNBQSwrQkFBdUIsTUFBTSxpQ0FBaUMsS0FBSyw4QkFBOEIsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUNuSCxlQUFTLE1BQU07QUFBQSxJQUNuQjtBQUNBLFFBQUksT0FBTyxXQUFXLFFBQVEsU0FBUztBQUNuQyxZQUFNLElBQUksa0JBQWlCO0FBQUEsSUFDL0I7QUFDQSxXQUFPLEtBQUssbUJBQW1CQSx5QkFBdUIsTUFBTSxpQ0FBaUMsS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLEVBQ2xKO0FBQUEsRUFDQSxFQUFFLCtCQUErQixvQkFBSSxRQUFPLEdBQUksMENBQTBDLG9CQUFJLFFBQU8sR0FBSSxzREFBc0Qsb0JBQUksUUFBTyxHQUFJLGtDQUFrQyxvQkFBSSxRQUFPLEdBQUkscUNBQXFDLFNBQVM2QyxzQ0FBcUM7QUFDOVMsUUFBSSxLQUFLO0FBQ0w7QUFDSi9DLDZCQUF1QixNQUFNLHFEQUFxRCxRQUFXLEdBQUc7QUFBQSxFQUNwRyxHQUFHLDRDQUE0QyxTQUFTZ0QsMkNBQTBDLFFBQVE7QUFDdEcsUUFBSSxRQUFROUMseUJBQXVCLE1BQU0seUNBQXlDLEdBQUcsRUFBRSxPQUFPLEtBQUs7QUFDbkcsUUFBSSxPQUFPO0FBQ1AsYUFBTztBQUFBLElBQ1g7QUFDQSxZQUFRO0FBQUEsTUFDSixjQUFjO0FBQUEsTUFDZCxjQUFjO0FBQUEsTUFDZCx1QkFBdUI7QUFBQSxNQUN2Qix1QkFBdUI7QUFBQSxNQUN2QixpQkFBaUIsb0JBQUksSUFBRztBQUFBLE1BQ3hCLHlCQUF5QjtBQUFBLElBQ3JDO0FBQ1FBLDZCQUF1QixNQUFNLHlDQUF5QyxHQUFHLEVBQUUsT0FBTyxLQUFLLElBQUk7QUFDM0YsV0FBTztBQUFBLEVBQ1gsR0FBRyxpQ0FBaUMsU0FBUytDLGdDQUErQixPQUFPO0FBQy9FLFFBQUksS0FBSztBQUNMO0FBQ0osVUFBTSxhQUFhL0MseUJBQXVCLE1BQU0saUNBQWlDLEtBQUssOENBQThDLEVBQUUsS0FBSyxNQUFNLEtBQUs7QUFDdEosU0FBSyxNQUFNLFNBQVMsT0FBTyxVQUFVO0FBQ3JDLGVBQVcsVUFBVSxNQUFNLFNBQVM7QUFDaEMsWUFBTSxpQkFBaUIsV0FBVyxRQUFRLE9BQU8sS0FBSztBQUN0RCxVQUFJLE9BQU8sTUFBTSxXQUFXLFFBQ3hCLGVBQWUsU0FBUyxTQUFTLGVBQ2pDLGVBQWUsU0FBUyxTQUFTO0FBQ2pDLGFBQUssTUFBTSxXQUFXLE9BQU8sTUFBTSxTQUFTLGVBQWUsUUFBUSxPQUFPO0FBQzFFLGFBQUssTUFBTSxpQkFBaUI7QUFBQSxVQUN4QixPQUFPLE9BQU8sTUFBTTtBQUFBLFVBQ3BCLFVBQVUsZUFBZSxRQUFRO0FBQUEsVUFDakMsUUFBUSxlQUFlLFFBQVE7QUFBQSxRQUNuRCxDQUFpQjtBQUFBLE1BQ0w7QUFDQSxVQUFJLE9BQU8sTUFBTSxXQUFXLFFBQ3hCLGVBQWUsU0FBUyxTQUFTLGVBQ2pDLGVBQWUsU0FBUyxTQUFTO0FBQ2pDLGFBQUssTUFBTSxpQkFBaUI7QUFBQSxVQUN4QixPQUFPLE9BQU8sTUFBTTtBQUFBLFVBQ3BCLFVBQVUsZUFBZSxRQUFRO0FBQUEsUUFDckQsQ0FBaUI7QUFBQSxNQUNMO0FBQ0EsVUFBSSxPQUFPLFVBQVUsV0FBVyxRQUFRLGVBQWUsU0FBUyxTQUFTLGFBQWE7QUFDbEYsYUFBSyxNQUFNLDBCQUEwQjtBQUFBLFVBQ2pDLFNBQVMsT0FBTyxVQUFVO0FBQUEsVUFDMUIsVUFBVSxlQUFlLFVBQVUsV0FBVyxDQUFBO0FBQUEsUUFDbEUsQ0FBaUI7QUFBQSxNQUNMO0FBQ0EsVUFBSSxPQUFPLFVBQVUsV0FBVyxRQUFRLGVBQWUsU0FBUyxTQUFTLGFBQWE7QUFDbEYsYUFBSyxNQUFNLDBCQUEwQjtBQUFBLFVBQ2pDLFNBQVMsT0FBTyxVQUFVO0FBQUEsVUFDMUIsVUFBVSxlQUFlLFVBQVUsV0FBVyxDQUFBO0FBQUEsUUFDbEUsQ0FBaUI7QUFBQSxNQUNMO0FBQ0EsWUFBTSxRQUFRQSx5QkFBdUIsTUFBTSxpQ0FBaUMsS0FBSyx5Q0FBeUMsRUFBRSxLQUFLLE1BQU0sY0FBYztBQUNySixVQUFJLGVBQWUsZUFBZTtBQUM5QkEsaUNBQXVCLE1BQU0saUNBQWlDLEtBQUssMkNBQTJDLEVBQUUsS0FBSyxNQUFNLGNBQWM7QUFDekksWUFBSSxNQUFNLDJCQUEyQixNQUFNO0FBQ3ZDQSxtQ0FBdUIsTUFBTSxpQ0FBaUMsS0FBSywyQ0FBMkMsRUFBRSxLQUFLLE1BQU0sZ0JBQWdCLE1BQU0sdUJBQXVCO0FBQUEsUUFDNUs7QUFBQSxNQUNKO0FBQ0EsaUJBQVcsWUFBWSxPQUFPLE1BQU0sY0FBYyxDQUFBLEdBQUk7QUFDbEQsWUFBSSxNQUFNLDRCQUE0QixTQUFTLE9BQU87QUFDbERBLG1DQUF1QixNQUFNLGlDQUFpQyxLQUFLLDJDQUEyQyxFQUFFLEtBQUssTUFBTSxjQUFjO0FBRXpJLGNBQUksTUFBTSwyQkFBMkIsTUFBTTtBQUN2Q0EscUNBQXVCLE1BQU0saUNBQWlDLEtBQUssMkNBQTJDLEVBQUUsS0FBSyxNQUFNLGdCQUFnQixNQUFNLHVCQUF1QjtBQUFBLFVBQzVLO0FBQUEsUUFDSjtBQUNBLGNBQU0sMEJBQTBCLFNBQVM7QUFBQSxNQUM3QztBQUNBLGlCQUFXLGlCQUFpQixPQUFPLE1BQU0sY0FBYyxDQUFBLEdBQUk7QUFDdkQsY0FBTSxtQkFBbUIsZUFBZSxRQUFRLGFBQWEsY0FBYyxLQUFLO0FBQ2hGLFlBQUksQ0FBQyxrQkFBa0IsTUFBTTtBQUN6QjtBQUFBLFFBQ0o7QUFDQSxZQUFJLGtCQUFrQixTQUFTLFlBQVk7QUFDdkMsZUFBSyxNQUFNLHVDQUF1QztBQUFBLFlBQzlDLE1BQU0saUJBQWlCLFVBQVU7QUFBQSxZQUNqQyxPQUFPLGNBQWM7QUFBQSxZQUNyQixXQUFXLGlCQUFpQixTQUFTO0FBQUEsWUFDckMsa0JBQWtCLGlCQUFpQixTQUFTO0FBQUEsWUFDNUMsaUJBQWlCLGNBQWMsVUFBVSxhQUFhO0FBQUEsVUFDOUUsQ0FBcUI7QUFBQSxRQUNMLE9BQ0s7QUFDRCxzQkFBWSxrQkFBa0IsSUFBSTtBQUFBLFFBQ3RDO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFBQSxFQUNKLEdBQUcsOENBQThDLFNBQVNnRCw2Q0FBNEMsZ0JBQWdCLGVBQWU7QUFDakksVUFBTSxRQUFRaEQseUJBQXVCLE1BQU0saUNBQWlDLEtBQUsseUNBQXlDLEVBQUUsS0FBSyxNQUFNLGNBQWM7QUFDckosUUFBSSxNQUFNLGdCQUFnQixJQUFJLGFBQWEsR0FBRztBQUUxQztBQUFBLElBQ0o7QUFDQSxVQUFNLG1CQUFtQixlQUFlLFFBQVEsYUFBYSxhQUFhO0FBQzFFLFFBQUksQ0FBQyxrQkFBa0I7QUFDbkIsWUFBTSxJQUFJLE1BQU0sdUJBQXVCO0FBQUEsSUFDM0M7QUFDQSxRQUFJLENBQUMsaUJBQWlCLE1BQU07QUFDeEIsWUFBTSxJQUFJLE1BQU0sbUNBQW1DO0FBQUEsSUFDdkQ7QUFDQSxRQUFJLGlCQUFpQixTQUFTLFlBQVk7QUFDdEMsWUFBTSxZQUFZQSx5QkFBdUIsTUFBTSw4QkFBOEIsR0FBRyxHQUFHLE9BQU8sS0FBSyxDQUFDLFNBQVMsS0FBSyxTQUFTLGNBQWMsS0FBSyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUMxTCxXQUFLLE1BQU0sc0NBQXNDO0FBQUEsUUFDN0MsTUFBTSxpQkFBaUIsU0FBUztBQUFBLFFBQ2hDLE9BQU87QUFBQSxRQUNQLFdBQVcsaUJBQWlCLFNBQVM7QUFBQSxRQUNyQyxrQkFBa0I4QixxQkFBbUIsU0FBUyxJQUFJLFVBQVUsVUFBVSxpQkFBaUIsU0FBUyxTQUFTLElBQ25HLFdBQVcsU0FBUyxTQUFTLEtBQUssTUFBTSxpQkFBaUIsU0FBUyxTQUFTLElBQ3ZFO0FBQUEsTUFDMUIsQ0FBYTtBQUFBLElBQ0wsT0FDSztBQUNELGtCQUFZLGlCQUFpQixJQUFJO0FBQUEsSUFDckM7QUFBQSxFQUNKLEdBQUcsOENBQThDLFNBQVNtQiw2Q0FBNEMsZ0JBQWdCO0FBQ2xILFVBQU0sUUFBUWpELHlCQUF1QixNQUFNLGlDQUFpQyxLQUFLLHlDQUF5QyxFQUFFLEtBQUssTUFBTSxjQUFjO0FBQ3JKLFFBQUksZUFBZSxRQUFRLFdBQVcsQ0FBQyxNQUFNLGNBQWM7QUFDdkQsWUFBTSxlQUFlO0FBQ3JCLFlBQU0saUJBQWlCQSx5QkFBdUIsTUFBTSxpQ0FBaUMsS0FBSyxvREFBb0QsRUFBRSxLQUFLLElBQUk7QUFDekosV0FBSyxNQUFNLGdCQUFnQjtBQUFBLFFBQ3ZCLFNBQVMsZUFBZSxRQUFRO0FBQUEsUUFDaEMsUUFBUSxpQkFBaUIsZUFBZSxVQUFVLGVBQWUsUUFBUSxPQUFPLElBQUk7QUFBQSxNQUNwRyxDQUFhO0FBQUEsSUFDTDtBQUNBLFFBQUksZUFBZSxRQUFRLFdBQVcsQ0FBQyxNQUFNLGNBQWM7QUFDdkQsWUFBTSxlQUFlO0FBQ3JCLFdBQUssTUFBTSxnQkFBZ0IsRUFBRSxTQUFTLGVBQWUsUUFBUSxTQUFTO0FBQUEsSUFDMUU7QUFDQSxRQUFJLGVBQWUsVUFBVSxXQUFXLENBQUMsTUFBTSx1QkFBdUI7QUFDbEUsWUFBTSx3QkFBd0I7QUFDOUIsV0FBSyxNQUFNLHlCQUF5QixFQUFFLFNBQVMsZUFBZSxTQUFTLFNBQVM7QUFBQSxJQUNwRjtBQUNBLFFBQUksZUFBZSxVQUFVLFdBQVcsQ0FBQyxNQUFNLHVCQUF1QjtBQUNsRSxZQUFNLHdCQUF3QjtBQUM5QixXQUFLLE1BQU0seUJBQXlCLEVBQUUsU0FBUyxlQUFlLFNBQVMsU0FBUztBQUFBLElBQ3BGO0FBQUEsRUFDSixHQUFHLG1DQUFtQyxTQUFTa0Qsb0NBQW1DO0FBQzlFLFFBQUksS0FBSyxPQUFPO0FBQ1osWUFBTSxJQUFJLFlBQVkseUNBQXlDO0FBQUEsSUFDbkU7QUFDQSxVQUFNLFdBQVdsRCx5QkFBdUIsTUFBTSxxREFBcUQsR0FBRztBQUN0RyxRQUFJLENBQUMsVUFBVTtBQUNYLFlBQU0sSUFBSSxZQUFZLDBDQUEwQztBQUFBLElBQ3BFO0FBQ0FGLDZCQUF1QixNQUFNLHFEQUFxRCxRQUFXLEdBQUc7QUFDaEdBLDZCQUF1QixNQUFNLHlDQUF5QyxDQUFBLEdBQUksR0FBRztBQUM3RSxXQUFPLHVCQUF1QixVQUFVRSx5QkFBdUIsTUFBTSw4QkFBOEIsR0FBRyxDQUFDO0FBQUEsRUFDM0csR0FBRyx1REFBdUQsU0FBU21ELHdEQUF1RDtBQUN0SCxVQUFNLGlCQUFpQm5ELHlCQUF1QixNQUFNLDhCQUE4QixHQUFHLEdBQUc7QUFDeEYsUUFBSSw2QkFBNkIsY0FBYyxHQUFHO0FBQzlDLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTztBQUFBLEVBQ1gsR0FBRyxpREFBaUQsU0FBU29ELGdEQUErQyxPQUFPO0FBQy9HLFFBQUlDLEtBQUksSUFBSSxJQUFJO0FBQ2hCLFFBQUksV0FBV3JELHlCQUF1QixNQUFNLHFEQUFxRCxHQUFHO0FBQ3BHLFVBQU0sRUFBRSxTQUFTLEdBQUcsS0FBSSxJQUFLO0FBQzdCLFFBQUksQ0FBQyxVQUFVO0FBQ1gsaUJBQVdGLHlCQUF1QixNQUFNLHFEQUFxRDtBQUFBLFFBQ3pGLEdBQUc7QUFBQSxRQUNILFNBQVMsQ0FBQTtBQUFBLE1BQ3pCLEdBQWUsR0FBRztBQUFBLElBQ1YsT0FDSztBQUNELGFBQU8sT0FBTyxVQUFVLElBQUk7QUFBQSxJQUNoQztBQUNBLGVBQVcsRUFBRSxPQUFPLGVBQWUsT0FBTyxXQUFXLE1BQU0sR0FBRyxNQUFLLEtBQU0sTUFBTSxTQUFTO0FBQ3BGLFVBQUksU0FBUyxTQUFTLFFBQVEsS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUTtBQUNULGlCQUFTLFNBQVMsUUFBUSxLQUFLLElBQUksRUFBRSxlQUFlLE9BQU8sU0FBUyxDQUFBLEdBQUksVUFBVSxHQUFHLE1BQUs7QUFBQSxNQUM5RjtBQUNBLFVBQUksVUFBVTtBQUNWLFlBQUksQ0FBQyxPQUFPLFVBQVU7QUFDbEIsaUJBQU8sV0FBVyxPQUFPLE9BQU8sQ0FBQSxHQUFJLFFBQVE7QUFBQSxRQUNoRCxPQUNLO0FBQ0QsZ0JBQU0sRUFBRSxTQUFBb0MsVUFBUyxTQUFBb0IsVUFBUyxHQUFHQyxNQUFJLElBQUs7QUFFdEMsaUJBQU8sT0FBTyxPQUFPLFVBQVVBLEtBQUk7QUFDbkMsY0FBSXJCLFVBQVM7QUFDVCxhQUFDbUIsTUFBSyxPQUFPLFVBQVUsWUFBWUEsSUFBRyxVQUFVO0FBQ2hELG1CQUFPLFNBQVMsUUFBUSxLQUFLLEdBQUduQixRQUFPO0FBQUEsVUFDM0M7QUFDQSxjQUFJb0IsVUFBUztBQUNULGFBQUMsS0FBSyxPQUFPLFVBQVUsWUFBWSxHQUFHLFVBQVU7QUFDaEQsbUJBQU8sU0FBUyxRQUFRLEtBQUssR0FBR0EsUUFBTztBQUFBLFVBQzNDO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFDQSxVQUFJLGVBQWU7QUFDZixlQUFPLGdCQUFnQjtBQUN2QixZQUFJdEQseUJBQXVCLE1BQU0sOEJBQThCLEdBQUcsS0FBSytCLHdCQUFzQi9CLHlCQUF1QixNQUFNLDhCQUE4QixHQUFHLENBQUMsR0FBRztBQUMzSixjQUFJLGtCQUFrQixVQUFVO0FBQzVCLGtCQUFNLElBQUksd0JBQXVCO0FBQUEsVUFDckM7QUFDQSxjQUFJLGtCQUFrQixrQkFBa0I7QUFDcEMsa0JBQU0sSUFBSSwrQkFBOEI7QUFBQSxVQUM1QztBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EsYUFBTyxPQUFPLFFBQVEsS0FBSztBQUMzQixVQUFJLENBQUM7QUFDRDtBQUNKLFlBQU0sRUFBRSxTQUFTLFNBQVMsZUFBZSxNQUFNLFlBQVksR0FBR3VELE1BQUksSUFBSztBQUV2RSxhQUFPLE9BQU8sT0FBTyxTQUFTQSxLQUFJO0FBQ2xDLFVBQUksU0FBUztBQUNULGVBQU8sUUFBUSxXQUFXLE9BQU8sUUFBUSxXQUFXLE1BQU07QUFBQSxNQUM5RDtBQUNBLFVBQUk7QUFDQSxlQUFPLFFBQVEsT0FBTztBQUMxQixVQUFJLGVBQWU7QUFDZixZQUFJLENBQUMsT0FBTyxRQUFRLGVBQWU7QUFDL0IsaUJBQU8sUUFBUSxnQkFBZ0I7QUFBQSxRQUNuQyxPQUNLO0FBQ0QsY0FBSSxjQUFjO0FBQ2QsbUJBQU8sUUFBUSxjQUFjLE9BQU8sY0FBYztBQUN0RCxjQUFJLGNBQWMsV0FBVztBQUN6QixhQUFDLEtBQUssT0FBTyxRQUFRLGVBQWUsY0FBYyxHQUFHLFlBQVk7QUFDakUsbUJBQU8sUUFBUSxjQUFjLGFBQWEsY0FBYztBQUFBLFVBQzVEO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFDQSxVQUFJLFNBQVM7QUFDVCxlQUFPLFFBQVEsV0FBVyxPQUFPLFFBQVEsV0FBVyxNQUFNO0FBQzFELFlBQUksQ0FBQyxPQUFPLFFBQVEsV0FBV3ZELHlCQUF1QixNQUFNLGlDQUFpQyxLQUFLLG9EQUFvRCxFQUFFLEtBQUssSUFBSSxHQUFHO0FBQ2hLLGlCQUFPLFFBQVEsU0FBUyxhQUFhLE9BQU8sUUFBUSxPQUFPO0FBQUEsUUFDL0Q7QUFBQSxNQUNKO0FBQ0EsVUFBSSxZQUFZO0FBQ1osWUFBSSxDQUFDLE9BQU8sUUFBUTtBQUNoQixpQkFBTyxRQUFRLGFBQWEsQ0FBQTtBQUNoQyxtQkFBVyxFQUFFLE9BQUF3RCxRQUFPLElBQUksTUFBTSxVQUFVLElBQUksR0FBR0QsTUFBSSxLQUFNLFlBQVk7QUFDakUsZ0JBQU0sYUFBYyxLQUFLLE9BQU8sUUFBUSxZQUFZQyxNQUFLLE1BQU0sR0FBR0EsTUFBSyxJQUFJLENBQUE7QUFDM0UsaUJBQU8sT0FBTyxXQUFXRCxLQUFJO0FBQzdCLGNBQUk7QUFDQSxzQkFBVSxLQUFLO0FBQ25CLGNBQUk7QUFDQSxzQkFBVSxPQUFPO0FBQ3JCLGNBQUk7QUFDQSxzQkFBVSxhQUFhLFVBQVUsV0FBVyxFQUFFLE1BQU0sR0FBRyxRQUFRLElBQUksV0FBVyxHQUFFO0FBQ3BGLGNBQUksSUFBSTtBQUNKLHNCQUFVLFNBQVMsT0FBTyxHQUFHO0FBQ2pDLGNBQUksSUFBSSxXQUFXO0FBQ2Ysc0JBQVUsU0FBUyxhQUFhLEdBQUc7QUFDbkMsZ0JBQUksb0JBQW9CdkQseUJBQXVCLE1BQU0sOEJBQThCLEdBQUcsR0FBRyxTQUFTLEdBQUc7QUFDakcsd0JBQVUsU0FBUyxtQkFBbUIsYUFBYSxVQUFVLFNBQVMsU0FBUztBQUFBLFlBQ25GO0FBQUEsVUFDSjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUNBLFdBQU87QUFBQSxFQUNYLEdBQUcsT0FBTyxrQkFBa0I7QUFDeEIsVUFBTSxZQUFZLENBQUE7QUFDbEIsVUFBTSxZQUFZLENBQUE7QUFDbEIsUUFBSSxPQUFPO0FBQ1gsU0FBSyxHQUFHLFNBQVMsQ0FBQyxVQUFVO0FBQ3hCLFlBQU0sU0FBUyxVQUFVLE1BQUs7QUFDOUIsVUFBSSxRQUFRO0FBQ1IsZUFBTyxRQUFRLEtBQUs7QUFBQSxNQUN4QixPQUNLO0FBQ0Qsa0JBQVUsS0FBSyxLQUFLO0FBQUEsTUFDeEI7QUFBQSxJQUNKLENBQUM7QUFDRCxTQUFLLEdBQUcsT0FBTyxNQUFNO0FBQ2pCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDNUIsZUFBTyxRQUFRLE1BQVM7QUFBQSxNQUM1QjtBQUNBLGdCQUFVLFNBQVM7QUFBQSxJQUN2QixDQUFDO0FBQ0QsU0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFRO0FBQ3RCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDNUIsZUFBTyxPQUFPLEdBQUc7QUFBQSxNQUNyQjtBQUNBLGdCQUFVLFNBQVM7QUFBQSxJQUN2QixDQUFDO0FBQ0QsU0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFRO0FBQ3RCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDNUIsZUFBTyxPQUFPLEdBQUc7QUFBQSxNQUNyQjtBQUNBLGdCQUFVLFNBQVM7QUFBQSxJQUN2QixDQUFDO0FBQ0QsV0FBTztBQUFBLE1BQ0gsTUFBTSxZQUFZO0FBQ2QsWUFBSSxDQUFDLFVBQVUsUUFBUTtBQUNuQixjQUFJLE1BQU07QUFDTixtQkFBTyxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUk7QUFBQSxVQUN6QztBQUNBLGlCQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVyxVQUFVLEtBQUssRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFLEtBQUssQ0FBQ21CLFdBQVdBLFNBQVEsRUFBRSxPQUFPQSxRQUFPLE1BQU0sTUFBSyxJQUFLLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSSxDQUFHO0FBQUEsUUFDM0s7QUFDQSxjQUFNLFFBQVEsVUFBVSxNQUFLO0FBQzdCLGVBQU8sRUFBRSxPQUFPLE9BQU8sTUFBTSxNQUFLO0FBQUEsTUFDdEM7QUFBQSxNQUNBLFFBQVEsWUFBWTtBQUNoQixhQUFLLE1BQUs7QUFDVixlQUFPLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSTtBQUFBLE1BQ3pDO0FBQUEsSUFDWjtBQUFBLEVBQ0k7QUFBQSxFQUNBLG1CQUFtQjtBQUNmLFVBQU0sU0FBUyxJQUFJLE9BQU8sS0FBSyxPQUFPLGFBQWEsRUFBRSxLQUFLLElBQUksR0FBRyxLQUFLLFVBQVU7QUFDaEYsV0FBTyxPQUFPLGlCQUFnQjtBQUFBLEVBQ2xDO0FBQ0o7QUFDQSxTQUFTLHVCQUF1QixVQUFVLFFBQVE7QUFDOUMsUUFBTSxFQUFFLElBQUksU0FBUyxTQUFTLE9BQU8sb0JBQW9CLEdBQUcsS0FBSSxJQUFLO0FBQ3JFLFFBQU0sYUFBYTtBQUFBLElBQ2YsR0FBRztBQUFBLElBQ0g7QUFBQSxJQUNBLFNBQVMsUUFBUSxJQUFJLENBQUMsRUFBRSxTQUFTLGVBQWUsT0FBTyxVQUFVLEdBQUcsaUJBQWlCO0FBQ2pGLFVBQUksQ0FBQyxlQUFlO0FBQ2hCLGNBQU0sSUFBSSxZQUFZLG9DQUFvQyxLQUFLLEVBQUU7QUFBQSxNQUNyRTtBQUNBLFlBQU0sRUFBRSxVQUFVLE1BQU0sZUFBZSxZQUFZLEdBQUcsWUFBVyxJQUFLO0FBQ3RFLFlBQU0sT0FBTyxRQUFRO0FBQ3JCLFVBQUksQ0FBQyxNQUFNO0FBQ1AsY0FBTSxJQUFJLFlBQVksMkJBQTJCLEtBQUssRUFBRTtBQUFBLE1BQzVEO0FBQ0EsVUFBSSxlQUFlO0FBQ2YsY0FBTSxFQUFFLFdBQVcsTUFBTSxLQUFJLElBQUs7QUFDbEMsWUFBSSxRQUFRLE1BQU07QUFDZCxnQkFBTSxJQUFJLFlBQVksOENBQThDLEtBQUssRUFBRTtBQUFBLFFBQy9FO0FBQ0EsWUFBSSxDQUFDLE1BQU07QUFDUCxnQkFBTSxJQUFJLFlBQVkseUNBQXlDLEtBQUssRUFBRTtBQUFBLFFBQzFFO0FBQ0EsZUFBTztBQUFBLFVBQ0gsR0FBRztBQUFBLFVBQ0gsU0FBUztBQUFBLFlBQ0w7QUFBQSxZQUNBLGVBQWUsRUFBRSxXQUFXLE1BQU0sS0FBSTtBQUFBLFlBQ3RDO0FBQUEsWUFDQSxTQUFTLFFBQVEsV0FBVztBQUFBLFVBQ3BEO0FBQUEsVUFDb0I7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ3BCO0FBQUEsTUFDWTtBQUNBLFVBQUksWUFBWTtBQUNaLGVBQU87QUFBQSxVQUNILEdBQUc7QUFBQSxVQUNIO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLFNBQVM7QUFBQSxZQUNMLEdBQUc7QUFBQSxZQUNIO0FBQUEsWUFDQTtBQUFBLFlBQ0EsU0FBUyxRQUFRLFdBQVc7QUFBQSxZQUM1QixZQUFZLFdBQVcsSUFBSSxDQUFDLFdBQVcsTUFBTTtBQUN6QyxvQkFBTSxFQUFFLFVBQVUsSUFBSSxNQUFNLElBQUFzQyxLQUFJLEdBQUcsU0FBUSxJQUFLO0FBQ2hELG9CQUFNLEVBQUUsV0FBVyxNQUFNLE1BQU0sR0FBRyxPQUFNLElBQUssTUFBTSxDQUFBO0FBQ25ELGtCQUFJQSxPQUFNLE1BQU07QUFDWixzQkFBTSxJQUFJLFlBQVksbUJBQW1CLEtBQUssZ0JBQWdCLENBQUM7QUFBQSxFQUFTLElBQUksUUFBUSxDQUFDLEVBQUU7QUFBQSxjQUMzRjtBQUNBLGtCQUFJLFFBQVEsTUFBTTtBQUNkLHNCQUFNLElBQUksWUFBWSxtQkFBbUIsS0FBSyxnQkFBZ0IsQ0FBQztBQUFBLEVBQVcsSUFBSSxRQUFRLENBQUMsRUFBRTtBQUFBLGNBQzdGO0FBQ0Esa0JBQUksUUFBUSxNQUFNO0FBQ2Qsc0JBQU0sSUFBSSxZQUFZLG1CQUFtQixLQUFLLGdCQUFnQixDQUFDO0FBQUEsRUFBb0IsSUFBSSxRQUFRLENBQUMsRUFBRTtBQUFBLGNBQ3RHO0FBQ0Esa0JBQUksUUFBUSxNQUFNO0FBQ2Qsc0JBQU0sSUFBSSxZQUFZLG1CQUFtQixLQUFLLGdCQUFnQixDQUFDO0FBQUEsRUFBeUIsSUFBSSxRQUFRLENBQUMsRUFBRTtBQUFBLGNBQzNHO0FBQ0EscUJBQU8sRUFBRSxHQUFHLFVBQVUsSUFBQUEsS0FBSSxNQUFNLFVBQVUsRUFBRSxHQUFHLFFBQVEsTUFBTSxXQUFXLEtBQUksRUFBRTtBQUFBLFlBQ2xGLENBQUM7QUFBQSxVQUN6QjtBQUFBLFFBQ0E7QUFBQSxNQUNZO0FBQ0EsYUFBTztBQUFBLFFBQ0gsR0FBRztBQUFBLFFBQ0gsU0FBUyxFQUFFLEdBQUcsYUFBYSxTQUFTLE1BQU0sU0FBUyxRQUFRLFdBQVcsS0FBSTtBQUFBLFFBQzFFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNoQjtBQUFBLElBQ1EsQ0FBQztBQUFBLElBQ0Q7QUFBQSxJQUNBO0FBQUEsSUFDQSxRQUFRO0FBQUEsSUFDUixHQUFJLHFCQUFxQixFQUFFLG1CQUFrQixJQUFLO0VBQzFEO0FBQ0ksU0FBTyx5QkFBeUIsWUFBWSxNQUFNO0FBQ3REO0FBQ0EsU0FBUyxJQUFJLEdBQUc7QUFDWixTQUFPLEtBQUssVUFBVSxDQUFDO0FBQzNCO0FBU0EsU0FBUyxZQUFZLElBQUk7QUFBRTtBQ2hmcEIsTUFBTSxzQ0FBc0MscUJBQXFCO0FBQUEsRUFDcEUsT0FBTyxtQkFBbUIsUUFBUTtBQUM5QixVQUFNLFNBQVMsSUFBSSw4QkFBOEIsSUFBSTtBQUNyRCxXQUFPLEtBQUssTUFBTSxPQUFPLG9CQUFvQixNQUFNLENBQUM7QUFDcEQsV0FBTztBQUFBLEVBQ1g7QUFBQTtBQUFBLEVBRUEsT0FBTyxhQUFhLFFBQVEsUUFBUSxTQUFTO0FBQ3pDLFVBQU0sU0FBUyxJQUFJLDhCQUE4QixJQUFJO0FBQ3JELFVBQU0sT0FBTztBQUFBLE1BQ1QsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLEdBQUcsU0FBUyxTQUFTLDZCQUE2QixlQUFjO0FBQUEsSUFDdkY7QUFDUSxXQUFPLEtBQUssTUFBTSxPQUFPLGNBQWMsUUFBUSxRQUFRLElBQUksQ0FBQztBQUM1RCxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsT0FBTyxTQUFTLFFBQVEsUUFBUSxTQUFTO0FBQ3JDLFVBQU0sU0FBUyxJQUFJO0FBQUE7QUFBQSxNQUVuQjtBQUFBLElBQU07QUFDTixVQUFNLE9BQU87QUFBQSxNQUNULEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxHQUFHLFNBQVMsU0FBUyw2QkFBNkIsV0FBVTtBQUFBLElBQ25GO0FBQ1EsV0FBTyxLQUFLLE1BQU0sT0FBTyxVQUFVLFFBQVEsUUFBUSxJQUFJLENBQUM7QUFDeEQsV0FBTztBQUFBLEVBQ1g7QUFDSjtvQkNsQk8sTUFBTS9DLHFCQUFvQixZQUFZO0FBQUEsRUFDekMsTUFBTSxNQUFNLFNBQVM7QUFDakIsdUJBQW1CLEtBQUssS0FBSztBQUM3QixXQUFPLEtBQUssUUFBUSxLQUFLLFlBQ3BCLE9BQU8sTUFBTTtBQUFBLE1BQ2QsR0FBRztBQUFBLE1BQ0gsU0FBUztBQUFBLFFBQ0wsR0FBRyxTQUFTO0FBQUEsUUFDWiw2QkFBNkI7QUFBQSxNQUM3QztBQUFBLElBQ0EsQ0FBUyxFQUNJLFlBQVksQ0FBQyxlQUFlLG9CQUFvQixZQUFZLElBQUksQ0FBQztBQUFBLEVBQzFFO0FBQUEsRUFDQSxhQUFhLE1BQU0sU0FBUztBQUN4QixRQUFJLEtBQUssUUFBUTtBQUNiLGFBQU8sOEJBQThCLGFBQWEsS0FBSyxTQUFTLE1BQU0sT0FBTztBQUFBLElBQ2pGO0FBQ0EsV0FBTyxxQkFBcUIsYUFBYSxLQUFLLFNBQVMsTUFBTSxPQUFPO0FBQUEsRUFDeEU7QUFBQSxFQUNBLFNBQVMsTUFBTSxTQUFTO0FBQ3BCLFFBQUksS0FBSyxRQUFRO0FBQ2IsYUFBTyw4QkFBOEIsU0FBUyxLQUFLLFNBQVMsTUFBTSxPQUFPO0FBQUEsSUFDN0U7QUFDQSxXQUFPLHFCQUFxQixTQUFTLEtBQUssU0FBUyxNQUFNLE9BQU87QUFBQSxFQUNwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxxQkFBcUIscUJBQXFCLEtBQUssU0FBUyxNQUFNLE9BQU87QUFBQSxFQUNoRjtBQUNKO0FDdENPLE1BQU1HLGNBQWEsWUFBWTtBQUFBLEVBQ2xDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLGNBQWMsSUFBSUQsY0FBMkIsS0FBSyxPQUFPO0FBQUEsRUFDbEU7QUFDSjtBQUFBLENBQ0MsU0FBVUMsT0FBTTtBQUNiLEVBQUFBLE1BQUssY0FBY0Q7QUFDdkIsR0FBR0MsVUFBU0EsUUFBTyxDQUFBLEVBQUc7QUNUZixNQUFNLGlCQUFpQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQnRDLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUssc0JBQXNCO0FBQUEsTUFDM0M7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQ0o7QUN2Qk8sTUFBTSw4QkFBOEIsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ0JuRCxPQUFPLE1BQU0sU0FBUztBQUNsQixXQUFPLEtBQUssUUFBUSxLQUFLLG9DQUFvQztBQUFBLE1BQ3pEO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUNKO0FDbkJPLE1BQU0saUJBQWlCLFlBQVk7QUFBQSxFQUN0QyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxXQUFXLElBQUk2QyxTQUFxQixLQUFLLE9BQU87QUFDckQsU0FBSyx3QkFBd0IsSUFBSUMsc0JBQStDLEtBQUssT0FBTztBQUFBLEVBQ2hHO0FBQ0o7QUFDQSxTQUFTLFdBQVc7QUFDcEIsU0FBUyx3QkFBd0I7QUNQMUIsTUFBTWhELGtCQUFpQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTXRDLE9BQU8sVUFBVSxNQUFNLFNBQVM7QUFDNUIsV0FBTyxLQUFLLFFBQVEsS0FBSyxZQUFZLFFBQVEsYUFBYTtBQUFBLE1BQ3REO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLFNBQVMsVUFBVSxXQUFXLFNBQVM7QUFDbkMsV0FBTyxLQUFLLFFBQVEsSUFBSSxZQUFZLFFBQVEsYUFBYSxTQUFTLElBQUk7QUFBQSxNQUNsRSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE9BQU8sVUFBVSxXQUFXLE1BQU0sU0FBUztBQUN2QyxXQUFPLEtBQUssUUFBUSxLQUFLLFlBQVksUUFBUSxhQUFhLFNBQVMsSUFBSTtBQUFBLE1BQ25FO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBLEVBQ0EsS0FBSyxVQUFVLFFBQVEsQ0FBQSxHQUFJLFNBQVM7QUFDaEMsUUFBSSxpQkFBaUIsS0FBSyxHQUFHO0FBQ3pCLGFBQU8sS0FBSyxLQUFLLFVBQVUsQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUN4QztBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcsWUFBWSxRQUFRLGFBQWEsY0FBYztBQUFBLE1BQzFFO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLElBQUksVUFBVSxXQUFXLFNBQVM7QUFDOUIsV0FBTyxLQUFLLFFBQVEsT0FBTyxZQUFZLFFBQVEsYUFBYSxTQUFTLElBQUk7QUFBQSxNQUNyRSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUNKO0FBQ08sTUFBTSxxQkFBcUIsV0FBVztBQUM3QztBQUNBQSxVQUFTLGVBQWU7QUM1RGpCLE1BQU0sY0FBYyxZQUFZO0FBQUEsRUFDbkMsU0FBUyxVQUFVLE9BQU8sUUFBUSxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ25ELFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssU0FBUyxVQUFVLE9BQU8sUUFBUSxDQUFBLEdBQUksS0FBSztBQUFBLElBQzNEO0FBQ0EsV0FBTyxLQUFLLFFBQVEsSUFBSSxZQUFZLFFBQVEsU0FBUyxLQUFLLFVBQVUsTUFBTSxJQUFJO0FBQUEsTUFDMUU7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUEsRUFDQSxLQUFLLFVBQVUsT0FBTyxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ3ZDLFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssS0FBSyxVQUFVLE9BQU8sQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUMvQztBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcsWUFBWSxRQUFRLFNBQVMsS0FBSyxVQUFVLGNBQWM7QUFBQSxNQUNyRjtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDMUUsQ0FBUztBQUFBLEVBQ0w7QUFDSjtBQUNPLE1BQU0scUJBQXFCLFdBQVc7QUFDN0M7QUFDQSxNQUFNLGVBQWU7YUNwQmQsTUFBTSxhQUFhLFlBQVk7QUFBQSxFQUNsQyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxRQUFRLElBQUlpRCxNQUFlLEtBQUssT0FBTztBQUFBLEVBQ2hEO0FBQUEsRUFDQSxPQUFPLFVBQVUsUUFBUSxTQUFTO0FBQzlCLFVBQU0sRUFBRSxTQUFTLEdBQUcsS0FBSSxJQUFLO0FBQzdCLFdBQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxRQUFRLFNBQVM7QUFBQSxNQUNsRCxPQUFPLEVBQUUsUUFBTztBQUFBLE1BQ2hCO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxNQUM5RCxRQUFRLE9BQU8sVUFBVTtBQUFBLElBQ3JDLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsU0FBUyxVQUFVLE9BQU8sU0FBUztBQUMvQixXQUFPLEtBQUssUUFBUSxJQUFJLFlBQVksUUFBUSxTQUFTLEtBQUssSUFBSTtBQUFBLE1BQzFELEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsT0FBTyxVQUFVLE9BQU8sTUFBTSxTQUFTO0FBQ25DLFdBQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxRQUFRLFNBQVMsS0FBSyxJQUFJO0FBQUEsTUFDM0Q7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUEsRUFDQSxLQUFLLFVBQVUsUUFBUSxDQUFBLEdBQUksU0FBUztBQUNoQyxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssVUFBVSxDQUFBLEdBQUksS0FBSztBQUFBLElBQ3hDO0FBQ0EsV0FBTyxLQUFLLFFBQVEsV0FBVyxZQUFZLFFBQVEsU0FBUyxVQUFVO0FBQUEsTUFDbEU7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsT0FBTyxVQUFVLE9BQU8sU0FBUztBQUM3QixXQUFPLEtBQUssUUFBUSxLQUFLLFlBQVksUUFBUSxTQUFTLEtBQUssV0FBVztBQUFBLE1BQ2xFLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxjQUFjLFVBQVUsTUFBTSxTQUFTO0FBQ3pDLFVBQU0sTUFBTSxNQUFNLEtBQUssT0FBTyxVQUFVLE1BQU0sT0FBTztBQUNyRCxXQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsSUFBSSxJQUFJLE9BQU87QUFBQSxFQUNwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLGdCQUFnQixVQUFVLE1BQU0sU0FBUztBQUNyQyxXQUFPLGdCQUFnQixzQkFBc0IsVUFBVSxLQUFLLFFBQVEsS0FBSyxRQUFRLE1BQU0sTUFBTSxPQUFPO0FBQUEsRUFDeEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLEtBQUssVUFBVSxPQUFPLFNBQVM7QUFDakMsVUFBTSxVQUFVLEVBQUUsR0FBRyxTQUFTLFNBQVMsMkJBQTJCLE9BQU07QUFDeEUsUUFBSSxTQUFTLGdCQUFnQjtBQUN6QixjQUFRLGtDQUFrQyxJQUFJLFFBQVEsZUFBZSxTQUFRO0FBQUEsSUFDakY7QUFDQSxXQUFPLE1BQU07QUFDVCxZQUFNLEVBQUUsTUFBTSxLQUFLLFNBQVEsSUFBSyxNQUFNLEtBQUssU0FBUyxVQUFVLE9BQU87QUFBQSxRQUNqRSxHQUFHO0FBQUEsUUFDSCxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsR0FBRyxRQUFPO0FBQUEsTUFDMUQsQ0FBYSxFQUFFLGFBQVk7QUFDZixjQUFRLElBQUksUUFBTTtBQUFBO0FBQUEsUUFFZCxLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQ0QsY0FBSSxnQkFBZ0I7QUFDcEIsY0FBSSxTQUFTLGdCQUFnQjtBQUN6Qiw0QkFBZ0IsUUFBUTtBQUFBLFVBQzVCLE9BQ0s7QUFDRCxrQkFBTSxpQkFBaUIsU0FBUyxRQUFRLElBQUksc0JBQXNCO0FBQ2xFLGdCQUFJLGdCQUFnQjtBQUNoQixvQkFBTSxtQkFBbUIsU0FBUyxjQUFjO0FBQ2hELGtCQUFJLENBQUMsTUFBTSxnQkFBZ0IsR0FBRztBQUMxQixnQ0FBZ0I7QUFBQSxjQUNwQjtBQUFBLFlBQ0o7QUFBQSxVQUNKO0FBQ0EsZ0JBQU0sTUFBTSxhQUFhO0FBQ3pCO0FBQUE7QUFBQSxRQUVKLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDRCxpQkFBTztBQUFBLE1BQzNCO0FBQUEsSUFDUTtBQUFBLEVBQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLE9BQU8sVUFBVSxNQUFNLFNBQVM7QUFDNUIsV0FBTyxnQkFBZ0Isc0JBQXNCLFVBQVUsS0FBSyxRQUFRLEtBQUssUUFBUSxNQUFNLE1BQU0sT0FBTztBQUFBLEVBQ3hHO0FBQUEsRUFDQSxrQkFBa0IsVUFBVSxPQUFPLE1BQU0sU0FBUztBQUM5QyxXQUFPLEtBQUssUUFBUSxLQUFLLFlBQVksUUFBUSxTQUFTLEtBQUssd0JBQXdCO0FBQUEsTUFDL0U7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLE1BQzlELFFBQVEsS0FBSyxVQUFVO0FBQUEsSUFDbkMsQ0FBUztBQUFBLEVBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLHlCQUF5QixVQUFVLE9BQU8sTUFBTSxTQUFTO0FBQzNELFVBQU0sTUFBTSxNQUFNLEtBQUssa0JBQWtCLFVBQVUsT0FBTyxNQUFNLE9BQU87QUFDdkUsV0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVLElBQUksSUFBSSxPQUFPO0FBQUEsRUFDcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSx3QkFBd0IsVUFBVSxPQUFPLE1BQU0sU0FBUztBQUNwRCxXQUFPLGdCQUFnQiwwQkFBMEIsVUFBVSxPQUFPLEtBQUssUUFBUSxLQUFLLFFBQVEsTUFBTSxNQUFNLE9BQU87QUFBQSxFQUNuSDtBQUNKO0FBQ08sTUFBTSxpQkFBaUIsV0FBVztBQUN6QztBQUNBQyxPQUFLLFdBQVc7QUFDaEJBLE9BQUssUUFBUTtBQUNiQSxPQUFLLGVBQWU7QUM5SmIsTUFBTSxnQkFBZ0IsWUFBWTtBQUFBLEVBQ3JDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLE9BQU8sSUFBSUMsT0FBYSxLQUFLLE9BQU87QUFDekMsU0FBSyxXQUFXLElBQUlyRCxVQUFxQixLQUFLLE9BQU87QUFBQSxFQUN6RDtBQUFBLEVBQ0EsT0FBTyxPQUFPLENBQUEsR0FBSSxTQUFTO0FBQ3ZCLFFBQUksaUJBQWlCLElBQUksR0FBRztBQUN4QixhQUFPLEtBQUssT0FBTyxDQUFBLEdBQUksSUFBSTtBQUFBLElBQy9CO0FBQ0EsV0FBTyxLQUFLLFFBQVEsS0FBSyxZQUFZO0FBQUEsTUFDakM7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsU0FBUyxVQUFVLFNBQVM7QUFDeEIsV0FBTyxLQUFLLFFBQVEsSUFBSSxZQUFZLFFBQVEsSUFBSTtBQUFBLE1BQzVDLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsT0FBTyxVQUFVLE1BQU0sU0FBUztBQUM1QixXQUFPLEtBQUssUUFBUSxLQUFLLFlBQVksUUFBUSxJQUFJO0FBQUEsTUFDN0M7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsSUFBSSxVQUFVLFNBQVM7QUFDbkIsV0FBTyxLQUFLLFFBQVEsT0FBTyxZQUFZLFFBQVEsSUFBSTtBQUFBLE1BQy9DLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUEsRUFDQSxhQUFhLE1BQU0sU0FBUztBQUN4QixXQUFPLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtBQUFBLE1BQ3RDO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxNQUM5RCxRQUFRLEtBQUssVUFBVTtBQUFBLElBQ25DLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxpQkFBaUIsTUFBTSxTQUFTO0FBQ2xDLFVBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxNQUFNLE9BQU87QUFDakQsV0FBTyxNQUFNLEtBQUssS0FBSyxLQUFLLElBQUksV0FBVyxJQUFJLElBQUksT0FBTztBQUFBLEVBQzlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxtQkFBbUIsTUFBTSxTQUFTO0FBQzlCLFdBQU8sZ0JBQWdCLDRCQUE0QixNQUFNLEtBQUssUUFBUSxLQUFLLFNBQVMsT0FBTztBQUFBLEVBQy9GO0FBQ0o7QUFDQSxRQUFRLE9BQU9vRDtBQUNmLFFBQVEsV0FBVztBQUNuQixRQUFRLFdBQVdsRDtBQUNuQixRQUFRLGVBQWU7QUM5RWhCLE1BQU0sYUFBYSxZQUFZO0FBQUEsRUFDbEMsY0FBYztBQUNWLFVBQU0sR0FBRyxTQUFTO0FBQ2xCLFNBQUssV0FBVyxJQUFJb0QsU0FBcUIsS0FBSyxPQUFPO0FBQ3JELFNBQUssT0FBTyxJQUFJQyxNQUFhLEtBQUssT0FBTztBQUN6QyxTQUFLLGFBQWEsSUFBSUMsV0FBeUIsS0FBSyxPQUFPO0FBQzNELFNBQUssVUFBVSxJQUFJQyxRQUFtQixLQUFLLE9BQU87QUFBQSxFQUN0RDtBQUNKO0FBQ0EsS0FBSyxXQUFXO0FBQ2hCLEtBQUssYUFBYTtBQUNsQixLQUFLLGlCQUFpQjtBQUN0QixLQUFLLFVBQVU7QUNwQlIsTUFBTXhELHFCQUFvQixZQUFZO0FBQUEsRUFDekMsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxLQUFLLFFBQVEsS0FBSyxnQkFBZ0IsRUFBRSxNQUFNLEdBQUcsU0FBUyxRQUFRLEtBQUssVUFBVSxNQUFLLENBQUU7QUFBQSxFQUMvRjtBQUNKO0FDSk8sTUFBTSxnQkFBZ0IsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSXJDLFNBQVMsYUFBYSxRQUFRLFNBQVM7QUFDbkMsV0FBTyxLQUFLLFFBQVEsSUFBSSxlQUFlLFdBQVcsVUFBVSxNQUFNLFlBQVk7QUFBQSxNQUMxRSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsUUFBUSxzQkFBc0IsR0FBRyxTQUFTLFFBQU87QUFBQSxNQUM1RCxrQkFBa0I7QUFBQSxJQUM5QixDQUFTO0FBQUEsRUFDTDtBQUNKO2NDTk8sTUFBTSxjQUFjLFlBQVk7QUFBQSxFQUNuQyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxVQUFVLElBQUl5RCxRQUFtQixLQUFLLE9BQU87QUFBQSxFQUN0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsT0FBTyxhQUFhLE1BQU0sU0FBUztBQUMvQixXQUFPLEtBQUssUUFBUSxLQUFLLGVBQWUsV0FBVyxVQUFVckQsNEJBQWlDLEVBQUUsTUFBTSxHQUFHLFFBQU8sQ0FBRSxDQUFDO0FBQUEsRUFDdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFNBQVMsYUFBYSxRQUFRLFNBQVM7QUFDbkMsV0FBTyxLQUFLLFFBQVEsSUFBSSxlQUFlLFdBQVcsVUFBVSxNQUFNLElBQUksT0FBTztBQUFBLEVBQ2pGO0FBQUEsRUFDQSxLQUFLLGFBQWEsUUFBUSxDQUFBLEdBQUksU0FBUztBQUNuQyxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssYUFBYSxDQUFBLEdBQUksS0FBSztBQUFBLElBQzNDO0FBQ0EsV0FBTyxLQUFLLFFBQVEsV0FBVyxlQUFlLFdBQVcsVUFBVSx1QkFBdUI7QUFBQSxNQUN0RjtBQUFBLE1BQ0EsR0FBRztBQUFBLElBQ2YsQ0FBUztBQUFBLEVBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLElBQUksYUFBYSxRQUFRLFNBQVM7QUFDOUIsV0FBTyxLQUFLLFFBQVEsT0FBTyxlQUFlLFdBQVcsVUFBVSxNQUFNLElBQUk7QUFBQSxNQUNyRSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsUUFBUSxPQUFPLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDekQsQ0FBUztBQUFBLEVBQ0w7QUFDSjtBQUNPLE1BQU0sOEJBQThCLFdBQVc7QUFDdEQ7QUFDQXNELFFBQU0sd0JBQXdCO0FBQzlCQSxRQUFNLFVBQVU7QUMzQ1QsTUFBTSxtQkFBbUIsWUFBWTtBQUFBLEVBQ3hDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLFFBQVEsSUFBSUMsUUFBZSxLQUFLLE9BQU87QUFBQSxFQUNoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxLQUFLLFFBQVEsS0FBSyxlQUFlLEVBQUUsTUFBTSxHQUFHLFNBQVM7QUFBQSxFQUNoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsU0FBUyxhQUFhLFNBQVM7QUFDM0IsV0FBTyxLQUFLLFFBQVEsSUFBSSxlQUFlLFdBQVcsSUFBSSxPQUFPO0FBQUEsRUFDakU7QUFBQSxFQUNBLEtBQUssUUFBUSxDQUFBLEdBQUksU0FBUztBQUN0QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUM5QjtBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcsZUFBZSw0QkFBNEIsRUFBRSxPQUFPLEdBQUcsU0FBUztBQUFBLEVBQ25HO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxJQUFJLGFBQWEsU0FBUztBQUN0QixXQUFPLEtBQUssUUFBUSxPQUFPLGVBQWUsV0FBVyxJQUFJO0FBQUEsTUFDckQsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLFFBQVEsT0FBTyxHQUFHLFNBQVMsUUFBTztBQUFBLElBQ3pELENBQVM7QUFBQSxFQUNMO0FBQ0o7QUFDTyxNQUFNLG1DQUFtQyxXQUFXO0FBQzNEO0FBQ0EsV0FBVyw2QkFBNkI7QUFDeEMsV0FBVyxRQUFRRDtBQUNuQixXQUFXLHdCQUF3QjtBQ3hDNUIsTUFBTSxtQkFBbUIsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBYXhDLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFVBQU0sZ0NBQWdDLENBQUMsQ0FBQyxLQUFLO0FBRzdDLFFBQUksa0JBQWtCLGdDQUFnQyxLQUFLLGtCQUFrQjtBQUM3RSxRQUFJLCtCQUErQjtBQUMvQkUsWUFBVyxXQUFXLGlDQUFpQyxLQUFLLGVBQWU7QUFBQSxJQUMvRTtBQUNBLFVBQU0sV0FBVyxLQUFLLFFBQVEsS0FBSyxlQUFlO0FBQUEsTUFDOUMsTUFBTTtBQUFBLFFBQ0YsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNoQjtBQUFBLE1BQ1ksR0FBRztBQUFBLElBQ2YsQ0FBUztBQUVELFFBQUksK0JBQStCO0FBQy9CLGFBQU87QUFBQSxJQUNYO0FBS0FBLFVBQVcsWUFBWSw2Q0FBNkM7QUFDcEUsV0FBTyxTQUFTLFlBQVksQ0FBQ0MsY0FBYTtBQUN0QyxVQUFJQSxhQUFZQSxVQUFTLE1BQU07QUFDM0IsUUFBQUEsVUFBUyxLQUFLLFFBQVEsQ0FBQyx1QkFBdUI7QUFDMUMsZ0JBQU0scUJBQXFCLG1CQUFtQjtBQUM5Qyw2QkFBbUIsWUFBWUMsZUFBb0Isa0JBQWtCO0FBQUEsUUFDekUsQ0FBQztBQUFBLE1BQ0w7QUFDQSxhQUFPRDtBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFDSjtBQzlDTyxNQUFNLG9CQUFvQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJekMsU0FBUyxRQUFRLE9BQU8sY0FBYyxTQUFTO0FBQzNDLFdBQU8sS0FBSyxRQUFRLElBQUksVUFBVSxNQUFNLFNBQVMsS0FBSyxpQkFBaUIsWUFBWSxJQUFJLE9BQU87QUFBQSxFQUNsRztBQUFBLEVBQ0EsS0FBSyxRQUFRLE9BQU8sUUFBUSxDQUFBLEdBQUksU0FBUztBQUNyQyxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssUUFBUSxPQUFPLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDN0M7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTLEtBQUssaUJBQWlCLDZCQUE2QixFQUFFLE9BQU8sR0FBRyxRQUFPLENBQUU7QUFBQSxFQUNwSTtBQUNKO0FBQ08sTUFBTSxvQ0FBb0MsV0FBVztBQUM1RDtBQUNBLFlBQVksOEJBQThCO0FDZG5DLE1BQU1WLGNBQWEsWUFBWTtBQUFBLEVBQ2xDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLGNBQWMsSUFBSVksWUFBMkIsS0FBSyxPQUFPO0FBQUEsRUFDbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxPQUFPLFFBQVEsTUFBTSxTQUFTO0FBQzFCLFdBQU8sS0FBSyxRQUFRLEtBQUssVUFBVSxNQUFNLFNBQVMsRUFBRSxNQUFNLEdBQUcsUUFBTyxDQUFFO0FBQUEsRUFDMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFNBQVMsUUFBUSxPQUFPLFNBQVM7QUFDN0IsV0FBTyxLQUFLLFFBQVEsSUFBSSxVQUFVLE1BQU0sU0FBUyxLQUFLLElBQUksT0FBTztBQUFBLEVBQ3JFO0FBQUEsRUFDQSxLQUFLLFFBQVEsUUFBUSxDQUFBLEdBQUksU0FBUztBQUM5QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssUUFBUSxDQUFBLEdBQUksS0FBSztBQUFBLElBQ3RDO0FBQ0EsV0FBTyxLQUFLLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUyxzQkFBc0IsRUFBRSxPQUFPLEdBQUcsUUFBTyxDQUFFO0FBQUEsRUFDdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLElBQUksUUFBUSxPQUFPLFNBQVM7QUFDeEIsV0FBTyxLQUFLLFFBQVEsT0FBTyxVQUFVLE1BQU0sU0FBUyxLQUFLLElBQUksT0FBTztBQUFBLEVBQ3hFO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxPQUFPLFFBQVEsT0FBTyxTQUFTO0FBQzNCLFdBQU8sS0FBSyxRQUFRLEtBQUssVUFBVSxNQUFNLFNBQVMsS0FBSyxJQUFJLE9BQU87QUFBQSxFQUN0RTtBQUNKO0FBQ08sTUFBTSw2QkFBNkIsV0FBVztBQUNyRDtBQUNBWixNQUFLLHVCQUF1QjtBQUM1QkEsTUFBSyxjQUFjO0FBQ25CQSxNQUFLLDhCQUE4QjtBQzFDNUIsTUFBTSxjQUFjLFlBQVk7QUFBQSxFQUNuQyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxPQUFPLElBQUlDLE1BQWEsS0FBSyxPQUFPO0FBQUEsRUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFPLE1BQU0sU0FBUztBQUNsQixXQUFPLEtBQUssUUFBUSxLQUFLLFVBQVUsRUFBRSxNQUFNLEdBQUcsU0FBUztBQUFBLEVBQzNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxTQUFTLFFBQVEsU0FBUztBQUN0QixXQUFPLEtBQUssUUFBUSxJQUFJLFVBQVUsTUFBTSxJQUFJLE9BQU87QUFBQSxFQUN2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxRQUFRLE1BQU0sU0FBUztBQUMxQixXQUFPLEtBQUssUUFBUSxLQUFLLFVBQVUsTUFBTSxJQUFJLEVBQUUsTUFBTSxHQUFHLFNBQVM7QUFBQSxFQUNyRTtBQUFBLEVBQ0EsS0FBSyxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ3RCLFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssS0FBSyxDQUFBLEdBQUksS0FBSztBQUFBLElBQzlCO0FBQ0EsV0FBTyxLQUFLLFFBQVEsV0FBVyxVQUFVLHVCQUF1QixFQUFFLE9BQU8sR0FBRyxTQUFTO0FBQUEsRUFDekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLElBQUksUUFBUSxTQUFTO0FBQ2pCLFdBQU8sS0FBSyxRQUFRLE9BQU8sVUFBVSxNQUFNLElBQUksT0FBTztBQUFBLEVBQzFEO0FBQ0o7QUFDTyxNQUFNLDhCQUE4QixXQUFXO0FBQ3REO0FBQ0EsTUFBTSx3QkFBd0I7QUFDOUIsTUFBTSxPQUFPRDtBQUNiLE1BQU0sdUJBQXVCO2NDNUN0QixNQUFNTyxlQUFjLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3Qm5DLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUssVUFBVXRELDRCQUFpQyxFQUFFLE1BQU0sR0FBRyxRQUFPLENBQUUsQ0FBQztBQUFBLEVBQzdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxTQUFTLFFBQVEsU0FBUztBQUN0QixXQUFPLEtBQUssUUFBUSxJQUFJLFVBQVUsTUFBTSxJQUFJLE9BQU87QUFBQSxFQUN2RDtBQUFBLEVBQ0EsS0FBSyxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ3RCLFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssS0FBSyxDQUFBLEdBQUksS0FBSztBQUFBLElBQzlCO0FBQ0EsV0FBTyxLQUFLLFFBQVEsV0FBVyxVQUFVLGlCQUFpQixFQUFFLE9BQU8sR0FBRyxTQUFTO0FBQUEsRUFDbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLElBQUksUUFBUSxTQUFTO0FBQ2pCLFdBQU8sS0FBSyxRQUFRLE9BQU8sVUFBVSxNQUFNLElBQUksT0FBTztBQUFBLEVBQzFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxRQUFRLFFBQVEsU0FBUztBQUNyQixXQUFPLEtBQUssUUFBUSxJQUFJLFVBQVUsTUFBTSxZQUFZO0FBQUEsTUFDaEQsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLFFBQVEsc0JBQXNCLEdBQUcsU0FBUyxRQUFPO0FBQUEsTUFDNUQsa0JBQWtCO0FBQUEsSUFDOUIsQ0FBUztBQUFBLEVBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxnQkFBZ0IsUUFBUSxTQUFTO0FBQzdCLFdBQU8sS0FBSyxRQUFRLElBQUksVUFBVSxNQUFNLFlBQVksT0FBTztBQUFBLEVBQy9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxNQUFNLGtCQUFrQixJQUFJLEVBQUUsZUFBZSxLQUFNLFVBQVUsS0FBSyxLQUFLLElBQUksSUFBSyxJQUFJO0FBQ2hGLFVBQU0sa0JBQWtCLG9CQUFJLElBQUksQ0FBQyxhQUFhLFNBQVMsU0FBUyxDQUFDO0FBQ2pFLFVBQU0sUUFBUSxLQUFLLElBQUc7QUFDdEIsUUFBSSxPQUFPLE1BQU0sS0FBSyxTQUFTLEVBQUU7QUFDakMsV0FBTyxDQUFDLEtBQUssVUFBVSxDQUFDLGdCQUFnQixJQUFJLEtBQUssTUFBTSxHQUFHO0FBQ3RELFlBQU0sTUFBTSxZQUFZO0FBQ3hCLGFBQU8sTUFBTSxLQUFLLFNBQVMsRUFBRTtBQUM3QixVQUFJLEtBQUssUUFBUSxRQUFRLFNBQVM7QUFDOUIsY0FBTSxJQUFJLDBCQUEwQjtBQUFBLFVBQ2hDLFNBQVMsaUNBQWlDLEVBQUUsK0JBQStCLE9BQU87QUFBQSxRQUN0RyxDQUFpQjtBQUFBLE1BQ0w7QUFBQSxJQUNKO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDSjtBQUNPLE1BQU0sd0JBQXdCLFdBQVc7QUFDaEQ7QUFDQXNELFFBQU0sa0JBQWtCO0FDekZqQixNQUFNLGdCQUFnQixZQUFZO0FBQ3pDO2dCQ0RPLE1BQU0sZ0JBQWdCLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CckMsSUFBSSxNQUFNLFNBQVM7QUFDZixXQUFPLEtBQUssUUFBUSxLQUFLLGtDQUFrQyxFQUFFLE1BQU0sR0FBRyxTQUFTO0FBQUEsRUFDbkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQkEsU0FBUyxNQUFNLFNBQVM7QUFDcEIsV0FBTyxLQUFLLFFBQVEsS0FBSyx1Q0FBdUMsRUFBRSxNQUFNLEdBQUcsU0FBUztBQUFBLEVBQ3hGO0FBQ0o7QUN4Q08sTUFBTSxjQUFjLFlBQVk7QUFBQSxFQUNuQyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxVQUFVLElBQUlNLFVBQW1CLEtBQUssT0FBTztBQUFBLEVBQ3REO0FBQ0o7QUFDQSxNQUFNLFVBQVVDO0FDTlQsTUFBTSxvQkFBb0IsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtCekMsT0FBTywwQkFBMEIsTUFBTSxTQUFTO0FBQzVDLFdBQU8sS0FBSyxRQUFRLFdBQVcsNEJBQTRCLHdCQUF3QixnQkFBZ0IsK0JBQStCLEVBQUUsTUFBTSxRQUFRLFFBQVEsR0FBRyxRQUFPLENBQUU7QUFBQSxFQUMxSztBQUFBLEVBQ0EsU0FBUywwQkFBMEIsUUFBUSxDQUFBLEdBQUksU0FBUztBQUNwRCxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLFNBQVMsMEJBQTBCLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDNUQ7QUFDQSxXQUFPLEtBQUssUUFBUSxJQUFJLDRCQUE0Qix3QkFBd0IsZ0JBQWdCO0FBQUEsTUFDeEY7QUFBQSxNQUNBLEdBQUc7QUFBQSxJQUNmLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkEsSUFBSSwwQkFBMEIsY0FBYyxTQUFTO0FBQ2pELFdBQU8sS0FBSyxRQUFRLE9BQU8sNEJBQTRCLHdCQUF3QixnQkFBZ0IsWUFBWSxJQUFJLE9BQU87QUFBQSxFQUMxSDtBQUNKO0FBSU8sTUFBTSxzQ0FBc0MsS0FBSztBQUN4RDtBQUNBLFlBQVksZ0NBQWdDO29CQ3REckMsTUFBTSxvQkFBb0IsWUFBWTtBQUFBLEVBQ3pDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLGNBQWMsSUFBSUMsWUFBMkIsS0FBSyxPQUFPO0FBQUEsRUFDbEU7QUFDSjtBQUNBQyxjQUFZLGNBQWM7QUFDMUJBLGNBQVksZ0NBQWdDO0FDUHJDLE1BQU1BLHFCQUFvQixZQUFZO0FBQUEsRUFDekMsS0FBSyxpQkFBaUIsUUFBUSxDQUFBLEdBQUksU0FBUztBQUN2QyxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssaUJBQWlCLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDL0M7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLHFCQUFxQixlQUFlLGdCQUFnQiw4QkFBOEIsRUFBRSxPQUFPLEdBQUcsUUFBTyxDQUFFO0FBQUEsRUFDMUk7QUFDSjtBQUNPLE1BQU0scUNBQXFDLFdBQVc7QUFDN0Q7QUFDQUEsYUFBWSwrQkFBK0I7QUNScEMsTUFBTSxhQUFhLFlBQVk7QUFBQSxFQUNsQyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxjQUFjLElBQUlDLGFBQTJCLEtBQUssT0FBTztBQUFBLEVBQ2xFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0JBLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUsscUJBQXFCLEVBQUUsTUFBTSxHQUFHLFNBQVM7QUFBQSxFQUN0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBYUEsU0FBUyxpQkFBaUIsU0FBUztBQUMvQixXQUFPLEtBQUssUUFBUSxJQUFJLHFCQUFxQixlQUFlLElBQUksT0FBTztBQUFBLEVBQzNFO0FBQUEsRUFDQSxLQUFLLFFBQVEsQ0FBQSxHQUFJLFNBQVM7QUFDdEIsUUFBSSxpQkFBaUIsS0FBSyxHQUFHO0FBQ3pCLGFBQU8sS0FBSyxLQUFLLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDOUI7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLHFCQUFxQixvQkFBb0IsRUFBRSxPQUFPLEdBQUcsU0FBUztBQUFBLEVBQ2pHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBLE9BQU8saUJBQWlCLFNBQVM7QUFDN0IsV0FBTyxLQUFLLFFBQVEsS0FBSyxxQkFBcUIsZUFBZSxXQUFXLE9BQU87QUFBQSxFQUNuRjtBQUFBLEVBQ0EsV0FBVyxpQkFBaUIsUUFBUSxDQUFBLEdBQUksU0FBUztBQUM3QyxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLFdBQVcsaUJBQWlCLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDckQ7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLHFCQUFxQixlQUFlLFdBQVcseUJBQXlCO0FBQUEsTUFDbkc7QUFBQSxNQUNBLEdBQUc7QUFBQSxJQUNmLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBLE1BQU0saUJBQWlCLFNBQVM7QUFDNUIsV0FBTyxLQUFLLFFBQVEsS0FBSyxxQkFBcUIsZUFBZSxVQUFVLE9BQU87QUFBQSxFQUNsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXQSxPQUFPLGlCQUFpQixTQUFTO0FBQzdCLFdBQU8sS0FBSyxRQUFRLEtBQUsscUJBQXFCLGVBQWUsV0FBVyxPQUFPO0FBQUEsRUFDbkY7QUFDSjtBQUNPLE1BQU0sMkJBQTJCLFdBQVc7QUFDbkQ7QUFDTyxNQUFNLGdDQUFnQyxXQUFXO0FBQ3hEO0FBQ0EsS0FBSyxxQkFBcUI7QUFDMUIsS0FBSywwQkFBMEI7QUFDL0IsS0FBSyxjQUFjRDtBQUNuQixLQUFLLCtCQUErQjtBQ2xHN0IsTUFBTSxtQkFBbUIsWUFBWTtBQUFBLEVBQ3hDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLFVBQVUsSUFBSUUsUUFBbUIsS0FBSyxPQUFPO0FBQ2xELFNBQUssT0FBTyxJQUFJQyxLQUFhLEtBQUssT0FBTztBQUN6QyxTQUFLLGNBQWMsSUFBSUYsY0FBMkIsS0FBSyxPQUFPO0FBQzlELFNBQUssUUFBUSxJQUFJRyxNQUFlLEtBQUssT0FBTztBQUFBLEVBQ2hEO0FBQ0o7QUFDQSxXQUFXLFVBQVU7QUFDckIsV0FBVyxPQUFPO0FBQ2xCLFdBQVcscUJBQXFCO0FBQ2hDLFdBQVcsMEJBQTBCO0FBQ3JDLFdBQVcsY0FBY0o7QUFDekIsV0FBVyxRQUFRO0FDdEJaLE1BQU0scUJBQXFCLFlBQVk7QUFDOUM7QUNDTyxNQUFNRixpQkFBZ0IsWUFBWTtBQUFBLEVBQ3JDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLGVBQWUsSUFBSU8sYUFBNkIsS0FBSyxPQUFPO0FBQUEsRUFDckU7QUFDSjtBQUNBUCxTQUFRLGVBQWU7QUNQaEIsTUFBTSxlQUFlLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV3BDLGdCQUFnQixNQUFNLFNBQVM7QUFDM0IsV0FBTyxLQUFLLFFBQVEsS0FBSyxzQkFBc0I3RCw0QkFBaUMsRUFBRSxNQUFNLEdBQUcsUUFBTyxDQUFFLENBQUM7QUFBQSxFQUN6RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBYUEsS0FBSyxNQUFNLFNBQVM7QUFDaEIsV0FBTyxLQUFLLFFBQVEsS0FBSyxpQkFBaUJBLDRCQUFpQyxFQUFFLE1BQU0sR0FBRyxRQUFPLENBQUUsQ0FBQztBQUFBLEVBQ3BHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUEsU0FBUyxNQUFNLFNBQVM7QUFDcEIsV0FBTyxLQUFLLFFBQVEsS0FBSyx1QkFBdUIsRUFBRSxNQUFNLEdBQUcsU0FBUztBQUFBLEVBQ3hFO0FBQ0o7QUMzQ08sTUFBTSxlQUFlLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS3BDLFNBQVMsT0FBTyxTQUFTO0FBQ3JCLFdBQU8sS0FBSyxRQUFRLElBQUksV0FBVyxLQUFLLElBQUksT0FBTztBQUFBLEVBQ3ZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLEtBQUssU0FBUztBQUNWLFdBQU8sS0FBSyxRQUFRLFdBQVcsV0FBVyxZQUFZLE9BQU87QUFBQSxFQUNqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxJQUFJLE9BQU8sU0FBUztBQUNoQixXQUFPLEtBQUssUUFBUSxPQUFPLFdBQVcsS0FBSyxJQUFJLE9BQU87QUFBQSxFQUMxRDtBQUNKO0FBSU8sTUFBTSxtQkFBbUIsS0FBSztBQUNyQztBQUNBLE9BQU8sYUFBYTtBQzdCYixNQUFNLG9CQUFvQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUt6QyxPQUFPLE1BQU0sU0FBUztBQUNsQixXQUFPLEtBQUssUUFBUSxLQUFLLGdCQUFnQixFQUFFLE1BQU0sR0FBRyxTQUFTO0FBQUEsRUFDakU7QUFDSjtBQ1JPLFNBQVMsbUJBQW1CLFVBQVUsUUFBUTtBQUNqRCxNQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixNQUFNLEdBQUc7QUFDM0MsV0FBTztBQUFBLE1BQ0gsR0FBRztBQUFBLE1BQ0gsZUFBZTtBQUFBLE1BQ2YsUUFBUSxTQUFTLE9BQU8sSUFBSSxDQUFDLFNBQVM7QUFDbEMsWUFBSSxLQUFLLFNBQVMsaUJBQWlCO0FBQy9CLGlCQUFPO0FBQUEsWUFDSCxHQUFHO0FBQUEsWUFDSCxrQkFBa0I7QUFBQSxVQUMxQztBQUFBLFFBQ2dCO0FBQ0EsWUFBSSxLQUFLLFNBQVMsV0FBVztBQUN6QixpQkFBTztBQUFBLFlBQ0gsR0FBRztBQUFBLFlBQ0gsU0FBUyxLQUFLLFFBQVEsSUFBSSxDQUFDLGFBQWE7QUFBQSxjQUNwQyxHQUFHO0FBQUEsY0FDSCxRQUFRO0FBQUEsWUFDcEMsRUFBMEI7QUFBQSxVQUMxQjtBQUFBLFFBQ2dCLE9BQ0s7QUFDRCxpQkFBTztBQUFBLFFBQ1g7QUFBQSxNQUNKLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDSTtBQUNBLFNBQU8sY0FBYyxVQUFVLE1BQU07QUFDekM7QUFDTyxTQUFTLGNBQWMsVUFBVSxRQUFRO0FBQzVDLFFBQU0sU0FBUyxTQUFTLE9BQU8sSUFBSSxDQUFDLFNBQVM7QUFDekMsUUFBSSxLQUFLLFNBQVMsaUJBQWlCO0FBQy9CLGFBQU87QUFBQSxRQUNILEdBQUc7QUFBQSxRQUNILGtCQUFrQixjQUFjLFFBQVEsSUFBSTtBQUFBLE1BQzVEO0FBQUEsSUFDUTtBQUNBLFFBQUksS0FBSyxTQUFTLFdBQVc7QUFDekIsWUFBTSxVQUFVLEtBQUssUUFBUSxJQUFJLENBQUNvQixhQUFZO0FBQzFDLFlBQUlBLFNBQVEsU0FBUyxlQUFlO0FBQ2hDLGlCQUFPO0FBQUEsWUFDSCxHQUFHQTtBQUFBLFlBQ0gsUUFBUSxnQkFBZ0IsUUFBUUEsU0FBUSxJQUFJO0FBQUEsVUFDcEU7QUFBQSxRQUNnQjtBQUNBLGVBQU9BO0FBQUEsTUFDWCxDQUFDO0FBQ0QsYUFBTztBQUFBLFFBQ0gsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNoQjtBQUFBLElBQ1E7QUFDQSxXQUFPO0FBQUEsRUFDWCxDQUFDO0FBQ0QsUUFBTSxTQUFTLE9BQU8sT0FBTyxDQUFBLEdBQUksVUFBVSxFQUFFLFFBQVE7QUFDckQsTUFBSSxDQUFDLE9BQU8seUJBQXlCLFVBQVUsYUFBYSxHQUFHO0FBQzNELGtCQUFjLE1BQU07QUFBQSxFQUN4QjtBQUNBLFNBQU8sZUFBZSxRQUFRLGlCQUFpQjtBQUFBLElBQzNDLFlBQVk7QUFBQSxJQUNaLE1BQU07QUFDRixpQkFBV2lELFdBQVUsT0FBTyxRQUFRO0FBQ2hDLFlBQUlBLFFBQU8sU0FBUyxXQUFXO0FBQzNCO0FBQUEsUUFDSjtBQUNBLG1CQUFXLFdBQVdBLFFBQU8sU0FBUztBQUNsQyxjQUFJLFFBQVEsU0FBUyxpQkFBaUIsUUFBUSxXQUFXLE1BQU07QUFDM0QsbUJBQU8sUUFBUTtBQUFBLFVBQ25CO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ1IsQ0FBSztBQUNELFNBQU87QUFDWDtBQUNBLFNBQVMsZ0JBQWdCLFFBQVEsU0FBUztBQUN0QyxNQUFJLE9BQU8sTUFBTSxRQUFRLFNBQVMsZUFBZTtBQUM3QyxXQUFPO0FBQUEsRUFDWDtBQUNBLE1BQUksZUFBZSxPQUFPLE1BQU0sUUFBUTtBQUNwQyxVQUFNLGNBQWMsT0FBTyxNQUFNO0FBQ2pDLFdBQU8sWUFBWSxVQUFVLE9BQU87QUFBQSxFQUN4QztBQUNBLFNBQU8sS0FBSyxNQUFNLE9BQU87QUFDN0I7QUFDTyxTQUFTLHNCQUFzQixRQUFRO0FBQzFDLE1BQUksNkJBQTZCLE9BQU8sTUFBTSxNQUFNLEdBQUc7QUFDbkQsV0FBTztBQUFBLEVBQ1g7QUFDQSxTQUFPO0FBQ1g7QUFtQk8sU0FBUyxtQkFBbUIsTUFBTTtBQUNyQyxTQUFPLE9BQU8sUUFBUSxNQUFNO0FBQ2hDO0FBQ0EsU0FBUyxtQkFBbUIsYUFBYSxNQUFNO0FBQzNDLFNBQU8sWUFBWSxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsY0FBYyxLQUFLLFNBQVMsSUFBSTtBQUNwRjtBQUNBLFNBQVMsY0FBYyxRQUFRLFVBQVU7QUFDckMsUUFBTSxZQUFZLG1CQUFtQixPQUFPLFNBQVMsQ0FBQSxHQUFJLFNBQVMsSUFBSTtBQUN0RSxTQUFPO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsSUFDSCxrQkFBa0IsbUJBQW1CLFNBQVMsSUFBSSxVQUFVLFVBQVUsU0FBUyxTQUFTLElBQ2xGLFdBQVcsU0FBUyxLQUFLLE1BQU0sU0FBUyxTQUFTLElBQzdDO0FBQUEsRUFDbEI7QUFDQTtBQWtCTyxTQUFTLGNBQWMsS0FBSztBQUMvQixRQUFNLFFBQVEsQ0FBQTtBQUNkLGFBQVcsVUFBVSxJQUFJLFFBQVE7QUFDN0IsUUFBSSxPQUFPLFNBQVMsV0FBVztBQUMzQjtBQUFBLElBQ0o7QUFDQSxlQUFXLFdBQVcsT0FBTyxTQUFTO0FBQ2xDLFVBQUksUUFBUSxTQUFTLGVBQWU7QUFDaEMsY0FBTSxLQUFLLFFBQVEsSUFBSTtBQUFBLE1BQzNCO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFDQSxNQUFJLGNBQWMsTUFBTSxLQUFLLEVBQUU7QUFDbkM7QUMxSk8sTUFBTSxtQkFBbUIsWUFBWTtBQUFBLEVBQ3hDLEtBQUssWUFBWSxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ2xDLFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssS0FBSyxZQUFZLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDMUM7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLGNBQWMsVUFBVSxnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDdEY7QUFBQSxNQUNBLEdBQUc7QUFBQSxJQUNmLENBQVM7QUFBQSxFQUNMO0FBQ0o7QUNkQSxJQUFJLHlCQUFrRSxTQUFVLFVBQVUsT0FBTyxPQUFPcEYsT0FBTSxHQUFHO0FBQzdHLE1BQUlBLFVBQVMsSUFBSyxPQUFNLElBQUksVUFBVSxnQ0FBZ0M7QUFDdEUsTUFBSUEsVUFBUyxPQUFPLENBQUMsRUFBRyxPQUFNLElBQUksVUFBVSwrQ0FBK0M7QUFDM0YsTUFBSSxPQUFPLFVBQVUsYUFBYSxhQUFhLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRyxPQUFNLElBQUksVUFBVSx5RUFBeUU7QUFDaEwsU0FBUUEsVUFBUyxNQUFNLEVBQUUsS0FBSyxVQUFVLEtBQUssSUFBSSxJQUFJLEVBQUUsUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVLEtBQUssR0FBSTtBQUN4RztBQUNBLElBQUkseUJBQWtFLFNBQVUsVUFBVSxPQUFPQSxPQUFNLEdBQUc7QUFDdEcsTUFBSUEsVUFBUyxPQUFPLENBQUMsRUFBRyxPQUFNLElBQUksVUFBVSwrQ0FBK0M7QUFDM0YsTUFBSSxPQUFPLFVBQVUsYUFBYSxhQUFhLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRyxPQUFNLElBQUksVUFBVSwwRUFBMEU7QUFDakwsU0FBT0EsVUFBUyxNQUFNLElBQUlBLFVBQVMsTUFBTSxFQUFFLEtBQUssUUFBUSxJQUFJLElBQUksRUFBRSxRQUFRLE1BQU0sSUFBSSxRQUFRO0FBQ2hHO0FBQ0EsSUFBSSwyQkFBMkIsd0JBQXdCLHlDQUF5QywrQkFBK0IsOEJBQThCLDBCQUEwQiw0QkFBNEI7QUFJNU0sTUFBTSx1QkFBdUIsWUFBWTtBQUFBLEVBQzVDLFlBQVksUUFBUTtBQUNoQixVQUFLO0FBQ0wsOEJBQTBCLElBQUksSUFBSTtBQUNsQywyQkFBdUIsSUFBSSxNQUFNLE1BQU07QUFDdkMsNENBQXdDLElBQUksTUFBTSxNQUFNO0FBQ3hELGtDQUE4QixJQUFJLE1BQU0sTUFBTTtBQUM5QywyQkFBdUIsTUFBTSx3QkFBd0IsUUFBUSxHQUFHO0FBQUEsRUFDcEU7QUFBQSxFQUNBLE9BQU8sZUFBZSxRQUFRLFFBQVEsU0FBUztBQUMzQyxVQUFNLFNBQVMsSUFBSSxlQUFlLE1BQU07QUFDeEMsV0FBTyxLQUFLLE1BQU0sT0FBTywwQkFBMEIsUUFBUSxRQUFRO0FBQUEsTUFDL0QsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLEdBQUcsU0FBUyxTQUFTLDZCQUE2QixTQUFRO0FBQUEsSUFDakYsQ0FBUyxDQUFDO0FBQ0YsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLE1BQU0sMEJBQTBCLFFBQVEsUUFBUSxTQUFTO0FBQ3JELFVBQU0sU0FBUyxTQUFTO0FBQ3hCLFFBQUksUUFBUTtBQUNSLFVBQUksT0FBTztBQUNQLGFBQUssV0FBVyxNQUFLO0FBQ3pCLGFBQU8saUJBQWlCLFNBQVMsTUFBTSxLQUFLLFdBQVcsT0FBTztBQUFBLElBQ2xFO0FBQ0EsMkJBQXVCLE1BQU0sMkJBQTJCLEtBQUssNEJBQTRCLEVBQUUsS0FBSyxJQUFJO0FBQ3BHLFFBQUk7QUFDSixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLGlCQUFpQixRQUFRO0FBQ3pCLGVBQVMsTUFBTSxPQUFPLFVBQVUsU0FBUyxPQUFPLGFBQWEsRUFBRSxRQUFRLEtBQUksR0FBSSxFQUFFLEdBQUcsU0FBUyxRQUFRLEtBQUssV0FBVyxRQUFRLFFBQVEsTUFBTTtBQUMzSSx1QkFBaUIsT0FBTyxrQkFBa0I7QUFBQSxJQUM5QyxPQUNLO0FBQ0QsZUFBUyxNQUFNLE9BQU8sVUFBVSxPQUFPLEVBQUUsR0FBRyxRQUFRLFFBQVEsS0FBSSxHQUFJLEVBQUUsR0FBRyxTQUFTLFFBQVEsS0FBSyxXQUFXLFFBQVE7QUFBQSxJQUN0SDtBQUNBLFNBQUssV0FBVTtBQUNmLHFCQUFpQixTQUFTLFFBQVE7QUFDOUIsNkJBQXVCLE1BQU0sMkJBQTJCLEtBQUssd0JBQXdCLEVBQUUsS0FBSyxNQUFNLE9BQU8sY0FBYztBQUFBLElBQzNIO0FBQ0EsUUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTO0FBQ25DLFlBQU0sSUFBSSxrQkFBaUI7QUFBQSxJQUMvQjtBQUNBLFdBQU8sdUJBQXVCLE1BQU0sMkJBQTJCLEtBQUssMEJBQTBCLEVBQUUsS0FBSyxJQUFJO0FBQUEsRUFDN0c7QUFBQSxFQUNBLEVBQUUseUJBQXlCLG9CQUFJLFFBQU8sR0FBSSwwQ0FBMEMsb0JBQUksUUFBTyxHQUFJLGdDQUFnQyxvQkFBSSxRQUFPLEdBQUksNEJBQTRCLG9CQUFJLFFBQU8sR0FBSSwrQkFBK0IsU0FBU3FGLGdDQUErQjtBQUNoUSxRQUFJLEtBQUs7QUFDTDtBQUNKLDJCQUF1QixNQUFNLHlDQUF5QyxRQUFXLEdBQUc7QUFBQSxFQUN4RixHQUFHLDJCQUEyQixTQUFTQywwQkFBeUIsT0FBTyxnQkFBZ0I7QUFDbkYsUUFBSSxLQUFLO0FBQ0w7QUFDSixVQUFNLFlBQVksQ0FBQyxNQUFNQyxXQUFVO0FBQy9CLFVBQUksa0JBQWtCLFFBQVFBLE9BQU0sa0JBQWtCLGdCQUFnQjtBQUNsRSxhQUFLLE1BQU0sTUFBTUEsTUFBSztBQUFBLE1BQzFCO0FBQUEsSUFDSjtBQUNBLFVBQU0sV0FBVyx1QkFBdUIsTUFBTSwyQkFBMkIsS0FBSyxrQ0FBa0MsRUFBRSxLQUFLLE1BQU0sS0FBSztBQUNsSSxjQUFVLFNBQVMsS0FBSztBQUN4QixZQUFRLE1BQU0sTUFBSTtBQUFBLE1BQ2QsS0FBSyw4QkFBOEI7QUFDL0IsY0FBTSxTQUFTLFNBQVMsT0FBTyxNQUFNLFlBQVk7QUFDakQsWUFBSSxDQUFDLFFBQVE7QUFDVCxnQkFBTSxJQUFJLFlBQVksMkJBQTJCLE1BQU0sWUFBWSxFQUFFO0FBQUEsUUFDekU7QUFDQSxZQUFJLE9BQU8sU0FBUyxXQUFXO0FBQzNCLGdCQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU0sYUFBYTtBQUNsRCxjQUFJLENBQUMsU0FBUztBQUNWLGtCQUFNLElBQUksWUFBWSw0QkFBNEIsTUFBTSxhQUFhLEVBQUU7QUFBQSxVQUMzRTtBQUNBLGNBQUksUUFBUSxTQUFTLGVBQWU7QUFDaEMsa0JBQU0sSUFBSSxZQUFZLDZDQUE2QyxRQUFRLElBQUksRUFBRTtBQUFBLFVBQ3JGO0FBQ0Esb0JBQVUsOEJBQThCO0FBQUEsWUFDcEMsR0FBRztBQUFBLFlBQ0gsVUFBVSxRQUFRO0FBQUEsVUFDMUMsQ0FBcUI7QUFBQSxRQUNMO0FBQ0E7QUFBQSxNQUNKO0FBQUEsTUFDQSxLQUFLLDBDQUEwQztBQUMzQyxjQUFNLFNBQVMsU0FBUyxPQUFPLE1BQU0sWUFBWTtBQUNqRCxZQUFJLENBQUMsUUFBUTtBQUNULGdCQUFNLElBQUksWUFBWSwyQkFBMkIsTUFBTSxZQUFZLEVBQUU7QUFBQSxRQUN6RTtBQUNBLFlBQUksT0FBTyxTQUFTLGlCQUFpQjtBQUNqQyxvQkFBVSwwQ0FBMEM7QUFBQSxZQUNoRCxHQUFHO0FBQUEsWUFDSCxVQUFVLE9BQU87QUFBQSxVQUN6QyxDQUFxQjtBQUFBLFFBQ0w7QUFDQTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQ0ksa0JBQVUsTUFBTSxNQUFNLEtBQUs7QUFDM0I7QUFBQSxJQUNoQjtBQUFBLEVBQ0ksR0FBRyw2QkFBNkIsU0FBU0MsOEJBQTZCO0FBQ2xFLFFBQUksS0FBSyxPQUFPO0FBQ1osWUFBTSxJQUFJLFlBQVkseUNBQXlDO0FBQUEsSUFDbkU7QUFDQSxVQUFNLFdBQVcsdUJBQXVCLE1BQU0seUNBQXlDLEdBQUc7QUFDMUYsUUFBSSxDQUFDLFVBQVU7QUFDWCxZQUFNLElBQUksWUFBWSwwQ0FBMEM7QUFBQSxJQUNwRTtBQUNBLDJCQUF1QixNQUFNLHlDQUF5QyxRQUFXLEdBQUc7QUFDcEYsVUFBTSxpQkFBaUIsaUJBQWlCLFVBQVUsdUJBQXVCLE1BQU0sd0JBQXdCLEdBQUcsQ0FBQztBQUMzRywyQkFBdUIsTUFBTSwrQkFBK0IsZ0JBQWdCLEdBQUc7QUFDL0UsV0FBTztBQUFBLEVBQ1gsR0FBRyxxQ0FBcUMsU0FBU0Msb0NBQW1DLE9BQU87QUFDdkYsUUFBSSxXQUFXLHVCQUF1QixNQUFNLHlDQUF5QyxHQUFHO0FBQ3hGLFFBQUksQ0FBQyxVQUFVO0FBQ1gsVUFBSSxNQUFNLFNBQVMsb0JBQW9CO0FBQ25DLGNBQU0sSUFBSSxZQUFZLDZFQUE2RSxNQUFNLElBQUksRUFBRTtBQUFBLE1BQ25IO0FBQ0EsaUJBQVcsdUJBQXVCLE1BQU0seUNBQXlDLE1BQU0sVUFBVSxHQUFHO0FBQ3BHLGFBQU87QUFBQSxJQUNYO0FBQ0EsWUFBUSxNQUFNLE1BQUk7QUFBQSxNQUNkLEtBQUssOEJBQThCO0FBQy9CLGlCQUFTLE9BQU8sS0FBSyxNQUFNLElBQUk7QUFDL0I7QUFBQSxNQUNKO0FBQUEsTUFDQSxLQUFLLCtCQUErQjtBQUNoQyxjQUFNLFNBQVMsU0FBUyxPQUFPLE1BQU0sWUFBWTtBQUNqRCxZQUFJLENBQUMsUUFBUTtBQUNULGdCQUFNLElBQUksWUFBWSwyQkFBMkIsTUFBTSxZQUFZLEVBQUU7QUFBQSxRQUN6RTtBQUNBLFlBQUksT0FBTyxTQUFTLFdBQVc7QUFDM0IsaUJBQU8sUUFBUSxLQUFLLE1BQU0sSUFBSTtBQUFBLFFBQ2xDO0FBQ0E7QUFBQSxNQUNKO0FBQUEsTUFDQSxLQUFLLDhCQUE4QjtBQUMvQixjQUFNLFNBQVMsU0FBUyxPQUFPLE1BQU0sWUFBWTtBQUNqRCxZQUFJLENBQUMsUUFBUTtBQUNULGdCQUFNLElBQUksWUFBWSwyQkFBMkIsTUFBTSxZQUFZLEVBQUU7QUFBQSxRQUN6RTtBQUNBLFlBQUksT0FBTyxTQUFTLFdBQVc7QUFDM0IsZ0JBQU0sVUFBVSxPQUFPLFFBQVEsTUFBTSxhQUFhO0FBQ2xELGNBQUksQ0FBQyxTQUFTO0FBQ1Ysa0JBQU0sSUFBSSxZQUFZLDRCQUE0QixNQUFNLGFBQWEsRUFBRTtBQUFBLFVBQzNFO0FBQ0EsY0FBSSxRQUFRLFNBQVMsZUFBZTtBQUNoQyxrQkFBTSxJQUFJLFlBQVksNkNBQTZDLFFBQVEsSUFBSSxFQUFFO0FBQUEsVUFDckY7QUFDQSxrQkFBUSxRQUFRLE1BQU07QUFBQSxRQUMxQjtBQUNBO0FBQUEsTUFDSjtBQUFBLE1BQ0EsS0FBSywwQ0FBMEM7QUFDM0MsY0FBTSxTQUFTLFNBQVMsT0FBTyxNQUFNLFlBQVk7QUFDakQsWUFBSSxDQUFDLFFBQVE7QUFDVCxnQkFBTSxJQUFJLFlBQVksMkJBQTJCLE1BQU0sWUFBWSxFQUFFO0FBQUEsUUFDekU7QUFDQSxZQUFJLE9BQU8sU0FBUyxpQkFBaUI7QUFDakMsaUJBQU8sYUFBYSxNQUFNO0FBQUEsUUFDOUI7QUFDQTtBQUFBLE1BQ0o7QUFBQSxNQUNBLEtBQUssc0JBQXNCO0FBQ3ZCLCtCQUF1QixNQUFNLHlDQUF5QyxNQUFNLFVBQVUsR0FBRztBQUN6RjtBQUFBLE1BQ0o7QUFBQSxJQUNaO0FBQ1EsV0FBTztBQUFBLEVBQ1gsR0FBRyxPQUFPLGtCQUFrQjtBQUN4QixVQUFNLFlBQVksQ0FBQTtBQUNsQixVQUFNLFlBQVksQ0FBQTtBQUNsQixRQUFJLE9BQU87QUFDWCxTQUFLLEdBQUcsU0FBUyxDQUFDLFVBQVU7QUFDeEIsWUFBTSxTQUFTLFVBQVUsTUFBSztBQUM5QixVQUFJLFFBQVE7QUFDUixlQUFPLFFBQVEsS0FBSztBQUFBLE1BQ3hCLE9BQ0s7QUFDRCxrQkFBVSxLQUFLLEtBQUs7QUFBQSxNQUN4QjtBQUFBLElBQ0osQ0FBQztBQUNELFNBQUssR0FBRyxPQUFPLE1BQU07QUFDakIsYUFBTztBQUNQLGlCQUFXLFVBQVUsV0FBVztBQUM1QixlQUFPLFFBQVEsTUFBUztBQUFBLE1BQzVCO0FBQ0EsZ0JBQVUsU0FBUztBQUFBLElBQ3ZCLENBQUM7QUFDRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQVE7QUFDdEIsYUFBTztBQUNQLGlCQUFXLFVBQVUsV0FBVztBQUM1QixlQUFPLE9BQU8sR0FBRztBQUFBLE1BQ3JCO0FBQ0EsZ0JBQVUsU0FBUztBQUFBLElBQ3ZCLENBQUM7QUFDRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQVE7QUFDdEIsYUFBTztBQUNQLGlCQUFXLFVBQVUsV0FBVztBQUM1QixlQUFPLE9BQU8sR0FBRztBQUFBLE1BQ3JCO0FBQ0EsZ0JBQVUsU0FBUztBQUFBLElBQ3ZCLENBQUM7QUFDRCxXQUFPO0FBQUEsTUFDSCxNQUFNLFlBQVk7QUFDZCxZQUFJLENBQUMsVUFBVSxRQUFRO0FBQ25CLGNBQUksTUFBTTtBQUNOLG1CQUFPLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSTtBQUFBLFVBQ3pDO0FBQ0EsaUJBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXLFVBQVUsS0FBSyxFQUFFLFNBQVMsUUFBUSxDQUFDLEVBQUUsS0FBSyxDQUFDRixXQUFXQSxTQUFRLEVBQUUsT0FBT0EsUUFBTyxNQUFNLE1BQUssSUFBSyxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUksQ0FBRztBQUFBLFFBQzNLO0FBQ0EsY0FBTSxRQUFRLFVBQVUsTUFBSztBQUM3QixlQUFPLEVBQUUsT0FBTyxPQUFPLE1BQU0sTUFBSztBQUFBLE1BQ3RDO0FBQUEsTUFDQSxRQUFRLFlBQVk7QUFDaEIsYUFBSyxNQUFLO0FBQ1YsZUFBTyxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUk7QUFBQSxNQUN6QztBQUFBLElBQ1o7QUFBQSxFQUNJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLE1BQU0sZ0JBQWdCO0FBQ2xCLFVBQU0sS0FBSyxLQUFJO0FBQ2YsVUFBTSxXQUFXLHVCQUF1QixNQUFNLCtCQUErQixHQUFHO0FBQ2hGLFFBQUksQ0FBQztBQUNELFlBQU0sSUFBSSxZQUFZLGlEQUFpRDtBQUMzRSxXQUFPO0FBQUEsRUFDWDtBQUNKO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVSxRQUFRO0FBQ3hDLFNBQU8sbUJBQW1CLFVBQVUsTUFBTTtBQUM5QztBQzdPTyxNQUFNLGtCQUFrQixZQUFZO0FBQUEsRUFDdkMsY0FBYztBQUNWLFVBQU0sR0FBRyxTQUFTO0FBQ2xCLFNBQUssYUFBYSxJQUFJRyxXQUF5QixLQUFLLE9BQU87QUFBQSxFQUMvRDtBQUFBLEVBQ0EsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxLQUFLLFFBQVEsS0FBSyxjQUFjLEVBQUUsTUFBTSxHQUFHLFNBQVMsUUFBUSxLQUFLLFVBQVUsTUFBSyxDQUFFLEVBQUUsWUFBWSxDQUFDLFFBQVE7QUFDNUcsVUFBSSxZQUFZLE9BQU8sSUFBSSxXQUFXLFlBQVk7QUFDOUMsc0JBQWMsR0FBRztBQUFBLE1BQ3JCO0FBQ0EsYUFBTztBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFBQSxFQUNBLFNBQVMsWUFBWSxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ3RDLFdBQU8sS0FBSyxRQUFRLElBQUksY0FBYyxVQUFVLElBQUk7QUFBQSxNQUNoRDtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsUUFBUSxPQUFPLFVBQVU7QUFBQSxJQUNyQyxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXQSxJQUFJLFlBQVksU0FBUztBQUNyQixXQUFPLEtBQUssUUFBUSxPQUFPLGNBQWMsVUFBVSxJQUFJO0FBQUEsTUFDbkQsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLFFBQVEsT0FBTyxHQUFHLFNBQVMsUUFBTztBQUFBLElBQ3pELENBQVM7QUFBQSxFQUNMO0FBQUEsRUFDQSxNQUFNLE1BQU0sU0FBUztBQUNqQixXQUFPLEtBQUssUUFBUSxVQUNmLE9BQU8sTUFBTSxPQUFPLEVBQ3BCLFlBQVksQ0FBQyxhQUFhLGNBQWMsVUFBVSxJQUFJLENBQUM7QUFBQSxFQUNoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxNQUFNLFNBQVM7QUFDbEIsV0FBTyxlQUFlLGVBQWUsS0FBSyxTQUFTLE1BQU0sT0FBTztBQUFBLEVBQ3BFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQSxPQUFPLFlBQVksU0FBUztBQUN4QixXQUFPLEtBQUssUUFBUSxLQUFLLGNBQWMsVUFBVSxXQUFXO0FBQUEsTUFDeEQsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLFFBQVEsT0FBTyxHQUFHLFNBQVMsUUFBTztBQUFBLElBQ3pELENBQVM7QUFBQSxFQUNMO0FBQ0o7QUFDTyxNQUFNLDBCQUEwQixXQUFXO0FBQ2xEO0FBQ0EsVUFBVSxhQUFhO0FDeEVoQixNQUFNLGNBQWMsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjbkMsT0FBTyxVQUFVLE1BQU0sU0FBUztBQUM1QixXQUFPLEtBQUssUUFBUSxLQUFLLFlBQVksUUFBUSxVQUFVM0UsNEJBQWlDLEVBQUUsTUFBTSxHQUFHLFFBQU8sQ0FBRSxDQUFDO0FBQUEsRUFDakg7QUFDSjtBQ2hCTyxNQUFNLGdCQUFnQixZQUFZO0FBQUEsRUFDckMsY0FBYztBQUNWLFVBQU0sR0FBRyxTQUFTO0FBQ2xCLFNBQUssUUFBUSxJQUFJNEUsTUFBZSxLQUFLLE9BQU87QUFBQSxFQUNoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0JBLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxFQUFFLE1BQU0sR0FBRyxTQUFTO0FBQUEsRUFDN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLE9BQU8sVUFBVSxTQUFTO0FBQ3RCLFdBQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxRQUFRLFdBQVcsT0FBTztBQUFBLEVBQ25FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkEsU0FBUyxVQUFVLE1BQU0sU0FBUztBQUM5QixXQUFPLEtBQUssUUFBUSxLQUFLLFlBQVksUUFBUSxhQUFhLEVBQUUsTUFBTSxHQUFHLFFBQU8sQ0FBRTtBQUFBLEVBQ2xGO0FBQ0o7QUFDQSxRQUFRLFFBQVE7QUN2RFQsTUFBTSxzQkFBc0IsT0FBTyxhQUFhO0FBQ25ELFFBQU0sVUFBVSxNQUFNLFFBQVEsV0FBVyxRQUFRO0FBQ2pELFFBQU0sV0FBVyxRQUFRLE9BQU8sQ0FBQ3pGLFlBQVdBLFFBQU8sV0FBVyxVQUFVO0FBQ3hFLE1BQUksU0FBUyxRQUFRO0FBQ2pCLGVBQVdBLFdBQVUsVUFBVTtBQUMzQixjQUFRLE1BQU1BLFFBQU8sTUFBTTtBQUFBLElBQy9CO0FBQ0EsVUFBTSxJQUFJLE1BQU0sR0FBRyxTQUFTLE1BQU0sMkNBQTJDO0FBQUEsRUFDakY7QUFFQSxRQUFNLFNBQVMsQ0FBQTtBQUNmLGFBQVdBLFdBQVUsU0FBUztBQUMxQixRQUFJQSxRQUFPLFdBQVcsYUFBYTtBQUMvQixhQUFPLEtBQUtBLFFBQU8sS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDSjtBQUNBLFNBQU87QUFDWDtBQ2hCTyxNQUFNbUUsZUFBYyxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTW5DLE9BQU8sZUFBZSxNQUFNLFNBQVM7QUFDakMsV0FBTyxLQUFLLFFBQVEsS0FBSyxrQkFBa0IsYUFBYSxVQUFVO0FBQUEsTUFDOUQ7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxTQUFTLGVBQWUsUUFBUSxTQUFTO0FBQ3JDLFdBQU8sS0FBSyxRQUFRLElBQUksa0JBQWtCLGFBQWEsVUFBVSxNQUFNLElBQUk7QUFBQSxNQUN2RSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxlQUFlLFFBQVEsTUFBTSxTQUFTO0FBQ3pDLFdBQU8sS0FBSyxRQUFRLEtBQUssa0JBQWtCLGFBQWEsVUFBVSxNQUFNLElBQUk7QUFBQSxNQUN4RTtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDMUUsQ0FBUztBQUFBLEVBQ0w7QUFBQSxFQUNBLEtBQUssZUFBZSxRQUFRLENBQUEsR0FBSSxTQUFTO0FBQ3JDLFFBQUksaUJBQWlCLEtBQUssR0FBRztBQUN6QixhQUFPLEtBQUssS0FBSyxlQUFlLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDN0M7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLGtCQUFrQixhQUFhLFVBQVUsc0JBQXNCO0FBQUEsTUFDMUY7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxJQUFJLGVBQWUsUUFBUSxTQUFTO0FBQ2hDLFdBQU8sS0FBSyxRQUFRLE9BQU8sa0JBQWtCLGFBQWEsVUFBVSxNQUFNLElBQUk7QUFBQSxNQUMxRSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsTUFBTSxjQUFjLGVBQWUsTUFBTSxTQUFTO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssT0FBTyxlQUFlLE1BQU0sT0FBTztBQUMzRCxXQUFPLE1BQU0sS0FBSyxLQUFLLGVBQWUsS0FBSyxJQUFJLE9BQU87QUFBQSxFQUMxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxLQUFLLGVBQWUsUUFBUSxTQUFTO0FBQ3ZDLFVBQU0sVUFBVSxFQUFFLEdBQUcsU0FBUyxTQUFTLDJCQUEyQixPQUFNO0FBQ3hFLFFBQUksU0FBUyxnQkFBZ0I7QUFDekIsY0FBUSxrQ0FBa0MsSUFBSSxRQUFRLGVBQWUsU0FBUTtBQUFBLElBQ2pGO0FBQ0EsV0FBTyxNQUFNO0FBQ1QsWUFBTSxlQUFlLE1BQU0sS0FBSyxTQUFTLGVBQWUsUUFBUTtBQUFBLFFBQzVELEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDaEIsQ0FBYSxFQUFFLGFBQVk7QUFDZixZQUFNLE9BQU8sYUFBYTtBQUMxQixjQUFRLEtBQUssUUFBTTtBQUFBLFFBQ2YsS0FBSztBQUNELGNBQUksZ0JBQWdCO0FBQ3BCLGNBQUksU0FBUyxnQkFBZ0I7QUFDekIsNEJBQWdCLFFBQVE7QUFBQSxVQUM1QixPQUNLO0FBQ0Qsa0JBQU0saUJBQWlCLGFBQWEsU0FBUyxRQUFRLElBQUksc0JBQXNCO0FBQy9FLGdCQUFJLGdCQUFnQjtBQUNoQixvQkFBTSxtQkFBbUIsU0FBUyxjQUFjO0FBQ2hELGtCQUFJLENBQUMsTUFBTSxnQkFBZ0IsR0FBRztBQUMxQixnQ0FBZ0I7QUFBQSxjQUNwQjtBQUFBLFlBQ0o7QUFBQSxVQUNKO0FBQ0EsZ0JBQU0sTUFBTSxhQUFhO0FBQ3pCO0FBQUEsUUFDSixLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQ0QsaUJBQU87QUFBQSxNQUMzQjtBQUFBLElBQ1E7QUFBQSxFQUNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLE9BQU8sZUFBZSxNQUFNLFNBQVM7QUFDdkMsVUFBTSxXQUFXLE1BQU0sS0FBSyxRQUFRLE1BQU0sT0FBTyxFQUFFLE1BQVksU0FBUyxhQUFZLEdBQUksT0FBTztBQUMvRixXQUFPLEtBQUssT0FBTyxlQUFlLEVBQUUsU0FBUyxTQUFTLEdBQUUsR0FBSSxPQUFPO0FBQUEsRUFDdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLE1BQU0sY0FBYyxlQUFlLE1BQU0sU0FBUztBQUM5QyxVQUFNLFdBQVcsTUFBTSxLQUFLLE9BQU8sZUFBZSxNQUFNLE9BQU87QUFDL0QsV0FBTyxNQUFNLEtBQUssS0FBSyxlQUFlLFNBQVMsSUFBSSxPQUFPO0FBQUEsRUFDOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFFBQVEsZUFBZSxRQUFRLFNBQVM7QUFDcEMsV0FBTyxLQUFLLFFBQVEsV0FBVyxrQkFBa0IsYUFBYSxVQUFVLE1BQU0sWUFBWSwwQkFBMEIsRUFBRSxHQUFHLFNBQVMsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPLEdBQUk7QUFBQSxFQUN4TTtBQUNKO0FBQ08sTUFBTSw2QkFBNkIsV0FBVztBQUNyRDtBQUlPLE1BQU0saUNBQWlDLEtBQUs7QUFDbkQ7QUFDQUEsT0FBTSx1QkFBdUI7QUFDN0JBLE9BQU0sMkJBQTJCO0FDbkkxQixNQUFNLG9CQUFvQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJekMsT0FBTyxlQUFlLE1BQU0sU0FBUztBQUNqQyxXQUFPLEtBQUssUUFBUSxLQUFLLGtCQUFrQixhQUFhLGlCQUFpQjtBQUFBLE1BQ3JFO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsU0FBUyxlQUFlLFNBQVMsU0FBUztBQUN0QyxXQUFPLEtBQUssUUFBUSxJQUFJLGtCQUFrQixhQUFhLGlCQUFpQixPQUFPLElBQUk7QUFBQSxNQUMvRSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxPQUFPLGVBQWUsU0FBUyxTQUFTO0FBQ3BDLFdBQU8sS0FBSyxRQUFRLEtBQUssa0JBQWtCLGFBQWEsaUJBQWlCLE9BQU8sV0FBVztBQUFBLE1BQ3ZGLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxNQUFNLGNBQWMsZUFBZSxNQUFNLFNBQVM7QUFDOUMsVUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLGVBQWUsSUFBSTtBQUNuRCxXQUFPLE1BQU0sS0FBSyxLQUFLLGVBQWUsTUFBTSxJQUFJLE9BQU87QUFBQSxFQUMzRDtBQUFBLEVBQ0EsVUFBVSxlQUFlLFNBQVMsUUFBUSxDQUFBLEdBQUksU0FBUztBQUNuRCxRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLFVBQVUsZUFBZSxTQUFTLENBQUEsR0FBSSxLQUFLO0FBQUEsSUFDM0Q7QUFDQSxXQUFPLEtBQUssUUFBUSxXQUFXLGtCQUFrQixhQUFhLGlCQUFpQixPQUFPLFVBQVUsc0JBQXNCLEVBQUUsT0FBTyxHQUFHLFNBQVMsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPLEdBQUk7QUFBQSxFQUNqTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxLQUFLLGVBQWUsU0FBUyxTQUFTO0FBQ3hDLFVBQU0sVUFBVSxFQUFFLEdBQUcsU0FBUyxTQUFTLDJCQUEyQixPQUFNO0FBQ3hFLFFBQUksU0FBUyxnQkFBZ0I7QUFDekIsY0FBUSxrQ0FBa0MsSUFBSSxRQUFRLGVBQWUsU0FBUTtBQUFBLElBQ2pGO0FBQ0EsV0FBTyxNQUFNO0FBQ1QsWUFBTSxFQUFFLE1BQU0sT0FBTyxTQUFRLElBQUssTUFBTSxLQUFLLFNBQVMsZUFBZSxTQUFTO0FBQUEsUUFDMUUsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNoQixDQUFhLEVBQUUsYUFBWTtBQUNmLGNBQVEsTUFBTSxRQUFNO0FBQUEsUUFDaEIsS0FBSztBQUNELGNBQUksZ0JBQWdCO0FBQ3BCLGNBQUksU0FBUyxnQkFBZ0I7QUFDekIsNEJBQWdCLFFBQVE7QUFBQSxVQUM1QixPQUNLO0FBQ0Qsa0JBQU0saUJBQWlCLFNBQVMsUUFBUSxJQUFJLHNCQUFzQjtBQUNsRSxnQkFBSSxnQkFBZ0I7QUFDaEIsb0JBQU0sbUJBQW1CLFNBQVMsY0FBYztBQUNoRCxrQkFBSSxDQUFDLE1BQU0sZ0JBQWdCLEdBQUc7QUFDMUIsZ0NBQWdCO0FBQUEsY0FDcEI7QUFBQSxZQUNKO0FBQUEsVUFDSjtBQUNBLGdCQUFNLE1BQU0sYUFBYTtBQUN6QjtBQUFBLFFBQ0osS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNELGlCQUFPO0FBQUEsTUFDM0I7QUFBQSxJQUNRO0FBQUEsRUFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sY0FBYyxlQUFlLEVBQUUsT0FBTyxVQUFVLENBQUEsRUFBRSxHQUFJLFNBQVM7QUFDakUsUUFBSSxTQUFTLFFBQVEsTUFBTSxVQUFVLEdBQUc7QUFDcEMsWUFBTSxJQUFJLE1BQU0sZ0hBQWdIO0FBQUEsSUFDcEk7QUFDQSxVQUFNLHdCQUF3QixTQUFTLGtCQUFrQjtBQUV6RCxVQUFNLG1CQUFtQixLQUFLLElBQUksdUJBQXVCLE1BQU0sTUFBTTtBQUNyRSxVQUFNLFNBQVMsS0FBSztBQUNwQixVQUFNLGVBQWUsTUFBTSxPQUFNO0FBQ2pDLFVBQU0sYUFBYSxDQUFDLEdBQUcsT0FBTztBQUc5QixtQkFBZSxhQUFhLFVBQVU7QUFDbEMsZUFBUyxRQUFRLFVBQVU7QUFDdkIsY0FBTSxVQUFVLE1BQU0sT0FBTyxNQUFNLE9BQU8sRUFBRSxNQUFNLE1BQU0sU0FBUyxhQUFZLEdBQUksT0FBTztBQUN4RixtQkFBVyxLQUFLLFFBQVEsRUFBRTtBQUFBLE1BQzlCO0FBQUEsSUFDSjtBQUVBLFVBQU0sVUFBVSxNQUFNLGdCQUFnQixFQUFFLEtBQUssWUFBWSxFQUFFLElBQUksWUFBWTtBQUUzRSxVQUFNLG9CQUFvQixPQUFPO0FBQ2pDLFdBQU8sTUFBTSxLQUFLLGNBQWMsZUFBZTtBQUFBLE1BQzNDLFVBQVU7QUFBQSxJQUN0QixDQUFTO0FBQUEsRUFDTDtBQUNKO0FDaEhPLE1BQU0scUJBQXFCLFlBQVk7QUFBQSxFQUMxQyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxRQUFRLElBQUlDLE9BQWUsS0FBSyxPQUFPO0FBQzVDLFNBQUssY0FBYyxJQUFJc0IsWUFBMkIsS0FBSyxPQUFPO0FBQUEsRUFDbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLE9BQU8sTUFBTSxTQUFTO0FBQ2xCLFdBQU8sS0FBSyxRQUFRLEtBQUssa0JBQWtCO0FBQUEsTUFDdkM7QUFBQSxNQUNBLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxTQUFTLGVBQWUsU0FBUztBQUM3QixXQUFPLEtBQUssUUFBUSxJQUFJLGtCQUFrQixhQUFhLElBQUk7QUFBQSxNQUN2RCxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxlQUFlLE1BQU0sU0FBUztBQUNqQyxXQUFPLEtBQUssUUFBUSxLQUFLLGtCQUFrQixhQUFhLElBQUk7QUFBQSxNQUN4RDtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDMUUsQ0FBUztBQUFBLEVBQ0w7QUFBQSxFQUNBLEtBQUssUUFBUSxDQUFBLEdBQUksU0FBUztBQUN0QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDekIsYUFBTyxLQUFLLEtBQUssQ0FBQSxHQUFJLEtBQUs7QUFBQSxJQUM5QjtBQUNBLFdBQU8sS0FBSyxRQUFRLFdBQVcsa0JBQWtCLGtCQUFrQjtBQUFBLE1BQy9EO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLEVBQUUsZUFBZSxpQkFBaUIsR0FBRyxTQUFTLFFBQU87QUFBQSxJQUMxRSxDQUFTO0FBQUEsRUFDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsSUFBSSxlQUFlLFNBQVM7QUFDeEIsV0FBTyxLQUFLLFFBQVEsT0FBTyxrQkFBa0IsYUFBYSxJQUFJO0FBQUEsTUFDMUQsR0FBRztBQUFBLE1BQ0gsU0FBUyxFQUFFLGVBQWUsaUJBQWlCLEdBQUcsU0FBUyxRQUFPO0FBQUEsSUFDMUUsQ0FBUztBQUFBLEVBQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsT0FBTyxlQUFlLE1BQU0sU0FBUztBQUNqQyxXQUFPLEtBQUssUUFBUSxXQUFXLGtCQUFrQixhQUFhLFdBQVcsZ0NBQWdDO0FBQUEsTUFDckc7QUFBQSxNQUNBLFFBQVE7QUFBQSxNQUNSLEdBQUc7QUFBQSxNQUNILFNBQVMsRUFBRSxlQUFlLGlCQUFpQixHQUFHLFNBQVMsUUFBTztBQUFBLElBQzFFLENBQVM7QUFBQSxFQUNMO0FBQ0o7QUFDTyxNQUFNLHlCQUF5QixXQUFXO0FBQ2pEO0FBSU8sTUFBTSx1Q0FBdUMsS0FBSztBQUN6RDtBQUNBLGFBQWEsbUJBQW1CO0FBQ2hDLGFBQWEsaUNBQWlDO0FBQzlDLGFBQWEsUUFBUXZCO0FBQ3JCLGFBQWEsdUJBQXVCO0FBQ3BDLGFBQWEsMkJBQTJCO0FBQ3hDLGFBQWEsY0FBYztBQ3RGM0IsSUFBSTtBQTRCRyxNQUFNLGVBQWV3QixVQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQnZDLFlBQVksRUFBRSxVQUFVQyxRQUFhLGlCQUFpQixHQUFHLFNBQVNBLFFBQWEsZ0JBQWdCLEdBQUcsZUFBZUEsUUFBYSxlQUFlLEtBQUssTUFBTSxVQUFVQSxRQUFhLG1CQUFtQixLQUFLLE1BQU0sR0FBRyxLQUFBLElBQVMsSUFBSTtBQUN6TixRQUFJLFdBQVcsUUFBVztBQUN0QixZQUFNLElBQUlDLFlBQW1CLG9MQUFvTDtBQUFBLElBQ3JOO0FBQ0EsVUFBTSxVQUFVO0FBQUEsTUFDWjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxTQUFTLFdBQVc7QUFBQSxJQUFBO0FBRXhCLFFBQUksQ0FBQyxRQUFRLDJCQUEyQkMsc0JBQTJCO0FBQy9ELFlBQU0sSUFBSUQsWUFBbUIsb2JBQW9iO0FBQUEsSUFDcmQ7QUFDQSxVQUFNO0FBQUEsTUFDRixTQUFTLFFBQVE7QUFBQSxNQUNqQixTQUFTLFFBQVEsV0FBVztBQUFBLE1BQzVCLFdBQVcsUUFBUTtBQUFBLE1BQ25CLFlBQVksUUFBUTtBQUFBLE1BQ3BCLE9BQU8sUUFBUTtBQUFBLElBQUEsQ0FDbEI7QUFDRCxTQUFLLGNBQWMsSUFBSUUsYUFBZ0IsSUFBSTtBQUMzQyxTQUFLLE9BQU8sSUFBSUMsT0FBUyxJQUFJO0FBQzdCLFNBQUssYUFBYSxJQUFJQyxXQUFlLElBQUk7QUFDekMsU0FBSyxRQUFRLElBQUlDLFFBQVUsSUFBSTtBQUMvQixTQUFLLFNBQVMsSUFBSUMsT0FBVyxJQUFJO0FBQ2pDLFNBQUssUUFBUSxJQUFJQyxNQUFVLElBQUk7QUFDL0IsU0FBSyxjQUFjLElBQUlDLFlBQWdCLElBQUk7QUFDM0MsU0FBSyxTQUFTLElBQUlDLE9BQVcsSUFBSTtBQUNqQyxTQUFLLGFBQWEsSUFBSUMsV0FBZSxJQUFJO0FBQ3pDLFNBQUssVUFBVSxJQUFJQyxTQUFZLElBQUk7QUFDbkMsU0FBSyxlQUFlLElBQUlDLGFBQWlCLElBQUk7QUFDN0MsU0FBSyxPQUFPLElBQUlDLEtBQVMsSUFBSTtBQUM3QixTQUFLLFVBQVUsSUFBSUMsUUFBWSxJQUFJO0FBQ25DLFNBQUssVUFBVSxJQUFJQyxRQUFZLElBQUk7QUFDbkMsU0FBSyxZQUFZLElBQUlDLFVBQWMsSUFBSTtBQUN2QyxTQUFLLFFBQVEsSUFBSUMsTUFBVSxJQUFJO0FBQy9CLFNBQUssYUFBYSxJQUFJQyxXQUFlLElBQUk7QUFDekMsU0FBSyxXQUFXO0FBQ2hCLFNBQUssU0FBUztBQUNkLFNBQUssZUFBZTtBQUNwQixTQUFLLFVBQVU7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsZUFBZTtBQUNYLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFDekI7QUFBQSxFQUNBLGVBQWUsTUFBTTtBQUNqQixXQUFPO0FBQUEsTUFDSCxHQUFHLE1BQU0sZUFBZSxJQUFJO0FBQUEsTUFDNUIsdUJBQXVCLEtBQUs7QUFBQSxNQUM1QixrQkFBa0IsS0FBSztBQUFBLE1BQ3ZCLEdBQUcsS0FBSyxTQUFTO0FBQUEsSUFBQTtBQUFBLEVBRXpCO0FBQUEsRUFDQSxZQUFZLE1BQU07QUFDZCxXQUFPLEVBQUUsZUFBZSxVQUFVLEtBQUssTUFBTSxHQUFBO0FBQUEsRUFDakQ7QUFBQSxFQUNBLGVBQWUsT0FBTztBQUNsQixXQUFPQyxVQUFhLE9BQU8sRUFBRSxhQUFhLFlBQVk7QUFBQSxFQUMxRDtBQUNKO0FBQ0EsS0FBSztBQUNMLE9BQU8sU0FBUztBQUNoQixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLGNBQWNuQjtBQUNyQixPQUFPLFdBQVdvQjtBQUNsQixPQUFPLHFCQUFxQkM7QUFDNUIsT0FBTyw0QkFBNEJDO0FBQ25DLE9BQU8sb0JBQW9CQztBQUMzQixPQUFPLGdCQUFnQkM7QUFDdkIsT0FBTyxnQkFBZ0JDO0FBQ3ZCLE9BQU8saUJBQWlCQztBQUN4QixPQUFPLGtCQUFrQkM7QUFDekIsT0FBTyxzQkFBc0JDO0FBQzdCLE9BQU8sc0JBQXNCQztBQUM3QixPQUFPLHdCQUF3QkM7QUFDL0IsT0FBTywyQkFBMkJDO0FBQ2xDLE9BQU8sU0FBU0M7QUFDaEIsT0FBTyxlQUFlQztBQUN0QixPQUFPLGNBQWNySDtBQUNyQixPQUFPLE9BQU9HO0FBQ2QsT0FBTyxzQkFBc0I7QUFDN0IsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sUUFBUXVEO0FBQ2YsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxTQUFTO0FBQ2hCLE9BQU8sUUFBUTtBQUNmLE9BQU8sY0FBYztBQUNyQixPQUFPLFNBQVM7QUFDaEIsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sYUFBYTtBQUNwQixPQUFPLFVBQVVPO0FBQ2pCLE9BQU8sZUFBZTtBQUN0QixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLGlDQUFpQztBQUN4QyxPQUFPLE9BQU87QUFDZCxPQUFPLFVBQVU7QUFDakIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sVUFBVXFEO0FBQ2pCLE9BQU8sWUFBWTtBQUNuQixPQUFPLFFBQVE7QUFDZixPQUFPLHdCQUF3QjtBQUMvQixPQUFPLGFBQWE7QUFDcEIsT0FBTyw2QkFBNkI7QUNsSnBDLE1BQUEsbUJBQUE7QUFBQSxFQUFtQyxRQUFBO0FBQUEsRUFDekIsT0FBQTtBQUFBLEVBQ0QsVUFBQTtBQUFBLEVBQ0csV0FBQTtBQUFBLEVBQ0MsTUFBQTtBQUViO0FBRUEsZUFBQSxjQUFBO0FBQ0UsUUFBQS9ILFVBQUEsTUFBQSxRQUFBLFFBQUEsTUFBQSxJQUFBLFVBQUE7QUFDQSxTQUFBLEVBQUEsR0FBQSxrQkFBQSxHQUFBQSxRQUFBLFNBQUE7QUFDRjtBQ1JBLE1BQUEsYUFBQSxpQkFBQTtBQUFBLEVBQWdDLE1BQUE7QUFBQSxFQUN4QixPQUFBO0FBR0osWUFBQSxJQUFBLGlEQUFBO0FBR0EsWUFBQSxRQUFBLFVBQUEsWUFBQSxPQUFBLFNBQUEsWUFBQTtBQUNFLFVBQUEsUUFBQSxXQUFBLHVCQUFBO0FBQ0UsZUFBQSxNQUFBLG9CQUFBLFFBQUEsSUFBQTtBQUFBLE1BQTZDO0FBRy9DLFVBQUEsUUFBQSxXQUFBLGNBQUE7QUFFRSxjQUFBLGNBQUEsTUFBQSxlQUFBO0FBQ0EsWUFBQSxhQUFBO0FBQ0UsaUJBQUEsTUFBQSxvQkFBQSxXQUFBO0FBQUEsUUFBNEM7QUFFOUMsZUFBQSxFQUFBLGFBQUEsSUFBQSxPQUFBLDRCQUFBO0FBQUEsTUFBNkQ7QUFBQSxJQUMvRCxDQUFBO0FBQUEsRUFDRDtBQUVMLENBQUE7QUFFQSxlQUFBLG9CQUFBLFNBQUE7QUFDRSxNQUFBO0FBQ0UsVUFBQSxXQUFBLE1BQUEsWUFBQTtBQUVBLFFBQUEsQ0FBQSxTQUFBLFFBQUE7QUFDRSxhQUFBO0FBQUEsUUFBTyxPQUFBO0FBQUEsUUFDRSxhQUFBLENBQUE7QUFBQSxNQUNPO0FBQUEsSUFDaEI7QUFHRixVQUFBLFNBQUEsSUFBQSxPQUFBO0FBQUEsTUFBMEIsUUFBQSxTQUFBO0FBQUEsTUFDUCx5QkFBQTtBQUFBO0FBQUEsSUFDUSxDQUFBO0FBRzNCLFVBQUEsZUFBQSxnQkFBQSxTQUFBLFFBQUE7QUFDQSxVQUFBLGFBQUEsaUJBQUEsT0FBQTtBQUVBLFVBQUEsV0FBQSxNQUFBLE9BQUEsS0FBQSxZQUFBLE9BQUE7QUFBQSxNQUFzRCxPQUFBLFNBQUE7QUFBQSxNQUNwQyxVQUFBO0FBQUEsUUFDTixFQUFBLE1BQUEsVUFBQSxTQUFBLGFBQUE7QUFBQSxRQUNnQyxFQUFBLE1BQUEsUUFBQSxTQUFBLFdBQUE7QUFBQSxNQUNKO0FBQUEsTUFDdEMsYUFBQTtBQUFBLE1BQ2EsWUFBQTtBQUFBLElBQ0QsQ0FBQTtBQUdkLFVBQUEsYUFBQSxTQUFBLFFBQUEsQ0FBQSxHQUFBLFNBQUEsV0FBQTtBQUNBLFVBQUEsY0FBQSxnQkFBQSxVQUFBO0FBR0EsVUFBQSxnQkFBQSxPQUFBO0FBRUEsV0FBQSxFQUFBLGFBQUEsT0FBQSxLQUFBO0FBQUEsRUFBa0MsU0FBQSxPQUFBO0FBRWxDLFlBQUEsTUFBQSxxQkFBQSxLQUFBO0FBQ0EsV0FBQTtBQUFBLE1BQU8sT0FBQSxZQUFBLEtBQUE7QUFBQSxNQUNtQixhQUFBLENBQUE7QUFBQSxJQUNWO0FBQUEsRUFDaEI7QUFFSjtBQUVBLFNBQUEsZ0JBQUEsVUFBQTtBQUNFLFFBQUEsVUFBQTtBQUFBLElBQWdCLElBQUE7QUFBQSxJQUNWLElBQUE7QUFBQSxJQUVBLE9BQUE7QUFBQSxFQUVHO0FBR1QsU0FBQSxRQUFBLFFBQUEsS0FBQSxRQUFBO0FBQ0Y7QUFFQSxTQUFBLGlCQUFBLFNBQUE7QUFDRSxRQUFBLGFBQUEsUUFBQSxpQkFBQSxTQUFBLElBQUE7QUFBQSxFQUNJLFFBQUEsaUJBQUEsS0FBQSxJQUFBLENBQUE7QUFBQTtBQUFBLElBQThEO0FBR2xFLFNBQUEsR0FBQSxVQUFBLFdBQUEsUUFBQSxVQUFBLGlCQUFBLFFBQUEsY0FBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFZRjtBQUVBLFNBQUEsZ0JBQUEsVUFBQTtBQUNFLFFBQUEsY0FBQSxDQUFBO0FBR0EsUUFBQSxvQkFBQSxTQUFBLE1BQUEsZ0RBQUE7QUFDQSxNQUFBLG1CQUFBO0FBQ0UsZ0JBQUEsS0FBQTtBQUFBLE1BQWlCLElBQUE7QUFBQSxNQUNYLE1BQUE7QUFBQSxNQUNFLE1BQUEsa0JBQUEsQ0FBQSxFQUFBLEtBQUE7QUFBQSxNQUMwQixNQUFBO0FBQUEsSUFDMUIsQ0FBQTtBQUFBLEVBQ1A7QUFJSCxRQUFBLGdCQUFBLFNBQUEsTUFBQSw0Q0FBQTtBQUNBLE1BQUEsZUFBQTtBQUNFLGdCQUFBLEtBQUE7QUFBQSxNQUFpQixJQUFBO0FBQUEsTUFDWCxNQUFBO0FBQUEsTUFDRSxNQUFBLGNBQUEsQ0FBQSxFQUFBLEtBQUE7QUFBQSxNQUNzQixNQUFBO0FBQUEsSUFDdEIsQ0FBQTtBQUFBLEVBQ1A7QUFJSCxRQUFBLGFBQUEsU0FBQSxNQUFBLCtCQUFBO0FBQ0EsTUFBQSxZQUFBO0FBQ0UsZ0JBQUEsS0FBQTtBQUFBLE1BQWlCLElBQUE7QUFBQSxNQUNYLE1BQUE7QUFBQSxNQUNFLE1BQUEsV0FBQSxDQUFBLEVBQUEsS0FBQTtBQUFBLE1BQ21CLE1BQUE7QUFBQSxJQUNuQixDQUFBO0FBQUEsRUFDUDtBQUlILE1BQUEsWUFBQSxXQUFBLEdBQUE7QUFDRSxVQUFBLFFBQUEsU0FBQSxNQUFBLElBQUEsRUFBQSxPQUFBLENBQUEsU0FBQSxLQUFBLE1BQUE7QUFDQSxRQUFBLGNBQUE7QUFDQSxRQUFBLGNBQUE7QUFFQSxlQUFBLFFBQUEsT0FBQTtBQUNFLFVBQUEsS0FBQSxNQUFBLG1CQUFBLEdBQUE7QUFDRSxZQUFBLGFBQUE7QUFDRSxzQkFBQSxLQUFBO0FBQUEsWUFBaUIsSUFBQSxPQUFBLFlBQUEsU0FBQSxDQUFBO0FBQUEsWUFDa0IsTUFBQTtBQUFBLFlBQzNCLE1BQUEsWUFBQSxLQUFBO0FBQUEsWUFDaUIsTUFBQSxnQkFBQSxpQkFBQSxPQUFBLGdCQUFBLGFBQUEsT0FBQTtBQUFBLFVBQzJELENBQUE7QUFBQSxRQUNuRjtBQUVILHNCQUFBO0FBQ0Esc0JBQUEsS0FBQSxRQUFBLHVCQUFBLEVBQUEsRUFBQSxLQUFBO0FBQUEsTUFBMkQsV0FBQSxLQUFBLE1BQUEsZUFBQSxHQUFBO0FBRTNELFlBQUEsYUFBQTtBQUNFLHNCQUFBLEtBQUE7QUFBQSxZQUFpQixJQUFBLE9BQUEsWUFBQSxTQUFBLENBQUE7QUFBQSxZQUNrQixNQUFBO0FBQUEsWUFDM0IsTUFBQSxZQUFBLEtBQUE7QUFBQSxZQUNpQixNQUFBLGdCQUFBLGlCQUFBLE9BQUEsZ0JBQUEsYUFBQSxPQUFBO0FBQUEsVUFDMkQsQ0FBQTtBQUFBLFFBQ25GO0FBRUgsc0JBQUE7QUFDQSxzQkFBQSxLQUFBLFFBQUEsbUJBQUEsRUFBQSxFQUFBLEtBQUE7QUFBQSxNQUF1RCxXQUFBLEtBQUEsTUFBQSxZQUFBLEdBQUE7QUFFdkQsWUFBQSxhQUFBO0FBQ0Usc0JBQUEsS0FBQTtBQUFBLFlBQWlCLElBQUEsT0FBQSxZQUFBLFNBQUEsQ0FBQTtBQUFBLFlBQ2tCLE1BQUE7QUFBQSxZQUMzQixNQUFBLFlBQUEsS0FBQTtBQUFBLFlBQ2lCLE1BQUEsZ0JBQUEsaUJBQUEsT0FBQSxnQkFBQSxhQUFBLE9BQUE7QUFBQSxVQUMyRCxDQUFBO0FBQUEsUUFDbkY7QUFFSCxzQkFBQTtBQUNBLHNCQUFBLEtBQUEsUUFBQSxnQkFBQSxFQUFBLEVBQUEsS0FBQTtBQUFBLE1BQW9ELE9BQUE7QUFFcEQsdUJBQUEsTUFBQSxLQUFBLEtBQUE7QUFBQSxNQUErQjtBQUFBLElBQ2pDO0FBR0YsUUFBQSxlQUFBLFlBQUEsU0FBQSxHQUFBO0FBQ0Usa0JBQUEsS0FBQTtBQUFBLFFBQWlCLElBQUEsT0FBQSxZQUFBLFNBQUEsQ0FBQTtBQUFBLFFBQ2tCLE1BQUE7QUFBQSxRQUMzQixNQUFBLFlBQUEsS0FBQTtBQUFBLFFBQ2lCLE1BQUEsZ0JBQUEsaUJBQUEsT0FBQSxnQkFBQSxhQUFBLE9BQUE7QUFBQSxNQUMyRCxDQUFBO0FBQUEsSUFDbkY7QUFBQSxFQUNIO0FBR0YsU0FBQTtBQUNGO0FBRUEsU0FBQSxZQUFBLE9BQUE7QUFDRSxNQUFBLE1BQUEsV0FBQSxJQUFBLFFBQUE7QUFDQSxNQUFBLE1BQUEsV0FBQSxJQUFBLFFBQUE7QUFDQSxNQUFBLE1BQUEsV0FBQSxJQUFBLFFBQUE7QUFDQSxTQUFBO0FBQ0Y7QUFFQSxlQUFBLGdCQUFBLFNBQUE7QUFDRSxRQUFBLFFBQUEsUUFBQSxNQUFBLElBQUEsRUFBQSxhQUFBLFNBQUE7QUFDRjtBQUVBLGVBQUEsaUJBQUE7QUFDRSxRQUFBQSxVQUFBLE1BQUEsUUFBQSxRQUFBLE1BQUEsSUFBQSxhQUFBO0FBQ0EsU0FBQUEsUUFBQSxlQUFBO0FBQ0Y7OztBQ3BOQSxJQUFJLGdCQUFnQixNQUFNO0FBQUEsRUFDeEIsWUFBWSxjQUFjO0FBQ3hCLFFBQUksaUJBQWlCLGNBQWM7QUFDakMsV0FBSyxZQUFZO0FBQ2pCLFdBQUssa0JBQWtCLENBQUMsR0FBRyxjQUFjLFNBQVM7QUFDbEQsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxnQkFBZ0I7QUFBQSxJQUN2QixPQUFPO0FBQ0wsWUFBTSxTQUFTLHVCQUF1QixLQUFLLFlBQVk7QUFDdkQsVUFBSSxVQUFVO0FBQ1osY0FBTSxJQUFJLG9CQUFvQixjQUFjLGtCQUFrQjtBQUNoRSxZQUFNLENBQUMsR0FBRyxVQUFVLFVBQVUsUUFBUSxJQUFJO0FBQzFDLHVCQUFpQixjQUFjLFFBQVE7QUFDdkMsdUJBQWlCLGNBQWMsUUFBUTtBQUV2QyxXQUFLLGtCQUFrQixhQUFhLE1BQU0sQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLFFBQVE7QUFDdkUsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxnQkFBZ0I7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFNBQVMsS0FBSztBQUNaLFFBQUksS0FBSztBQUNQLGFBQU87QUFDVCxVQUFNLElBQUksT0FBTyxRQUFRLFdBQVcsSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0FBQ2pHLFdBQU8sQ0FBQyxDQUFDLEtBQUssZ0JBQWdCLEtBQUssQ0FBQyxhQUFhO0FBQy9DLFVBQUksYUFBYTtBQUNmLGVBQU8sS0FBSyxZQUFZLENBQUM7QUFDM0IsVUFBSSxhQUFhO0FBQ2YsZUFBTyxLQUFLLGFBQWEsQ0FBQztBQUM1QixVQUFJLGFBQWE7QUFDZixlQUFPLEtBQUssWUFBWSxDQUFDO0FBQzNCLFVBQUksYUFBYTtBQUNmLGVBQU8sS0FBSyxXQUFXLENBQUM7QUFDMUIsVUFBSSxhQUFhO0FBQ2YsZUFBTyxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQzVCLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFDQSxZQUFZLEtBQUs7QUFDZixXQUFPLElBQUksYUFBYSxXQUFXLEtBQUssZ0JBQWdCLEdBQUc7QUFBQSxFQUM3RDtBQUFBLEVBQ0EsYUFBYSxLQUFLO0FBQ2hCLFdBQU8sSUFBSSxhQUFhLFlBQVksS0FBSyxnQkFBZ0IsR0FBRztBQUFBLEVBQzlEO0FBQUEsRUFDQSxnQkFBZ0IsS0FBSztBQUNuQixRQUFJLENBQUMsS0FBSyxpQkFBaUIsQ0FBQyxLQUFLO0FBQy9CLGFBQU87QUFDVCxVQUFNLHNCQUFzQjtBQUFBLE1BQzFCLEtBQUssc0JBQXNCLEtBQUssYUFBYTtBQUFBLE1BQzdDLEtBQUssc0JBQXNCLEtBQUssY0FBYyxRQUFRLFNBQVMsRUFBRSxDQUFDO0FBQUEsSUFDeEU7QUFDSSxVQUFNLHFCQUFxQixLQUFLLHNCQUFzQixLQUFLLGFBQWE7QUFDeEUsV0FBTyxDQUFDLENBQUMsb0JBQW9CLEtBQUssQ0FBQyxVQUFVLE1BQU0sS0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLLG1CQUFtQixLQUFLLElBQUksUUFBUTtBQUFBLEVBQ2hIO0FBQUEsRUFDQSxZQUFZLEtBQUs7QUFDZixVQUFNLE1BQU0scUVBQXFFO0FBQUEsRUFDbkY7QUFBQSxFQUNBLFdBQVcsS0FBSztBQUNkLFVBQU0sTUFBTSxvRUFBb0U7QUFBQSxFQUNsRjtBQUFBLEVBQ0EsV0FBVyxLQUFLO0FBQ2QsVUFBTSxNQUFNLG9FQUFvRTtBQUFBLEVBQ2xGO0FBQUEsRUFDQSxzQkFBc0IsU0FBUztBQUM3QixVQUFNLFVBQVUsS0FBSyxlQUFlLE9BQU87QUFDM0MsVUFBTSxnQkFBZ0IsUUFBUSxRQUFRLFNBQVMsSUFBSTtBQUNuRCxXQUFPLE9BQU8sSUFBSSxhQUFhLEdBQUc7QUFBQSxFQUNwQztBQUFBLEVBQ0EsZUFBZSxRQUFRO0FBQ3JCLFdBQU8sT0FBTyxRQUFRLHVCQUF1QixNQUFNO0FBQUEsRUFDckQ7QUFDRjtBQUNBLElBQUksZUFBZTtBQUNuQixhQUFhLFlBQVksQ0FBQyxRQUFRLFNBQVMsUUFBUSxPQUFPLEtBQUs7QUFDL0QsSUFBSSxzQkFBc0IsY0FBYyxNQUFNO0FBQUEsRUFDNUMsWUFBWSxjQUFjLFFBQVE7QUFDaEMsVUFBTSwwQkFBMEIsWUFBWSxNQUFNLE1BQU0sRUFBRTtBQUFBLEVBQzVEO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixjQUFjLFVBQVU7QUFDaEQsTUFBSSxDQUFDLGFBQWEsVUFBVSxTQUFTLFFBQVEsS0FBSyxhQUFhO0FBQzdELFVBQU0sSUFBSTtBQUFBLE1BQ1I7QUFBQSxNQUNBLEdBQUcsUUFBUSwwQkFBMEIsYUFBYSxVQUFVLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDNUU7QUFDQTtBQUNBLFNBQVMsaUJBQWlCLGNBQWMsVUFBVTtBQUNoRCxNQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxvQkFBb0IsY0FBYyxnQ0FBZ0M7QUFDOUUsTUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLLFNBQVMsU0FBUyxLQUFLLENBQUMsU0FBUyxXQUFXLElBQUk7QUFDNUUsVUFBTSxJQUFJO0FBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxJQUNOO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0Myw0NCw0NSw0Niw0Nyw0OCw0OSw1MCw1MSw1Miw1Myw1NCw1NSw1Niw1Nyw1OCw1OSw2MCw2MSw2Miw2Myw2NCw2NSw2Niw2Nyw2OCw2OSw3MCw3MSw3Miw3Myw3NCw3NSw3Niw3Nyw3OCw3OSw4MCw4M119
