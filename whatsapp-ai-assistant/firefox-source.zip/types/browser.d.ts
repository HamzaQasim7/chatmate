// Browser WebExtensions API types
declare const browser: typeof chrome;

